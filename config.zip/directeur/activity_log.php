<?php
// directeur/activity_log.php
require_once '../includes/header.php';
checkRole('coordinateur_regional');

$errors = [];
$activities = [];

try {
    $stmt = $pdo->prepare("
        SELECT al.id_log, al.action, al.date_action, al.details, u.nom, u.prenom
        FROM activity_log al
        JOIN utilisateurs u ON al.id_utilisateur = u.id_utilisateur
        JOIN adhesions a ON al.id_utilisateur = a.created_by
        WHERE a.departement = ?
        ORDER BY al.date_action DESC
    ");
    $stmt->execute([$_SESSION['departement']]);
    $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des activités : " . htmlspecialchars($e->getMessage());
    error_log("Erreur dans activity_log.php : " . $e->getMessage());
}
?>

<h2 class="mb-4 text-center"><i class="bi bi-clock-history"></i> Suivi des Activités</h2>

<?php if ($errors): ?>
    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <i class="bi bi-list"></i> Journal des Activités
    </div>
    <div class="card-body">
        <input type="text" id="search_activity" class="form-control mb-3" placeholder="Rechercher une activité..." aria-label="Rechercher">
        <div class="table-responsive">
            <table class="table table-striped table-hover table-activities">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Utilisateur</th>
                        <th>Action</th>
                        <th>Détails</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($activities)): ?>
                        <tr>
                            <td colspan="4" class="text-center">Aucune activité trouvée.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($activities as $activity): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($activity['date_action']); ?></td>
                                <td><?php echo htmlspecialchars($activity['nom'] . ' ' . $activity['prenom']); ?></td>
                                <td><?php echo htmlspecialchars($activity['action']); ?></td>
                                <td><?php echo htmlspecialchars($activity['details'] ?? 'Aucun détail'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <a href="dashboard_coordinateur.php" class="btn btn-secondary mt-3"><i class="bi bi-arrow-left"></i> Retour</a>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script>
document.getElementById('search_activity').addEventListener('input', function(e) {
    const search = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('.table-activities tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(search) ? '' : 'none';
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>