<?php
// directeur/dashboard_coordinateur.php
require_once '../includes/header.php';
checkRole('coordinateur_regional');

$errors = [];
$kpi = [
    'beneficiaires_total' => 0,
    'demandes_total' => 0,
    'demandes_en_attente' => 0,
    'demandes_en_validation' => 0,
    'demandes_approuvees' => 0,
    'demandes_rejetees' => 0,
    'montant_facture' => 0,
    'montant_rembourse' => 0,
    'prestataires_total' => 0,
    'coordinators_total' => 0,
    'recettes_total' => 0,
    'depenses_total' => 0,
    'solde_total' => 0,
    'adhesions_total' => 0
];
$recent_activities = [];

try {
    // KPI: Total bénéficiaires
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT b.id_beneficiaire)
        FROM beneficiaires b
        JOIN adhesions a ON b.id_adhesion = a.id_adhesion
        WHERE a.departement = ? AND a.statut = 'active'
    ");
    $stmt->execute([$_SESSION['departement']]);
    $kpi['beneficiaires_total'] = $stmt->fetchColumn();

    // KPI: Total demandes
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM demande_remboursement dr
        JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
        WHERE a.departement = ?
    ");
    $stmt->execute([$_SESSION['departement']]);
    $kpi['demandes_total'] = $stmt->fetchColumn();

    // KPI: Demandes par statut
    $stmt = $pdo->prepare("
        SELECT statut, COUNT(*)
        FROM demande_remboursement dr
        JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
        WHERE a.departement = ?
        GROUP BY statut
    ");
    $stmt->execute([$_SESSION['departement']]);
    $statut_counts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    $kpi['demandes_en_attente'] = $statut_counts['en_attente'] ?? 0;
    $kpi['demandes_en_validation'] = $statut_counts['en_validation'] ?? 0;
    $kpi['demandes_approuvees'] = $statut_counts['approuve'] ?? 0;
    $kpi['demandes_rejetees'] = $statut_counts['rejete'] ?? 0;

    // KPI: Montant total facturé
    $stmt = $pdo->prepare("
        SELECT SUM(dr.montant_facture)
        FROM demande_remboursement dr
        JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
        WHERE a.departement = ?
    ");
    $stmt->execute([$_SESSION['departement']]);
    $kpi['montant_facture'] = $stmt->fetchColumn() ?: 0;

    // KPI: Montant total remboursé
    $stmt = $pdo->prepare("
        SELECT SUM(dr.montant_rembourse)
        FROM demande_remboursement dr
        JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
        WHERE a.departement = ? AND dr.statut = 'approuve'
    ");
    $stmt->execute([$_SESSION['departement']]);
    $kpi['montant_rembourse'] = $stmt->fetchColumn() ?: 0;

    // KPI: Total prestataires
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM utilisateurs
        WHERE role = 'prestataire_soins' AND departement = ? AND statut = 'actif'
    ");
    $stmt->execute([$_SESSION['departement']]);
    $kpi['prestataires_total'] = $stmt->fetchColumn();

    // KPI: Total coordinateurs
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM utilisateurs
        WHERE role = 'coordinateur_regional' AND departement = ? AND statut = 'actif'
    ");
    $stmt->execute([$_SESSION['departement']]);
    $kpi['coordinators_total'] = $stmt->fetchColumn();

    // KPI: Résumé financier
    $stmt = $pdo->prepare("
        SELECT SUM(recettes) as total_recettes, SUM(depenses) as total_depenses, SUM(solde) as total_solde
        FROM bilans_financiers
        WHERE departement = ?
    ");
    $stmt->execute([$_SESSION['departement']]);
    $bilan = $stmt->fetch(PDO::FETCH_ASSOC);
    $kpi['recettes_total'] = $bilan['total_recettes'] ?? 0;
    $kpi['depenses_total'] = $bilan['total_depenses'] ?? 0;
    $kpi['solde_total'] = $bilan['total_solde'] ?? 0;

    // KPI: Total adhésions actives
    $stmt = $pdo->prepare("
        SELECT COUNT(a.id_adhesion)
        FROM adhesions a
        JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
        WHERE a.statut = 'active' AND u.departement = ?
    ");
    $stmt->execute([$_SESSION['departement']]);
    $kpi['adhesions_total'] = $stmt->fetchColumn();

    // Recent activities
    $stmt = $pdo->prepare("
        SELECT al.id_log, al.action, al.date_action, al.details, u.nom, u.prenom
        FROM activity_log al
        JOIN utilisateurs u ON al.id_utilisateur = u.id_utilisateur
        WHERE u.departement = ?
        ORDER BY al.date_action DESC
        LIMIT 10
    ");
    $stmt->execute([$_SESSION['departement']]);
    $recent_activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des données : " . htmlspecialchars($e->getMessage());
    error_log("Erreur dans dashboard_coordinateur.php : " . $e->getMessage());
}
?>

<h2 class="mb-4 text-center"><i class="bi bi-hospital"></i> Tableau de Bord - Coordinateur Régional</h2>

<?php if ($errors): ?>
    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<!-- KPI Cards -->
<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-person-hearts"></i> Bénéficiaires</h5>
                <p class="card-text display-6"><?php echo htmlspecialchars($kpi['beneficiaires_total']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-list-task"></i> Adhésions Actives</h5>
                <p class="card-text display-6"><?php echo htmlspecialchars($kpi['adhesions_total']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-list-task"></i> Demandes Totales</h5>
                <p class="card-text display-6"><?php echo htmlspecialchars($kpi['demandes_total']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-hourglass-split"></i> Demandes en Attente</h5>
                <p class="card-text display-6"><?php echo htmlspecialchars($kpi['demandes_en_attente']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-check-circle"></i> Demandes en Validation</h5>
                <p class="card-text display-6"><?php echo htmlspecialchars($kpi['demandes_en_validation']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-white bg-success">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-check-circle-fill"></i> Demandes Approuvées</h5>
                <p class="card-text display-6"><?php echo htmlspecialchars($kpi['demandes_approuvees']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-white bg-danger">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-x-circle"></i> Demandes Rejetées</h5>
                <p class="card-text display-6"><?php echo htmlspecialchars($kpi['demandes_rejetees']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-hospital"></i> Prestataires Actifs</h5>
                <p class="card-text display-6"><?php echo htmlspecialchars($kpi['prestataires_total']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-person-gear"></i> Coordinateurs Actifs</h5>
                <p class="card-text display-6"><?php echo htmlspecialchars($kpi['coordinators_total']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-white bg-secondary">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-currency-exchange"></i> Recettes Totales</h5>
                <p class="card-text"><?php echo htmlspecialchars(formatFCFA($kpi['recettes_total'])); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-white bg-secondary">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-currency-exchange"></i> Dépenses Totales</h5>
                <p class="card-text"><?php echo htmlspecialchars(formatFCFA($kpi['depenses_total'])); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-white bg-success">
            <div class="card-body">
                <h5 class="card-title"><i class="bi bi-currency-exchange"></i> Solde Total</h5>
                <p class="card-text"><?php echo htmlspecialchars(formatFCFA($kpi['solde_total'])); ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Actions Rapides -->
<div class="card mb-4">
    <div class="card-header bg-primary text-white">
        <i class="bi bi-rocket-takeoff"></i> Actions Rapides
    </div>
    <div class="card-body">
        <a href="/sante/directeur/list_adherents_beneficiaires.php" class="btn btn-primary me-2"><i class="bi bi-people"></i> Liste Adhérents/Bénéficiaires</a>
        <a href="/sante/directeur/verify_beneficiaire.php" class="btn btn-primary me-2"><i class="bi bi-check-circle"></i> Vérifier Éligibilité</a>
        <a href="/sante/directeur/track_refunds.php" class="btn btn-primary me-2"><i class="bi bi-wallet"></i> Suivi Remboursements</a>
        <a href="/sante/directeur/manage_coordinators.php" class="btn btn-primary me-2"><i class="bi bi-person-gear"></i> Gérer Coordinateurs</a>
        <a href="/sante/directeur/activity_log.php" class="btn btn-primary"><i class="bi bi-clock-history"></i> Journal des Activités</a>
    </div>
</div>

<!-- Recent Activities -->
<div class="card">
    <div class="card-header bg-primary text-white">
        <i class="bi bi-clock-history"></i> Activités Récentes
    </div>
    <div class="card-body">
        <input type="text" id="search_activity" class="form-control mb-3" placeholder="Rechercher une activité..." aria-label="Rechercher">
        <div class="table-responsive">
            <table class="table table-striped table-hover table-activities">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Utilisateur</th>
                        <th>Action</th>
                        <th>Détails</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($recent_activities)): ?>
                        <tr>
                            <td colspan="4" class="text-center">Aucune activité récente trouvée.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($recent_activities as $activity): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($activity['date_action']); ?></td>
                                <td><?php echo htmlspecialchars($activity['nom'] . ' ' . $activity['prenom']); ?></td>
                                <td><?php echo htmlspecialchars($activity['action']); ?></td>
                                <td><?php echo htmlspecialchars($activity['details'] ?? 'Aucun détail'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script>
document.getElementById('search_activity').addEventListener('input', function(e) {
    const search = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('.table-activities tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(search) ? '' : 'none';
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>