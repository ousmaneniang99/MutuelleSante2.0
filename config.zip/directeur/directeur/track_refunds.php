<?php
// directeur/track_refunds.php
require_once '../includes/header.php';
checkRole('coordinateur_regional');

$errors = [];
$demandes_remboursement = [];
$statut_filter = $_GET['statut'] ?? 'all';

try {
    $query = "
        SELECT dr.id_demande, dr.id_adhesion, dr.date_soin, dr.montant_facture, dr.montant_rembourse, dr.statut,
               p.nom AS prestation_nom, b.nom AS beneficiaire_nom, b.prenom AS beneficiaire_prenom, a.num_adherent,
               u.nom AS prestataire_nom, u.prenom AS prestataire_prenom
        FROM demande_remboursement dr
        JOIN prestations p ON dr.id_prestation = p.id_prestation
        JOIN beneficiaires b ON dr.id_adhesion = b.id_adhesion
        JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
        JOIN utilisateurs u ON dr.id_prestataire = u.id_utilisateur
        WHERE a.departement = ?
    ";
    if ($statut_filter !== 'all') {
        $query .= " AND dr.statut = ?";
    }
    $query .= " ORDER BY dr.date_soin DESC";
    $stmt = $pdo->prepare($query);
    $params = [$_SESSION['departement']];
    if ($statut_filter !== 'all') {
        $params[] = $statut_filter;
    }
    $stmt->execute($params);
    $demandes_remboursement = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des données : " . htmlspecialchars($e->getMessage());
    error_log("Erreur dans track_refunds.php : " . $e->getMessage());
}
?>

<h2 class="mb-4 text-center"><i class="bi bi-wallet"></i> Suivi des Remboursements</h2>

<?php if ($errors): ?>
    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <i class="bi bi-list"></i> Liste des Demandes de Remboursement
    </div>
    <div class="card-body">
        <div class="mb-3">
            <label for="statut_filter" class="form-label">Filtrer par statut :</label>
            <select id="statut_filter" class="form-control w-auto d-inline-block" onchange="window.location.href='track_refunds.php?statut='+this.value;">
                <option value="all" <?php echo $statut_filter === 'all' ? 'selected' : ''; ?>>Tous</option>
                <option value="en_attente" <?php echo $statut_filter === 'en_attente' ? 'selected' : ''; ?>>En attente</option>
                <option value="en_validation" <?php echo $statut_filter === 'en_validation' ? 'selected' : ''; ?>>En validation</option>
                <option value="approuve" <?php echo $statut_filter === 'approuve' ? 'selected' : ''; ?>>Approuvé</option>
                <option value="rejete" <?php echo $statut_filter === 'rejete' ? 'selected' : ''; ?>>Rejeté</option>
            </select>
        </div>
        <input type="text" id="search_demande" class="form-control mb-3" placeholder="Rechercher une demande..." aria-label="Rechercher">
        <div class="table-responsive">
            <table class="table table-striped table-hover table-demandes">
                <thead>
                    <tr>
                        <th>Numéro Adhésion</th>
                        <th>Bénéficiaire</th>
                        <th>Prestataire</th>
                        <th>Prestation</th>
                        <th>Date de Soin</th>
                        <th>Montant Facturé</th>
                        <th>Montant Remboursé</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($demandes_remboursement)): ?>
                        <tr>
                            <td colspan="9" class="text-center">Aucune demande trouvée.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($demandes_remboursement as $demande): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($demande['num_adherent']); ?></td>
                                <td><?php echo htmlspecialchars($demande['beneficiaire_nom'] . ' ' . $demande['beneficiaire_prenom']); ?></td>
                                <td><?php echo htmlspecialchars($demande['prestataire_nom'] . ' ' . $demande['prestataire_prenom']); ?></td>
                                <td><?php echo htmlspecialchars($demande['prestation_nom']); ?></td>
                                <td><?php echo htmlspecialchars($demande['date_soin']); ?></td>
                                <td><?php echo htmlspecialchars(formatFCFA($demande['montant_facture'])); ?></td>
                                <td><?php echo htmlspecialchars(formatFCFA($demande['montant_rembourse'] ?: 0)); ?></td>
                                <td><?php echo htmlspecialchars($demande['statut']); ?></td>
                                <td>
                                    <a href="view_invoice.php?id=<?php echo htmlspecialchars($demande['id_demande']); ?>" class="btn btn-sm btn-info"><i class="bi bi-receipt"></i> Facture</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <a href="dashboard_coordinateur.php" class="btn btn-secondary mt-3"><i class="bi bi-arrow-left"></i> Retour</a>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script>
document.getElementById('search_demande').addEventListener('input', function(e) {
    const search = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('.table-demandes tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(search) ? '' : 'none';
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>