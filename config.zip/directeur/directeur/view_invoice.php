<?php
// directeur/view_invoice.php
require_once '../includes/header.php';
checkRole('coordinateur_regional');

$errors = [];
$demande = null;

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $errors[] = "ID de la demande non valide.";
} else {
    $id_demande = intval($_GET['id']);
    try {
        $stmt = $pdo->prepare("
            SELECT dr.id_demande, dr.id_adhesion, dr.date_soin, dr.montant_facture, dr.montant_rembourse, dr.pieces_jointes, dr.commentaire,
                   p.nom AS prestation_nom, p.taux_remboursement, b.nom AS beneficiaire_nom, b.prenom AS beneficiaire_prenom,
                   a.num_adherent, u.nom AS adherent_nom, u.prenom AS adherent_prenom, u2.nom AS prestataire_nom, u2.prenom AS prestataire_prenom
            FROM demande_remboursement dr
            JOIN prestations p ON dr.id_prestation = p.id_prestation
            JOIN beneficiaires b ON dr.id_adhesion = b.id_adhesion
            JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
            JOIN utilisateurs u2 ON dr.id_prestataire = u2.id_utilisateur
            WHERE dr.id_demande = ? AND a.departement = ?
        ");
        $stmt->execute([$id_demande, $_SESSION['departement']]);
        $demande = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$demande) {
            $errors[] = "Demande non trouvée ou accès non autorisé.";
        }
    } catch (PDOException $e) {
        $errors[] = "Erreur lors de la récupération des données : " . htmlspecialchars($e->getMessage());
        error_log("Erreur dans view_invoice.php : " . $e->getMessage());
    }
}
?>

<h2 class="mb-4 text-center"><i class="bi bi-receipt"></i> Consultation de Facture</h2>

<?php if ($errors): ?>
    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
<?php elseif ($demande): ?>
    <div class="card">
        <div class="card-header bg-primary text-white">
            <i class="bi bi-receipt"></i> Détails de la Facture
        </div>
        <div class="card-body">
            <h5>Demande #<?php echo htmlspecialchars($demande['id_demande']); ?></h5>
            <p><strong>Adhérent :</strong> <?php echo htmlspecialchars($demande['adherent_nom'] . ' ' . $demande['adherent_prenom']); ?></p>
            <p><strong>Numéro Adhésion :</strong> <?php echo htmlspecialchars($demande['num_adherent']); ?></p>
            <p><strong>Bénéficiaire :</strong> <?php echo htmlspecialchars($demande['beneficiaire_nom'] . ' ' . $demande['beneficiaire_prenom']); ?></p>
            <p><strong>Prestataire :</strong> <?php echo htmlspecialchars($demande['prestataire_nom'] . ' ' . $demande['prestataire_prenom']); ?></p>
            <p><strong>Prestation :</strong> <?php echo htmlspecialchars($demande['prestation_nom']); ?></p>
            <p><strong>Date du Soin :</strong> <?php echo htmlspecialchars($demande['date_soin']); ?></p>
            <p><strong>Montant Facturé :</strong> <?php echo htmlspecialchars(formatFCFA($demande['montant_facture'])); ?></p>
            <p><strong>Taux de Remboursement :</strong> <?php echo htmlspecialchars($demande['taux_remboursement']); ?>%</p>
            <p><strong>Montant Remboursé :</strong> <?php echo htmlspecialchars(formatFCFA($demande['montant_rembourse'] ?: 0)); ?></p>
            <p><strong>Commentaire :</strong> <?php echo htmlspecialchars($demande['commentaire'] ?? 'Aucun'); ?></p>
            <?php if ($demande['pieces_jointes']): ?>
                <p><strong>Pièces Jointes :</strong> <a href="<?php echo htmlspecialchars($demande['pieces_jointes']); ?>" target="_blank" class="btn btn-sm btn-info"><i class="bi bi-file-earmark"></i> Voir</a></p>
            <?php endif; ?>
            <a href="track_refunds.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Retour</a>
        </div>
    </div>
<?php endif; ?>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<?php require_once '../includes/footer.php'; ?>