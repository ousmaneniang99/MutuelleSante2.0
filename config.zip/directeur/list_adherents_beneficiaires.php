<?php
// directeur/list_adherents_beneficiaires.php
require_once '../includes/header.php';
checkRole('coordinateur_regional');

$errors = [];
$adherents_beneficiaires = [];

try {
    $stmt = $pdo->prepare("
        SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom, a.statut AS adhesion_statut, a.departement,
               'Adhérent' AS type
        FROM adhesions a
        JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
        WHERE a.departement = ? AND a.statut = 'active'
        UNION
        SELECT b.id_adhesion, b.code_beneficiaire AS num_adherent, b.nom, b.prenom, b.statut AS adhesion_statut, a.departement,
               'Bénéficiaire' AS type
        FROM beneficiaires b
        JOIN adhesions a ON b.id_adhesion = a.id_adhesion
        WHERE a.departement = ? AND b.statut = 'actif' AND (b.date_sortie IS NULL OR b.date_sortie > NOW())
        ORDER BY nom, prenom
    ");
    $stmt->execute([$_SESSION['departement'], $_SESSION['departement']]);
    $adherents_beneficiaires = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des données : " . htmlspecialchars($e->getMessage());
    error_log("Erreur dans list_adherents_beneficiaires.php : " . $e->getMessage());
}
?>

<h2 class="mb-4 text-center"><i class="bi bi-people"></i> Liste des Adhérents et Bénéficiaires</h2>

<?php if ($errors): ?>
    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <i class="bi bi-list"></i> Adhérents et Bénéficiaires du Département
    </div>
    <div class="card-body">
        <input type="text" id="search_person" class="form-control mb-3" placeholder="Rechercher un adhérent/bénéficiaire..." aria-label="Rechercher">
        <div class="table-responsive">
            <table class="table table-striped table-hover table-persons">
                <thead>
                    <tr>
                        <th>Numéro</th>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Type</th>
                        <th>Statut</th>
                        <th>Département</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($adherents_beneficiaires)): ?>
                        <tr>
                            <td colspan="6" class="text-center">Aucun adhérent ou bénéficiaire trouvé.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($adherents_beneficiaires as $person): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($person['num_adherent']); ?></td>
                                <td><?php echo htmlspecialchars($person['nom']); ?></td>
                                <td><?php echo htmlspecialchars($person['prenom']); ?></td>
                                <td><?php echo htmlspecialchars($person['type']); ?></td>
                                <td><?php echo htmlspecialchars($person['adhesion_statut']); ?></td>
                                <td><?php echo htmlspecialchars($person['departement']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <a href="dashboard_coordinateur.php" class="btn btn-secondary mt-3"><i class="bi bi-arrow-left"></i> Retour</a>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script>
document.getElementById('search_person').addEventListener('input', function(e) {
    const search = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('.table-persons tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(search) ? '' : 'none';
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>