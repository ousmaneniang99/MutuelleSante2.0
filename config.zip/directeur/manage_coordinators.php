<?php
// directeur/manage_coordinators.php
require_once '../includes/header.php';
checkRole('coordinateur_regional');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();
$coordinators = [];

try {
    // Fetch coordinators
    $stmt = $pdo->prepare("
        SELECT id_utilisateur, nom, prenom, email, statut
        FROM utilisateurs
        WHERE role = 'coordinateur_regional' AND departement = ? AND id_utilisateur != ?
    ");
    $stmt->execute([$_SESSION['departement'], $_SESSION['user_id']]);
    $coordinators = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
            $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
        } else {
            $action = $_POST['action'] ?? '';
            if ($action === 'add') {
                $nom = trim($_POST['nom'] ?? '');
                $prenom = trim($_POST['prenom'] ?? '');
                $email = trim($_POST['email'] ?? '');
                $password = $_POST['password'] ?? '';

                if (empty($nom) || empty($prenom) || empty($email) || empty($password)) {
                    $errors[] = "Tous les champs sont requis.";
                } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $errors[] = "Email invalide.";
                } elseif (strlen($password) < 8) {
                    $errors[] = "Le mot de passe doit contenir au moins 8 caractères.";
                } else {
                    // Check if email exists
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE email = ?");
                    $stmt->execute([$email]);
                    if ($stmt->fetchColumn() > 0) {
                        $errors[] = "Cet email est déjà utilisé.";
                    } else {
                        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                        $stmt = $pdo->prepare("
                            INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role, departement, statut)
                            VALUES (?, ?, ?, ?, 'coordinateur_regional', ?, 'actif')
                        ");
                        $stmt->execute([$nom, $prenom, $email, $hashed_password, $_SESSION['departement']]);
                        logActivity($pdo, $_SESSION['user_id'], "Ajout d'un coordinateur régional : $email");
                        $success = "Coordinateur ajouté avec succès.";
                        // Refresh coordinators
                        $stmt = $pdo->prepare("
                            SELECT id_utilisateur, nom, prenom, email, statut
                            FROM utilisateurs
                            WHERE role = 'coordinateur_regional' AND departement = ? AND id_utilisateur != ?
                        ");
                        $stmt->execute([$_SESSION['departement'], $_SESSION['user_id']]);
                        $coordinators = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    }
                }
            } elseif ($action === 'delete') {
                $id_utilisateur = intval($_POST['id_utilisateur'] ?? 0);
                if ($id_utilisateur <= 0) {
                    $errors[] = "ID utilisateur invalide.";
                } else {
                    $stmt = $pdo->prepare("UPDATE utilisateurs SET statut = 'inactif' WHERE id_utilisateur = ? AND role = 'coordinateur_regional' AND departement = ?");
                    $stmt->execute([$id_utilisateur, $_SESSION['departement']]);
                    if ($stmt->rowCount() > 0) {
                        logActivity($pdo, $_SESSION['user_id'], "Suppression d'un coordinateur régional ID $id_utilisateur");
                        $success = "Coordinateur supprimé avec succès.";
                        // Refresh coordinators
                        $stmt = $pdo->prepare("
                            SELECT id_utilisateur, nom, prenom, email, statut
                            FROM utilisateurs
                            WHERE role = 'coordinateur_regional' AND departement = ? AND id_utilisateur != ?
                        ");
                        $stmt->execute([$_SESSION['departement'], $_SESSION['user_id']]);
                        $coordinators = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    } else {
                        $errors[] = "Coordinateur non trouvé ou accès non autorisé.";
                    }
                }
            }
        }
    }
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la gestion des coordinateurs : " . htmlspecialchars($e->getMessage());
    error_log("Erreur dans manage_coordinators.php : " . $e->getMessage());
}
?>

<h2 class="mb-4 text-center"><i class="bi bi-person-gear"></i> Gestion des Coordinateurs Régionaux</h2>

<?php if ($errors): ?>
    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($success); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<!-- Add Coordinator Form -->
<div class="card mb-4">
    <div class="card-header bg-primary text-white">
        <i class="bi bi-person-plus"></i> Ajouter un Coordinateur
    </div>
    <div class="card-body">
        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            <input type="hidden" name="action" value="add">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="nom" class="form-label">Nom <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="nom" name="nom" value="<?php echo htmlspecialchars($_POST['nom'] ?? ''); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="prenom" class="form-label">Prénom <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="prenom" name="prenom" value="<?php echo htmlspecialchars($_POST['prenom'] ?? ''); ?>" required>
                </div>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Mot de passe <span class="text-danger">*</span></label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Ajouter</button>
            <a href="dashboard_coordinateur.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Retour</a>
        </form>
    </div>
</div>

<!-- Coordinators List -->
<div class="card">
    <div class="card-header bg-primary text-white">
        <i class="bi bi-person-lines-fill"></i> Liste des Coordinateurs
    </div>
    <div class="card-body">
        <input type="text" id="search_coordinator" class="form-control mb-3" placeholder="Rechercher un coordinateur..." aria-label="Rechercher">
        <div class="table-responsive">
            <table class="table table-striped table-hover table-coordinators">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Email</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($coordinators)): ?>
                        <tr>
                            <td colspan="5" class="text-center">Aucun coordinateur trouvé.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($coordinators as $coordinator): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($coordinator['nom']); ?></td>
                                <td><?php echo htmlspecialchars($coordinator['prenom']); ?></td>
                                <td><?php echo htmlspecialchars($coordinator['email']); ?></td>
                                <td><?php echo htmlspecialchars($coordinator['statut']); ?></td>
                                <td>
                                    <form method="POST" action="" class="d-inline">
                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id_utilisateur" value="<?php echo htmlspecialchars($coordinator['id_utilisateur']); ?>">
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Voulez-vous vraiment supprimer ce coordinateur ?');"><i class="bi bi-trash"></i> Supprimer</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script>
document.getElementById('search_coordinator').addEventListener('input', function(e) {
    const search = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('.table-coordinators tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(search) ? '' : 'none';
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>