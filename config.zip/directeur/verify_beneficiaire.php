<?php
// directeur/verify_beneficiaire.php
require_once '../includes/header.php';
checkRole('coordinateur_regional');

$errors = [];
$result = null;
$csrf_token = generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
    } else {
        $identifier = trim($_POST['identifier'] ?? '');
        if (empty($identifier)) {
            $errors[] = "Veuillez entrer un code bénéficiaire ou un numéro de carte d'identité.";
        } else {
            try {
                $stmt = $pdo->prepare("
                    SELECT b.id_beneficiaire, b.nom, b.prenom, b.code_beneficiaire, b.statut, b.date_sortie,
                           a.id_adhesion, a.num_adherent, a.departement, a.statut AS adhesion_statut,
                           u.numero_carte_identite
                    FROM beneficiaires b
                    JOIN adhesions a ON b.id_adhesion = a.id_adhesion
                    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                    WHERE (b.code_beneficiaire = ? OR u.numero_carte_identite = ?) AND a.departement = ?
                ");
                $stmt->execute([$identifier, $identifier, $_SESSION['departement']]);
                $beneficiaire = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$beneficiaire) {
                    $errors[] = "Bénéficiaire non trouvé dans votre département.";
                } else {
                    if ($beneficiaire['adhesion_statut'] !== 'active') {
                        $errors[] = "L'adhésion associée n'est pas active.";
                    } elseif ($beneficiaire['statut'] !== 'actif' || ($beneficiaire['date_sortie'] && $beneficiaire['date_sortie'] < date('Y-m-d'))) {
                        $errors[] = "La carte du bénéficiaire n'est pas valide.";
                    } else {
                        $stmt = $pdo->prepare("
                            SELECT COUNT(*) 
                            FROM paiements p
                            WHERE p.id_adhesion = ? AND p.statut = 'paye' 
                            AND p.date_paiement >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                        ");
                        $stmt->execute([$beneficiaire['id_adhesion']]);
                        $has_valid_payment = $stmt->fetchColumn();

                        if (!$has_valid_payment) {
                            $errors[] = "La cotisation n'est pas à jour.";
                        } else {
                            $result = [
                                'nom' => $beneficiaire['nom'],
                                'prenom' => $beneficiaire['prenom'],
                                'code_beneficiaire' => $beneficiaire['code_beneficiaire'],
                                'num_adherent' => $beneficiaire['num_adherent'],
                                'statut' => 'Éligible',
                                'message' => 'Le bénéficiaire est éligible pour les soins.'
                            ];
                            logActivity($pdo, $_SESSION['user_id'], "Vérification d'éligibilité réussie pour le bénéficiaire {$beneficiaire['code_beneficiaire']}");
                        }
                    }
                }
            } catch (PDOException $e) {
                $errors[] = "Erreur lors de la vérification : " . htmlspecialchars($e->getMessage());
                error_log("Erreur dans verify_beneficiaire.php : " . $e->getMessage());
            }
        }
    }
}
?>

<h2 class="mb-4 text-center"><i class="bi bi-check-circle"></i> Vérification d'Éligibilité</h2>

<?php if ($errors): ?>
    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php if ($result): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($result['message']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <div class="card">
        <div class="card-header bg-success text-white">
            <i class="bi bi-person-check"></i> Résultat de la Vérification
        </div>
        <div class="card-body">
            <p><strong>Nom :</strong> <?php echo htmlspecialchars($result['nom']); ?></p>
            <p><strong>Prénom :</strong> <?php echo htmlspecialchars($result['prenom']); ?></p>
            <p><strong>Code Bénéficiaire :</strong> <?php echo htmlspecialchars($result['code_beneficiaire']); ?></p>
            <p><strong>Numéro Adhésion :</strong> <?php echo htmlspecialchars($result['num_adherent']); ?></p>
            <p><strong>Statut :</strong> <?php echo htmlspecialchars($result['statut']); ?></p>
        </div>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <i class="bi bi-search"></i> Vérifier un Bénéficiaire
    </div>
    <div class="card-body">
        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            <div class="mb-3">
                <label for="identifier" class="form-label">Code Bénéficiaire ou Numéro de Carte d'Identité <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="identifier" name="identifier" value="<?php echo htmlspecialchars($_POST['identifier'] ?? ''); ?>" required>
            </div>
            <button type="submit" name="verify" class="btn btn-primary"><i class="bi bi-check"></i> Vérifier</button>
            <a href="dashboard_coordinateur.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Retour</a>
        </form>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<?php require_once '../includes/footer.php'; ?>