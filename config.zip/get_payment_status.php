<?php
// get_payment_status.php
require_once '../includes/database.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $id_adhesion = isset($data['id_adhesion']) ? intval($data['id_adhesion']) : 0;

    if ($id_adhesion <= 0) {
        echo json_encode(['error' => 'Adhésion non spécifiée']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("SELECT SUM(montant_verse) as total_paye FROM paiements WHERE id_adhesion = ? AND statut = 'paye'");
        $stmt->execute([$id_adhesion]);
        $total_paye = $stmt->fetchColumn() ?: 0;
        echo json_encode(['total_paye' => $total_paye]);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Erreur de base de données']);
    }
} else {
    echo json_encode(['error' => 'Méthode non autorisée']);
}
?>