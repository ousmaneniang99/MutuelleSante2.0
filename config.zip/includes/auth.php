<?php
// includes/auth.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Vérifier si l'utilisateur est connecté
function checkAuth() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || !isset($_SESSION['departement'])) {
        header('Location: ../pages/login.php?error=not_authenticated');
        exit();
    }
}

// Vérifier le timeout de session (30 minutes)
function checkSessionTimeout() {
    $timeout_duration = 1800; // 30 minutes en secondes
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout_duration)) {
        session_unset();
        session_destroy();
        header('Location: ../pages/login.php?error=session_expired');
        exit();
    }
    $_SESSION['last_activity'] = time();
}

// Générer un jeton CSRF
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Vérifier le jeton CSRF
function verifyCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
?>