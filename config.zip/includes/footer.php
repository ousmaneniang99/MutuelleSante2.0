<?php
// includes/footer.php

// Fermeture du main container si ouvert dans header
if (!ob_get_level()) {
    ob_start();
}

// Ajout de métadonnées de debug si en mode développement
if (defined('DEBUG') && DEBUG) {
    $debug_info = [
        'Page' => basename($_SERVER['PHP_SELF']),
        'Rôle' => $_SESSION['role'] ?? 'Non connecté',
        'Mémoire' => round(memory_get_peak_usage(true) / 1024 / 1024, 2) . ' MB',
        'Temps' => round((microtime(true) - $_SERVER['REQUEST_TIME_FLOAT']) * 1000, 2) . ' ms'
    ];
}
?>

    <!-- Fermeture du container principal -->
    </main>

    <!-- FOOTER PRINCIPAL -->
    <footer class="footer bg-white border-top shadow-sm mt-auto">
        <div class="container-fluid px-4">
            <div class="row align-items-center py-3">
                <!-- COLONNE GAUCHE - BRANDING -->
                <div class="col-md-6 col-12 mb-2 mb-md-0">
                    <div class="d-flex align-items-center gap-2">
                        <!-- Logo miniature -->
                        <img src="Uploads/photos/logo1.png" 
                             alt="Mutuelle Santé Matam" 
                             class="footer-logo"
                             width="28" height="28"
                             onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjgiIGhlaWdodD0iMjgiIHZpZXdCb3g9IjAgMCAyOCAyOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTQiIGN5PSIxNCIgcj0iMTQiIGZpbGw9IiMwMDdiZmYiLz4KPHRleHQgeD0iMTQiIHk9IjE3IiBmb250LWZhbWlseT0iSW50ZXIiIGZvbnQtc2l6ZT0iNyIgZmlsbD0id2hpdGUiIHRleHQtYW5jaG9yPSJtaWRkbGxlIj5NU008L3RleHQ+Cjwvc3ZnPgo='">
                        
                        <!-- Texte -->
                        <div>
                            <h6 class="mb-0 fw-semibold text-primary">Mutuelle Santé Matam</h6>
                            <small class="text-muted d-block">
                                © <?php echo date('Y'); ?> - Système de gestion
                            </small>
                        </div>
                    </div>
                </div>

                <!-- COLONNE DROITE - INFOS & LIENS -->
                <div class="col-md-6 col-12 text-md-end text-start">
                    <div class="d-flex flex-wrap justify-content-center justify-content-md-end gap-3 gap-md-4">
                        <!-- Version -->
                        <small class="text-muted">
                            <i class="bi bi-tag me-1"></i>
                            v<?php echo defined('APP_VERSION') ? APP_VERSION : '1.0'; ?>
                        </small>

                        <!-- Support -->
                        <?php if (isset($_SESSION['role'])): ?>
                            <a href="support.php" class="btn btn-sm btn-outline-primary" title="Support technique">
                                <i class="bi bi-headset"></i>
                            </a>
                        <?php endif; ?>

                        <!-- Stats rapides -->
                        <div class="d-none d-md-flex align-items-center gap-2 text-muted small">
                            <i class="bi bi-clock-history"></i>
                            <span id="uptime"></span>
                        </div>

                        <!-- Mode debug -->
                        <?php if (defined('DEBUG') && DEBUG): ?>
                            <div class="debug-info badge bg-dark text-warning small d-none d-md-inline-block">
                                <i class="bi bi-bug me-1"></i>Debug
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- BARRE INFÉRIEURE -->
            <div class="footer-bottom bg-light border-top px-3 py-2">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <small class="text-muted">
                            <i class="bi bi-shield-check me-1"></i>
                            Sécurisé • Données confidentielles • Conformité RGPD
                        </small>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <small class="text-muted">
                            Développé avec <i class="bi bi-heart-fill text-danger"></i> par MSMA Team
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- MODALES GLOBALES -->
    <!-- Modal de confirmation générique -->
    <div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="bi bi-exclamation-triangle me-2"></i>Confirmation</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p id="confirmMessage"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="button" class="btn btn-danger" id="confirmBtn">Confirmer</button>
                </div>
            </div>
        </div>
    </div>

    <!-- TOAST NOTIFICATIONS -->
    <div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 1090">
        <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <i class="bi bi-info-circle-fill text-primary me-2"></i>
                <strong class="me-auto">Notification</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body" id="toastBody"></div>
        </div>
    </div>

    <!-- LIBRAIRIES JAVASCRIPT -->
    <!-- Bootstrap JS (version 5.3.3 pour cohérence avec header) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" 
            crossorigin="anonymous"></script>

    <!-- SweetAlert2 pour notifications élégantes (optionnel) -->
    <?php if (defined('USE_SWEETALERT') && USE_SWEETALERT): ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php endif; ?>

    <!-- SCRIPTS GLOBAUX -->
    <script>
        // Configuration globale
        window.MSMA = {
            debug: <?php echo (defined('DEBUG') && DEBUG) ? 'true' : 'false'; ?>,
            csrf_token: '<?php echo isset($_SESSION['csrf_token']) ? $_SESSION['csrf_token'] : ''; ?>',
            user_role: '<?php echo $_SESSION['role'] ?? ''; ?>'
        };

        document.addEventListener('DOMContentLoaded', function() {
            // Uptime du serveur
            const uptimeEl = document.getElementById('uptime');
            if (uptimeEl) {
                const now = new Date();
                const uptime = now.toLocaleTimeString('fr-FR', { 
                    hour: '2-digit', 
                    minute: '2-digit', 
                    second: '2-digit' 
                });
                uptimeEl.textContent = uptime;
                
                // Mise à jour chaque seconde
                setInterval(() => {
                    const newTime = new Date().toLocaleTimeString('fr-FR', {
                        hour: '2-digit', minute: '2-digit', second: '2-digit'
                    });
                    uptimeEl.textContent = newTime;
                }, 1000);
            }

            // Fonction de confirmation modale
            window.showConfirm = function(message, callback) {
                const modal = new bootstrap.Modal(document.getElementById('confirmModal'));
                document.getElementById('confirmMessage').textContent = message;
                document.getElementById('confirmBtn').onclick = function() {
                    modal.hide();
                    if (callback && typeof callback === 'function') {
                        callback();
                    }
                };
                modal.show();
            };

            // Toast notification générique
            window.showToast = function(message, type = 'info') {
                const toastEl = document.getElementById('liveToast');
                const toastBody = document.getElementById('toastBody');
                const icons = {
                    success: 'bi-check-circle-fill text-success',
                    error: 'bi-exclamation-triangle-fill text-danger',
                    warning: 'bi-exclamation-circle-fill text-warning',
                    info: 'bi-info-circle-fill text-primary'
                };
                
                toastBody.innerHTML = `<i class="${icons[type] || icons.info} me-2"></i>${message}`;
                toastEl.className = `toast ${type === 'error' ? 'border-danger' : ''}`;
                
                const toast = new bootstrap.Toast(toastEl);
                toast.show();
            };

            // CSRF protection pour formulaires AJAX
            window.addCsrfToken = function(formData) {
                if (window.MSMA.csrf_token) {
                    formData.append('csrf_token', window.MSMA.csrf_token);
                }
                return formData;
            };

            // Gestion des erreurs globales
            window.addEventListener('error', function(e) {
                if (window.MSMA.debug) {
                    console.error('Erreur JavaScript:', e.error);
                }
                // Optionnel : envoyer à un endpoint d'erreur
            });

            <?php if (defined('DEBUG') && DEBUG): ?>
                // Debug panel
                console.log('MSMA Debug Info:', {
                    page: '<?php echo basename($_SERVER['PHP_SELF']); ?>',
                    role: '<?php echo $_SESSION['role'] ?? 'guest'; ?>',
                    session: <?php echo json_encode(array_keys($_SESSION ?? [])); ?>
                });

                // Performance metrics
                if (performance) {
                    const navTiming = performance.getEntriesByType('navigation')[0];
                    console.log('Temps de chargement:', navTiming.loadEventEnd - navTiming.fetchStart, 'ms');
                }
            <?php endif; ?>

            // Traitement des messages PHP flash
            <?php if (isset($_SESSION['flash_message'])): ?>
                window.showToast('<?php echo addslashes($_SESSION['flash_message']); ?>', 'success');
                <?php unset($_SESSION['flash_message']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['flash_error'])): ?>
                window.showToast('<?php echo addslashes($_SESSION['flash_error']); ?>', 'error');
                <?php unset($_SESSION['flash_error']); ?>
            <?php endif; ?>
        });
    </script>

    <?php 
    // Debug info en bas de page (mode dev seulement)
    if (defined('DEBUG') && DEBUG && isset($debug_info)): 
        ob_start(); 
    ?>
    <!-- DEBUG PANEL -->
    <div class="debug-panel position-fixed bottom-0 start-0 bg-dark text-white p-2 small d-none d-md-block" 
         style="z-index: 9999; font-size: 0.7rem; max-width: 300px;">
        <div class="d-flex justify-content-between align-items-center mb-1">
            <strong>Debug</strong>
            <button class="btn-close btn-close-white btn-sm" onclick="this.parentElement.parentElement.style.display='none'"></button>
        </div>
        <?php foreach ($debug_info as $key => $value): ?>
            <div class="d-flex justify-content-between">
                <span class="text-muted"><?php echo htmlspecialchars($key); ?>:</span>
                <span><?php echo htmlspecialchars($value); ?></span>
            </div>
        <?php endforeach; ?>
    </div>
    <?php 
        $debug_html = ob_get_clean();
        echo $debug_html;
    endif; 
    ?>

</body>
</html>

<?php
// Nettoyage final
if (ob_get_level()) {
    ob_end_flush();
}

// Logs de fin de requête si debug
if (defined('DEBUG') && DEBUG) {
    error_log("Page terminée: " . basename($_SERVER['PHP_SELF']) . " - " . 
              round((microtime(true) - $_SERVER['REQUEST_TIME_FLOAT']) * 1000, 2) . "ms");
}
?>