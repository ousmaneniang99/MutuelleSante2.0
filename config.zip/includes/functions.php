<?php
// includes/functions.php

// Inclure la connexion à la base de données avec un chemin robuste
require_once __DIR__ . '/../config/database.php';

// Fonction pour vérifier le rôle de l'utilisateur, l'authentification, le timeout et le département
function checkRole($required_role, $pdo = null, $check_departement = false) {
    global $pdo; // Utiliser la variable globale $pdo si non fournie

    // Vérifier que $pdo est disponible
    if ($pdo === null && !isset($GLOBALS['pdo'])) {
        error_log("Erreur : Connexion PDO non disponible dans checkRole.");
        header("Location: /sante/pages/login.php?error=database_error");
        exit();
    }
    if ($pdo === null) {
        $pdo = $GLOBALS['pdo'];
    }

    // Vérifier si l'utilisateur est connecté
    if (!isLoggedIn() || !isset($_SESSION['role']) || ($check_departement && !isset($_SESSION['departement']))) {
        error_log("Échec de checkRole : utilisateur non connecté ou session incomplète (user_id: " . ($_SESSION['user_id'] ?? 'non défini') . ", role: " . ($_SESSION['role'] ?? 'non défini') . ", departement: " . ($_SESSION['departement'] ?? 'non défini') . ")");
        header("Location: /sante/pages/login.php?error=not_authenticated");
        exit();
    }

    // Vérifier le timeout de session
    $timeout_duration = 1800; // 30 minutes
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout_duration)) {
        logActivity($pdo, $_SESSION['user_id'] ?? null, 'logout', "Session expirée pour l'utilisateur ID: {$_SESSION['user_id']}");
        session_unset();
        session_destroy();
        header("Location: /sante/pages/login.php?error=session_expired");
        exit();
    }
    $_SESSION['last_activity'] = time();

    // Vérifier le rôle et le statut dans la base de données
    try {
        $stmt = $pdo->prepare("SELECT role, statut, departement FROM utilisateurs WHERE id_utilisateur = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user) {
            error_log("Échec de checkRole : utilisateur ID {$_SESSION['user_id']} non trouvé dans la base de données.");
            session_unset();
            session_destroy();
            header("Location: /sante/pages/login.php?error=invalid_user");
            exit();
        }
        if ($user['statut'] !== 'actif') {
            error_log("Échec de checkRole : utilisateur ID {$_SESSION['user_id']} a un statut {$user['statut']} (non actif).");
            session_unset();
            session_destroy();
            header("Location: /sante/pages/login.php?error=inactive_user");
            exit();
        }
        if ($user['role'] !== $required_role) {
            error_log("Échec de checkRole : rôle incorrect pour l'utilisateur ID {$_SESSION['user_id']}, rôle requis = $required_role, rôle actuel = {$user['role']}");
            logActivity($pdo, $_SESSION['user_id'], 'access_denied', "Tentative d'accès non autorisé à la page pour le rôle $required_role par l'utilisateur ID: {$_SESSION['user_id']}");
            header("Location: /sante/pages/unauthorized.php");
            exit();
        }
        $_SESSION['role'] = $user['role'];
        $_SESSION['departement'] = $user['departement'];

        // Vérifier le département si requis
        if ($check_departement) {
            $stmt = $pdo->prepare("SELECT id_departement FROM departements WHERE nom_departement = ?");
            $stmt->execute([$_SESSION['departement']]);
            if (!$stmt->fetch()) {
                error_log("Échec de checkRole : département non valide pour l'utilisateur ID {$_SESSION['user_id']}, département = {$_SESSION['departement']}");
                logActivity($pdo, $_SESSION['user_id'], 'access_denied', "Département non valide: {$_SESSION['departement']}");
                session_unset();
                session_destroy();
                header("Location: /sante/pages/login.php?error=invalid_department");
                exit();
            }
        }
    } catch (PDOException $e) {
        error_log("Erreur PDO dans checkRole : " . $e->getMessage());
        logActivity($pdo, $_SESSION['user_id'] ?? null, 'error', "Erreur PDO lors de la vérification du rôle : " . $e->getMessage());
        session_destroy();
        header("Location: /sante/pages/login.php?error=database_error");
        exit();
    }
}

// Fonction pour vérifier si l'utilisateur est connecté
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Fonction pour nettoyer les données d'entrée
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Fonction pour formater les montants en FCFA
function formatFCFA($montant) {
    // Si null, vide ou non numérique → 0
    $montant = is_numeric($montant) ? floatval($montant) : 0;
    return number_format($montant, 0, ',', ' ') . ' FCFA';
}

// Fonction pour définir un message flash
function setFlashMessage($type, $message) {
    $_SESSION['flash_message'] = ['type' => $type, 'message' => $message];
}

// Fonction pour enregistrer une activité dans logs_activites
function logActivity($pdo, $id_utilisateur, $action, $details = '') {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO logs_activites (id_utilisateur, action, details, date_action) 
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$id_utilisateur, $action, $details]);
    } catch (PDOException $e) {
        error_log("Erreur lors de l'enregistrement de l'activité : " . $e->getMessage());
    }
}

// Fonction pour envoyer une notification
function sendNotification($pdo, $id_utilisateur, $message) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO notifications (id_utilisateur, message, date_notification) 
            VALUES (?, ?, NOW())
        ");
        $stmt->execute([$id_utilisateur, $message]);
    } catch (PDOException $e) {
        error_log("Erreur lors de l'envoi de la notification : " . $e->getMessage());
    }
}

// Fonction pour générer un numéro de reçu
function generateReceiptNumber() {
    return 'REC' . date('YmdHis') . rand(1000, 9999);
}

// Fonction pour téléverser une photo
function uploadPhoto($file, $target_dir = 'Uploads/photos/') {
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    $allowed_types = ['image/jpeg', 'image/png'];
    $max_size = 2 * 1024 * 1024; // 2MB
    $file_name = uniqid() . '_' . basename($file['name']);
    $target_file = $target_dir . $file_name;

    if ($file['size'] > $max_size) {
        return ['error' => 'Fichier trop volumineux (max 2MB).'];
    }
    if (!in_array($file['type'], $allowed_types)) {
        return ['error' => 'Type de fichier non autorisé (JPEG/PNG uniquement).'];
    }
    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        return ['path' => $target_file];
    }
    return ['error' => 'Erreur lors du téléchargement.'];
}

// Fonction pour valider un numéro de téléphone
function validatePhone($phone) {
    return preg_match('/^[0-9]{9,15}$/', $phone) ? true : false;
}

// Fonction pour vérifier si l'utilisateur est un directeur départemental
function isDirecteurDepartemental() {
    return isLoggedIn() && isset($_SESSION['role']) && $_SESSION['role'] === 'directeur_departemental';
}

?>
