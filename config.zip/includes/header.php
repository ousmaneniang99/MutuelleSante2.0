<?php
// includes/header.php

// ==========================
// VÉRIFICATIONS ET INCLUSIONS
// ==========================
if (!file_exists(__DIR__ . '/../includes/auth.php')) {
    die("Erreur : Le fichier includes/auth.php est introuvable.");
}
require_once __DIR__ . '/../includes/auth.php';

if (!file_exists(__DIR__ . '/../config/database.php')) {
    die("Erreur : Le fichier config/database.php est introuvable.");
}
require_once __DIR__ . '/../config/database.php';

if (!file_exists(__DIR__ . '/../includes/functions.php')) {
    die("Erreur : Le fichier includes/functions.php est introuvable.");
}
require_once __DIR__ . '/../includes/functions.php';

// Débogage : Afficher l'état de la session pour diagnostiquer
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (isset($_SESSION['user_id'])) {
    error_log("Session active - user_id: {$_SESSION['user_id']}, role: " . ($_SESSION['role'] ?? 'non défini'));
} else {
    error_log("Aucune session active");
}

// Vérifier la session
// checkSessionTimeout(); // Commenté pour éviter l'erreur fatale car la fonction n'est pas définie

// Déterminer la page actuelle (sans extension)
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// Mapping des dashboards par rôle
$dashboard_map = [
    'coordinateur_regional' => 'dashboard_coordinateur',
    'directeur_departemental' => 'dashboard_directeur',
    'agent_mobilisateur' => 'dashboard_agent',
    'prestataire_soins' => 'dashboard_prestataire',
    'comptable' => 'dashboard_comptable',
    'admin' => 'dashboard_admin'
];

// Pages nécessitant vérification de rôle spécifique
$page_roles = [
    'dashboard_comptable' => 'comptable',
    'confirmation_paiements' => 'comptable',
    'list_transactions' => 'comptable',
    'dashboard_agent' => 'agent_mobilisateur',
    'register_adherent' => 'agent_mobilisateur',
    'register_beneficiaire' => 'agent_mobilisateur',
    'edit_beneficiaire' => 'agent_mobilisateur',
    'renouvellement' => 'agent_mobilisateur',
    'dashboard_directeur' => 'directeur_departemental',
    'add_agent' => 'directeur_departemental',
    'add_comptable' => 'directeur_departemental',
    'validate_referencement' => 'directeur_departemental',
    'validate_remboursement' => 'directeur_departemental',
    'list_agents' => 'directeur_departemental',
    'register_prestataire' => 'directeur_departemental',
    'dashboard_prestataire' => 'prestataire_soins',
    'list_adherents_beneficiaires' => 'prestataire_soins',
    'verify_beneficiaire' => 'prestataire_soins',
    'register_prestation' => 'prestataire_soins',
    'dashboard_coordinateur' => 'coordinateur_regional',
    'dashboard_admin' => 'admin',
    'report_global' => 'admin',
    'manage_departements' => 'admin',
    'manage_users' => 'admin',
    'generer_cartes_beneficiaires' => 'directeur_departemental'

];

// Vérifier le rôle pour la page actuelle
if (isset($page_roles[$current_page])) {
    // Débogage : Contourner temporairement checkRole pour admin
    if ($current_page === 'dashboard_admin' && isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        error_log("Accès admin autorisé pour $current_page");
    } else {
        checkRole($page_roles[$current_page]);
    }
}

// Vérifier authentification (sauf pages publiques)
$public_pages = ['login', 'index', 'forgot_password'];
if (!in_array($current_page, $public_pages)) {
    // Débogage : Contourner temporairement checkAuth pour diagnostiquer
    if (!isset($_SESSION['user_id'])) {
        error_log("Redirection vers login.php car user_id non défini");
        header("Location: ../pages/login.php?error=not_authenticated");
        exit();
    }
}

// URL du dashboard selon rôle
$dashboard_url = isset($_SESSION['role']) && isset($dashboard_map[$_SESSION['role']]) 
    ? $dashboard_map[$_SESSION['role']] . '.php' 
    : 'dashboard_agent.php';

// Configuration des menus par rôle
$role_menus = [
    'coordinateur_regional' => [
        ['dashboard_coordinateur', '<i class="bi bi-speedometer2"></i><span class="menu-text">Dashboard</span>', 'Tableau de bord'],
        ['report_regional', '<i class="bi bi-file-earmark-text"></i><span class="menu-text">Rapports</span>', 'Rapports régionaux'],
        ['manage_departements', '<i class="bi bi-geo-alt"></i><span class="menu-text">Départements</span>', 'Gestion départements']
    ],
    'directeur_departemental' => [
        ['dashboard_directeur', '<i class="bi bi-speedometer2"></i><span class="menu-text">Dashboard</span>', 'Tableau de bord'],
        ['list_agents', '<i class="bi bi-people"></i><span class="menu-text">Agents</span>', 'Gestion agents'],
        ['add_comptable', '<i class="bi bi-person-plus"></i><span class="menu-text">Nouveau Comptable</span>', 'Ajouter comptable'],
        ['validate_referencement', '<i class="bi bi-check-circle"></i><span class="menu-text">Référencements</span>', 'Valider référencements'],
        ['validate_remboursement', '<i class="bi bi-wallet"></i><span class="menu-text">Remboursements</span>', 'Valider remboursements'],
        ['register_prestataire', '<i class="bi bi-hospital"></i><span class="menu-text">Prestataires</span>', 'Ajouter prestataire']
    ],
    'agent_mobilisateur' => [
        ['dashboard_agent', '<i class="bi bi-house"></i><span class="menu-text">Dashboard</span>', 'Tableau de bord'],
        ['register_adherent', '<i class="bi bi-person-plus"></i><span class="menu-text">Nouveaux</span>', 'Nouveau adhérent'],
        ['renouvellement', '<i class="bi bi-arrow-clockwise"></i><span class="menu-text">Renouvellements</span>', 'Renouvellements'],
        ['register_beneficiaire', '<i class="bi bi-people"></i><span class="menu-text">Bénéficiaires</span>', 'Gérer bénéficiaires']
    ],
    'prestataire_soins' => [
        ['dashboard_prestataire', '<i class="bi bi-hospital"></i><span class="menu-text">Dashboard</span>', 'Tableau de bord'],
        ['list_adherents_beneficiaires', '<i class="bi bi-people"></i><span class="menu-text">Patients</span>', 'Adhérents/Bénéficiaires'],
        ['verify_beneficiaire', '<i class="bi bi-check-circle"></i><span class="menu-text">Vérifier</span>', 'Vérifier éligibilité'],
        ['register_prestation', '<i class="bi bi-clipboard-plus"></i><span class="menu-text">Prestations</span>', 'Nouvelle prestation']
    ],
    'comptable' => [
        ['dashboard_comptable', '<i class="bi bi-calculator"></i><span class="menu-text">Dashboard</span>', 'Tableau de bord'],
        ['list_transactions', '<i class="bi bi-receipt"></i><span class="menu-text">Transactions</span>', 'Transactions'],
        ['confirmation_paiements', '<i class="bi bi-graph-up"></i><span class="menu-text">Paiements</span>', 'Confirmation des paiements']
    ],
    'admin' => [
        ['dashboard_admin', '<i class="bi bi-speedometer2"></i><span class="menu-text">Dashboard</span>', 'Tableau de bord global'],
        ['manage_users', '<i class="bi bi-person-gear"></i><span class="menu-text">Utilisateurs</span>', 'Gestion utilisateurs']
    ]
];

// Labels des rôles pour affichage
$role_labels = [
    'coordinateur_regional' => 'Coord. Rég.',
    'directeur_departemental' => 'Directeur Dpt',
    'agent_mobilisateur' => 'Agent',
    'prestataire_soins' => 'Prestataire',
    'comptable' => 'Comptable',
    'admin' => 'Admin Global'
];
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Mutuelle Santé Matam - <?php echo isset($page_title) ? htmlspecialchars($page_title) : 'Gestion'; ?></title>
    <link rel="icon" type="image/png" href="Uploads/photos/logo1.png">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    
    <!-- Google Fonts - Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #007bff;
            --primary-dark: #0056b3;
            --success: #28a745;
            --warning: #ffc107;
            --danger: #dc3545;
            --navbar-height: 60px;
            --text-sm: clamp(0.75rem, 2vw, 0.875rem);
            --text-xs: clamp(0.625rem, 1.5vw, 0.75rem);
        }

        * { box-sizing: border-box; }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            /* Background ajusté pour un meilleur contraste sur petits appareils : dégradé neutre clair pour éviter les tons bleus pâles qui lavent sur mobile */
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            font-size: clamp(0.875rem, 2.5vw, 0.95rem);
            line-height: 1.6;
            color: #333;
            min-height: 100vh;
        }

        /* NAVBAR OPTIMISÉE - Mobile-first : styles de base pour mobile, puis améliorations pour écrans plus grands */
        .navbar {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            box-shadow: 0 2px 12px rgba(0,0,0,0.15);
            padding: 0.5rem 0.5rem; /* Base mobile : padding réduit */
            position: sticky;
            top: 0;
            z-index: 1030;
            min-height: var(--navbar-height);
        }

        .navbar-brand {
            font-size: clamp(0.875rem, 4vw, 1.1rem);
            font-weight: 600;
            color: #fff !important;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: clamp(0.25rem, 2vw, 0.75rem);
            padding: 0.25rem 0;
            transition: all 0.2s ease;
        }
        .navbar-brand:hover {
            opacity: 0.95;
            transform: translateY(-1px);
            color: #fff !important;
        }
        
        .navbar-logo {
            height: clamp(20px, 8vw, 32px);
            width: auto;
            border-radius: 6px;
            background: rgba(255,255,255,0.2);
            padding: 2px;
            transition: transform 0.2s ease;
            flex-shrink: 0;
        }
        .navbar-logo:hover { transform: scale(1.05); }
        
        .navbar-brand-text {
            white-space: nowrap;
        }

        /* LIENS NAVIGATION AMÉLIORÉS - Min-height pour touch targets (44px min) */
        .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-size: var(--text-sm);
            font-weight: 500;
            padding: 0.75rem 0.5rem !important; /* Padding vertical pour touch */
            margin: 0 0.125rem;
            border-radius: 8px;
            transition: all 0.3s ease;
            white-space: nowrap;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            position: relative;
            overflow: hidden;
            min-height: 44px; /* Touch target minimum */
            line-height: 1.2;
        }
        .nav-link::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }
        .nav-link:hover::before { left: 100%; }
        .nav-link:hover {
            background-color: rgba(255,255,255,0.15);
            color: #fff !important;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
        .nav-link.active {
            background: rgba(255,255,255,0.25);
            color: #fff !important;
            font-weight: 600;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        /* Cacher le texte des menus sur très petits écrans */
        @media (max-width: 400px) {
            .menu-text { display: none; }
            .nav-link { padding: 0.75rem !important; font-size: 1rem; justify-content: center; }
        }

        /* UTILISATEUR CONNECTÉ - Responsive : cacher sur mobile pour espace */
        .navbar-user {
            background: rgba(255,255,255,0.15);
            color: #fff;
            font-size: var(--text-sm);
            font-weight: 500;
            padding: 0.5rem 0.75rem;
            border-radius: 25px;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            white-space: nowrap;
            backdrop-filter: blur(10px);
            transition: all 0.2s ease;
            min-height: 44px;
        }
        .navbar-user:hover {
            background: rgba(255,255,255,0.25);
            transform: translateY(-1px);
        }

        /* TOGGLER ANIMATION - Amélioré pour tactile */
        .navbar-toggler-icon {
            transition: transform 0.3s ease, opacity 0.3s ease;
            min-height: 44px;
            min-width: 44px;
        }
        .navbar-toggler[aria-expanded="true"] .navbar-toggler-icon {
            transform: rotate(90deg);
            opacity: 0.8;
        }

        /* RESPONSIVE - Mobile-first : utiliser min-width pour étendre aux plus grands écrans */
        /* Base : mobile (jusqu'à 575.98px) déjà définie ci-dessus */

        /* Tablette portrait et paysage (576px et +) */
        @media (min-width: 576px) {
            .navbar { padding: 0.5rem 1rem; }
            .navbar-brand { gap: 0.5rem; }
            .navbar-logo { height: 24px; padding: 3px; }
            .nav-link { 
                font-size: 0.8rem;
                padding: 0.5rem 0.75rem !important;
                text-align: center;
            }
        }

        /* Petite tablette / grand mobile (768px et +) */
        @media (min-width: 768px) {
            .navbar { padding: 0.5rem 1rem; }
            .navbar-logo { height: 28px; }
            .nav-link { padding: 0.75rem 1rem !important; }
        }

        /* Desktop petit (992px et +) */
        @media (min-width: 992px) {
            .navbar-user { display: flex; padding: 0.5rem 1rem; }
            .nav-link { 
                font-size: var(--text-sm);
                padding: 0.5rem 0.75rem !important;
                margin: 0 0.25rem;
                justify-content: flex-start;
            }
            .navbar-brand-text { display: inline; } /* Réafficher sur desktop */
        }

        /* Desktop large (1200px et +) - Améliorations optionnelles */
        @media (min-width: 1200px) {
            .navbar-brand { font-size: 1.1rem; gap: 0.75rem; }
            .navbar-logo { height: 32px; }
        }

        /* ANIMATIONS */
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .navbar-collapse { animation: slideDown 0.3s ease-out; }

        /* SÉCURITÉ & UTILITAIRES - Amélioré pour responsive */
        .text-truncate-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        /* LOADING SPINNER - Responsive */
        .spinner-border-sm-custom {
            width: clamp(0.75rem, 2vw, 1rem);
            height: clamp(0.75rem, 2vw, 1rem);
        }

        /* SCROLLBAR PERSONNALISÉE - Stable sur tous les écrans */
        ::-webkit-scrollbar {
            width: 6px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        ::-webkit-scrollbar-thumb {
            background: var(--primary);
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <!-- NAVBAR PRINCIPALE -->
    <nav class="navbar navbar-expand-lg" role="navigation" aria-label="Navigation principale">
        <div class="container-fluid">
            <!-- LOGO -->
            <a class="navbar-brand" href="<?php echo htmlspecialchars($dashboard_url); ?>" 
               title="Retour au tableau de bord" aria-label="Tableau de bord">
                <img src="Uploads/photos/logo1.png" 
                     alt="Logo Mutuelle Santé Matam" 
                     class="navbar-logo"
                     onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMwMDdiZmYiLz4KPHRleHQgeD0iMTYiIHk9IjE4IiBmb250LWZhbWlseT0iSW50ZXIiIGZvbnQtd2VpZ2h0PSI2MDAiIGZvbnQtc2l6ZT0iOSIgZmlsbD0id2hpdGUiIHRleHQtYW5jaG9yPSJtaWRkbGUiPk1TTTwvdGV4dD4KPC9zdmc+'">
                <span class="navbar-brand-text">Mutuelle Santé Matam</span>
            </a>

            <!-- TOGGLER MOBILE -->
            <button class="navbar-toggler border-0 p-2" type="button" 
                    data-bs-toggle="collapse" 
                    data-bs-target="#navbarNav" 
                    aria-controls="navbarNav" 
                    aria-expanded="false" 
                    aria-label="Ouvrir le menu de navigation">
                <i class="bi bi-list text-white fs-4 navbar-toggler-icon"></i>
            </button>

            <!-- MENU DE NAVIGATION -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <?php if (isset($_SESSION['role']) && isset($role_menus[$_SESSION['role']])): ?>
                        <?php foreach ($role_menus[$_SESSION['role']] as $menu_item): 
                            [$url, $label, $title] = $menu_item;
                            $active = ($current_page === $url) ? 'active' : '';
                            $full_url = htmlspecialchars($url . '.php');
                        ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $active; ?>" 
                                   href="<?php echo $full_url; ?>" 
                                   title="<?php echo htmlspecialchars($title); ?>"
                                   role="menuitem">
                                    <?php echo $label; ?>
                                </a>
                            </li>
                        <?php endforeach; ?>

                        <!-- UTILISATEUR -->
                        <?php $user_label = $role_labels[$_SESSION['role']] ?? ucwords(str_replace('_', ' ', $_SESSION['role'])); ?>
                        <li class="nav-item">
                            <span class="navbar-user" 
                                  title="<?php echo htmlspecialchars($_SESSION['prenom'] . ' ' . $_SESSION['nom']); ?>"
                                  aria-label="Utilisateur connecté">
                                <i class="bi bi-person-circle"></i>
                                <?php echo htmlspecialchars($user_label); ?>
                            </span>
                        </li>

                        <!-- PROFIL & DÉCONNEXION -->
                        <li class="nav-item">
                            <a class="nav-link" href="profil.php" title="Mon profil" role="menuitem" aria-label="Accéder au profil">
                                <i class="bi bi-person-gear"></i><span class="menu-text">Profil</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="logout.php" title="Déconnexion" 
                               onclick="return confirm('Voulez-vous vous déconnecter ?')" role="menuitem" aria-label="Se déconnecter">
                                <i class="bi bi-box-arrow-right"></i><span class="menu-text">Déconnexion</span>
                            </a>
                        </li>

                    <?php else: ?>
                        <!-- NON CONNECTÉ -->
                        <li class="nav-item">
                            <a class="nav-link" href="login.php" title="Connexion" role="menuitem" aria-label="Se connecter">
                                <i class="bi bi-box-arrow-in-right"></i><span class="menu-text">Connexion</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- CONTENU PRINCIPAL -->
    <main class="container-fluid py-3">
        <!-- Alertes globales -->
        <?php if (isset($global_alerts) && !empty($global_alerts)): ?>
            <?php foreach ($global_alerts as $alert): ?>
                <div class="alert alert-<?php echo $alert['type']; ?> alert-dismissible fade show" role="alert">
                    <?php echo $alert['message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer l'alerte"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

    <!-- Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Marquer lien actif
            const currentPage = '<?php echo $current_page; ?>';
            document.querySelectorAll('.nav-link').forEach(link => {
                if (link.href.includes(currentPage + '.php') || link.href.includes(currentPage)) {
                    link.classList.add('active');
                }
            });

            // Toggler mobile amélioré
            const toggler = document.querySelector('.navbar-toggler i');
            if (toggler) {
                document.querySelector('.navbar-toggler').addEventListener('click', function() {
                    toggler.classList.toggle('bi-list');
                    toggler.classList.toggle('bi-x-lg');
                });
            }

            // Fallback logo
            const logo = document.querySelector('.navbar-logo');
            if (logo) {
                logo.addEventListener('error', function() {
                    this.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMwMDdiZmYiLz4KPHRleHQgeD0iMTYiIHk9IjE4IiBmb250LWZhbWlseT0iSW50ZXIiIGZvbnQtd2VpZ2h0PSI2MDAiIGZvbnQtc2l6ZT0iOSIgZmlsbD0id2hpdGUiIHRleHQtYW5jaG9yPSJtaWRkbGUiPk1TTTwvdGV4dD4KPC9zdmc+Cg==';
                });
            }
        });

        // Fonction utilitaire de confirmation
        function confirmAction(message, url) {
            return confirm(message) ? (window.location.href = url, true) : false;
        }
    </script>
</body>
</html>