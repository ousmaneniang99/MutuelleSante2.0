<?php
// index.php
require_once 'config/database.php';
require_once 'includes/functions.php';

// Démarrer la session si ce n'est pas déjà fait
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Vérifier si l'utilisateur est connecté
if (!isLoggedIn()) {
    header("Location: pages/login.php");
    exit();
}

// Définir les redirections selon les rôles
$dashboards = [
    'admin' => 'dashboard_admin.php',
    'agent_mobilisateur' => 'dashboard_agent.php',
    'directeur_departemental' => 'dashboard_directeur.php',
    'prestataire_soins' => 'dashboard_prestataire.php',
    'coordinateur_regional' => 'dashboard_coordinateur.php',
    'adherent' => 'dashboard_adherent.php'
];

try {
    // Vérifier l'utilisateur et son rôle dans la base de données
    $stmt = $pdo->prepare("SELECT role FROM utilisateurs WHERE id_utilisateur = ? AND statut = 'actif'");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !array_key_exists($user['role'], $dashboards)) {
        // Utilisateur introuvable, inactif ou rôle invalide : déconnexion
        logActivity($pdo, $_SESSION['user_id'] ?? null, 'logout', "Tentative d'accès avec rôle invalide ou utilisateur introuvable (ID: {$_SESSION['user_id']})");
        session_destroy();
        header("Location: pages/login.php");
        exit();
    }

    // Mettre à jour $_SESSION['role'] pour garantir la cohérence
    $_SESSION['role'] = $user['role'];

    // Vérifier que le fichier du tableau de bord existe
    $dashboard_path = "pages/{$dashboards[$user['role']]}";
    if (!file_exists($dashboard_path)) {
        logActivity($pdo, $_SESSION['user_id'], 'error', "Tableau de bord introuvable pour le rôle {$user['role']} : $dashboard_path");
        session_destroy();
        header("Location: pages/login.php");
        exit();
    }

    // Rediriger vers le tableau de bord correspondant
    header("Location: $dashboard_path");
    exit();
} catch (PDOException $e) {
    // Erreur de base de données : journaliser et déconnecter
    error_log("Erreur PDO dans index.php : " . $e->getMessage());
    logActivity($pdo, $_SESSION['user_id'] ?? null, 'error', "Erreur PDO lors de la vérification du rôle : " . $e->getMessage());
    session_destroy();
    header("Location: pages/login.php");
    exit();
}
?>