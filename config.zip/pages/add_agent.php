<?php
// pages/add_agent.php
require_once '../includes/header.php';
checkRole('directeur_departemental');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();

// Vérifier que le département de l'utilisateur est défini et valide
$departement = isset($_SESSION['departement']) ? (int)$_SESSION['departement'] : null;
if (!$departement) {
    $_SESSION['errors'] = ["Erreur : Aucun département défini pour l'utilisateur. Veuillez contacter l'administrateur."];
    header('Location: dashboard_directeur.php');
    exit();
} else {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM departements WHERE id_departement = ?");
    $stmt->execute([$departement]);
    if ($stmt->fetchColumn() == 0) {
        $_SESSION['errors'] = ["Erreur : Le département de l'utilisateur est invalide."];
        header('Location: dashboard_directeur.php');
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
    } else {
        // Récupérer et nettoyer les données du formulaire
        $nom = filter_var(trim($_POST['nom'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $prenom = filter_var(trim($_POST['prenom'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $date_naissance = trim($_POST['date_naissance'] ?? '');
        $lieu_naissance = filter_var(trim($_POST['lieu_naissance'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $adresse = filter_var(trim($_POST['adresse'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $telephone = filter_var(trim($_POST['telephone'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
        $numero_carte_identite = filter_var(trim($_POST['numero_carte_identite'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $profession = filter_var(trim($_POST['profession'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $photo_base64 = isset($_POST['photo_base64']) ? $_POST['photo_base64'] : null;

        // Gestion de la photo (facultative)
        $photo_path = null;
        if ($photo_base64 && strpos($photo_base64, 'data:image') === 0) {
            // Process base64 photo
            $photo_data = explode(',', $photo_base64);
            if (count($photo_data) === 2) {
                $image_data = base64_decode($photo_data[1]);
                if (strlen($image_data) > 2 * 1024 * 1024) { // 2MB limit
                    $errors[] = "La photo capturée dépasse la taille maximale de 2MB.";
                } else {
                    $upload_dir = '../Uploads/photos/';
                    $photo_name = uniqid() . '.jpg';
                    $photo_path = $upload_dir . $photo_name;
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    if (!file_put_contents($photo_path, $image_data)) {
                        $errors[] = "Erreur lors de l'enregistrement de la photo capturée.";
                    }
                }
            } else {
                $errors[] = "Format de la photo capturée invalide.";
            }
        } elseif (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../Uploads/photos/';
            $photo_name = uniqid() . '_' . basename($_FILES['photo']['name']);
            $photo_path = $upload_dir . $photo_name;
            if (!move_uploaded_file($_FILES['photo']['tmp_name'], $photo_path)) {
                $errors[] = "Erreur lors de l'upload de la photo.";
            }
        }

        // Validation des champs
        if (empty($nom) || empty($prenom) || empty($email) || empty($telephone) || empty($numero_carte_identite)) {
            $errors[] = "Les champs Nom, Prénom, Email, Téléphone et Numéro de Carte d'Identité sont obligatoires.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "L'email n'est pas valide.";
        } elseif (!empty($date_naissance) && !DateTime::createFromFormat('Y-m-d', $date_naissance)) {
            $errors[] = "La date de naissance n'est pas valide (format : AAAA-MM-JJ).";
        } elseif (!validatePhone($telephone)) {
            $errors[] = "Le numéro de téléphone est invalide (9-15 chiffres).";
        } else {
            try {
                // Vérifier l'unicité de l'email
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetchColumn() > 0) {
                    $errors[] = "Cet email est déjà utilisé.";
                }

                // Vérifier l'unicité du numéro de carte d'identité
                if (!empty($numero_carte_identite)) {
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE numero_carte_identite = ?");
                    $stmt->execute([$numero_carte_identite]);
                    if ($stmt->fetchColumn() > 0) {
                        $errors[] = "Ce numéro de carte d'identité est déjà utilisé.";
                    }
                }

                if (empty($errors)) {
                    // Mot de passe par défaut
                    $mot_de_passe = 'password123';
                    $hashed_password = password_hash($mot_de_passe, PASSWORD_DEFAULT);

                    // Insérer le nouvel agent
                    $stmt = $pdo->prepare("
                        INSERT INTO utilisateurs (
                            nom, prenom, date_naissance, lieu_naissance, adresse, telephone, email, 
                            mot_de_passe, role, departement, numero_carte_identite, profession, 
                            photo_path, statut, date_inscription, date_mise_a_jour
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'agent_mobilisateur', ?, ?, ?, ?, 'actif', NOW(), NOW())
                    ");
                    $stmt->execute([
                        $nom, $prenom, 
                        $date_naissance ?: null, 
                        $lieu_naissance ?: null, 
                        $adresse ?: null, 
                        $telephone, 
                        $email, 
                        $hashed_password, 
                        $departement, 
                        $numero_carte_identite, 
                        $profession ?: null, 
                        $photo_path
                    ]);

                    // Log activité
                    logActivity($pdo, $_SESSION['user_id'], "Ajout de l'agent: $nom $prenom ($email)");
                    $success = "Agent ajouté avec succès. Mot de passe par défaut : password123";
                }
            } catch (PDOException $e) {
                $errors[] = "Erreur lors de l'ajout de l'agent : " . htmlspecialchars($e->getMessage());
                error_log("Erreur dans add_agent.php : " . $e->getMessage());
            }
        }
    }
}
?>

<div class="container">
    <h2 class="page-title text-center"><i class="bi bi-person-plus me-2"></i>Ajouter un Agent</h2>

    <!-- Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if ($errors): ?>
        <?php foreach ($errors as $error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Agent Form -->
    <div class="card">
        <div class="card-header">
            <i class="bi bi-person-plus-fill me-2"></i>Formulaire d'Ajout d'Agent
        </div>
        <div class="card-body">
            <form method="POST" action="" enctype="multipart/form-data" id="agent_form">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                <input type="hidden" name="photo_base64" id="photo_base64">
                <div class="row g-3">
                    <div class="col-12 col-md-6">
                        <div class="mb-3">
                            <label for="nom" class="form-label"><i class="bi bi-person me-2"></i>Nom <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="nom" name="nom" value="<?php echo htmlspecialchars($_POST['nom'] ?? ''); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="prenom" class="form-label"><i class="bi bi-person me-2"></i>Prénom <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="prenom" name="prenom" value="<?php echo htmlspecialchars($_POST['prenom'] ?? ''); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label"><i class="bi bi-envelope me-2"></i>Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="telephone" class="form-label"><i class="bi bi-telephone me-2"></i>Téléphone <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo htmlspecialchars($_POST['telephone'] ?? ''); ?>" required>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="mb-3">
                            <label for="date_naissance" class="form-label"><i class="bi bi-calendar me-2"></i>Date de Naissance</label>
                            <input type="date" class="form-control" id="date_naissance" name="date_naissance" value="<?php echo htmlspecialchars($_POST['date_naissance'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="lieu_naissance" class="form-label"><i class="bi bi-geo-alt me-2"></i>Lieu de Naissance</label>
                            <input type="text" class="form-control" id="lieu_naissance" name="lieu_naissance" value="<?php echo htmlspecialchars($_POST['lieu_naissance'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="adresse" class="form-label"><i class="bi bi-house-door me-2"></i>Adresse</label>
                            <input type="text" class="form-control" id="adresse" name="adresse" value="<?php echo htmlspecialchars($_POST['adresse'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="numero_carte_identite" class="form-label"><i class="bi bi-person-vcard me-2"></i>Numéro de Carte d'Identité <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="numero_carte_identite" name="numero_carte_identite" value="<?php echo htmlspecialchars($_POST['numero_carte_identite'] ?? ''); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="profession" class="form-label"><i class="bi bi-briefcase me-2"></i>Profession</label>
                            <input type="text" class="form-control" id="profession" name="profession" value="<?php echo htmlspecialchars($_POST['profession'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="photo" class="form-label"><i class="bi bi-image me-2"></i>Photo (JPEG/PNG, max 2MB, facultatif)</label>
                            <input type="file" class="form-control" id="photo" name="photo" accept="image/jpeg,image/png">
                            <button type="button" class="btn btn-secondary mt-2" data-bs-toggle="modal" data-bs-target="#capturePhotoModal"><i class="bi bi-camera me-2"></i>Prendre une photo</button>
                            <img id="photoPreview" src="#" alt="Aperçu de la photo" style="display: none;">
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between mt-3">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save me-2"></i>Ajouter l'Agent</button>
                    <a href="dashboard_directeur.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Retour</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal for capturing photo -->
    <div class="modal fade" id="capturePhotoModal" tabindex="-1" aria-labelledby="capturePhotoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="capturePhotoModalLabel">Prendre une Photo</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <video id="video" autoplay style="max-width: 100%; height: auto;"></video>
                    <canvas id="canvas" style="display: none;"></canvas>
                    <div class="mt-3">
                        <button type="button" id="captureButton" class="btn btn-primary"><i class="bi bi-camera me-2"></i>Capturer</button>
                        <button type="button" id="retakeButton" class="btn btn-secondary" style="display: none;"><i class="bi bi-arrow-repeat me-2"></i>Reprendre</button>
                        <button type="button" id="savePhotoButton" class="btn btn-success" style="display: none;" data-bs-dismiss="modal"><i class="bi bi-check-circle me-2"></i>Enregistrer la Photo</button>
                    </div>
                    <p id="cameraError" class="text-danger mt-3" style="display: none;"></p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    :root {
        --primary: #1d4ed8;
        --accent: #059669;
        --danger: #ef4444;
        --warning: #f59e0b;
        --secondary: #6b7280;
        --background: #f1f5f9;
        --card-bg: #ffffff;
        --text: #111827;
        --success-dark: #047857;
    }

    .container {
        max-width: 900px;
        margin: 2rem auto;
        padding: 0 1rem;
    }

    .page-title {
        font-size: clamp(1.5rem, 5vw, 2rem);
        font-weight: 700;
        color: var(--primary);
        display: flex;
        align-items: center;
        gap: 0.5rem;
        text-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        margin-bottom: 1.5rem;
        animation: fadeIn 0.5s ease-in;
    }

    .card {
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        background: var(--card-bg);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-4px);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    }

    .card-header {
        background: linear-gradient(135deg, var(--primary), #3b82f6);
        color: white;
        font-weight: 600;
        border-radius: 12px 12px 0 0;
        padding: 1rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .card-body {
        padding: clamp(1rem, 3vw, 1.5rem);
    }

    .alert {
        border-radius: 8px;
        animation: slideIn 0.5s ease-in-out;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.75rem;
        font-size: clamp(0.85rem, 2.5vw, 0.9rem);
    }

    .form-control, .form-select {
        border-radius: 6px;
        padding: clamp(0.5rem, 2vw, 0.75rem);
        border: 1px solid var(--primary);
        font-size: clamp(0.85rem, 2.5vw, 0.95rem);
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
        height: auto;
        min-height: 38px;
    }

    .form-control:focus, .form-select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 8px rgba(29, 78, 216, 0.4);
    }

    .form-label {
        font-size: clamp(0.8rem, 2.5vw, 0.9rem);
        margin-bottom: 0.3rem;
        display: flex;
        align-items: center;
        gap: 0.3rem;
    }

    .btn-primary, .btn-secondary, .btn-success {
        border-radius: 6px;
        padding: clamp(0.5rem, 2vw, 0.75rem) 1rem;
        font-size: clamp(0.85rem, 2.5vw, 0.9rem);
        font-weight: 500;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.3rem;
        touch-action: manipulation;
    }

    .btn-primary {
        background-color: var(--primary);
        border: none;
    }

    .btn-primary:hover {
        background-color: #1e3a8a;
        transform: scale(1.05);
        box-shadow: 0 0 10px rgba(29, 78, 216, 0.4);
    }

    .btn-secondary:hover {
        background-color: #5a6268;
    }

    .btn-success:hover {
        background-color: #218838;
    }

    #photoPreview {
        max-width: 200px;
        height: auto;
        margin-top: 10px;
        border: 1px solid var(--primary);
        border-radius: 6px;
    }

    @keyframes slideIn {
        from { opacity: 0; transform: translateX(-15px); }
        to { opacity: 1; transform: translateX(0); }
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* Media Queries pour responsive */
    @media (max-width: 768px) {
        .container {
            margin: 1rem;
            padding: 0 0.5rem;
        }

        .page-title {
            font-size: clamp(1.25rem, 4vw, 1.5rem);
            margin-bottom: 1rem;
        }

        .card {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
        }

        .card-header {
            padding: 0.75rem;
            font-size: clamp(0.9rem, 3vw, 1rem);
        }

        .card-body {
            padding: 1rem;
        }

        .form-control, .form-select {
            padding: 0.5rem;
            font-size: clamp(0.8rem, 2.5vw, 0.9rem);
            min-height: 36px;
        }

        .form-label {
            font-size: clamp(0.75rem, 2.5vw, 0.85rem);
        }

        .btn-primary, .btn-secondary, .btn-success {
            padding: 0.5rem 0.75rem;
            font-size: clamp(0.8rem, 2.5vw, 0.85rem);
        }

        .alert {
            padding: 0.5rem;
            font-size: clamp(0.8rem, 2.5vw, 0.85rem);
        }

        #photoPreview {
            max-width: 150px;
        }
    }

    @media (max-width: 576px) {
        .container {
            margin: 0.5rem;
        }

        .page-title {
            font-size: clamp(1.1rem, 4vw, 1.3rem);
            flex-direction: column;
            align-items: flex-start;
        }

        .card {
            border-radius: 8px;
        }

        .card-header {
            padding: 0.5rem;
            font-size: clamp(0.85rem, 3vw, 0.95rem);
        }

        .form-control, .form-select {
            font-size: clamp(0.75rem, 2.5vw, 0.85rem);
            min-height: 34px;
        }

        .btn-primary, .btn-secondary, .btn-success {
            font-size: clamp(0.75rem, 2.5vw, 0.8rem);
            padding: 0.4rem 0.6rem;
        }

        #photoPreview {
            max-width: 120px;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const captureButton = document.getElementById('captureButton');
        const retakeButton = document.getElementById('retakeButton');
        const savePhotoButton = document.getElementById('savePhotoButton');
        const photoPreview = document.getElementById('photoPreview');
        const photoBase64Input = document.getElementById('photo_base64');
        const photoInput = document.getElementById('photo');
        let stream = null;

        // Start camera when modal is opened
        document.getElementById('capturePhotoModal')?.addEventListener('shown.bs.modal', async function() {
            try {
                stream = await navigator.mediaDevices.getUserMedia({ 
                    video: { 
                        facingMode: 'user',
                        width: { ideal: 640 },
                        height: { ideal: 480 }
                    } 
                });
                video.srcObject = stream;
                document.getElementById('cameraError').style.display = 'none';
                captureButton.style.display = 'inline-block';
                retakeButton.style.display = 'none';
                savePhotoButton.style.display = 'none';
            } catch (err) {
                console.error('Camera access error:', err);
                document.getElementById('cameraError').textContent = 'Impossible d\'accéder à la caméra. Vérifiez les autorisations ou utilisez une image téléversée.';
                document.getElementById('cameraError').style.display = 'block';
                captureButton.style.display = 'none';
            }
        });

        // Stop camera when modal is closed
        document.getElementById('capturePhotoModal')?.addEventListener('hidden.bs.modal', function() {
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
                stream = null;
            }
            video.srcObject = null;
            video.style.display = 'block';
            canvas.style.display = 'none';
        });

        // Capture photo
        captureButton?.addEventListener('click', function() {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0);
            const imageData = canvas.toDataURL('image/jpeg', 0.7);
            photoPreview.src = imageData;
            photoPreview.style.display = 'block';
            photoBase64Input.value = imageData;
            photoInput.value = '';
            captureButton.style.display = 'none';
            retakeButton.style.display = 'inline-block';
            savePhotoButton.style.display = 'inline-block';
            video.style.display = 'none';
            canvas.style.display = 'block';
        });

        // Retake photo
        retakeButton?.addEventListener('click', function() {
            video.style.display = 'block';
            canvas.style.display = 'none';
            captureButton.style.display = 'inline-block';
            retakeButton.style.display = 'none';
            savePhotoButton.style.display = 'none';
            photoPreview.style.display = 'none';
            photoBase64Input.value = '';
        });

        // Clear captured photo if a file is selected
        photoInput?.addEventListener('change', function() {
            if (photoInput.files.length > 0) {
                photoBase64Input.value = '';
                photoPreview.style.display = 'none';
            }
        });
    });
</script>

<?php require_once '../includes/footer.php'; ?>
