<?php
// pages/add_comptable.php
require_once '../includes/header.php';

checkRole('directeur_departemental'); 

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
    } else {
        // Récupérer et nettoyer les données du formulaire
        $nom = filter_var(trim($_POST['nom'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $prenom = filter_var(trim($_POST['prenom'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $date_naissance = trim($_POST['date_naissance'] ?? '');
        $lieu_naissance = filter_var(trim($_POST['lieu_naissance'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $adresse = filter_var(trim($_POST['adresse'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $telephone = filter_var(trim($_POST['telephone'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
        $numero_carte_identite = filter_var(trim($_POST['numero_carte_identite'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $profession = filter_var(trim($_POST['profession'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $photo_base64 = isset($_POST['photo_base64']) ? $_POST['photo_base64'] : null;

        // Gestion de la photo (capturée ou téléversée)
        $photo_path = null;
        if ($photo_base64 && strpos($photo_base64, 'data:image') === 0) {
            // Process base64 photo
            $photo_data = explode(',', $photo_base64);
            if (count($photo_data) === 2) {
                $image_data = base64_decode($photo_data[1]);
                if (strlen($image_data) > 2 * 1024 * 1024) { // 2MB limit
                    $errors[] = "La photo capturée dépasse la taille maximale de 2MB.";
                } else {
                    $upload_dir = '../Uploads/photos/';
                    $photo_name = uniqid() . '.jpg';
                    $photo_path = $upload_dir . $photo_name;
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    if (!file_put_contents($photo_path, $image_data)) {
                        $errors[] = "Erreur lors de l'enregistrement de la photo capturée.";
                    }
                }
            } else {
                $errors[] = "Format de la photo capturée invalide.";
            }
        } elseif (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../Uploads/photos/';
            $photo_name = uniqid() . '_' . basename($_FILES['photo']['name']);
            $photo_path = $upload_dir . $photo_name;
            if (!move_uploaded_file($_FILES['photo']['tmp_name'], $photo_path)) {
                $errors[] = "Erreur lors de l'upload de la photo.";
            }
        } else {
            $errors[] = "Une photo (téléversée ou capturée) est requise.";
        }

        // Validation des champs
        if (empty($nom) || empty($prenom) || empty($email) || empty($telephone) || empty($numero_carte_identite)) {
            $errors[] = "Les champs Nom, Prénom, Email, Téléphone et Numéro de Carte d'Identité sont obligatoires.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "L'email n'est pas valide.";
        } elseif (!empty($date_naissance) && !DateTime::createFromFormat('Y-m-d', $date_naissance)) {
            $errors[] = "La date de naissance n'est pas valide (format : AAAA-MM-JJ).";
        } elseif (!validatePhone($telephone)) {
            $errors[] = "Le numéro de téléphone est invalide (9-15 chiffres).";
        } else {
            try {
                // Vérifier l'unicité de l'email
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetchColumn() > 0) {
                    $errors[] = "Cet email est déjà utilisé.";
                }

                // Vérifier l'unicité du numéro de carte d'identité
                if (!empty($numero_carte_identite)) {
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE numero_carte_identite = ?");
                    $stmt->execute([$numero_carte_identite]);
                    if ($stmt->fetchColumn() > 0) {
                        $errors[] = "Ce numéro de carte d'identité est déjà utilisé.";
                    }
                }

                if (empty($errors)) {
                    // Mot de passe par défaut
                    $mot_de_passe = 'password123';
                    $hashed_password = password_hash($mot_de_passe, PASSWORD_DEFAULT);

                    // Insérer le nouveau comptable
                    $stmt = $pdo->prepare("
                        INSERT INTO utilisateurs (
                            nom, prenom, date_naissance, lieu_naissance, adresse, telephone, email, 
                            mot_de_passe, role, departement, numero_carte_identite, profession, 
                            photo_path, statut, date_inscription, date_mise_a_jour
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'comptable', ?, ?, ?, ?, 'actif', NOW(), NOW())
                    ");
                    $stmt->execute([
                        $nom, $prenom, 
                        $date_naissance ?: null, 
                        $lieu_naissance ?: null, 
                        $adresse ?: null, 
                        $telephone, 
                        $email, 
                        $hashed_password, 
                        $_SESSION['departement'], 
                        $numero_carte_identite, 
                        $profession ?: null, 
                        $photo_path
                    ]);

                    // Log activité
                    logActivity($pdo, $_SESSION['user_id'], "Ajout du comptable: $nom $prenom ($email)");
                    $success = "Comptable ajouté avec succès. Mot de passe par défaut : password123";
                }
            } catch (PDOException $e) {
                $errors[] = "Erreur lors de l'ajout du comptable : " . htmlspecialchars($e->getMessage());
                error_log("Erreur dans add_comptable.php : " . $e->getMessage());
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Comptable</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .card-header {
            border-bottom: none;
            padding: 1.5rem;
            font-size: 1.25rem;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .alert {
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert i {
            font-size: 1.2rem;
        }
        .form-control, .form-select {
            border-radius: 8px;
            padding: 0.75rem;
            border: 1px solid #ced4da;
            transition: border-color 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
        }
        .btn-primary, .btn-secondary, .btn-success {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 2rem;
        }
        .modal-content {
            border-radius: 10px;
        }
        .modal-body img, .modal-body video, .modal-body canvas {
            max-width: 100%;
            height: auto;
        }
        #photoPreview {
            max-width: 200px;
            height: auto;
            margin-top: 10px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-person-plus me-2"></i>Ajouter un Comptable</h2>

        <!-- Messages -->
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill"></i>
                <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Comptable Form -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <i class="bi bi-person-plus-fill me-2"></i>Formulaire d'Ajout de Comptable
            </div>
            <div class="card-body">
                <form method="POST" action="" enctype="multipart/form-data" id="comptable_form">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                    <input type="hidden" name="photo_base64" id="photo_base64">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="nom" class="form-label"><i class="bi bi-person me-2"></i>Nom <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="nom" name="nom" value="<?php echo htmlspecialchars($_POST['nom'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="prenom" class="form-label"><i class="bi bi-person me-2"></i>Prénom <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="prenom" name="prenom" value="<?php echo htmlspecialchars($_POST['prenom'] ?? ''); ?>" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label"><i class="bi bi-envelope me-2"></i>Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="telephone" class="form-label"><i class="bi bi-telephone me-2"></i>Téléphone <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo htmlspecialchars($_POST['telephone'] ?? ''); ?>" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="date_naissance" class="form-label"><i class="bi bi-calendar me-2"></i>Date de Naissance</label>
                            <input type="date" class="form-control" id="date_naissance" name="date_naissance" value="<?php echo htmlspecialchars($_POST['date_naissance'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="lieu_naissance" class="form-label"><i class="bi bi-geo-alt me-2"></i>Lieu de Naissance</label>
                            <input type="text" class="form-control" id="lieu_naissance" name="lieu_naissance" value="<?php echo htmlspecialchars($_POST['lieu_naissance'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="adresse" class="form-label"><i class="bi bi-house-door me-2"></i>Adresse</label>
                        <input type="text" class="form-control" id="adresse" name="adresse" value="<?php echo htmlspecialchars($_POST['adresse'] ?? ''); ?>">
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="numero_carte_identite" class="form-label"><i class="bi bi-person-vcard me-2"></i>Numéro de Carte d'Identité <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="numero_carte_identite" name="numero_carte_identite" value="<?php echo htmlspecialchars($_POST['numero_carte_identite'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="profession" class="form-label"><i class="bi bi-briefcase me-2"></i>Profession</label>
                            <input type="text" class="form-control" id="profession" name="profession" value="<?php echo htmlspecialchars($_POST['profession'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="photo" class="form-label"><i class="bi bi-image me-2"></i>Photo (JPEG/PNG, max 2MB) <span class="text-danger">*</span></label>
                        <input type="file" class="form-control" id="photo" name="photo" accept="image/jpeg,image/png">
                        <button type="button" class="btn btn-secondary mt-2" data-bs-toggle="modal" data-bs-target="#capturePhotoModal"><i class="bi bi-camera me-2"></i>Prendre une photo</button>
                        <img id="photoPreview" src="#" alt="Aperçu de la photo" style="display: none;">
                    </div>
                    <div class="d-flex justify-content-between">
                        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-2"></i>Ajouter le Comptable</button>
                        <a href="dashboard_directeur.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Retour</a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Modal for capturing photo -->
        <div class="modal fade" id="capturePhotoModal" tabindex="-1" aria-labelledby="capturePhotoModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="capturePhotoModalLabel">Prendre une Photo</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center">
                        <video id="video" autoplay style="max-width: 100%; height: auto;"></video>
                        <canvas id="canvas" style="display: none;"></canvas>
                        <div class="mt-3">
                            <button type="button" id="captureButton" class="btn btn-primary"><i class="bi bi-camera me-2"></i>Capturer</button>
                            <button type="button" id="retakeButton" class="btn btn-secondary" style="display: none;"><i class="bi bi-arrow-repeat me-2"></i>Reprendre</button>
                            <button type="button" id="savePhotoButton" class="btn btn-success" style="display: none;" data-bs-dismiss="modal"><i class="bi bi-check-circle me-2"></i>Enregistrer la Photo</button>
                        </div>
                        <p id="cameraError" class="text-danger mt-3" style="display: none;"></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const video = document.getElementById('video');
            const canvas = document.getElementById('canvas');
            const captureButton = document.getElementById('captureButton');
            const retakeButton = document.getElementById('retakeButton');
            const savePhotoButton = document.getElementById('savePhotoButton');
            const photoPreview = document.getElementById('photoPreview');
            const photoBase64Input = document.getElementById('photo_base64');
            const photoInput = document.getElementById('photo');
            let stream = null;

            // Start camera when modal is opened
            document.getElementById('capturePhotoModal').addEventListener('shown.bs.modal', async function() {
                try {
                    stream = await navigator.mediaDevices.getUserMedia({ video: true });
                    video.srcObject = stream;
                    document.getElementById('cameraError').style.display = 'none';
                    captureButton.style.display = 'inline-block';
                    retakeButton.style.display = 'none';
                    savePhotoButton.style.display = 'none';
                } catch (err) {
                    document.getElementById('cameraError').textContent = 'Impossible d\'accéder à la caméra. Veuillez vérifier les autorisations ou utiliser une image téléversée.';
                    document.getElementById('cameraError').style.display = 'block';
                    captureButton.style.display = 'none';
                }
            });

            // Stop camera when modal is closed
            document.getElementById('capturePhotoModal').addEventListener('hidden.bs.modal', function() {
                if (stream) {
                    stream.getTracks().forEach(track => track.stop());
                    stream = null;
                }
                video.srcObject = null;
            });

            // Capture photo
            captureButton.addEventListener('click', function() {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                canvas.getContext('2d').drawImage(video, 0, 0);
                const imageData = canvas.toDataURL('image/jpeg', 0.7); // 70% quality
                photoPreview.src = imageData;
                photoPreview.style.display = 'block';
                photoBase64Input.value = imageData;
                photoInput.value = ''; // Clear file input to prioritize captured photo
                captureButton.style.display = 'none';
                retakeButton.style.display = 'inline-block';
                savePhotoButton.style.display = 'inline-block';
                video.style.display = 'none';
                canvas.style.display = 'block';
            });

            // Retake photo
            retakeButton.addEventListener('click', function() {
                video.style.display = 'block';
                canvas.style.display = 'none';
                captureButton.style.display = 'inline-block';
                retakeButton.style.display = 'none';
                savePhotoButton.style.display = 'none';
                photoPreview.style.display = 'none';
                photoBase64Input.value = '';
            });

            // Clear captured photo if a file is selected
            photoInput.addEventListener('change', function() {
                if (photoInput.files.length > 0) {
                    photoBase64Input.value = '';
                    photoPreview.style.display = 'none';
                }
            });

            // Validate form submission
            document.getElementById('comptable_form').addEventListener('submit', function(e) {
                if (!photoBase64Input.value && !photoInput.files.length) {
                    alert('Veuillez fournir une photo (téléversée ou capturée).');
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>

<?php 
require_once '../includes/footer.php'; 

?>