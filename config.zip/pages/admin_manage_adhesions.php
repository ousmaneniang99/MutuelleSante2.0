<?php
// pages/admin_manage_adhesions.php
ob_start(); // Start output buffering to prevent headers already sent
require_once __DIR__ . '/../includes/header.php';

// Enable error reporting for debugging (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Vérifications de session et rôle
checkSessionTimeout();
checkRole('admin');

$errors = [];
$success = null;
$adhesions = []; // Initialiser pour adhésions incomplètes
$total_pages = 0; // Pagination

// Paramètres de pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['csrf_token'])) {
    if (!verifyCsrfToken($_POST['csrf_token'])) {
        $errors[] = "Erreur de sécurité CSRF. Veuillez réessayer.";
        error_log("Échec de validation CSRF pour admin_manage_adhesions.php, utilisateur ID: {$_SESSION['user_id']}");
    } else {
        try {
            $pdo->beginTransaction();

            if ($_POST['action'] === 'set_pending_all') {
                $stmt = $pdo->prepare("
                    SELECT a.id_adhesion
                    FROM adhesions a
                    WHERE a.statut = 'active'
                    AND EXISTS (
                        SELECT 1 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion 
                        AND (b.photo_path IS NULL OR b.photo_path = '')
                    )
                ");
                $stmt->execute();
                $adhesions_to_update = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if ($adhesions_to_update) {
                    $stmt_adhesion = $pdo->prepare("
                        UPDATE adhesions 
                        SET statut = 'en_attente_validation' 
                        WHERE id_adhesion = ?
                    ");
                    $stmt_benef = $pdo->prepare("
                        UPDATE beneficiaires 
                        SET statut = 'en_attente_approbation' 
                        WHERE id_adhesion = ?
                    ");

                    foreach ($adhesions_to_update as $adh) {
                        $id_adhesion = $adh['id_adhesion'];

                        $stmt_adhesion->execute([$id_adhesion]);
                        $stmt_benef->execute([$id_adhesion]);
                        $details = "Adhésion #$id_adhesion mise en attente d'approbation par l'admin (bénéficiaires incomplets)";
                        logActivity($pdo, $_SESSION['user_id'], 'set_pending_adhesion', $details);
                    }

                    $success = count($adhesions_to_update) . " adhésion(s) mise(s) en attente d'approbation avec succès.";
                    error_log(count($adhesions_to_update) . " adhésions mises en attente par admin ID: {$_SESSION['user_id']}");
                    $pdo->commit();
                } else {
                    $errors[] = "Aucune adhésion incomplète trouvée.";
                    $pdo->commit();
                }
            } elseif (isset($_POST['id_adhesion']) && $_POST['action'] === 'set_pending') {
                $id_adhesion = filter_var($_POST['id_adhesion'], FILTER_VALIDATE_INT);

                if ($id_adhesion) {
                    $stmt_adhesion = $pdo->prepare("
                        UPDATE adhesions 
                        SET statut = 'en_attente_validation' 
                        WHERE id_adhesion = ? AND statut = 'active'
                    ");
                    $stmt_adhesion->execute([$id_adhesion]);

                    if ($stmt_adhesion->rowCount() > 0) {
                        $stmt_benef = $pdo->prepare("
                            UPDATE beneficiaires 
                            SET statut = 'en_attente_approbation' 
                            WHERE id_adhesion = ? AND statut = 'actif'
                        ");
                        $stmt_benef->execute([$id_adhesion]);

                        $details = "Adhésion #$id_adhesion mise en attente d'approbation par l'admin (bénéficiaires incomplets)";
                        logActivity($pdo, $_SESSION['user_id'], 'set_pending_adhesion', $details);
                        $success = "Adhésion mise en attente d'approbation avec succès.";
                        $pdo->commit();
                    } else {
                        $pdo->rollBack();
                        $errors[] = "Adhésion non trouvée ou déjà traitée.";
                    }
                } else {
                    $errors[] = "ID d'adhésion invalide.";
                    $pdo->commit();
                }
            } else {
                $errors[] = "Action invalide.";
                $pdo->commit();
            }

            header("Location: admin_manage_adhesions.php?page=$page" . ($success ? "&success=" . urlencode($success) : ""));
            exit();
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = "Erreur lors de la mise à jour des adhésions.";
            error_log("Erreur PDO dans admin_manage_adhesions.php : " . $e->getMessage() . " - Code: " . $e->getCode());
        }
    }
}

// Récupérer les adhésions incomplètes
try {
    if (!$pdo instanceof PDO) {
        $errors[] = "Erreur : Connexion à la base de données non établie.";
        error_log("Connexion PDO non initialisée dans admin_manage_adhesions.php");
    } else {
        // Vérifier si la colonne old_card_photo existe
        $stmt_check = $pdo->query("SHOW COLUMNS FROM adhesions LIKE 'old_card_photo'");
        $old_card_photo_exists = $stmt_check->rowCount() > 0;

        if (!$old_card_photo_exists) {
            $errors[] = "Erreur : La colonne 'old_card_photo' n'existe pas dans la table adhesions.";
            error_log("Colonne old_card_photo manquante dans la table adhesions, utilisateur ID: {$_SESSION['user_id']}");
        } else {
            $stmt = $pdo->prepare("
                SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom, a.date_adhesion, a.type_adhesion, a.statut, 
                       uc.nom AS creator_nom, uc.prenom AS creator_prenom, uc.telephone AS creator_telephone,
                       (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion) AS total_beneficiaires,
                       (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion AND b.photo_path IS NOT NULL AND b.photo_path != '') AS beneficiaire_count_with_photos
                FROM adhesions a 
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                JOIN utilisateurs uc ON a.created_by = uc.id_utilisateur
                WHERE a.statut = 'active'
                AND EXISTS (
                    SELECT 1 
                    FROM beneficiaires b 
                    WHERE b.id_adhesion = a.id_adhesion 
                    AND (b.photo_path IS NULL OR b.photo_path = '')
                )
                ORDER BY a.date_adhesion DESC
                LIMIT ? OFFSET ?
            ");
            $stmt->bindValue(1, (int)$perPage, PDO::PARAM_INT);
            $stmt->bindValue(2, (int)$offset, PDO::PARAM_INT);
            $stmt->execute();
            $adhesions = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Fetch beneficiaries for each adhesion
            $beneficiaries = [];
            foreach ($adhesions as $adhesion) {
                $stmt_benef = $pdo->prepare("
                    SELECT nom, prenom, date_naissance, photo_path
                    FROM beneficiaires 
                    WHERE id_adhesion = ?
                ");
                $stmt_benef->execute([$adhesion['id_adhesion']]);
                $beneficiaries[$adhesion['id_adhesion']] = $stmt_benef->fetchAll(PDO::FETCH_ASSOC);
            }

            $stmt_count = $pdo->query("
                SELECT COUNT(*) 
                FROM adhesions a 
                WHERE a.statut = 'active'
                AND EXISTS (
                    SELECT 1 
                    FROM beneficiaires b 
                    WHERE b.id_adhesion = a.id_adhesion 
                    AND (b.photo_path IS NULL OR b.photo_path = '')
                )
            ");
            $total_adhesions = $stmt_count->fetchColumn() ?: 0;
            $total_pages = ceil($total_adhesions / $perPage);
        }
    }
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des adhésions.";
    error_log("Erreur PDO dans admin_manage_adhesions.php (récupération des adhésions) : " . $e->getMessage() . " - Code: " . $e->getCode());
}

$csrf_token = generateCsrfToken();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Adhésions Incomplètes - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1d4ed8; /* Bleu moderne */
            --secondary: #6b7280; /* Gris neutre */
            --accent: #10b981; /* Vert émeraude */
            --warning: #f59e0b; /* Orange doux */
            --danger: #dc2626; /* Rouge vif */
            --background: #f1f5f9; /* Fond clair */
            --card-bg: #ffffff; /* Fond carte */
            --text: #111827; /* Texte sombre */
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 1rem 0.75rem;
        }

        .card {
            background: var(--card-bg);
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin-bottom: 1.25rem;
        }

        .card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary), #1e3a8a);
            color: white;
            font-weight: 600;
            border-radius: 10px 10px 0 0;
            padding: 0.75rem;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }

        .btn-primary, .btn-success, .btn-danger, .btn-info {
            border-radius: 8px;
            padding: 0.4rem 0.9rem;
            font-weight: 500;
            font-size: 0.85rem;
            min-width: 80px;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
        }

        .btn-primary {
            background: var(--primary);
            border: none;
        }

        .btn-primary:hover {
            background: #1e3a8a;
            transform: scale(1.03);
            box-shadow: 0 3px 10px rgba(37, 99, 235, 0.2);
        }

        .btn-success {
            background: var(--accent);
            border: none;
        }

        .btn-success:hover {
            background: #059669;
            transform: scale(1.03);
            box-shadow: 0 3px 10px rgba(16, 185, 129, 0.2);
        }

        .btn-danger {
            background: var(--danger);
            border: none;
        }

        .btn-danger:hover {
            background: #b91c1c;
            transform: scale(1.03);
            box-shadow: 0 3px 10px rgba(239, 68, 68, 0.2);
        }

        .btn-info {
            background: #17a2b8;
            border: none;
        }

        .btn-info:hover {
            background: #138496;
            transform: scale(1.03);
            box-shadow: 0 3px 10px rgba(23, 162, 184, 0.2);
        }

        .table {
            background: var(--card-bg);
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
        }

        .table thead {
            background: #e5e7eb;
            color: var(--text);
            font-weight: 600;
            font-size: 0.85rem;
        }

        .table tbody tr {
            transition: background 0.2s ease;
        }

        .table tbody tr:hover {
            background: #f3f4f6;
        }

        .table td, .table th {
            padding: 0.6rem;
            font-size: 0.8rem;
            white-space: nowrap;
        }

        .pagination .page-link {
            border-radius: 6px;
            margin: 0 3px;
            color: var(--primary);
            border: 1px solid #d1d5db;
            font-size: 0.85rem;
            padding: 0.4rem 0.7rem;
            transition: all 0.3s ease;
        }

        .pagination .page-item.active .page-link {
            background: var(--primary);
            border-color: var(--primary);
            color: white;
        }

        .pagination .page-link:hover {
            background: #e5e7eb;
            color: var(--primary);
        }

        .search-container {
            position: relative;
            max-width: 100%;
            margin-bottom: 1rem;
        }

        .search-input {
            border-radius: 8px;
            padding: 0.5rem 1rem 0.5rem 2.2rem;
            border: 1px solid #d1d5db;
            width: 100%;
            font-size: 0.85rem;
            transition: all 0.3s ease;
        }

        .search-input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 6px rgba(37, 99, 235, 0.2);
            outline: none;
        }

        .search-icon {
            position: absolute;
            left: 0.6rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary);
            font-size: 0.85rem;
        }

        .alert {
            border-radius: 8px;
            padding: 0.6rem 1rem;
            margin-bottom: 0.75rem;
            font-size: 0.85rem;
            animation: slideIn 0.5s ease-in-out;
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-15px); }
            to { opacity: 1; transform: translateX(0); }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .table thead {
                display: none;
            }

            .table tbody tr {
                display: block;
                margin-bottom: 0.75rem;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                padding: 0.5rem;
                background: var(--card-bg);
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            }

            .table tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: 0.75rem;
                padding: 0.4rem 0.5rem;
                border: none;
            }

            .table tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                font-size: 0.75rem;
                color: var(--secondary);
                width: 40%;
            }

            .table tbody td[data-label="Actions"] {
                display: flex;
                flex-wrap: wrap;
                gap: 0.4rem;
                justify-content: center;
            }

            .search-input {
                font-size: 0.8rem;
                padding: 0.4rem 0.9rem 0.4rem 2rem;
            }

            .search-icon {
                font-size: 0.8rem;
            }

            .pagination .page-link {
                font-size: 0.8rem;
                padding: 0.35rem 0.6rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-person-lines-fill"></i> Gestion des Adhésions Incomplètes
            </div>
            <div class="card-body">
                <!-- Alerts -->
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo htmlspecialchars($_GET['success']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo htmlspecialchars($success); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if ($errors): ?>
                    <?php foreach ($errors as $error): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>

                <!-- Bouton pour mettre toutes les adhésions en attente -->
                <form method="POST" action="" class="mb-3">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                    <input type="hidden" name="action" value="set_pending_all">
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-hourglass-split"></i> Mettre toutes les adhésions incomplètes en attente
                    </button>
                </form>

                <!-- Recherche -->
                <div class="search-container">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" id="search_adhesion" class="form-control search-input" placeholder="Rechercher une adhésion ou un agent..." aria-label="Rechercher une adhésion ou un agent">
                </div>

                <!-- Tableau des adhésions -->
                <div class="table-responsive">
                    <table class="table table-striped table-adhesions">
                        <thead>
                            <tr>
                                <th>ID Adhésion</th>
                                <th>Numéro Adhérent</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Date Adhésion</th>
                                <th>Type</th>
                                <th>Agent Créateur</th>
                                <th>Bénéficiaires</th>
                                <th>Photos</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($adhesions)): ?>
                                <tr><td colspan="10" class="text-center">Aucune adhésion incomplète trouvée.</td></tr>
                            <?php else: ?>
                                <?php foreach ($adhesions as $adhesion): ?>
                                    <tr>
                                        <td data-label="ID Adhésion"><?php echo htmlspecialchars($adhesion['id_adhesion']); ?></td>
                                        <td data-label="Numéro Adhérent"><?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?></td>
                                        <td data-label="Nom"><?php echo htmlspecialchars($adhesion['nom']); ?></td>
                                        <td data-label="Prénom"><?php echo htmlspecialchars($adhesion['prenom']); ?></td>
                                        <td data-label="Date Adhésion"><?php echo htmlspecialchars($adhesion['date_adhesion']); ?></td>
                                        <td data-label="Type"><?php echo htmlspecialchars($adhesion['type_adhesion']); ?></td>
                                        <td data-label="Agent Créateur">
                                            <?php echo htmlspecialchars(($adhesion['creator_nom'] ?? 'N/A') . ' ' . ($adhesion['creator_prenom'] ?? '')); ?>
                                            <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#agentModal<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                                <i class="bi bi-info-circle"></i>
                                            </button>
                                        </td>
                                        <td data-label="Bénéficiaires">
                                            <?php echo htmlspecialchars($adhesion['total_beneficiaires'] ?? '0'); ?>
                                            <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#benefModal<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                                <i class="bi bi-person-lines-fill"></i>
                                            </button>
                                        </td>
                                        <td data-label="Photos"><?php echo htmlspecialchars(($adhesion['beneficiaire_count_with_photos'] ?? '0') . '/' . ($adhesion['total_beneficiaires'] ?? '0')); ?></td>
                                        <td data-label="Actions">
                                            <form method="POST" action="" class="d-inline">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                                <input type="hidden" name="action" value="set_pending">
                                                <input type="hidden" name="id_adhesion" value="<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                                <button type="submit" class="btn btn-primary btn-sm">
                                                    <i class="bi bi-hourglass-split"></i> Mettre en attente
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Pagination des adhésions">
                        <ul class="pagination justify-content-center mt-3">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>">Précédent</a>
                            </li>
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>">Suivant</a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modals pour Détails de l'Agent -->
    <?php if (!empty($adhesions)): ?>
        <?php foreach ($adhesions as $adhesion): ?>
            <div class="modal fade" id="agentModal<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" tabindex="-1" aria-labelledby="agentModalLabel<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="agentModalLabel<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                Détails de l'Agent Créateur
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                        </div>
                        <div class="modal-body">
                            <p><strong>Nom :</strong> <?php echo htmlspecialchars($adhesion['creator_nom'] ?? 'N/A'); ?></p>
                            <p><strong>Prénom :</strong> <?php echo htmlspecialchars($adhesion['creator_prenom'] ?? 'N/A'); ?></p>
                            <p><strong>Téléphone :</strong> <?php echo htmlspecialchars($adhesion['creator_telephone'] ?? 'N/A'); ?></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal pour Détails des Bénéficiaires -->
            <div class="modal fade" id="benefModal<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" tabindex="-1" aria-labelledby="benefModalLabel<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="benefModalLabel<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                Bénéficiaires de l'Adhésion #<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                        </div>
                        <div class="modal-body">
                            <?php if (isset($beneficiaries[$adhesion['id_adhesion']]) && !empty($beneficiaries[$adhesion['id_adhesion']])): ?>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Nom</th>
                                            <th>Prénom</th>
                                            <th>Date de Naissance</th>
                                            <th>Statut Photo</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($beneficiaries[$adhesion['id_adhesion']] as $benef): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($benef['nom'] ?? 'N/A'); ?></td>
                                                <td><?php echo htmlspecialchars($benef['prenom'] ?? 'N/A'); ?></td>
                                                <td><?php echo htmlspecialchars($benef['date_naissance'] ?? 'N/A'); ?></td>
                                                <td>
                                                    <?php 
                                                    echo ($benef['photo_path'] && $benef['photo_path'] !== '') 
                                                        ? '<span class="text-success">Photo présente</span>' 
                                                        : '<span class="text-danger">Aucune photo</span>'; 
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p>Aucun bénéficiaire trouvé pour cette adhésion.</p>
                            <?php endif; ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Recherche en temps réel
        document.getElementById('search_adhesion').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-adhesions tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });
    </script>
</body>
</html>
<?php require_once '../includes/footer.php'; ?>