<?php
// pages/all_beneficiaires.php
require_once '../includes/header.php';
checkRole('agent_mobilisateur');

$errors = [];
$csrf_token = generateCsrfToken();

// Fetch all beneficiaries
$stmt_beneficiaires = $pdo->prepare("
    SELECT b.id_beneficiaire, b.nom, b.prenom, b.date_naissance, b.relation, b.code_beneficiaire, b.statut, a.num_adherent
    FROM beneficiaires b 
    JOIN adhesions a ON b.id_adhesion = a.id_adhesion 
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
    WHERE u.departement = ? AND a.created_by = ? 
    ORDER BY b.date_entree DESC
");
$stmt_beneficiaires->execute([$_SESSION['departement'], $_SESSION['user_id']]);
$beneficiaires = $stmt_beneficiaires->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tous les Bénéficiaires - Agent Mobilisateur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1d4ed8;
            --accent: #059669;
            --danger: #ef4444;
            --warning: #f59e0b;
            --secondary: #6b7280;
            --background: #f1f5f9;
            --card-bg: #ffffff;
            --text: #111827;
            --success-dark: #047857;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #e2e8f0 0%, #dbeafe 100%);
            background-size: 200% 200%;
            color: var(--text);
            min-height: 100vh;
            animation: gradientShift 15s ease infinite;
        }

        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .container {
            max-width: 1200px;
            margin: 3rem auto;
            padding: 0 1.5rem;
        }

        .page-title {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease-in;
        }

        .card {
            border-radius: 16px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
            background: var(--card-bg);
            transition: transform 0.3s ease, box-shadow 0.3s ease, border 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
            border: 2px solid transparent;
            border-image: linear-gradient(45deg, var(--primary), var(--accent)) 1;
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary), #3b82f6);
            color: white;
            font-weight: 600;
            border-radius: 16px 16px 0 0;
            padding: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-body {
            padding: 2rem;
        }

        .table {
            margin-bottom: 0;
            border-radius: 12px;
            overflow: hidden;
            background: var(--card-bg);
        }

        .table th {
            font-weight: 600;
            color: var(--text);
            border-bottom: 2px solid var(--primary);
            padding: 0.75rem;
            font-size: 0.9rem;
        }

        .table td {
            vertical-align: middle;
            padding: 0.75rem;
            font-size: 0.9rem;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .badge {
            font-size: 0.85rem;
            padding: 0.4rem 0.8rem;
            border-radius: 12px;
        }

        .badge-active {
            background-color: var(--accent);
        }

        .badge-en_attente_approbation {
            background-color: var(--warning);
            animation: pulseBadge 2s infinite;
        }

        .badge-rejete {
            background-color: var(--danger);
        }

        .input-group {
            max-width: 400px;
            margin-bottom: 1.5rem;
        }

        .input-group-text {
            background-color: var(--card-bg);
            border: 1px solid var(--primary);
            border-right: none;
            transition: background-color 0.3s ease;
        }

        .form-control {
            border: 1px solid var(--primary);
            border-radius: 8px;
            padding: 0.75rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease, transform 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 10px rgba(29, 78, 216, 0.5);
            transform: scale(1.02);
        }

        .form-control::placeholder {
            color: var(--secondary);
            transition: opacity 0.3s ease;
        }

        .form-control:focus::placeholder {
            opacity: 0;
        }

        .btn-primary, .btn-warning, .btn-info, .btn-secondary {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
        }

        .btn-primary {
            background-color: var(--primary);
            border: none;
        }

        .btn-primary:hover {
            background-color: #1e3a8a;
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(29, 78, 216, 0.5);
        }

        .btn-warning {
            background-color: var(--warning);
            border: none;
        }

        .btn-warning:hover {
            background-color: #d97706;
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(245, 158, 11, 0.5);
        }

        .btn-info {
            background-color: #0ea5e9;
            border: none;
        }

        .btn-info:hover {
            background-color: #0284c7;
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(14, 165, 233, 0.5);
        }

        .btn-secondary {
            background-color: var(--secondary);
            border: none;
        }

        .btn-secondary:hover {
            background-color: #4b5563;
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(107, 114, 128, 0.5);
        }

        .btn-disabled {
            background-color: var(--secondary);
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .btn-disabled:hover {
            transform: none;
            box-shadow: none;
        }

        .alert {
            border-radius: 12px;
            animation: slideIn 0.5s ease-in-out;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem;
        }

        .modal-content {
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .modal-header {
            background: linear-gradient(135deg, var(--primary), #3b82f6);
            color: white;
            border-radius: 15px 15px 0 0;
        }

        .modal.fade .modal-dialog {
            transition: transform 0.3s ease-out, opacity 0.3s ease-out;
            transform: translateY(-50px);
        }

        .modal.show .modal-dialog {
            transform: translateY(0);
        }

        .bi:hover {
            transform: rotate(360deg);
            transition: transform 0.5s ease;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes pulseBadge {
            0% { box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(245, 158, 11, 0); }
            100% { box-shadow: 0 0 0 0 rgba(245, 158, 11, 0); }
        }

        @media (max-width: 768px) {
            .container {
                margin: 1.5rem;
                padding: 0 1rem;
            }
            .page-title {
                font-size: 1.5rem;
            }
            .table th, .table td {
                font-size: 0.75rem;
                padding: 0.5rem;
            }
            .btn-primary, .btn-warning, .btn-info, .btn-secondary, .btn-disabled {
                font-size: 0.75rem;
                padding: 0.4rem 0.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-people me-2"></i>Tous les Bénéficiaires</h2>

        <!-- Messages -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Beneficiaries -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-people me-2"></i>Liste des Bénéficiaires
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" id="search_beneficiaire" class="form-control" placeholder="Rechercher par numéro, nom, prénom...">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-beneficiaires">
                        <thead>
                            <tr>
                                <th><i class="bi bi-person-vcard me-2"></i>Numéro Adhérent</th>
                                <th><i class="bi bi-person me-2"></i>Nom</th>
                                <th><i class="bi bi-person me-2"></i>Prénom</th>
                                <th><i class="bi bi-calendar me-2"></i>Date de Naissance</th>
                                <th><i class="bi bi-link-45deg me-2"></i>Relation</th>
                                <th><i class="bi bi-shield-check me-2"></i>Statut</th>
                                <th><i class="bi bi-gear me-2"></i>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($beneficiaires)): ?>
                                <tr><td colspan="7" class="text-center">Aucun bénéficiaire trouvé.</td></tr>
                            <?php else: ?>
                                <?php foreach ($beneficiaires as $beneficiaire): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($beneficiaire['num_adherent']); ?></td>
                                        <td><?php echo htmlspecialchars($beneficiaire['nom']); ?></td>
                                        <td><?php echo htmlspecialchars($beneficiaire['prenom']); ?></td>
                                        <td><?php echo htmlspecialchars($beneficiaire['date_naissance']); ?></td>
                                        <td><?php echo htmlspecialchars($beneficiaire['relation']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo htmlspecialchars($beneficiaire['statut']); ?>">
                                                <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $beneficiaire['statut']))); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($beneficiaire['statut'] === 'actif'): ?>
                                                <button class="btn btn-disabled btn-sm" disabled data-bs-toggle="tooltip" title="Bénéficiaire validé, modification impossible">
                                                    <i class="bi bi-lock"></i>
                                                </button>
                                            <?php else: ?>
                                                <a href="edit_beneficiaire.php?id=<?php echo htmlspecialchars($beneficiaire['id_beneficiaire']); ?>" class="btn btn-warning btn-sm" data-bs-toggle="tooltip" title="Modifier le bénéficiaire">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Enable tooltips
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

        // Search functionality for beneficiaries table
        document.getElementById('search_beneficiaire').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-beneficiaires tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>