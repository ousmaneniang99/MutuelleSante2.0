<?php
// pages/all_missing_photos.php
require_once '../includes/header.php';
checkRole('agent_mobilisateur');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();

// Pagination settings
$records_per_page = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;

// Search query
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$search_param = $search ? "%$search%" : '%';

// Sorting settings
$allowed_columns = ['num_adherent', 'nom', 'prenom', 'missing_photo_count', 'date_adhesion'];
$sort_column = isset($_GET['sort']) && in_array($_GET['sort'], $allowed_columns) ? $_GET['sort'] : 'date_adhesion';
$sort_order = isset($_GET['order']) && in_array($_GET['order'], ['ASC', 'DESC']) ? $_GET['order'] : 'DESC';
$sort_order_toggle = $sort_order === 'ASC' ? 'DESC' : 'ASC';

// Count total adhesions for pagination
$stmt_count = $pdo->prepare("
    SELECT COUNT(*) as total
    FROM adhesions a 
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
    WHERE u.departement = ? AND a.created_by = ? 
    AND EXISTS (
        SELECT 1 FROM beneficiaires b 
        WHERE b.id_adhesion = a.id_adhesion 
        AND (b.photo_path IS NULL OR b.photo_path = '')
    )
    AND (a.num_adherent LIKE ? OR u.nom LIKE ? OR u.prenom LIKE ?)
");
$stmt_count->execute([$_SESSION['departement'], $_SESSION['user_id'], $search_param, $search_param, $search_param]);
$total_records = $stmt_count->fetchColumn();
$total_pages = ceil($total_records / $records_per_page);

// Fetch adhesions with beneficiaries missing photos
$stmt_missing_photos = $pdo->prepare("
    SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom, a.statut,
           (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion AND (b.photo_path IS NULL OR b.photo_path = '')) as missing_photo_count
    FROM adhesions a 
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
    WHERE u.departement = ? AND a.created_by = ? 
    AND EXISTS (
        SELECT 1 FROM beneficiaires b 
        WHERE b.id_adhesion = a.id_adhesion 
        AND (b.photo_path IS NULL OR b.photo_path = '')
    )
    AND (a.num_adherent LIKE ? OR u.nom LIKE ? OR u.prenom LIKE ?)
    ORDER BY " . $sort_column . " " . $sort_order . "
    LIMIT :limit OFFSET :offset
");
$stmt_missing_photos->bindValue(':limit', $records_per_page, PDO::PARAM_INT);
$stmt_missing_photos->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt_missing_photos->execute([$_SESSION['departement'], $_SESSION['user_id'], $search_param, $search_param, $search_param]);
$adhesions_missing_photos = $stmt_missing_photos->fetchAll(PDO::FETCH_ASSOC);

// Fetch beneficiaries missing photos for each adhesion
$beneficiaries_missing_photos = [];
foreach ($adhesions_missing_photos as $adhesion) {
    $stmt_beneficiaries_missing = $pdo->prepare("
        SELECT id_beneficiaire, nom, prenom, date_naissance, relation, code_beneficiaire, statut, date_entree
        FROM beneficiaires 
        WHERE id_adhesion = ? AND (photo_path IS NULL OR photo_path = '')
        ORDER BY date_entree DESC
    ");
    $stmt_beneficiaries_missing->execute([$adhesion['id_adhesion']]);
    $beneficiaries_missing_photos[$adhesion['id_adhesion']] = $stmt_beneficiaries_missing->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adhésions avec Bénéficiaires sans Photo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1d4ed8;
            --accent: #059669;
            --danger: #ef4444;
            --danger-dark: #b91c1c;
            --danger-darker: #7f1d1d;
            --warning: #f59e0b;
            --secondary: #6b7280;
            --background: #f1f5f9;
            --card-bg: #ffffff;
            --text: #111827;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #e2e8f0 0%, #dbeafe 100%);
            background-size: 200% 200%;
            color: var(--text);
            min-height: 100vh;
            animation: gradientShift 15s ease infinite;
        }

        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .container {
            max-width: 1200px;
            margin: 3rem auto;
            padding: 0 1.5rem;
        }

        .page-title {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease-in;
        }

        .card {
            border-radius: 16px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
            background: var(--card-bg);
            transition: transform 0.3s ease, box-shadow 0.3s ease, border 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 30px rgba(239, 68, 68, 0.4);
            border: 3px solid transparent;
            border-image: linear-gradient(45deg, var(--danger), var(--danger-darker)) 1;
        }

        .card-header {
            background: linear-gradient(135deg, var(--danger), var(--danger-darker));
            color: white;
            font-size: 1.5rem;
            font-weight: 700;
            border-radius: 16px 16px 0 0;
            padding: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            animation: pulseUrgent 1.5s infinite;
        }

        .card-body {
            padding: 2rem;
        }

        .table {
            margin-bottom: 0;
            border-radius: 12px;
            overflow: hidden;
            background: var(--card-bg);
        }

        .table th {
            font-weight: 600;
            color: var(--text);
            border-bottom: 2px solid var(--danger);
            padding: 1rem;
            font-size: 1rem;
        }

        .table th a {
            color: var(--text);
            text-decoration: none;
        }

        .table th a:hover {
            color: var(--danger);
        }

        .table td {
            vertical-align: middle;
            padding: 1rem;
            font-size: 0.95rem;
        }

        .table-striped>tbody>tr:nth-of-type(odd) {
            background-color: rgba(239, 68, 68, 0.1);
        }

        .table-striped>tbody>tr:nth-of-type(even) {
            background-color: var(--card-bg);
        }

        .table-hover>tbody>tr:hover {
            background-color: rgba(239, 68, 68, 0.2);
            transition: background-color 0.3s ease;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .badge {
            font-size: 0.85rem;
            padding: 0.4rem 0.8rem;
            border-radius: 12px;
        }

        .badge-active, .badge-actif {
            background-color: var(--accent);
        }

        .badge-en_attente_validation, .badge-en_attente_approbation {
            background-color: var(--warning);
            animation: pulseBadge 2s infinite;
        }

        .badge-rejete {
            background-color: var(--danger);
        }

        .input-group {
            max-width: 400px;
            margin-bottom: 1.5rem;
        }

        .input-group-text {
            background-color: var(--card-bg);
            border: 1px solid var(--danger);
            border-right: none;
            transition: background-color 0.3s ease;
        }

        .form-control {
            border: 1px solid var(--danger);
            border-radius: 8px;
            padding: 0.75rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease, transform 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--danger);
            box-shadow: 0 0 10px rgba(239, 68, 68, 0.5);
            transform: scale(1.02);
        }

        .form-control::placeholder {
            color: var(--secondary);
            transition: opacity 0.3s ease;
        }

        .form-control:focus::placeholder {
            opacity: 0;
        }

        .btn-primary, .btn-warning, .btn-urgent {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
        }

        .btn-primary {
            background-color: var(--primary);
            border: none;
        }

        .btn-primary:hover {
            background-color: #1e3a8a;
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(29, 78, 216, 0.5);
        }

        .btn-warning {
            background-color: var(--warning);
            border: none;
        }

        .btn-warning:hover {
            background-color: #d97706;
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(245, 158, 11, 0.5);
        }

        .btn-urgent {
            background-color: var(--danger);
            border: none;
            font-size: 0.9rem;
            padding: 0.6rem 1.2rem;
        }

        .btn-urgent:hover {
            background-color: var(--danger-darker);
            transform: scale(1.15);
            box-shadow: 0 0 15px rgba(239, 68, 68, 0.6);
        }

        .btn-sticky {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            background-color: var(--primary);
            color: white;
            border-radius: 12px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease, background-color 0.3s ease;
        }

        .btn-sticky:hover {
            background-color: #1e3a8a;
            transform: scale(1.1);
        }

        .alert {
            border-radius: 12px;
            animation: slideIn 0.5s ease-in-out;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem;
        }

        .modal-content {
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            border: 2px solid var(--danger);
        }

        .modal-header {
            background: linear-gradient(135deg, var(--danger), var(--danger-darker));
            color: white;
            border-radius: 13px 13px 0 0;
            font-weight: 700;
        }

        .modal.fade .modal-dialog {
            transition: transform 0.3s ease-out, opacity 0.3s ease-out;
            transform: translateY(-50px);
        }

        .modal.show .modal-dialog {
            transform: translateY(0);
        }

        .modal-body .table tr {
            animation: fadeInRow 0.5s ease-in;
        }

        .bi-urgent {
            font-size: 1.5rem;
            animation: shake 2s infinite;
        }

        .pagination .page-link {
            color: var(--danger);
            border-radius: 8px;
            margin: 0 3px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .pagination .page-link:hover {
            background-color: var(--danger);
            color: white;
            transform: scale(1.1);
        }

        .pagination .page-item.active .page-link {
            background-color: var(--danger);
            border-color: var(--danger);
            color: white;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInRow {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes pulseUrgent {
            0% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.6); }
            70% { box-shadow: 0 0 0 12px rgba(239, 68, 68, 0); }
            100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
        }

        @keyframes pulseBadge {
            0% { box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(245, 158, 11, 0); }
            100% { box-shadow: 0 0 0 0 rgba(245, 158, 11, 0); }
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-2px); }
            20%, 40%, 60%, 80% { transform: translateX(2px); }
        }

        @media (max-width: 768px) {
            .container {
                margin: 1.5rem;
                padding: 0 1rem;
            }
            .page-title {
                font-size: 1.5rem;
            }
            .card-header {
                font-size: 1.2rem;
            }
            .table th, .table td {
                font-size: 0.8rem;
                padding: 0.6rem;
            }
            .btn-primary, .btn-warning, .btn-urgent {
                font-size: 0.75rem;
                padding: 0.4rem 0.8rem;
            }
            .btn-sticky {
                padding: 0.5rem 1rem;
                font-size: 0.8rem;
            }
            .bi-urgent {
                font-size: 1.2rem;
            }
            .pagination .page-link {
                padding: 0.4rem 0.8rem;
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-exclamation-triangle bi-urgent me-2"></i>Adhésions avec Bénéficiaires sans Photo</h2>

        <!-- Messages -->
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i><?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Search and Table -->
        <div class="card urgent mb-4">
            <div class="card-header">
                <i class="bi bi-exclamation-triangle bi-urgent me-2"></i>Liste des Adhésions avec Bénéficiaires sans Photo
            </div>
            <div class="card-body">
                <form method="GET" class="input-group mb-3">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="Rechercher par numéro, nom, prénom..." value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit" class="btn btn-urgent"><i class="bi bi-search me-2"></i>Rechercher</button>
                </form>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-missing-photos">
                        <thead>
                            <tr>
                                <th><a href="?sort=num_adherent&order=<?php echo $sort_column === 'num_adherent' ? $sort_order_toggle : 'ASC'; ?>&search=<?php echo urlencode($search); ?>"><i class="bi bi-person-vcard me-2"></i>Numéro<?php echo $sort_column === 'num_adherent' ? ($sort_order === 'ASC' ? ' <i class="bi bi-arrow-up"></i>' : ' <i class="bi bi-arrow-down"></i>') : ''; ?></a></th>
                                <th><a href="?sort=nom&order=<?php echo $sort_column === 'nom' ? $sort_order_toggle : 'ASC'; ?>&search=<?php echo urlencode($search); ?>"><i class="bi bi-person me-2"></i>Nom<?php echo $sort_column === 'nom' ? ($sort_order === 'ASC' ? ' <i class="bi bi-arrow-up"></i>' : ' <i class="bi bi-arrow-down"></i>') : ''; ?></a></th>
                                <th><a href="?sort=prenom&order=<?php echo $sort_column === 'prenom' ? $sort_order_toggle : 'ASC'; ?>&search=<?php echo urlencode($search); ?>"><i class="bi bi-person me-2"></i>Prénom<?php echo $sort_column === 'prenom' ? ($sort_order === 'ASC' ? ' <i class="bi bi-arrow-up"></i>' : ' <i class="bi bi-arrow-down"></i>') : ''; ?></a></th>
                                <th><a href="?sort=missing_photo_count&order=<?php echo $sort_column === 'missing_photo_count' ? $sort_order_toggle : 'ASC'; ?>&search=<?php echo urlencode($search); ?>"><i class="bi bi-camera me-2"></i>Bénéficiaires sans Photo<?php echo $sort_column === 'missing_photo_count' ? ($sort_order === 'ASC' ? ' <i class="bi bi-arrow-up"></i>' : ' <i class="bi bi-arrow-down"></i>') : ''; ?></a></th>
                                <th><i class="bi bi-gear me-2"></i>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($adhesions_missing_photos)): ?>
                                <tr><td colspan="5" class="text-center">Aucun bénéficiaire sans photo trouvé.</td></tr>
                            <?php else: ?>
                                <?php foreach ($adhesions_missing_photos as $adhesion): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($adhesion['num_adherent']); ?></td>
                                        <td><?php echo htmlspecialchars($adhesion['nom']); ?></td>
                                        <td><?php echo htmlspecialchars($adhesion['prenom']); ?></td>
                                        <td><?php echo htmlspecialchars($adhesion['missing_photo_count']); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-urgent btn-sm" data-bs-toggle="modal" data-bs-target="#missingPhotosModal<?php echo $adhesion['id_adhesion']; ?>" data-bs-toggle="tooltip" title="Voir les bénéficiaires sans photo">
                                                <i class="bi bi-eye"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Pagination" class="mt-3">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&sort=<?php echo $sort_column; ?>&order=<?php echo $sort_order; ?>&search=<?php echo urlencode($search); ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&sort=<?php echo $sort_column; ?>&order=<?php echo $sort_order; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&sort=<?php echo $sort_column; ?>&order=<?php echo $sort_order; ?>&search=<?php echo urlencode($search); ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sticky Back to Dashboard Button -->
        <a href="dashboard_agent.php" class="btn btn-sticky" data-bs-toggle="tooltip" title="Retour au tableau de bord">
            <i class="bi bi-speedometer2 me-2"></i>Retour au Dashboard
        </a>

        <!-- Modals for Beneficiaries Missing Photos -->
        <?php foreach ($adhesions_missing_photos as $adhesion): ?>
            <?php if (!empty($beneficiaries_missing_photos[$adhesion['id_adhesion']])): ?>
                <div class="modal fade" id="missingPhotosModal<?php echo $adhesion['id_adhesion']; ?>" tabindex="-1" aria-labelledby="missingPhotosModalLabel<?php echo $adhesion['id_adhesion']; ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="missingPhotosModalLabel<?php echo $adhesion['id_adhesion']; ?>">
                                    Bénéficiaires sans Photo pour <?php echo htmlspecialchars($adhesion['num_adherent'] . ' - ' . $adhesion['nom'] . ' ' . $adhesion['prenom']); ?>
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th><i class="bi bi-person-vcard me-2"></i>Code</th>
                                                <th><i class="bi bi-person me-2"></i>Nom</th>
                                                <th><i class="bi bi-person me-2"></i>Prénom</th>
                                                <th><i class="bi bi-calendar me-2"></i>Date de Naissance</th>
                                                <th><i class="bi bi-link-45deg me-2"></i>Relation</th>
                                                <th><i class="bi bi-shield-check me-2"></i>Statut</th>
                                                <th><i class="bi bi-gear me-2"></i>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($beneficiaries_missing_photos[$adhesion['id_adhesion']] as $beneficiary): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($beneficiary['code_beneficiaire']); ?></td>
                                                    <td><?php echo htmlspecialchars($beneficiary['nom']); ?></td>
                                                    <td><?php echo htmlspecialchars($beneficiary['prenom']); ?></td>
                                                    <td><?php echo htmlspecialchars($beneficiary['date_naissance']); ?></td>
                                                    <td><?php echo htmlspecialchars($beneficiary['relation']); ?></td>
                                                    <td>
                                                        <span class="badge badge-<?php echo htmlspecialchars($beneficiary['statut']); ?>">
                                                            <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $beneficiary['statut']))); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php if ($adhesion['statut'] === 'active'): ?>
                                                            <button class="btn btn-disabled btn-sm" disabled data-bs-toggle="tooltip" title="Bénéficiaire validé, modification impossible">
                                                                <i class="bi bi-lock"></i>
                                                            </button>
                                                        <?php else: ?>
                                                            <a href="edit_beneficiaire.php?id=<?php echo htmlspecialchars($beneficiary['id_beneficiaire']); ?>" class="btn btn-warning btn-sm" data-bs-toggle="tooltip" title="Modifier le bénéficiaire">
                                                                <i class="bi bi-pencil"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-urgent" data-bs-dismiss="modal">
                                    <i class="bi bi-x-circle me-2"></i>Fermer
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Enable tooltips
        document.addEventListener('shown.bs.modal', function () {
            const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
            tooltipTriggerList.forEach(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
        });

        // Client-side search fallback
        document.querySelector('input[name="search"]').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-missing-photos tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>