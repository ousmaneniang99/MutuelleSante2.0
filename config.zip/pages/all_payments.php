<?php
// pages/all_payments.php
require_once '../includes/header.php';
checkRole('agent_mobilisateur');

$errors = [];
$csrf_token = generateCsrfToken();

// Fetch all payments
$stmt_paiements = $pdo->prepare("
    SELECT p.id_paiement, a.num_adherent, p.date_paiement, p.montant_verse, p.methode, p.reference_transaction 
    FROM paiements p 
    JOIN adhesions a ON p.id_adhesion = a.id_adhesion 
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
    WHERE u.departement = ? AND a.created_by = ? 
    ORDER BY p.date_paiement DESC
");
$stmt_paiements->execute([$_SESSION['departement'], $_SESSION['user_id']]);
$paiements = $stmt_paiements->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tous les Paiements - Agent Mobilisateur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }
        .container {
            max-width: 1200px;
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .card-header {
            border-bottom: none;
            padding: 1.5rem;
            font-size: 1.25rem;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .table {
            border-radius: 8px;
            overflow: hidden;
        }
        .table th {
            background-color: #e9ecef;
            font-weight: 600;
            color: #2c3e50;
        }
        .table td, .table th {
            padding: 1rem;
            vertical-align: middle;
        }
        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-wallet2 me-2"></i>Tous les Paiements</h2>
        <div class="card">
            <div class="card-header bg-primary text-white">
                <i class="bi bi-wallet2 me-2"></i>Liste des Paiements
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" id="search_paiement" class="form-control" placeholder="Rechercher par numéro, date, référence...">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-paiements">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Numéro Adhérent</th>
                                <th>Date</th>
                                <th>Montant</th>
                                <th>Méthode</th>
                                <th>Référence</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($paiements)): ?>
                                <tr><td colspan="6" class="text-center">Aucun paiement trouvé.</td></tr>
                            <?php else: ?>
                                <?php foreach ($paiements as $paiement): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($paiement['id_paiement']); ?></td>
                                        <td><?php echo htmlspecialchars($paiement['num_adherent']); ?></td>
                                        <td><?php echo htmlspecialchars($paiement['date_paiement']); ?></td>
                                        <td><?php echo htmlspecialchars(formatFCFA($paiement['montant_verse'])); ?></td>
                                        <td><?php echo htmlspecialchars($paiement['methode']); ?></td>
                                        <td><?php echo htmlspecialchars($paiement['reference_transaction']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Search functionality for payments table
        document.getElementById('search_paiement').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-paiements tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>