```chartjs
{
    "type": "line",
    "data": {
        "labels": [
            <?php
            $stmt = $pdo->query("SELECT DISTINCT DATE_FORMAT(date_soin, '%Y-%m') AS mois FROM demandes_remboursement WHERE id_prestataire = ? ORDER BY mois DESC LIMIT 6");
            $stmt->execute([$_SESSION['user_id']]);
            $mois = $stmt->fetchAll(PDO::FETCH_COLUMN);
            echo '"' . implode('","', array_reverse($mois)) . '"';
            ?>
        ],
        "datasets": [
            {
                "label": "Montant Remboursé (FCFA)",
                "data": [
                    <?php
                    $stmt = $pdo->prepare("SELECT DATE_FORMAT(date_soin, '%Y-%m') AS mois, SUM(montant_rembourse) AS total FROM demandes_remboursement WHERE id_prestataire = ? AND statut = 'approuve' GROUP BY mois ORDER BY mois DESC LIMIT 6");
                    $stmt->execute([$_SESSION['user_id']]);
                    $totals = $stmt->fetchAll(PDO::FETCH_COLUMN, 1);
                    echo implode(',', array_reverse($totals));
                    ?>
                ],
                "borderColor": "#28a745",
                "backgroundColor": "rgba(40, 167, 69, 0.2)",
                "fill": true
            }
        ]
    },
    "options": {
        "scales": {
            "y": {
                "beginAtZero": true,
                "title": {
                    "display": true,
                    "text": "Montant (FCFA)"
                }
            },
            "x": {
                "title": {
                    "display": true,
                    "text": "Mois"
                }
            }
        },
        "plugins": {
            "legend": {
                "display": true,
                "position": "top"
            },
            "title": {
                "display": true,
                "text": "Évolution des Remboursements par Mois"
            }
        }
    }
}
```