<?php
// pages/confirmation_paiements.php
require_once __DIR__ . '/../includes/header.php';
checkRole('comptable');

$user_id = $_SESSION['user_id'];
$departement_id = $_SESSION['departement'];

try {
    $stmt = $pdo->prepare("SELECT nom FROM departements WHERE id_departement = ?");
    $stmt->execute([$departement_id]);
    $departement_nom = $stmt->fetchColumn() ?: 'Inconnu';
} catch (Exception $e) {
    $departement_nom = 'Inconnu';
}

// Nombre total en attente (pour badge)
try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM paiements p 
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion 
        WHERE p.statut = 'en_attente' AND a.departement = ?
    ");
    $stmt->execute([$departement_id]);
    $nb_en_attente = $stmt->fetchColumn();
} catch (Exception $e) {
    $nb_en_attente = 0;
}

// Traitement confirmation
$errors = $success = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_payment'])) {
    $id_paiement = (int)$_POST['id_paiement'];
    $transaction_id = trim($_POST['transaction_id'] ?? '');

    if (empty($transaction_id)) {
        $errors[] = "La référence de transaction est obligatoire.";
    } else {
        try {
            $stmt = $pdo->prepare("
                UPDATE paiements p
                JOIN adhesions a ON p.id_adhesion = a.id_adhesion
                SET p.statut = 'paye',
                    p.reference_transaction = ?,
                    p.date_confirmation = NOW(),
                    p.confirmed_by = ?
                WHERE p.id_paiement = ?
                  AND p.statut = 'en_attente'
                  AND a.departement = ?
            ");
            $stmt->execute([$transaction_id, $user_id, $id_paiement, $departement_id]);

            if ($stmt->rowCount() > 0) {
                $success[] = "Paiement n°$id_paiement confirmé avec succès.";
            } else {
                $errors[] = "Ce paiement n'existe plus ou a déjà été traité.";
            }
        } catch (Exception $e) {
            $errors[] = "Erreur système : " . $e->getMessage();
        }
    }
}

// Recherche + liste paiements en attente
$search_term = trim($_GET['search'] ?? '');
$pending_payments = [];

try {
    $where = "WHERE p.statut = 'en_attente' AND a.departement = :dept";
    $params = [':dept' => $departement_id];

    if ($search_term) {
        $where .= " AND (a.num_adherent LIKE :search 
                       OR p.methode LIKE :search 
                       OR CONCAT(u.nom, ' ', u.prenom) LIKE :search 
                       OR p.reference_transaction LIKE :search)";
        $params[':search'] = '%' . $search_term . '%';
    }

    $stmt = $pdo->prepare("
        SELECT p.*, a.num_adherent, CONCAT(u.nom, ' ', u.prenom) AS agent_nom
        FROM paiements p
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion
        LEFT JOIN utilisateurs u ON a.created_by = u.id_utilisateur
        $where
        ORDER BY p.date_paiement DESC
    ");
    $stmt->execute($params);
    $pending_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $errors[] = "Erreur lors du chargement des paiements : " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiements à Valider - <?= htmlspecialchars($departement_nom) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: #1d4ed8;
            --success: #198754;
            --warning: #ffc107;
            --danger: #dc3545;
            --light: #f8f9fa;
        }
        body { background: linear-gradient(135deg, #f8f9fa, #e9ecef); min-height: 100vh; }
        .header-hero {
            background: linear-gradient(135deg, var(--primary), #3b82f6);
            color: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }
        .badge-en-attente {
            font-size: 0.9rem;
            padding: 0.5em 0.9em;
        }
        .table th, .table td { vertical-align: middle; }
        .btn-confirm {
            min-width: 110px;
        }
        .modal-content { border-radius: 12px; }
        .modal-header { background: var(--primary); color: white; }
    </style>
</head>
<body>

<div class="container py-4">

    <!-- Header -->
    <div class="header-hero text-center">
        <h1 class="mb-1">
            <i class="bi bi-check2-circle me-2"></i>
            Paiements à Valider
            <?php if ($nb_en_attente > 0): ?>
                <span class="badge bg-danger badge-en-attente ms-2"><?= $nb_en_attente ?></span>
            <?php endif; ?>
        </h1>
        <p class="mb-0">Département : <strong><?= htmlspecialchars($departement_nom) ?></strong></p>
    </div>

    <!-- Messages -->
    <?php if ($errors): ?>
        <?php foreach ($errors as $err): ?>
            <div class="alert alert-danger d-flex align-items-center">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?= htmlspecialchars($err) ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <?php if ($success): ?>
        <?php foreach ($success as $msg): ?>
            <div class="alert alert-success d-flex align-items-center">
                <i class="bi bi-check-circle-fill me-2"></i>
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Recherche -->
    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <form method="GET" class="d-flex gap-2 flex-wrap">
                <input type="text" name="search" class="form-control" 
                       placeholder="Rechercher adhérent, méthode, agent ou référence..." 
                       value="<?= htmlspecialchars($search_term) ?>">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-search"></i> Filtrer
                </button>
                <?php if ($search_term): ?>
                    <a href="?year=<?= $year ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-x-lg"></i> Effacer
                    </a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- Tableau -->
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <i class="bi bi-list-ul me-2"></i>Liste des paiements en attente
        </div>
        <div class="card-body p-0">
            <?php if (empty($pending_payments)): ?>
                <div class="alert alert-info m-3 text-center">
                    <i class="bi bi-info-circle me-2"></i>Aucun paiement en attente pour le moment.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover table-striped mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th>N° Adhérent</th>
                                <th>Montant</th>
                                <th>Méthode</th>
                                <th>Date</th>
                                <th>Agent</th>
                                <th>Réf. Transaction</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($pending_payments as $p): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($p['num_adherent']) ?></strong></td>
                                    <td><?= number_format($p['montant_verse'], 0, ',', ' ') ?> FCFA</td>
                                    <td><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $p['methode']))) ?></td>
                                    <td><?= date('d/m/Y', strtotime($p['date_paiement'])) ?></td>
                                    <td><?= htmlspecialchars($p['agent_nom'] ?: '—') ?></td>
                                    <td>
                                        <?php if ($p['reference_transaction']): ?>
                                            <code><?= htmlspecialchars($p['reference_transaction']) ?></code>
                                        <?php else: ?>
                                            <span class="text-muted">Non saisi</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-success btn-sm btn-confirm" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#modalConfirm<?= $p['id_paiement'] ?>">
                                            <i class="bi bi-check-circle"></i> Valider
                                        </button>
                                    </td>
                                </tr>

                                <!-- Modal -->
                                <div class="modal fade" id="modalConfirm<?= $p['id_paiement'] ?>" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Valider le paiement</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p><strong>Adhérent :</strong> <?= htmlspecialchars($p['num_adherent']) ?></p>
                                                <p><strong>Montant :</strong> <?= number_format($p['montant_verse'], 0, ',', ' ') ?> FCFA</p>
                                                <p><strong>Méthode :</strong> <?= htmlspecialchars(ucfirst($p['methode'])) ?></p>
                                                <p><strong>Réf. initiale :</strong> 
                                                    <?= $p['reference_transaction'] ? htmlspecialchars($p['reference_transaction']) : '—' ?>
                                                </p>
                                                <hr>
                                                <form method="POST">
                                                    <input type="hidden" name="id_paiement" value="<?= $p['id_paiement'] ?>">
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold">Référence de transaction (corrigez si besoin)</label>
                                                        <input type="text" name="transaction_id" class="form-control" 
                                                               value="<?= htmlspecialchars($p['reference_transaction'] ?? '') ?>" 
                                                               placeholder="Ex: WAV-XXXXXX ou OM-XXXXXX" 
                                                               required autofocus>
                                                    </div>
                                                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                                                        <button type="submit" name="confirm_payment" class="btn btn-success">
                                                            <i class="bi bi-check-lg"></i> Confirmer le paiement
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php require_once '../includes/footer.php'; ?>