<?php
// pages/dashboard_admin.php
ob_start();
require_once '../includes/header.php';
checkSessionTimeout();
checkRole('admin');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();
$periode = $_GET['periode'] ?? 'mois';

// INITIALISATION KPI GLOBAUX
$total_adherents = 0;
$total_beneficiaires = 0;
$total_cotisations = 0;
$adhesions_en_attente = 0;
$chart_data = [];
$departements_kpi = [];

// Liste des départements
$departements = [];

if (isset($pdo)) {
    try {
        // Récupérer tous les départements
        try {
            $stmt = $pdo->prepare("SELECT id_departement, nom FROM departements");
            $stmt->execute();
            $departements = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Erreur récupération départements : " . $e->getMessage());
            $departements = [];
        }

        // KPI globaux
        $stmt = $pdo->prepare("
            SELECT COUNT(DISTINCT u.id_utilisateur) as total 
            FROM utilisateurs u JOIN adhesions a ON u.id_utilisateur = a.id_utilisateur 
            WHERE a.statut = 'active' AND u.statut = 'actif'
        ");
        $stmt->execute();
        $total_adherents = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare("
            SELECT COUNT(*) as total 
            FROM beneficiaires b JOIN adhesions a ON b.id_adhesion = a.id_adhesion 
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
            WHERE b.statut = 'actif' AND a.statut = 'active'
        ");
        $stmt->execute();
        $total_beneficiaires = (int)$stmt->fetchColumn();

        $date_filter = match($periode) {
            'mois' => "DATE_SUB(CURDATE(), INTERVAL 30 DAY)",
            'trimestre' => "DATE_SUB(CURDATE(), INTERVAL 90 DAY)",
            'annee' => "DATE_SUB(CURDATE(), INTERVAL 365 DAY)",
            default => "DATE_SUB(CURDATE(), INTERVAL 30 DAY)"
        };

        $stmt = $pdo->prepare("
            SELECT COALESCE(SUM(p.montant_verse), 0) as total 
            FROM paiements p JOIN adhesions a ON p.id_adhesion = a.id_adhesion 
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
            WHERE p.statut = 'paye' AND p.date_paiement >= $date_filter
        ");
        $stmt->execute();
        $total_cotisations = (float)$stmt->fetchColumn();

        $stmt = $pdo->prepare("
            SELECT COUNT(*) as total 
            FROM adhesions a JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
            WHERE a.statut = 'en_attente_validation'
        ");
        $stmt->execute();
        $adhesions_en_attente = (int)$stmt->fetchColumn();

        // KPI par département
        $departements_kpi = [];
        if (!empty($departements)) {
            foreach ($departements as $dept) {
                $dept_id = $dept['id_departement'];
                try {
                    $stmt = $pdo->prepare("
                        SELECT 
                            COUNT(DISTINCT u.id_utilisateur) as adherents, 
                            COUNT(b.id_beneficiaire) as beneficiaires
                        FROM utilisateurs u 
                        JOIN adhesions a ON u.id_utilisateur = a.id_utilisateur 
                        LEFT JOIN beneficiaires b ON a.id_adhesion = b.id_adhesion
                        WHERE u.departement = ? AND a.statut = 'active'
                    ");
                    $stmt->execute([$dept_id]);
                    $dept_kpi = $stmt->fetch(PDO::FETCH_ASSOC);
                    $adherents = (int)($dept_kpi['adherents'] ?? 0);
                    $benef = (int)($dept_kpi['beneficiaires'] ?? 0);
                    $moyenne = $adherents > 0 ? round($benef / $adherents, 1) : 0;
                    $departements_kpi[] = array_merge($dept, ['adherents' => $adherents, 'beneficiaires' => $benef, 'moyenne' => $moyenne]);
                } catch (PDOException $e) {
                    error_log("Erreur KPI département $dept_id : " . $e->getMessage());
                }
            }
        }

        // Données pour graphiques
        $chart_data = [
            'adhesions_evol' => [],
            'cotisations_periode' => [],
            'adhesions_evol_dept' => [],
            'distribution_dept' => [], // Données pour pie chart distribution par département
            'cotisations_bar' => [], // Données pour bar chart cotisations par département
            'beneficiaires_evol' => [], // Nouveau: Évolution des bénéficiaires (30j)
            'distribution_benef' => [] // Nouveau: Distribution des bénéficiaires par département
        ];

        try {
            $stmt = $pdo->prepare("
                SELECT DATE(a.date_adhesion) as date, COUNT(*) as count
                FROM adhesions a WHERE a.statut = 'active'
                AND a.date_adhesion >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                GROUP BY DATE(a.date_adhesion) ORDER BY date ASC
            ");
            $stmt->execute();
            $chart_data['adhesions_evol'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Erreur chart adhesions_evol : " . $e->getMessage());
        }

        try {
            $stmt = $pdo->prepare("
                SELECT DATE(p.date_paiement) as date, SUM(p.montant_verse) as montant
                FROM paiements p WHERE p.statut = 'paye' 
                AND p.date_paiement >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                GROUP BY DATE(p.date_paiement) ORDER BY date ASC
            ");
            $stmt->execute();
            $chart_data['cotisations_periode'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Erreur chart cotisations_periode : " . $e->getMessage());
        }

        // Graphique évolution adhésions par département
        try {
            $stmt = $pdo->prepare("
                SELECT DATE(a.date_adhesion) as date, u.departement, COUNT(*) as count
                FROM adhesions a 
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                WHERE a.statut = 'active' AND a.date_adhesion >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                GROUP BY date, u.departement
                ORDER BY date ASC, u.departement
            ");
            $stmt->execute();
            $adhesions_evol_dept_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Traitement des données
            $dates = [];
            $grouped = [];
            foreach ($adhesions_evol_dept_raw as $row) {
                $dept_id = (int)$row['departement'];
                $date = $row['date'];
                $grouped[$dept_id][$date] = (int)$row['count'];
                $dates[$date] = true;
            }
            ksort($dates);
            $dates_list = array_keys($dates);

            $datasets = [];
            $colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];
            $i = 0;
            $dept_map = array_column($departements, 'nom', 'id_departement');
            foreach ($grouped as $dept_id => $data) {
                $counts = [];
                foreach ($dates_list as $date) {
                    $counts[] = $data[$date] ?? 0;
                }
                $dept_nom = $dept_map[$dept_id] ?? 'Inconnu';
                $datasets[] = [
                    'label' => $dept_nom,
                    'data' => $counts,
                    'borderColor' => $colors[$i % count($colors)],
                    'backgroundColor' => substr($colors[$i % count($colors)], 0, 7) . '20',
                    'tension' => 0.4,
                    'fill' => false
                ];
                $i++;
            }

            $chart_data['adhesions_evol_dept'] = [
                'dates' => $dates_list,
                'datasets' => $datasets
            ];
        } catch (PDOException $e) {
            error_log("Erreur chart adhesions_evol_dept : " . $e->getMessage());
        }

        // Distribution des adhérents par département (pour pie chart)
        try {
            $stmt = $pdo->prepare("
                SELECT u.departement, COUNT(DISTINCT u.id_utilisateur) as count
                FROM utilisateurs u JOIN adhesions a ON u.id_utilisateur = a.id_utilisateur 
                WHERE a.statut = 'active' AND u.statut = 'actif'
                GROUP BY u.departement
                ORDER BY count DESC
            ");
            $stmt->execute();
            $chart_data['distribution_dept'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $dept_map = array_column($departements, 'nom', 'id_departement');
            foreach ($chart_data['distribution_dept'] as &$row) {
                $row['label'] = $dept_map[(int)$row['departement']] ?? 'Inconnu';
            }
        } catch (PDOException $e) {
            error_log("Erreur chart distribution_dept : " . $e->getMessage());
        }

        // Cotisations par département (pour bar chart)
        try {
            $stmt = $pdo->prepare("
                SELECT u.departement, COALESCE(SUM(p.montant_verse), 0) as total
                FROM paiements p 
                JOIN adhesions a ON p.id_adhesion = a.id_adhesion 
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                WHERE p.statut = 'paye' AND p.date_paiement >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                GROUP BY u.departement
                ORDER BY total DESC
            ");
            $stmt->execute();
            $chart_data['cotisations_bar'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $dept_map = array_column($departements, 'nom', 'id_departement');
            foreach ($chart_data['cotisations_bar'] as &$row) {
                $row['label'] = $dept_map[(int)$row['departement']] ?? 'Inconnu';
            }
        } catch (PDOException $e) {
            error_log("Erreur chart cotisations_bar : " . $e->getMessage());
        }

        // Nouveau: Évolution des bénéficiaires (30j)
        try {
            $stmt = $pdo->prepare("
                SELECT DATE(b.date_creation) as date, COUNT(*) as count
                FROM beneficiaires b 
                JOIN adhesions a ON b.id_adhesion = a.id_adhesion 
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                WHERE b.statut = 'actif' AND a.statut = 'active'
                AND b.date_creation >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                GROUP BY DATE(b.date_creation) ORDER BY date ASC
            ");
            $stmt->execute();
            $chart_data['beneficiaires_evol'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Erreur chart beneficiaires_evol : " . $e->getMessage());
        }

        // Nouveau: Distribution des bénéficiaires par département (pour doughnut chart)
        try {
            $stmt = $pdo->prepare("
                SELECT u.departement, COUNT(b.id_beneficiaire) as count
                FROM beneficiaires b 
                JOIN adhesions a ON b.id_adhesion = a.id_adhesion 
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                WHERE b.statut = 'actif' AND a.statut = 'active'
                GROUP BY u.departement
                ORDER BY count DESC
            ");
            $stmt->execute();
            $chart_data['distribution_benef'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $dept_map = array_column($departements, 'nom', 'id_departement');
            foreach ($chart_data['distribution_benef'] as &$row) {
                $row['label'] = $dept_map[(int)$row['departement']] ?? 'Inconnu';
            }
        } catch (PDOException $e) {
            error_log("Erreur chart distribution_benef : " . $e->getMessage());
        }

    } catch (PDOException $e) {
        $errors[] = "Erreur base de données générale : " . $e->getMessage();
        error_log("Dashboard admin erreur générale : " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🛡️ Dashboard Admin Global - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-medical: linear-gradient(135deg, #1e3a8a, #3b82f6, #1d4ed8);
            --success-health: linear-gradient(135deg, #15803d, #22c55e, #16a34a);
            --warning-gold: linear-gradient(135deg, #d97706, #f59e0b, #b45309);
            --danger-alert: linear-gradient(135deg, #dc2626, #ef4444, #b91c1c);
            --glass-bg: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
            --shadow-glow: 0 25px 50px -12px rgba(59, 130, 246, 0.3);
            --shadow-hover: 0 35px 60px -15px rgba(59, 130, 246, 0.3);
        }

        * { font-family: 'Inter', sans-serif; }
        body { 
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 50%, #f0f9ff 100%);
            min-height: 100vh; 
            overflow-x: hidden;
            position: relative;
        }
        body::before {
            content: ''; 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%;
            background: radial-gradient(circle at 20% 50%, rgba(120, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 40% 80%, rgba(120, 219, 255, 0.1) 0%, transparent 50%);
            z-index: -1;
        }

        /* HEADER HERO */
        .header-hero {
            background: var(--primary-medical);
            border-radius: 24px; 
            padding: 2rem; 
            color: white; 
            margin-bottom: 2rem;
            position: relative; 
            overflow: hidden; 
            box-shadow: var(--shadow-glow);
            backdrop-filter: blur(20px);
        }
        .header-hero::before {
            content: ''; 
            position: absolute; 
            top: -50%; 
            left: -50%; 
            width: 200%; 
            height: 200%;
            background: conic-gradient(from 0deg, transparent, rgba(255,255,255,0.1), transparent 30%);
            animation: rotate 20s linear infinite; 
            opacity: 0.3;
        }
        @keyframes rotate { 100% { transform: rotate(360deg); } }
        .logo-hero {
            width: 80px; 
            height: 80px; 
            border-radius: 50%; 
            background: var(--glass-bg);
            display: flex; 
            align-items: center; 
            justify-content: center; 
            margin: 0 auto 1rem;
            backdrop-filter: blur(10px); 
            border: 2px solid var(--glass-border);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2); 
            animation: pulse 2s infinite;
        }
        .logo-hero img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
        @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.05); } }
        .header-title { 
            font-size: 2.2rem; 
            font-weight: 800; 
            margin-bottom: 0.5rem;
            background: linear-gradient(45deg, #fff, #e0f2fe); 
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent; 
            text-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header-subtitle { 
            font-size: 1.1rem; 
            opacity: 0.95; 
            font-weight: 400; 
            max-width: 700px; 
            margin: 0 auto;
        }

        /* BOUTONS D'ACTION */
        .actions-glass {
            background: var(--glass-bg); 
            backdrop-filter: blur(20px); 
            border-radius: 20px;
            padding: 1.5rem; 
            margin-bottom: 2rem; 
            border: 1px solid var(--glass-border);
            box-shadow: var(--shadow-glow);
        }
        .btn-glass {
            background: var(--glass-bg); 
            backdrop-filter: blur(20px); 
            border: 1px solid var(--glass-border);
            color: #1e40af; 
            font-weight: 600; 
            padding: 0.75rem 1.5rem; 
            border-radius: 15px;
            transition: all 0.3s ease; 
            margin: 0.25rem; 
            position: relative; 
            overflow: hidden;
        }
        .btn-glass::before {
            content: ''; 
            position: absolute; 
            top: 0; 
            left: -100%; 
            width: 100%; 
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            transition: left 0.5s;
        }
        .btn-glass:hover::before { left: 100%; }
        .btn-glass:hover { 
            transform: translateY(-3px) scale(1.05); 
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.2); 
            color: #1e40af;
        }
        .btn-primary-glass { background: linear-gradient(135deg, rgba(59,130,246,0.2), rgba(59,130,246,0.1)); }
        .btn-success-glass { background: linear-gradient(135deg, rgba(34,197,94,0.2), rgba(34,197,94,0.1)); }
        .btn-info-glass { background: linear-gradient(135deg, rgba(14,165,233,0.2), rgba(14,165,233,0.1)); }

        /* KPI CARDS */
        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .kpi-card {
            background: rgba(255,255,255,0.9);
            border-radius: 10px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: var(--shadow-glow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px);
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }
        .kpi-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-medical);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }
        .kpi-card:hover::before { transform: scaleX(1); }
        .kpi-card:hover {
            transform: translateY(-8px) rotateX(5deg);
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.95);
        }
        .kpi-link {
            text-decoration: none;
            color: inherit;
            display: block;
        }
        .kpi-link:hover .kpi-card {
            transform: translateY(-8px) rotateX(5deg);
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.95);
        }
        .kpi-link:hover .kpi-icon {
            transform: scale(1.1) rotate(360deg);
        }
        .kpi-icon {
            font-size: 2.5rem;
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        .kpi-value {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            background: var(--primary-medical);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .kpi-label {
            font-size: 1rem;
            font-weight: 600;
            color: #1e293b;
        }

        /* CHARTS */
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(380px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .chart-card {
            background: rgba(255,255,255,0.9);
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: var(--shadow-glow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px);
            height: 400px;
            position: relative;
        }
        .chart-header {
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            position: relative;
        }
        .chart-header::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 50px;
            height: 3px;
            background: var(--primary-medical);
            border-radius: 2px;
        }
        .chart-icon { font-size: 1.3rem; }

        /* BREAKDOWN TABLE */
        .breakdown-card {
            background: rgba(255,255,255,0.9);
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: var(--shadow-glow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px);
        }
        .table {
            margin-bottom: 0;
        }
        .table th {
            font-weight: 600;
            color: #1e293b;
            border-bottom: 2px solid rgba(59, 130, 246, 0.2);
        }
        .table td {
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        /* ALERTES */
        .alert-custom {
            border: none;
            border-radius: 15px;
            padding: 1rem 1.5rem;
            box-shadow: var(--shadow-glow);
            backdrop-filter: blur(10px);
            animation: slideInDown 0.5s ease;
        }
        @keyframes slideInDown {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        /* ANIMATIONS */
        .fade-in-up { 
            animation: fadeInUp 0.8s ease forwards; 
            opacity: 0;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .bounce-in { animation: bounceIn 0.6s ease; }
        @keyframes bounceIn {
            0% { transform: scale(0.3); opacity: 0; }
            50% { transform: scale(1.05); }
            70% { transform: scale(0.9); }
            100% { transform: scale(1); opacity: 1; }
        }

        /* RESPONSIVE */
        @media (max-width: 768px) {
            .header-title { font-size: 1.8rem; }
            .logo-hero { width: 60px; height: 60px; }
            .kpi-grid, .charts-grid { grid-template-columns: 1fr; }
            .actions-glass { padding: 1rem; }
            .btn-glass { font-size: 0.85rem; padding: 0.5rem 1rem; }
            .table-responsive { font-size: 0.85rem; }
        }
    </style>
</head>
<body>
    <div class="container py-4 px-3 position-relative">
        <!-- LOGO -->
        <div class="logo-hero mb-4 mx-auto d-flex justify-content-center bounce-in">
            <img src="Uploads/photos/logo1.png" alt="Logo Mutuelle Santé Matam">
        </div>

        <!-- HEADER HERO -->
        <div class="header-hero fade-in-up" 
             style="text-align:center; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:40px 0;">
            <h1 class="header-title animate__animated animate__fadeInDown">
                🛡️ Dashboard Admin Global
            </h1>
            <p class="header-subtitle animate__animated animate__fadeInUp">
                Vision globale sur tous les départements de MATAM • Contrôle total et supervision
            </p>
        </div>


        <!-- ALERTES -->
        <?php if (!empty($errors)): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-custom fade-in-up" style="animation-delay: 0.1s;">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- KPI GLOBAUX -->
        <div class="kpi-grid">
            <a href="list_adhesions_admin.php" class="kpi-link" title="Voir la liste des adhérents">
                <div class="kpi-card fade-in-up" style="animation-delay: 0.7s;">
                    <div class="kpi-icon" style="background: var(--primary-medical); color: white;">
                        <i class="bi bi-people-fill"></i>
                    </div>
                    <div class="kpi-value"><?php echo number_format($total_adherents); ?></div>
                    <div class="kpi-label">Adhérents Actifs (Global)</div>
                    <small class="text-primary">Couverture optimale ✨</small>
                </div>
            </a>
            <a href="voir_beneficiaires.php" class="kpi-link" title="Gérer les bénéficiaires">
                <div class="kpi-card fade-in-up" style="animation-delay: 0.8s;">
                    <div class="kpi-icon" style="background: var(--success-health); color: white;">
                        <i class="bi bi-heart-fill"></i>
                    </div>
                    <div class="kpi-value text-success"><?php echo number_format($total_beneficiaires); ?></div>
                    <div class="kpi-label">Bénéficiaires (Global)</div>
                    <small class="text-success">Soins garantis ✅</small>
                </div>
            </a>
            <a href="list_paiements_admin" class="kpi-link" title="Consulter les paiements">
                <div class="kpi-card fade-in-up" style="animation-delay: 0.9s;">
                    <div class="kpi-icon" style="background: var(--warning-gold); color: white;">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                    <div class="kpi-value text-warning">
                        <?php echo number_format($total_cotisations/1000, 0); ?>k<small class="fs-6">FCFA</small>
                    </div>
                    <div class="kpi-label">Cotisations <?php echo strtoupper($periode); ?> (Global)</div>
                    <small class="text-warning">Encaissements 💰</small>
                </div>
            </a>
            <a href="validate_adhesion_global.php" class="kpi-link" title="Valider les adhésions en attente">
                <div class="kpi-card fade-in-up" style="animation-delay: 1.0s;">
                    <div class="kpi-icon" style="background: var(--danger-alert); color: white;">
                        <i class="bi bi-hourglass-split"></i>
                    </div>
                    <div class="kpi-value text-danger"><?php echo $adhesions_en_attente; ?></div>
                    <div class="kpi-label">Adhésions en Attente</div>
                    <small class="text-danger">À traiter urgent ⚡</small>
                </div>
            </a>
        </div>

        <!-- BREAKDOWN PAR DÉPARTEMENT -->
        <?php if (!empty($departements_kpi)): ?>
        <div class="breakdown-card fade-in-up" style="animation-delay: 1.1s;">
            <div class="card-header d-flex align-items-center mb-3">
                <i class="bi bi-geo-alt-fill me-2"></i>
                <h5 class="mb-0">Point par Département</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Département</th>
                                <th>Adhérents</th>
                                <th>Bénéficiaires</th>
                                <th>Moyenne/Adhésion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($departements_kpi as $dept): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($dept['nom']); ?></td>
                                    <td><?php echo number_format($dept['adherents']); ?></td>
                                    <td><?php echo number_format($dept['beneficiaires']); ?></td>
                                    <td><?php echo $dept['moyenne']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- GRAPHIQUES GLOBAUX -->
        <div class="charts-grid">
            <div class="chart-card fade-in-up" style="animation-delay: 1.2s;">
                <div class="chart-header">
                    <i class="bi bi-graph-up-arrow text-success chart-icon"></i>
                    Évolution Adhésions (30j Global)
                </div>
                <canvas id="chartAdhesions"></canvas>
            </div>
            <div class="chart-card fade-in-up" style="animation-delay: 1.3s;">
                <div class="chart-header">
                    <i class="bi bi-cash-stack text-info chart-icon"></i>
                    Cotisations (7j Global)
                </div>
                <canvas id="chartCotisations"></canvas>
            </div>
            <?php if (!empty($chart_data['adhesions_evol_dept']['datasets'])): ?>
            <div class="chart-card fade-in-up" style="animation-delay: 1.4s;">
                <div class="chart-header">
                    <i class="bi bi-graph-up text-primary chart-icon"></i>
                    Évolution Adhésions par Département (30j)
                </div>
                <canvas id="chartAdhesionsDept"></canvas>
            </div>
            <?php endif; ?>
            <?php if (!empty($chart_data['distribution_dept'])): ?>
            <div class="chart-card fade-in-up" style="animation-delay: 1.5s;">
                <div class="chart-header">
                    <i class="bi bi-pie-chart text-warning chart-icon"></i>
                    Distribution Adhérents par Département
                </div>
                <canvas id="chartDistributionDept"></canvas>
            </div>
            <?php endif; ?>
            <?php if (!empty($chart_data['cotisations_bar'])): ?>
            <div class="chart-card fade-in-up" style="animation-delay: 1.6s;">
                <div class="chart-header">
                    <i class="bi bi-bar-chart text-danger chart-icon"></i>
                    Cotisations par Département (30j)
                </div>
                <canvas id="chartCotisationsBar"></canvas>
            </div>
            <?php endif; ?>
            <?php if (!empty($chart_data['beneficiaires_evol'])): ?>
            <div class="chart-card fade-in-up" style="animation-delay: 1.7s;">
                <div class="chart-header">
                    <i class="bi bi-graph-up text-success chart-icon"></i>
                    Évolution Bénéficiaires (30j Global)
                </div>
                <canvas id="chartBeneficiaires"></canvas>
            </div>
            <?php endif; ?>
            <?php if (!empty($chart_data['distribution_benef'])): ?>
            <div class="chart-card fade-in-up" style="animation-delay: 1.8s;">
                <div class="chart-header">
                    <i class="bi bi-pie-chart-fill text-success chart-icon"></i>
                    Distribution Bénéficiaires par Département
                </div>
                <canvas id="chartDistributionBenef"></canvas>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.js"></script>
    <script>
        const chartData = <?php echo json_encode($chart_data); ?>;

        const createChart = (id, type, dataKey, labelsKey, options = {}) => {
            const ctx = document.getElementById(id)?.getContext('2d');
            if (ctx && chartData[dataKey]?.length > 0) {
                new Chart(ctx, {
                    type,
                    data: {
                        labels: chartData[dataKey].map(d => d[labelsKey] || d.label),
                        datasets: [{
                            data: chartData[dataKey].map(d => d.count || d.total_montant || d.montant || d.total),
                            backgroundColor: type === 'doughnut' ? ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'] : 'rgba(59, 130, 246, 0.2)',
                            borderColor: type === 'doughnut' ? undefined : '#3b82f6',
                            borderWidth: type === 'doughnut' ? 0 : 2,
                            tension: type === 'line' ? 0.4 : 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { 
                            legend: { display: type === 'doughnut' ? true : false }
                        },
                        ...options
                    }
                });
            }
        };

        createChart('chartAdhesions', 'line', 'adhesions_evol', 'date');
        createChart('chartCotisations', 'line', 'cotisations_periode', 'date');
        createChart('chartBeneficiaires', 'line', 'beneficiaires_evol', 'date');

        // Chart adhésions par département
        if (chartData.adhesions_evol_dept && chartData.adhesions_evol_dept.dates && chartData.adhesions_evol_dept.dates.length > 0) {
            const ctxDept = document.getElementById('chartAdhesionsDept')?.getContext('2d');
            if (ctxDept) {
                new Chart(ctxDept, {
                    type: 'line',
                    data: {
                        labels: chartData.adhesions_evol_dept.dates,
                        datasets: chartData.adhesions_evol_dept.datasets
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: true }
                        },
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            }
        }

        // Pie chart distribution par département
        if (chartData.distribution_dept && chartData.distribution_dept.length > 0) {
            const ctxPie = document.getElementById('chartDistributionDept')?.getContext('2d');
            if (ctxPie) {
                new Chart(ctxPie, {
                    type: 'doughnut',
                    data: {
                        labels: chartData.distribution_dept.map(d => d.label),
                        datasets: [{
                            data: chartData.distribution_dept.map(d => d.count),
                            backgroundColor: ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: true, position: 'bottom' }
                        }
                    }
                });
            }
        }

        // Bar chart cotisations par département
        if (chartData.cotisations_bar && chartData.cotisations_bar.length > 0) {
            const ctxBar = document.getElementById('chartCotisationsBar')?.getContext('2d');
            if (ctxBar) {
                const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16', '#f97316', '#dc2626'];
                const backgroundColors = colors.map(color => color + '60'); // Ajout d'alpha pour les barres
                const borderColors = colors;
                new Chart(ctxBar, {
                    type: 'bar',
                    data: {
                        labels: chartData.cotisations_bar.map(d => d.label),
                        datasets: [{
                            label: 'Cotisations (FCFA)',
                            data: chartData.cotisations_bar.map(d => d.total),
                            backgroundColor: backgroundColors.slice(0, chartData.cotisations_bar.length),
                            borderColor: borderColors.slice(0, chartData.cotisations_bar.length),
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return (value / 1000).toFixed(0) + 'k';
                                    }
                                }
                            }
                        }
                    }
                });
            }
        }

        // Doughnut chart distribution bénéficiaires par département
        if (chartData.distribution_benef && chartData.distribution_benef.length > 0) {
            const ctxBenefPie = document.getElementById('chartDistributionBenef')?.getContext('2d');
            if (ctxBenefPie) {
                new Chart(ctxBenefPie, {
                    type: 'doughnut',
                    data: {
                        labels: chartData.distribution_benef.map(d => d.label),
                        datasets: [{
                            data: chartData.distribution_benef.map(d => d.count),
                            backgroundColor: ['#10b981', '#059669', '#047857', '#065f46', '#064e3b', '#0f5132'],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: true, position: 'bottom' }
                        }
                    }
                });
            }
        }
    </script>
</body>
</html>
<?php require_once '../includes/footer.php'; ob_end_flush(); ?>