<?php
// pages/dashboard_agent.php
require_once '../includes/header.php';
checkRole('agent_mobilisateur');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();

// Chemins des images QR code (conservés pour usage futur)
$qr_codes = [
    'wave' => '../Uploads/documents/wave.jpg',
    'orange_money' => '../Uploads/documents/OM.jpg'
];

// Vérifier l'existence des fichiers QR code
foreach ($qr_codes as $method => $path) {
    if (!file_exists($path)) {
        $errors[] = "L'image QR code pour $method est introuvable.";
    }
}

// Fetch tariffs
$stmt = $pdo->prepare("SELECT type_adhesion, cotisation_base, tarif_beneficiaire FROM tarifs WHERE date_fin IS NULL");
$stmt->execute();
$tarifs = $stmt->fetchAll(PDO::FETCH_ASSOC);
$tarifs_map = array_column($tarifs, null, 'type_adhesion');

// Fetch recent adhesions
$stmt_adhesions = $pdo->prepare("
    SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom, a.date_adhesion, a.statut, a.type_adhesion,
           (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion) as beneficiaire_count
    FROM adhesions a 
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
    WHERE u.departement = ? AND a.created_by = ? 
    ORDER BY a.date_adhesion DESC LIMIT 5
");
$stmt_adhesions->execute([$_SESSION['departement'], $_SESSION['user_id']]);
$adhesions = $stmt_adhesions->fetchAll(PDO::FETCH_ASSOC);

// Fetch beneficiaries for each adhesion
$beneficiaries_by_adhesion = [];
foreach ($adhesions as $adhesion) {
    $stmt_beneficiaries = $pdo->prepare("
        SELECT id_beneficiaire, nom, prenom, date_naissance, relation, code_beneficiaire, statut
        FROM beneficiaires 
        WHERE id_adhesion = ?
    ");
    $stmt_beneficiaries->execute([$adhesion['id_adhesion']]);
    $beneficiaries_by_adhesion[$adhesion['id_adhesion']] = $stmt_beneficiaries->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch adherents with beneficiaries missing photos
$stmt_missing_photos = $pdo->prepare("
    SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom, a.statut,
           (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion AND (b.photo_path IS NULL OR b.photo_path = '')) as missing_photo_count
    FROM adhesions a 
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
    WHERE u.departement = ? AND a.created_by = ? 
    AND EXISTS (
        SELECT 1 FROM beneficiaires b 
        WHERE b.id_adhesion = a.id_adhesion 
        AND (b.photo_path IS NULL OR b.photo_path = '')
    )
    ORDER BY a.date_adhesion DESC LIMIT 5
");
$stmt_missing_photos->execute([$_SESSION['departement'], $_SESSION['user_id']]);
$adhesions_missing_photos = $stmt_missing_photos->fetchAll(PDO::FETCH_ASSOC);

// Fetch beneficiaries missing photos for each adhesion
$beneficiaries_missing_photos = [];
foreach ($adhesions_missing_photos as $adhesion) {
    $stmt_beneficiaries_missing = $pdo->prepare("
        SELECT id_beneficiaire, nom, prenom, date_naissance, relation, code_beneficiaire, statut, date_entree
        FROM beneficiaires 
        WHERE id_adhesion = ? AND (photo_path IS NULL OR photo_path = '')
        ORDER BY date_entree DESC
    ");
    $stmt_beneficiaries_missing->execute([$adhesion['id_adhesion']]);
    $beneficiaries_missing_photos[$adhesion['id_adhesion']] = $stmt_beneficiaries_missing->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch recent payments
$stmt_paiements = $pdo->prepare("
    SELECT p.id_paiement, a.num_adherent, p.date_paiement, p.montant_verse, p.methode, p.reference_transaction 
    FROM paiements p 
    JOIN adhesions a ON p.id_adhesion = a.id_adhesion 
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
    WHERE u.departement = ? AND a.created_by = ? 
    ORDER BY p.date_paiement DESC LIMIT 5
");
$stmt_paiements->execute([$_SESSION['departement'], $_SESSION['user_id']]);
$paiements = $stmt_paiements->fetchAll(PDO::FETCH_ASSOC);

// Fetch recent beneficiaries
$stmt_beneficiaires = $pdo->prepare("
    SELECT b.id_beneficiaire, b.nom, b.prenom, a.num_adherent, b.statut 
    FROM beneficiaires b 
    JOIN adhesions a ON b.id_adhesion = a.id_adhesion 
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
    WHERE u.departement = ? AND a.created_by = ? 
    ORDER BY b.date_entree DESC LIMIT 5
");
$stmt_beneficiaires->execute([$_SESSION['departement'], $_SESSION['user_id']]);
$beneficiaires = $stmt_beneficiaires->fetchAll(PDO::FETCH_ASSOC);

// Fetch statistics
$stmt_stats = $pdo->prepare("
    SELECT 
        (SELECT COUNT(*) FROM adhesions a JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur WHERE u.departement = ? AND a.created_by = ? AND a.statut = 'active') as total_adhesions,
        (SELECT SUM(montant_verse) FROM paiements p JOIN adhesions a ON p.id_adhesion = a.id_adhesion JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur WHERE u.departement = ? AND a.created_by = ? AND MONTH(p.date_paiement) = MONTH(CURDATE()) AND YEAR(p.date_paiement) = YEAR(CURDATE())) as total_paiements_mois,
        (SELECT COUNT(*) FROM beneficiaires b JOIN adhesions a ON b.id_adhesion = a.id_adhesion JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur WHERE u.departement = ? AND a.created_by = ? AND b.statut = 'en_attente_approbation') as beneficiaires_en_attente
");
$stmt_stats->execute([$_SESSION['departement'], $_SESSION['user_id'], $_SESSION['departement'], $_SESSION['user_id'], $_SESSION['departement'], $_SESSION['user_id']]);
$stats = $stmt_stats->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord - Agent Mobilisateur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1d4ed8;
            --accent: #059669;
            --danger: #ef4444;
            --danger-dark: #b91c1c;
            --warning: #f59e0b;
            --secondary: #6b7280;
            --background: #f1f5f9;
            --card-bg: #ffffff;
            --text: #111827;
            --success-dark: #047857;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #e2e8f0 0%, #dbeafe 100%);
            background-size: 200% 200%;
            color: var(--text);
            min-height: 100vh;
            animation: gradientShift 15s ease infinite;
        }

        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .container {
            max-width: 1200px;
            margin: 3rem auto;
            padding: 0 1.5rem;
        }

        .page-title {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease-in;
        }

        .card {
            border-radius: 16px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
            background: var(--card-bg);
            transition: transform 0.3s ease, box-shadow 0.3s ease, border 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
            border: 2px solid transparent;
            border-image: linear-gradient(45deg, var(--primary), var(--accent)) 1;
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary), #3b82f6);
            color: white;
            font-weight: 600;
            border-radius: 16px 16px 0 0;
            padding: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-header.urgent {
            background: linear-gradient(135deg, var(--danger), var(--danger-dark));
            animation: pulseUrgent 2s infinite;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        }

        .card.urgent {
            border: 2px solid var(--danger);
        }

        .card.urgent:hover {
            border-image: linear-gradient(45deg, var(--danger), var(--danger-dark)) 1;
            box-shadow: 0 10px 25px rgba(239, 68, 68, 0.3);
        }

        .card-body {
            padding: 2rem;
        }

        .stat-card {
            text-align: center;
            padding: 1.5rem;
            animation: slideIn 0.5s ease-in-out;
        }

        .stat-card:hover {
            animation: pulse 1.5s infinite;
        }

        .stat-card p {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
        }

        .stat-card small {
            color: var(--secondary);
            font-size: 0.9rem;
            font-weight: 500;
        }

        .table {
            margin-bottom: 0;
            border-radius: 12px;
            overflow: hidden;
            background: var(--card-bg);
        }

        .table th {
            font-weight: 600;
            color: var(--text);
            border-bottom: 2px solid var(--primary);
            padding: 0.75rem;
            font-size: 0.9rem;
        }

        .table td {
            vertical-align: middle;
            padding: 0.75rem;
            font-size: 0.9rem;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .badge {
            font-size: 0.85rem;
            padding: 0.4rem 0.8rem;
            border-radius: 12px;
        }

        .badge-active, .badge-actif {
            background-color: var(--accent);
        }

        .badge-en_attente_validation, .badge-en_attente_approbation {
            background-color: var(--warning);
            animation: pulseBadge 2s infinite;
        }

        .badge-rejete {
            background-color: var(--danger);
        }

        .input-group {
            max-width: 400px;
            margin-bottom: 1.5rem;
        }

        .input-group-text {
            background-color: var(--card-bg);
            border: 1px solid var(--primary);
            border-right: none;
            transition: background-color 0.3s ease;
        }

        .form-control {
            border: 1px solid var(--primary);
            border-radius: 8px;
            padding: 0.75rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease, transform 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 10px rgba(29, 78, 216, 0.5);
            transform: scale(1.02);
        }

        .form-control::placeholder {
            color: var(--secondary);
            transition: opacity 0.3s ease;
        }

        .form-control:focus::placeholder {
            opacity: 0;
        }

        .btn-primary, .btn-warning, .btn-info, .btn-secondary {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
        }

        .btn-primary {
            background-color: var(--primary);
            border: none;
        }

        .btn-primary:hover {
            background-color: #1e3a8a;
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(29, 78, 216, 0.5);
        }

        .btn-warning {
            background-color: var(--warning);
            border: none;
        }

        .btn-warning:hover {
            background-color: #d97706;
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(245, 158, 11, 0.5);
        }

        .btn-info {
            background-color: #0ea5e9;
            border: none;
        }

        .btn-info:hover {
            background-color: #0284c7;
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(14, 165, 233, 0.5);
        }

        .btn-urgent {
            background-color: var(--danger);
            border: none;
        }

        .btn-urgent:hover {
            background-color: var(--danger-dark);
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(239, 68, 68, 0.5);
        }

        .btn-secondary {
            background-color: var(--secondary);
            border: none;
        }

        .btn-secondary:hover {
            background-color: #4b5563;
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(107, 114, 128, 0.5);
        }

        .btn-disabled {
            background-color: var(--secondary);
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .btn-disabled:hover {
            transform: none;
            box-shadow: none;
        }

        .quick-actions {
            position: sticky;
            top: 20px;
            z-index: 10;
        }

        .quick-action-btn {
            animation: slideIn 0.5s ease-in-out;
        }

        .alert {
            border-radius: 12px;
            animation: slideIn 0.5s ease-in-out;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem;
        }

        .modal-content {
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .modal-header {
            background: linear-gradient(135deg, var(--primary), #3b82f6);
            color: white;
            border-radius: 15px 15px 0 0;
        }

        .modal-header.urgent {
            background: linear-gradient(135deg, var(--danger), var(--danger-dark));
        }

        .modal.fade .modal-dialog {
            transition: transform 0.3s ease-out, opacity 0.3s ease-out;
            transform: translateY(-50px);
        }

        .modal.show .modal-dialog {
            transform: translateY(0);
        }

        .bi:hover {
            transform: rotate(360deg);
            transition: transform 0.5s ease;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        @keyframes pulseUrgent {
            0% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(239, 68, 68, 0); }
            100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
        }

        @keyframes pulseBadge {
            0% { box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(245, 158, 11, 0); }
            100% { box-shadow: 0 0 0 0 rgba(245, 158, 11, 0); }
        }

        @media (max-width: 768px) {
            .container {
                margin: 1.5rem;
                padding: 0 1rem;
            }
            .page-title {
                font-size: 1.5rem;
            }
            .stat-card {
                padding: 1rem;
            }
            .stat-card p {
                font-size: 1rem;
            }
            .table th, .table td {
                font-size: 0.75rem;
                padding: 0.5rem;
            }
            .btn-primary, .btn-warning, .btn-info, .btn-secondary, .btn-disabled, .btn-urgent {
                font-size: 0.75rem;
                padding: 0.4rem 0.8rem;
            }
            .quick-actions {
                position: static;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-speedometer2 me-2"></i>Tableau de Bord - Agent Mobilisateur</h2>

        <!-- Messages -->
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i><?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Quick Actions -->
        <div class="quick-actions mb-4">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-rocket-takeoff me-2"></i>Actions Rapides
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 col-sm-12 mb-2">
                            <a href="register_adherent.php" class="btn btn-primary w-100 quick-action-btn" data-bs-toggle="tooltip" title="Enregistrer un nouvel adhérent">
                                <i class="bi bi-person-plus me-2"></i>Enregistrer Adhérent
                            </a>
                        </div>
                        <div class="col-md-6 col-sm-12 mb-2">
                            <a href="renouvellement.php" class="btn btn-primary w-100 quick-action-btn" data-bs-toggle="tooltip" title="Renouvellement">
                                <i class="bi bi-arrow-clockwise"></i>Renouvellement
                            </a>
                        </div>
                        <div class="col-md-6 col-sm-12 mb-2">
                            <a href="register_beneficiaire.php" class="btn btn-primary w-100 quick-action-btn" data-bs-toggle="tooltip" title="Ajouter des bénéficiaires à une adhésion">
                                <i class="bi bi-people me-2"></i>Ajouter Bénéficiaires
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-md-4 col-sm-12 mb-3">
                <div class="card stat-card">
                    <div class="card-body">
                        <p data-count="<?php echo htmlspecialchars($stats['total_adhesions']); ?>" class="counter">0</p>
                        <small><i class="bi bi-person-check me-2"></i>Adhésions Actives</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12 mb-3">
                <div class="card stat-card">
                    <div class="card-body">
                        <p data-count="<?php echo htmlspecialchars($stats['total_paiements_mois'] ?: 0); ?>" class="counter">0</p>
                        <small><i class="bi bi-currency-exchange me-2"></i>Paiements ce Mois (FCFA)</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12 mb-3">
                <div class="card stat-card">
                    <div class="card-body">
                        <p data-count="<?php echo htmlspecialchars($stats['beneficiaires_en_attente']); ?>" class="counter">0</p>
                        <small><i class="bi bi-hourglass-split me-2"></i>Bénéficiaires en Attente</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Adherents with Beneficiaries Missing Photos -->
        <div class="card urgent mb-4">
            <div class="card-header urgent">
                <i class="bi bi-exclamation-triangle me-2"></i>Adhérents avec Bénéficiaires sans Photo
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" id="search_missing_photos" class="form-control" placeholder="Rechercher par numéro, nom, prénom...">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-missing-photos">
                        <thead>
                            <tr>
                                <th><i class="bi bi-person-vcard me-2"></i>Numéro</th>
                                <th><i class="bi bi-person me-2"></i>Nom</th>
                                <th><i class="bi bi-person me-2"></i>Prénom</th>
                                <th><i class="bi bi-camera me-2"></i>Bénéficiaires sans Photo</th>
                                <th><i class="bi bi-gear me-2"></i>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($adhesions_missing_photos)): ?>
                                <tr><td colspan="5" class="text-center">Aucun bénéficiaire sans photo.</td></tr>
                            <?php else: ?>
                                <?php foreach ($adhesions_missing_photos as $adhesion): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($adhesion['num_adherent']); ?></td>
                                        <td><?php echo htmlspecialchars($adhesion['nom']); ?></td>
                                        <td><?php echo htmlspecialchars($adhesion['prenom']); ?></td>
                                        <td><?php echo htmlspecialchars($adhesion['missing_photo_count']); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-urgent btn-sm" data-bs-toggle="modal" data-bs-target="#missingPhotosModal<?php echo $adhesion['id_adhesion']; ?>" data-bs-toggle="tooltip" title="Voir les bénéficiaires sans photo">
                                                <i class="bi bi-eye"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Modals for Beneficiaries Missing Photos -->
        <?php foreach ($adhesions_missing_photos as $adhesion): ?>
            <?php if (!empty($beneficiaries_missing_photos[$adhesion['id_adhesion']])): ?>
                <div class="modal fade" id="missingPhotosModal<?php echo $adhesion['id_adhesion']; ?>" tabindex="-1" aria-labelledby="missingPhotosModalLabel<?php echo $adhesion['id_adhesion']; ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header urgent">
                                <h5 class="modal-title" id="missingPhotosModalLabel<?php echo $adhesion['id_adhesion']; ?>">
                                    Bénéficiaires sans Photo pour <?php echo htmlspecialchars($adhesion['num_adherent'] . ' - ' . $adhesion['nom'] . ' ' . $adhesion['prenom']); ?>
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th><i class="bi bi-person-vcard me-2"></i>Code</th>
                                                <th><i class="bi bi-person me-2"></i>Nom</th>
                                                <th><i class="bi bi-person me-2"></i>Prénom</th>
                                                <th><i class="bi bi-calendar me-2"></i>Date de Naissance</th>
                                                <th><i class="bi bi-link-45deg me-2"></i>Relation</th>
                                                <th><i class="bi bi-shield-check me-2"></i>Statut</th>
                                                <th><i class="bi bi-gear me-2"></i>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($beneficiaries_missing_photos[$adhesion['id_adhesion']] as $beneficiary): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($beneficiary['code_beneficiaire']); ?></td>
                                                    <td><?php echo htmlspecialchars($beneficiary['nom']); ?></td>
                                                    <td><?php echo htmlspecialchars($beneficiary['prenom']); ?></td>
                                                    <td><?php echo htmlspecialchars($beneficiary['date_naissance']); ?></td>
                                                    <td><?php echo htmlspecialchars($beneficiary['relation']); ?></td>
                                                    <td>
                                                        <span class="badge badge-<?php echo htmlspecialchars($beneficiary['statut']); ?>">
                                                            <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $beneficiary['statut']))); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php if ($adhesion['statut'] === 'active'): ?>
                                                            <button class="btn btn-disabled btn-sm" disabled data-bs-toggle="tooltip" title="Bénéficiaire validé, modification impossible">
                                                                <i class="bi bi-lock"></i>
                                                            </button>
                                                        <?php else: ?>
                                                            <a href="edit_beneficiaire.php?id=<?php echo htmlspecialchars($beneficiary['id_beneficiaire']); ?>" class="btn btn-warning btn-sm" data-bs-toggle="tooltip" title="Modifier le bénéficiaire">
                                                                <i class="bi bi-pencil"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                    <i class="bi bi-x-circle me-2"></i>Fermer
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>

        <!-- Recent Adhesions -->
        <div class="card mb-4">
            <div class="card-header">
                <i class="bi bi-person-lines-fill me-2"></i>Adhésions Récentes
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" id="search_adhesion" class="form-control" placeholder="Rechercher par numéro, nom, prénom...">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-adhesions">
                        <thead>
                            <tr>
                                <th><i class="bi bi-person-vcard me-2"></i>Numéro</th>
                                <th><i class="bi bi-person me-2"></i>Nom</th>
                                <th><i class="bi bi-person me-2"></i>Prénom</th>
                                <th><i class="bi bi-calendar me-2"></i>Date</th>
                                <th><i class="bi bi-shield-check me-2"></i>Statut</th>
                                <th><i class="bi bi-card-list me-2"></i>Type</th>
                                <th><i class="bi bi-person-hearts me-2"></i>Bénéficiaires</th>
                                <th><i class="bi bi-gear me-2"></i>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($adhesions)): ?>
                                <tr><td colspan="8" class="text-center">Aucune adhésion récente.</td></tr>
                            <?php else: ?>
                                <?php foreach ($adhesions as $adhesion): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($adhesion['num_adherent']); ?></td>
                                        <td><?php echo htmlspecialchars($adhesion['nom']); ?></td>
                                        <td><?php echo htmlspecialchars($adhesion['prenom']); ?></td>
                                        <td><?php echo htmlspecialchars($adhesion['date_adhesion']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo htmlspecialchars($adhesion['statut']); ?>">
                                                <?php echo htmlspecialchars(ucfirst($adhesion['statut'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($adhesion['type_adhesion']); ?></td>
                                        <td>
                                            <?php echo htmlspecialchars($adhesion['beneficiaire_count']); ?>
                                            <?php if ($adhesion['beneficiaire_count'] > 0): ?>
                                                <button type="button" class="btn btn-info btn-sm ms-2" data-bs-toggle="modal" data-bs-target="#beneficiariesModal<?php echo $adhesion['id_adhesion']; ?>" data-bs-toggle="tooltip" title="Voir les bénéficiaires">
                                                    <i class="bi bi-eye"></i>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($adhesion['statut'] === 'active'): ?>
                                                <button class="btn btn-disabled btn-sm" disabled data-bs-toggle="tooltip" title="Adhésion validée, modification impossible">
                                                    <i class="bi bi-lock"></i>
                                                </button>
                                            <?php else: ?>
                                                <a href="edit_adherent.php?id=<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" class="btn btn-warning btn-sm" data-bs-toggle="tooltip" title="Modifier l'adhésion">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="text-end mt-3">
                    <a href="all_adhesions.php" class="btn btn-primary" data-bs-toggle="tooltip" title="Voir toutes les adhésions">
                        <i class="bi bi-list me-2"></i>Voir Toutes les Adhésions
                    </a>
                </div>
            </div>
        </div>

        <!-- Modals for Beneficiaries -->
        <?php foreach ($adhesions as $adhesion): ?>
            <?php if (!empty($beneficiaries_by_adhesion[$adhesion['id_adhesion']])): ?>
                <div class="modal fade" id="beneficiariesModal<?php echo $adhesion['id_adhesion']; ?>" tabindex="-1" aria-labelledby="beneficiariesModalLabel<?php echo $adhesion['id_adhesion']; ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="beneficiariesModalLabel<?php echo $adhesion['id_adhesion']; ?>">
                                    Bénéficiaires pour <?php echo htmlspecialchars($adhesion['num_adherent'] . ' - ' . $adhesion['nom'] . ' ' . $adhesion['prenom']); ?>
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th><i class="bi bi-person-vcard me-2"></i>Code</th>
                                                <th><i class="bi bi-person me-2"></i>Nom</th>
                                                <th><i class="bi bi-person me-2"></i>Prénom</th>
                                                <th><i class="bi bi-calendar me-2"></i>Date de Naissance</th>
                                                <th><i class="bi bi-link-45deg me-2"></i>Relation</th>
                                                <th><i class="bi bi-shield-check me-2"></i>Statut</th>
                                                <th><i class="bi bi-gear me-2"></i>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($beneficiaries_by_adhesion[$adhesion['id_adhesion']] as $beneficiary): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($beneficiary['code_beneficiaire']); ?></td>
                                                    <td><?php echo htmlspecialchars($beneficiary['nom']); ?></td>
                                                    <td><?php echo htmlspecialchars($beneficiary['prenom']); ?></td>
                                                    <td><?php echo htmlspecialchars($beneficiary['date_naissance']); ?></td>
                                                    <td><?php echo htmlspecialchars($beneficiary['relation']); ?></td>
                                                    <td>
                                                        <span class="badge badge-<?php echo htmlspecialchars($beneficiary['statut']); ?>">
                                                            <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $beneficiary['statut']))); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php if ($adhesion['statut'] === 'active'): ?>
                                                            <button class="btn btn-disabled btn-sm" disabled data-bs-toggle="tooltip" title="Bénéficiaire validé, modification impossible">
                                                                <i class="bi bi-lock"></i>
                                                            </button>
                                                        <?php else: ?>
                                                            <a href="edit_beneficiaire.php?id=<?php echo htmlspecialchars($beneficiary['id_beneficiaire']); ?>" class="btn btn-warning btn-sm" data-bs-toggle="tooltip" title="Modifier le bénéficiaire">
                                                                <i class="bi bi-pencil"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                    <i class="bi bi-x-circle me-2"></i>Fermer
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>

        <!-- Recent Beneficiaries -->
        <div class="card mb-4">
            <div class="card-header">
                <i class="bi bi-people me-2"></i>Bénéficiaires Récents
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" id="search_beneficiaire" class="form-control" placeholder="Rechercher par numéro, nom, prénom...">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-beneficiaires">
                        <thead>
                            <tr>
                                <th><i class="bi bi-person-vcard me-2"></i>Numéro Adhérent</th>
                                <th><i class="bi bi-person me-2"></i>Nom</th>
                                <th><i class="bi bi-person me-2"></i>Prénom</th>
                                <th><i class="bi bi-shield-check me-2"></i>Statut</th>
                                <th><i class="bi bi-gear me-2"></i>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($beneficiaires)): ?>
                                <tr><td colspan="5" class="text-center">Aucun bénéficiaire récent.</td></tr>
                            <?php else: ?>
                                <?php foreach ($beneficiaires as $beneficiaire): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($beneficiaire['num_adherent']); ?></td>
                                        <td><?php echo htmlspecialchars($beneficiaire['nom']); ?></td>
                                        <td><?php echo htmlspecialchars($beneficiaire['prenom']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo htmlspecialchars($beneficiaire['statut']); ?>">
                                                <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $beneficiaire['statut']))); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($beneficiaire['statut'] === 'actif'): ?>
                                                <button class="btn btn-disabled btn-sm" disabled data-bs-toggle="tooltip" title="Bénéficiaire validé, modification impossible">
                                                    <i class="bi bi-lock"></i>
                                                </button>
                                            <?php else: ?>
                                                <a href="edit_beneficiaire.php?id=<?php echo htmlspecialchars($beneficiaire['id_beneficiaire']); ?>" class="btn btn-warning btn-sm" data-bs-toggle="tooltip" title="Modifier le bénéficiaire">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="text-end mt-3">
                    <a href="all_beneficiaires.php" class="btn btn-primary" data-bs-toggle="tooltip" title="Voir tous les bénéficiaires">
                        <i class="bi bi-list me-2"></i>Voir Tous les Bénéficiaires
                    </a>
                </div>
            </div>
        </div>

        <!-- Recent Payments -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-wallet2 me-2"></i>Paiements Récents
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" id="search_paiement" class="form-control" placeholder="Rechercher par numéro, date, référence...">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-paiements">
                        <thead>
                            <tr>
                                <th><i class="bi bi-person-vcard me-2"></i>Numéro Adhérent</th>
                                <th><i class="bi bi-calendar me-2"></i>Date</th>
                                <th><i class="bi bi-currency-exchange me-2"></i>Montant</th>
                                <th><i class="bi bi-credit-card me-2"></i>Méthode</th>
                                <th><i class="bi bi-receipt me-2"></i>Référence</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($paiements)): ?>
                                <tr><td colspan="5" class="text-center">Aucun paiement récent.</td></tr>
                            <?php else: ?>
                                <?php foreach ($paiements as $paiement): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($paiement['num_adherent']); ?></td>
                                        <td><?php echo htmlspecialchars($paiement['date_paiement']); ?></td>
                                        <td><?php echo htmlspecialchars(formatFCFA($paiement['montant_verse'])); ?></td>
                                        <td><?php echo htmlspecialchars($paiement['methode']); ?></td>
                                        <td><?php echo htmlspecialchars($paiement['reference_transaction']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="text-end mt-3">
                    <a href="all_payments.php" class="btn btn-primary" data-bs-toggle="tooltip" title="Voir tous les paiements">
                        <i class="bi bi-list me-2"></i>Voir Tous les Paiements
                    </a>
                </div>
            </div>
        </div>

        <!-- Modal for enlarged QR code (conservé pour usage futur) -->
        <div class="modal fade" id="qrCodeModal" tabindex="-1" aria-labelledby="qrCodeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="qrCodeModalLabel">QR Code de Paiement</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center">
                        <img id="enlargedQrCode" src="" alt="QR Code" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Enable tooltips
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

        // Counter animation for statistics
        document.querySelectorAll('.counter').forEach(counter => {
            const target = parseFloat(counter.getAttribute('data-count'));
            let count = 0;
            const speed = 50; // Adjust speed (ms per increment)
            const increment = target / (1000 / speed);

            const updateCount = () => {
                count += increment;
                if (count >= target) {
                    counter.textContent = Number.isInteger(target) ? target : target.toFixed(2);
                } else {
                    counter.textContent = Number.isInteger(target) ? Math.ceil(count) : count.toFixed(2);
                    requestAnimationFrame(updateCount);
                }
            };

            requestAnimationFrame(updateCount);
        });

        // Search functionality for missing photos table
        document.getElementById('search_missing_photos').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-missing-photos tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });

        // Search functionality for adhesions table
        document.getElementById('search_adhesion').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-adhesions tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });

        // Search functionality for beneficiaries table
        document.getElementById('search_beneficiaire').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-beneficiaires tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });

        // Search functionality for payments table
        document.getElementById('search_paiement').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-paiements tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>