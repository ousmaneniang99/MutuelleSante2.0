<?php
// Inclusion du fichier header.php
require_once __DIR__ . '/../includes/header.php';

// Récupération des informations de session
$user_id = $_SESSION['user_id'];
$departement_id = $_SESSION['departement'];
// Récupérer le nom du département
try {
    $query_dept = "SELECT nom FROM departements WHERE id_departement = :departement_id";
    $stmt = $pdo->prepare($query_dept);
    $stmt->execute(['departement_id' => $departement_id]);
    $departement_nom = $stmt->fetchColumn() ?: 'Inconnu';
} catch (Exception $e) {
    $departement_nom = 'Inconnu';
}

// Initialisation des variables
$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$errors = [];
$chart_evolution_data = [];
$chart_monthly_data = [];
$chart_methodes_data = [];
$total_entrees = 0;
$total_sorties = 0;
$paiements_en_attente = 0;
$total_adherents = 0;
$adherents_avec_paiement = 0;
$total_beneficiaires = 0;
$montant_moyen_paiement = 0;
$evolution_mensuelle = [];

// Exportation CSV pour les paiements
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    try {
        $query_paiements = "
            SELECT p.*, a.num_adherent
            FROM paiements p
            JOIN adhesions a ON p.id_adhesion = a.id_adhesion 
            WHERE a.departement = :departement_id
            AND YEAR(p.date_paiement) = :year
            ORDER BY p.date_paiement DESC";
        $stmt = $pdo->prepare($query_paiements);
        $stmt->execute(['departement_id' => $departement_id, 'year' => $year]);
        $paiements = $stmt->fetchAll(PDO::FETCH_ASSOC);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="paiements_' . $departement_nom . '_' . $year . '.csv"');
        $output = fopen('php://output', 'w');
        fputs($output, "\xEF\xBB\xBF");
        fputcsv($output, ['Numéro Adhérent', 'Date Paiement', 'Montant (FCFA)', 'Méthode', 'Statut']);

        foreach ($paiements as $paiement) {
            fputcsv($output, [
                htmlspecialchars_decode($paiement['num_adherent'], ENT_QUOTES),
                htmlspecialchars_decode($paiement['date_paiement'], ENT_QUOTES),
                number_format($paiement['montant_verse'], 2, '.', ''),
                htmlspecialchars_decode($paiement['methode'] ?: 'N/A', ENT_QUOTES),
                htmlspecialchars_decode($paiement['statut'], ENT_QUOTES)
            ]);
        }
        fclose($output);
        exit;
    } catch (Exception $e) {
        $errors[] = "Erreur lors de l'exportation CSV : " . $e->getMessage();
    }
}

// Exportation CSV pour les adhésions
if (isset($_GET['export_adhesions']) && $_GET['export_adhesions'] === 'csv') {
    try {
        $query_adhesions = "
            SELECT 
                a.id_adhesion,
                a.num_adherent, 
                a.date_adhesion, 
                COUNT(b.id_beneficiaire) as nb_beneficiaires,
                (SELECT COUNT(*) FROM paiements p WHERE p.id_adhesion = a.id_adhesion AND p.statut = 'paye') as has_payment,
                (SELECT SUM(p.montant_verse) FROM paiements p WHERE p.id_adhesion = a.id_adhesion AND p.statut = 'paye') as total_paye,
                (SELECT MAX(p.date_paiement) FROM paiements p WHERE p.id_adhesion = a.id_adhesion AND p.statut = 'paye') as dernier_paiement_date,
                (SELECT p.montant_verse FROM paiements p WHERE p.id_adhesion = a.id_adhesion AND p.statut = 'paye' ORDER BY p.date_paiement DESC LIMIT 1) as dernier_paiement_montant,
                (SELECT p.methode FROM paiements p WHERE p.id_adhesion = a.id_adhesion AND p.statut = 'paye' ORDER BY p.date_paiement DESC LIMIT 1) as methode_paiement,
                (SELECT COUNT(*) FROM demandes_remboursement dr WHERE dr.id_adhesion = a.id_adhesion AND dr.statut IN ('approuve', 'en_attente', 'en_validation')) as nb_remboursements,
                (SELECT SUM(dr.montant_rembourse) FROM demandes_remboursement dr WHERE dr.id_adhesion = a.id_adhesion AND dr.statut = 'approuve') as total_rembourse
            FROM adhesions a
            LEFT JOIN beneficiaires b ON a.id_adhesion = b.id_adhesion
            WHERE a.departement = :departement_id
            GROUP BY a.id_adhesion
            ORDER BY a.date_adhesion DESC";
        $stmt = $pdo->prepare($query_adhesions);
        $stmt->execute(['departement_id' => $departement_id]);
        $adhesions_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $query_total_adherents = "SELECT COUNT(*) as total FROM adhesions WHERE departement = :departement_id";
        $stmt = $pdo->prepare($query_total_adherents);
        $stmt->execute(['departement_id' => $departement_id]);
        $total_adherents = $stmt->fetchColumn() ?: 0;

        $query_adherents_paiement = "
            SELECT COUNT(DISTINCT p.id_adhesion) as total
            FROM paiements p
            JOIN adhesions a ON p.id_adhesion = a.id_adhesion
            WHERE p.statut = 'paye'
            AND a.departement = :departement_id";
        $stmt = $pdo->prepare($query_adherents_paiement);
        $stmt->execute(['departement_id' => $departement_id]);
        $adherents_avec_paiement = $stmt->fetchColumn() ?: 0;

        $query_beneficiaires = "
            SELECT COUNT(*) as total
            FROM beneficiaires b
            JOIN adhesions a ON b.id_adhesion = a.id_adhesion
            WHERE a.departement = :departement_id";
        $stmt = $pdo->prepare($query_beneficiaires);
        $stmt->execute(['departement_id' => $departement_id]);
        $total_beneficiaires = $stmt->fetchColumn() ?: 0;

        $query_montant_moyen = "
            SELECT AVG(p.montant_verse) as moyenne
            FROM paiements p
            JOIN adhesions a ON p.id_adhesion = a.id_adhesion
            WHERE p.statut = 'paye'
            AND a.departement = :departement_id";
        $stmt = $pdo->prepare($query_montant_moyen);
        $stmt->execute(['departement_id' => $departement_id]);
        $montant_moyen_paiement = $stmt->fetchColumn() ?: 0;

        $query_evolution = "
            SELECT MONTHNAME(date_adhesion) as month, COUNT(*) as total
            FROM adhesions
            WHERE YEAR(date_adhesion) = :year
            AND departement = :departement_id
            GROUP BY MONTH(date_adhesion)
            ORDER BY MONTH(date_adhesion)";
        $stmt = $pdo->prepare($query_evolution);
        $stmt->execute(['year' => $year, 'departement_id' => $departement_id]);
        $evolution_mensuelle = $stmt->fetchAll(PDO::FETCH_ASSOC);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="adhesions_' . $departement_nom . '_' . $year . '.csv"');
        $output = fopen('php://output', 'w');
        fputs($output, "\xEF\xBB\xBF");

        fputcsv($output, ['Statistiques des Adhésions', '']);
        fputcsv($output, ['Métrique', 'Valeur']);
        fputcsv($output, ['Nombre total d’adhérents', $total_adherents]);
        fputcsv($output, ['Adhérents ayant effectué un paiement', $adherents_avec_paiement]);
        fputcsv($output, ['Pourcentage d’adhérents ayant payé', $total_adherents ? round(($adherents_avec_paiement / $total_adherents) * 100, 2) . '%' : '0%']);
        fputcsv($output, ['Nombre total de bénéficiaires', $total_beneficiaires]);
        fputcsv($output, ['Montant moyen par paiement', number_format($montant_moyen_paiement, 2, '.', '') . ' FCFA']);
        fputcsv($output, []);

        fputcsv($output, ['Liste des Adhésions', '']);
        fputcsv($output, ['Numéro Adhérent', 'Date d’Adhésion', 'Nombre de Bénéficiaires', 'Statut de Paiement', 'Méthode de Paiement', 'Montant Total Payé', 'Dernier Paiement', 'Remboursements Demandés', 'Montant Remboursé', 'Statut Financier']);
        foreach ($adhesions_data as $adhesion) {
            $statut_financier = 'En retard';
            if ($adhesion['has_payment'] > 0 && $adhesion['nb_remboursements'] == 0) {
                $statut_financier = 'À jour';
            } elseif ($adhesion['nb_remboursements'] > 0) {
                $statut_financier = 'En attente';
            }
            fputcsv($output, [
                htmlspecialchars_decode($adhesion['num_adherent'], ENT_QUOTES),
                htmlspecialchars_decode($adhesion['date_adhesion'], ENT_QUOTES),
                $adhesion['nb_beneficiaires'],
                $adhesion['has_payment'] > 0 ? 'Payé' : 'Non payé',
                htmlspecialchars_decode($adhesion['methode_paiement'] ?: 'N/A', ENT_QUOTES),
                number_format($adhesion['total_paye'] ?: 0, 2, '.', ''),
                $adhesion['dernier_paiement_date'] ? (htmlspecialchars_decode($adhesion['dernier_paiement_date'], ENT_QUOTES) . ' (' . number_format($adhesion['dernier_paiement_montant'], 2, '.', '') . ' FCFA)') : 'N/A',
                $adhesion['nb_remboursements'],
                number_format($adhesion['total_rembourse'] ?: 0, 2, '.', '') . ' FCFA',
                $statut_financier
            ]);
        }

        $total_annual_adhesions = array_sum(array_column($evolution_mensuelle, 'total'));
        fputcsv($output, []);
        fputcsv($output, ['Évolution Mensuelle des Adhésions (' . $year . ')', '']);
        fputcsv($output, ['Mois', 'Nombre d’Adhésions', 'Pourcentage du Total']);
        foreach ($evolution_mensuelle as $evolution) {
            $percentage = $total_annual_adhesions ? round(($evolution['total'] / $total_annual_adhesions) * 100, 2) : 0;
            fputcsv($output, [
                htmlspecialchars_decode($evolution['month'], ENT_QUOTES),
                $evolution['total'],
                $percentage . '%'
            ]);
        }

        fclose($output);
        exit;
    } catch (Exception $e) {
        $errors[] = "Erreur lors de l'exportation des adhésions : " . $e->getMessage();
    }
}

// Récupération des statistiques financières
try {
    $query_entrees = "
        SELECT SUM(p.montant_verse) as total
        FROM paiements p
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion
        WHERE p.statut = 'paye' 
        AND YEAR(p.date_paiement) = :year
        AND a.departement = :departement_id";
    $stmt = $pdo->prepare($query_entrees);
    $stmt->execute(['year' => $year, 'departement_id' => $departement_id]);
    $total_entrees = $stmt->fetchColumn() ?: 0;

    $query_sorties = "
        SELECT SUM(dr.montant_rembourse) as total
        FROM demandes_remboursement dr
        JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
        WHERE dr.statut = 'approuve'
        AND YEAR(dr.date_mise_a_jour) = :year
        AND a.departement = :departement_id";
    $stmt = $pdo->prepare($query_sorties);
    $stmt->execute(['year' => $year, 'departement_id' => $departement_id]);
    $total_sorties = $stmt->fetchColumn() ?: 0;

    $query_attente = "
        SELECT COUNT(*) as total
        FROM demandes_remboursement dr
        JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
        WHERE dr.statut IN ('en_attente', 'en_validation')
        AND a.departement = :departement_id";
    $stmt = $pdo->prepare($query_attente);
    $stmt->execute(['departement_id' => $departement_id]);
    $paiements_en_attente = $stmt->fetchColumn() ?: 0;

    $query_total_adherents = "SELECT COUNT(*) as total FROM adhesions WHERE departement = :departement_id";
    $stmt = $pdo->prepare($query_total_adherents);
    $stmt->execute(['departement_id' => $departement_id]);
    $total_adherents = $stmt->fetchColumn() ?: 0;

    $query_adherents_paiement = "
        SELECT COUNT(DISTINCT p.id_adhesion) as total
        FROM paiements p
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion
        WHERE p.statut = 'paye'
        AND a.departement = :departement_id";
    $stmt = $pdo->prepare($query_adherents_paiement);
    $stmt->execute(['departement_id' => $departement_id]);
    $adherents_avec_paiement = $stmt->fetchColumn() ?: 0;

    $query_beneficiaires = "
        SELECT COUNT(*) as total
        FROM beneficiaires b
        JOIN adhesions a ON b.id_adhesion = a.id_adhesion
        WHERE a.departement = :departement_id";
    $stmt = $pdo->prepare($query_beneficiaires);
    $stmt->execute(['departement_id' => $departement_id]);
    $total_beneficiaires = $stmt->fetchColumn() ?: 0;

    $query_montant_moyen = "
        SELECT AVG(p.montant_verse) as moyenne
        FROM paiements p
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion
        WHERE p.statut = 'paye'
        AND a.departement = :departement_id";
    $stmt = $pdo->prepare($query_montant_moyen);
    $stmt->execute(['departement_id' => $departement_id]);
    $montant_moyen_paiement = $stmt->fetchColumn() ?: 0;

    // Données pour les graphiques
    // Évolution Paiements (30j) - Séparé pour entrées et sorties
    $query_entrees_30j = "
        SELECT DATE(p.date_paiement) as date, SUM(p.montant_verse) as entrees
        FROM paiements p
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion
        WHERE p.date_paiement >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        AND p.statut = 'paye'
        AND a.departement = :departement_id
        GROUP BY DATE(p.date_paiement)
        ORDER BY DATE(p.date_paiement) ASC";
    $stmt = $pdo->prepare($query_entrees_30j);
    $stmt->execute(['departement_id' => $departement_id]);
    $entrees_30j = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $query_sorties_30j = "
        SELECT DATE(dr.date_mise_a_jour) as date, SUM(dr.montant_rembourse) as sorties
        FROM demandes_remboursement dr
        JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
        WHERE dr.date_mise_a_jour >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        AND dr.statut = 'approuve'
        AND a.departement = :departement_id
        GROUP BY DATE(dr.date_mise_a_jour)
        ORDER BY DATE(dr.date_mise_a_jour) ASC";
    $stmt = $pdo->prepare($query_sorties_30j);
    $stmt->execute(['departement_id' => $departement_id]);
    $sorties_30j = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Merger les données
    $dates = array_unique(array_merge(array_column($entrees_30j, 'date'), array_column($sorties_30j, 'date')));
    sort($dates);
    $entrees_data = [];
    $sorties_data = [];
    foreach ($dates as $date) {
        $entree = array_filter($entrees_30j, function($item) use ($date) { return $item['date'] == $date; });
        $sortie = array_filter($sorties_30j, function($item) use ($date) { return $item['date'] == $date; });
        $entrees_data[] = !empty($entree) ? reset($entree)['entrees'] : 0;
        $sorties_data[] = !empty($sortie) ? reset($sortie)['sorties'] : 0;
    }
    $labels = $dates;

    // Tendances Mensuelles - Séparé pour entrées et sorties
    $query_entrees_monthly = "
        SELECT MONTHNAME(p.date_paiement) as month, SUM(p.montant_verse) as entrees
        FROM paiements p
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion
        WHERE YEAR(p.date_paiement) = :year
        AND p.statut = 'paye'
        AND a.departement = :departement_id
        GROUP BY MONTH(p.date_paiement)
        ORDER BY MONTH(p.date_paiement)";
    $stmt = $pdo->prepare($query_entrees_monthly);
    $stmt->execute(['year' => $year, 'departement_id' => $departement_id]);
    $entrees_monthly = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $query_sorties_monthly = "
        SELECT MONTHNAME(dr.date_mise_a_jour) as month, SUM(dr.montant_rembourse) as sorties
        FROM demandes_remboursement dr
        JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
        WHERE YEAR(dr.date_mise_a_jour) = :year
        AND dr.statut = 'approuve'
        AND a.departement = :departement_id
        GROUP BY MONTH(dr.date_mise_a_jour)
        ORDER BY MONTH(dr.date_mise_a_jour)";
    $stmt = $pdo->prepare($query_sorties_monthly);
    $stmt->execute(['year' => $year, 'departement_id' => $departement_id]);
    $sorties_monthly = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Merger les données mensuelles
    $months = array_unique(array_merge(array_column($entrees_monthly, 'month'), array_column($sorties_monthly, 'month')));
    sort($months);
    $monthly_entrees = [];
    $monthly_sorties = [];
    foreach ($months as $month) {
        $entree = array_filter($entrees_monthly, function($item) use ($month) { return $item['month'] == $month; });
        $sortie = array_filter($sorties_monthly, function($item) use ($month) { return $item['month'] == $month; });
        $monthly_entrees[] = !empty($entree) ? reset($entree)['entrees'] : 0;
        $monthly_sorties[] = !empty($sortie) ? reset($sortie)['sorties'] : 0;
    }
    $monthly_labels = $months;

    // Méthodes de Paiement (seulement pour entrées)
    $query_methodes = "
        SELECT 
            MONTHNAME(p.date_paiement) as month,
            COALESCE(p.methode, 'N/A') as methode,
            SUM(p.montant_verse) as montant
        FROM paiements p
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion
        WHERE YEAR(p.date_paiement) = :year
        AND p.statut = 'paye'
        AND a.departement = :departement_id
        GROUP BY MONTH(p.date_paiement), p.methode
        ORDER BY MONTH(p.date_paiement)";
    $stmt = $pdo->prepare($query_methodes);
    $stmt->execute(['year' => $year, 'departement_id' => $departement_id]);
    $chart_methodes_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $methodes_labels = array_unique(array_column($chart_methodes_data, 'month'));
    $methodes = array_unique(array_column($chart_methodes_data, 'methode'));
    $methodes_datasets = [];
    $colors = ['#3b82f6', '#10b981', '#8b5cf6', '#06b6d4', '#f59e0b'];
    $i = 0;
    foreach ($methodes as $methode) {
        $counts = [];
        foreach ($methodes_labels as $month) {
            $found = false;
            foreach ($chart_methodes_data as $row) {
                if ($row['month'] === $month && $row['methode'] === $methode) {
                    $counts[] = (int)$row['montant'];
                    $found = true;
                    break;
                }
            }
            if (!$found) $counts[] = 0;
        }
        $methodes_datasets[] = [
            'label' => $methode ?: 'N/A',
            'data' => $counts,
            'backgroundColor' => $colors[$i % count($colors)] . '60',
            'borderColor' => $colors[$i % count($colors)],
            'borderWidth' => 1
        ];
        $i++;
    }

    $query_evolution = "
        SELECT MONTHNAME(date_adhesion) as month, COUNT(*) as total
        FROM adhesions
        WHERE YEAR(date_adhesion) = :year
        AND departement = :departement_id
        GROUP BY MONTH(date_adhesion)
        ORDER BY MONTH(date_adhesion)";
    $stmt = $pdo->prepare($query_evolution);
    $stmt->execute(['year' => $year, 'departement_id' => $departement_id]);
    $evolution_mensuelle = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $errors[] = "Erreur lors de la récupération des données : " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📊 Tableau de Bord Comptable - <?php echo htmlspecialchars($departement_nom, ENT_QUOTES, 'UTF-8'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-medical: linear-gradient(135deg, #1e3a8a, #3b82f6, #1d4ed8);
            --success-health: linear-gradient(135deg, #15803d, #22c55e, #16a34a);
            --warning-gold: linear-gradient(135deg, #d97706, #f59e0b, #b45309);
            --danger-alert: linear-gradient(135deg, #dc2626, #ef4444, #b91c1c);
            --glass-bg: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
            --shadow-glow: 0 25px 50px -12px rgba(59, 130, 246, 0.3);
            --shadow-hover: 0 35px 60px -15px rgba(59, 130, 246, 0.3);
        }

        * { font-family: 'Inter', sans-serif; }
        body { 
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 50%, #f0f9ff 100%);
            min-height: 100vh; 
            overflow-x: hidden;
            position: relative;
        }
        body::before {
            content: ''; 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%;
            background: radial-gradient(circle at 20% 50%, rgba(120, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 40% 80%, rgba(120, 219, 255, 0.1) 0%, transparent 50%);
            z-index: -1;
        }

        /* HEADER HERO */
        .header-hero {
            background: var(--primary-medical);
            border-radius: 24px; 
            padding: 2rem; 
            color: white; 
            margin-bottom: 2rem;
            position: relative; 
            overflow: hidden; 
            box-shadow: var(--shadow-glow);
            backdrop-filter: blur(20px);
        }
        .header-hero::before {
            content: ''; 
            position: absolute; 
            top: -50%; 
            left: -50%; 
            width: 200%; 
            height: 200%;
            background: conic-gradient(from 0deg, transparent, rgba(255,255,255,0.1), transparent 30%);
            animation: rotate 20s linear infinite; 
            opacity: 0.3;
        }
        @keyframes rotate { 100% { transform: rotate(360deg); } }
        .logo-hero {
            width: 80px; 
            height: 80px; 
            border-radius: 50%; 
            background: var(--glass-bg);
            display: flex; 
            align-items: center; 
            justify-content: center; 
            margin: 0 auto 1rem;
            backdrop-filter: blur(10px); 
            border: 2px solid var(--glass-border);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2); 
            animation: pulse 2s infinite;
        }
        .logo-hero img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
        @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.05); } }
        .header-title { 
            font-size: 2.2rem; 
            font-weight: 800; 
            margin-bottom: 0.5rem;
            background: linear-gradient(45deg, #fff, #e0f2fe); 
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent; 
            text-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header-subtitle { 
            font-size: 1.1rem; 
            opacity: 0.95; 
            font-weight: 400; 
            max-width: 700px; 
            margin: 0 auto;
        }

        /* BOUTONS D'ACTION */
        .actions-glass {
            background: var(--glass-bg); 
            backdrop-filter: blur(20px); 
            border-radius: 20px;
            padding: 1.5rem; 
            margin-bottom: 2rem; 
            border: 1px solid var(--glass-border);
            box-shadow: var(--shadow-glow);
        }
        .btn-glass {
            background: var(--glass-bg); 
            backdrop-filter: blur(20px); 
            border: 1px solid var(--glass-border);
            color: #1e40af; 
            font-weight: 600; 
            padding: 0.75rem 1.5rem; 
            border-radius: 15px;
            transition: all 0.3s ease; 
            margin: 0.25rem; 
            position: relative; 
            overflow: hidden;
        }
        .btn-glass::before {
            content: ''; 
            position: absolute; 
            top: 0; 
            left: -100%; 
            width: 100%; 
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            transition: left 0.5s;
        }
        .btn-glass:hover::before { left: 100%; }
        .btn-glass:hover { 
            transform: translateY(-3px) scale(1.05); 
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.2); 
            color: #1e40af;
        }
        .btn-primary-glass { background: linear-gradient(135deg, rgba(59,130,246,0.2), rgba(59,130,246,0.1)); }
        .btn-success-glass { background: linear-gradient(135deg, rgba(34,197,94,0.2), rgba(34,197,94,0.1)); }
        .btn-info-glass { background: linear-gradient(135deg, rgba(14,165,233,0.2), rgba(14,165,233,0.1)); }

        /* KPI CARDS */
        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .kpi-card {
            background: rgba(255,255,255,0.9);
            border-radius: 10px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: var(--shadow-glow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px);
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }
        .kpi-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-medical);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }
        .kpi-card:hover::before { transform: scaleX(1); }
        .kpi-card:hover {
            transform: translateY(-8px) rotateX(5deg);
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.95);
        }
        .kpi-link {
            text-decoration: none;
            color: inherit;
            display: block;
        }
        .kpi-link:hover .kpi-card {
            transform: translateY(-8px) rotateX(5deg);
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.95);
        }
        .kpi-link:hover .kpi-icon {
            transform: scale(1.1) rotate(360deg);
        }
        .kpi-icon {
            font-size: 2.5rem;
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        .kpi-value {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            background: var(--primary-medical);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: colorPulse 3s ease infinite alternate;
        }
        @keyframes colorPulse {
            0%, 100% { color: #1d4ed8; }
            50% { color: #3b82f6; }
        }
        .kpi-label {
            font-size: 1rem;
            font-weight: 600;
            color: #1e293b;
        }

        /* CHARTS */
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(380px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .chart-card {
            background: rgba(255,255,255,0.9);
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: var(--shadow-glow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px);
            height: 400px;
            position: relative;
            animation: fadeScaleIn 1s ease forwards;
        }
        @keyframes fadeScaleIn {
            0% { opacity: 0; transform: scale(0.9); }
            100% { opacity: 1; transform: scale(1); }
        }
        .chart-header {
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            position: relative;
        }
        .chart-header::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 50px;
            height: 3px;
            background: var(--primary-medical);
            border-radius: 2px;
            animation: expandLine 0.5s ease forwards;
        }
        @keyframes expandLine {
            0% { width: 0; }
            100% { width: 50px; }
        }
        .chart-icon { font-size: 1.3rem; animation: iconBounce 1s ease infinite; }
        @keyframes iconBounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }

        /* ALERTES */
        .alert-custom {
            border: none;
            border-radius: 15px;
            padding: 1rem 1.5rem;
            box-shadow: var(--shadow-glow);
            backdrop-filter: blur(10px);
            animation: slideInDown 0.5s ease;
        }
        @keyframes slideInDown {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        /* ANIMATIONS */
        .fade-in-up { 
            animation: fadeInUp 0.8s ease forwards; 
            opacity: 0;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .bounce-in { animation: bounceIn 0.6s ease; }
        @keyframes bounceIn {
            0% { transform: scale(0.3); opacity: 0; }
            50% { transform: scale(1.05); }
            70% { transform: scale(0.9); }
            100% { transform: scale(1); opacity: 1; }
        }

        /* RESPONSIVE */
        @media (max-width: 992px) {
            .header-title { font-size: 2rem; }
            .kpi-grid { grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); }
            .charts-grid { grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); }
            .actions-glass { flex-direction: column; gap: 1rem; }
        }

        @media (max-width: 768px) {
            .header-title { font-size: 1.8rem; }
            .logo-hero { width: 60px; height: 60px; }
            .kpi-grid, .charts-grid { grid-template-columns: 1fr; }
            .actions-glass { padding: 1rem; }
            .btn-glass { font-size: 0.85rem; padding: 0.5rem 1rem; }
            .table-responsive { font-size: 0.85rem; }
            .header-subtitle { font-size: 1rem; }
            .kpi-value { font-size: 1.5rem; }
            .kpi-label { font-size: 0.9rem; }
            .chart-header { font-size: 1rem; }
            .chart-card { height: 350px; }
        }

        @media (max-width: 576px) {
            .header-title { font-size: 1.5rem; }
            .header-subtitle { font-size: 0.9rem; }
            .kpi-card { padding: 1rem; }
            .kpi-icon { width: 60px; height: 60px; font-size: 2rem; }
            .chart-card { height: 300px; padding: 1rem; }
        }
    </style>
</head>
<body>
    <div class="container py-4 px-3 position-relative">
        <!-- LOGO -->
        <div class="logo-hero mb-4 mx-auto d-flex justify-content-center bounce-in">
            <img src="Uploads/photos/logo1.png" alt="Logo Mutuelle Santé Matam">
        </div>

        <!-- HEADER HERO -->
        <div class="header-hero fade-in-up" 
             style="text-align:center; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:40px 0;">
            <h1 class="header-title animate__animated animate__fadeInDown">
                📊 Tableau de Bord Comptable - <?php echo htmlspecialchars($departement_nom, ENT_QUOTES, 'UTF-8'); ?>
            </h1>
            <p class="header-subtitle animate__animated animate__fadeInUp">
                Gestion financière et statistiques pour le département de <?php echo htmlspecialchars($departement_nom, ENT_QUOTES, 'UTF-8'); ?> • Contrôle et supervision
            </p>
        </div>

        <!-- ALERTES -->
        <?php if (!empty($errors)): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-custom fade-in-up" style="animation-delay: 0.1s;">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- KPI FINANCIERS -->
        <div class="kpi-grid">
            <div class="kpi-card fade-in-up" style="animation-delay: 0.7s;">
                <div class="kpi-icon" style="background: var(--primary-medical); color: white;">
                    <i class="bi bi-arrow-up-circle-fill"></i>
                </div>
                <div class="kpi-value"><?php echo number_format($total_entrees, 2); ?> FCFA</div>
                <div class="kpi-label">Total Entrées (<?php echo $year; ?>)</div>
                <small class="text-primary">Cotisations validées ✨</small>
            </div>
            <div class="kpi-card fade-in-up" style="animation-delay: 0.8s;">
                <div class="kpi-icon" style="background: var(--danger-alert); color: white;">
                    <i class="bi bi-arrow-down-circle-fill"></i>
                </div>
                <div class="kpi-value text-danger"><?php echo number_format($total_sorties, 2); ?> FCFA</div>
                <div class="kpi-label">Total Sorties (<?php echo $year; ?>)</div>
                <small class="text-danger">Remboursements approuvés ⚡</small>
            </div>
            <div class="kpi-card fade-in-up" style="animation-delay: 0.9s;">
                <div class="kpi-icon" style="background: var(--warning-gold); color: white;">
                    <i class="bi bi-hourglass-split"></i>
                </div>
                <div class="kpi-value text-warning"><?php echo $paiements_en_attente; ?></div>
                <div class="kpi-label">Paiements en Attente</div>
                <small class="text-warning">À valider ou rejeter 💰</small>
            </div>
        </div>

        <!-- ACTIONS: FILTRES ET EXPORTATION -->
        <div class="actions-glass fade-in-up" style="animation-delay: 1.0s;">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div class="d-flex align-items-center mb-3 mb-md-0">
                    <label for="year" class="me-3 fw-bold text-dark">Période :</label>
                    <select id="year" onchange="window.location.href='?year='+this.value" class="form-select bg-white border border-glass-border rounded-3 py-2 px-3 shadow-sm">
                        <?php for ($i = date('Y'); $i >= date('Y') - 5; $i--): ?>
                            <option value="<?php echo $i; ?>" <?php echo $i == $year ? 'selected' : ''; ?>><?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="d-flex gap-2">
                    <a href="?export=csv&year=<?php echo $year; ?>" class="btn-glass btn-success-glass">
                        <i class="bi bi-file-earmark-arrow-down me-2"></i>Exporter Paiements
                    </a>
                    <a href="?export_adhesions=csv&year=<?php echo $year; ?>" class="btn-glass btn-primary-glass">
                        <i class="bi bi-file-earmark-arrow-down me-2"></i>Exporter Adhésions
                    </a>
                </div>
            </div>
        </div>

        <!-- KPI ADHÉSIONS -->
        <div class="kpi-grid">
            <div class="kpi-card fade-in-up" style="animation-delay: 1.1s;">
                <div class="kpi-icon" style="background: var(--primary-medical); color: white;">
                    <i class="bi bi-people-fill"></i>
                </div>
                <div class="kpi-value"><?php echo number_format($total_adherents); ?></div>
                <div class="kpi-label">Adhérents Totale</div>
                <small class="text-primary">Couverture optimale ✨</small>
            </div>
            <div class="kpi-card fade-in-up" style="animation-delay: 1.2s;">
                <div class="kpi-icon" style="background: var(--success-health); color: white;">
                    <i class="bi bi-check-circle-fill"></i>
                </div>
                <div class="kpi-value text-success"><?php echo number_format($adherents_avec_paiement); ?> (<?php echo $total_adherents ? round(($adherents_avec_paiement / $total_adherents) * 100, 2) : 0; ?>%)</div>
                <div class="kpi-label">Adhérents Payés</div>
                <small class="text-success">Paiements effectués ✅</small>
            </div>
            <div class="kpi-card fade-in-up" style="animation-delay: 1.3s;">
                <div class="kpi-icon" style="background: var(--success-health); color: white;">
                    <i class="bi bi-heart-fill"></i>
                </div>
                <div class="kpi-value text-success"><?php echo number_format($total_beneficiaires); ?></div>
                <div class="kpi-label">Bénéficiaires Totale</div>
                <small class="text-success">Soins garantis ✅</small>
            </div>
            <div class="kpi-card fade-in-up" style="animation-delay: 1.4s;">
                <div class="kpi-icon" style="background: var(--warning-gold); color: white;">
                    <i class="bi bi-cash-coin"></i>
                </div>
                <div class="kpi-value text-warning"><?php echo number_format($montant_moyen_paiement, 2); ?> FCFA</div>
                <div class="kpi-label">Montant Moyen Paiement</div>
                <small class="text-warning">Par paiement 💰</small>
            </div>
        </div>

        <!-- GRAPHIQUES -->
        <div class="charts-grid">
            <div class="chart-card fade-in-up" style="animation-delay: 1.5s;">
                <div class="chart-header">
                    <i class="bi bi-graph-up-arrow text-success chart-icon"></i>
                    Évolution Paiements (30j)
                </div>
                <canvas id="evolutionChart"></canvas>
            </div>
            <div class="chart-card fade-in-up" style="animation-delay: 1.6s;">
                <div class="chart-header">
                    <i class="bi bi-bar-chart text-info chart-icon"></i>
                    Tendances Mensuelles (<?php echo $year; ?>)
                </div>
                <canvas id="monthlyChart"></canvas>
            </div>
            <div class="chart-card fade-in-up" style="animation-delay: 1.7s;">
                <div class="chart-header">
                    <i class="bi bi-credit-card text-primary chart-icon"></i>
                    Méthodes de Paiement (<?php echo $year; ?>)
                </div>
                <canvas id="methodesChart"></canvas>
            </div>
            <div class="chart-card fade-in-up" style="animation-delay: 1.8s;">
                <div class="chart-header">
                    <i class="bi bi-graph-up text-success chart-icon"></i>
                    Évolution Mensuelle Adhésions (<?php echo $year; ?>)
                </div>
                <canvas id="evolutionMensuelleChart"></canvas>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.js"></script>
    <script>
        const chartData = {
            evolution: {
                labels: <?php echo json_encode($labels); ?>,
                entrees: <?php echo json_encode($entrees_data); ?>,
                sorties: <?php echo json_encode($sorties_data); ?>
            },
            monthly: {
                labels: <?php echo json_encode($monthly_labels); ?>,
                entrees: <?php echo json_encode($monthly_entrees); ?>,
                sorties: <?php echo json_encode($monthly_sorties); ?>
            },
            methodes: {
                labels: <?php echo json_encode($methodes_labels); ?>,
                datasets: <?php echo json_encode($methodes_datasets); ?>
            },
            evolutionMensuelle: {
                labels: <?php echo json_encode(array_column($evolution_mensuelle, 'month')); ?>,
                data: <?php echo json_encode(array_column($evolution_mensuelle, 'total')); ?>
            }
        };

        const createLineChart = (id, labels, datasets) => {
            const ctx = document.getElementById(id)?.getContext('2d');
            if (ctx && labels.length > 0) {
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: datasets
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: true } },
                        scales: { y: { beginAtZero: true } },
                        animation: {
                            duration: 2000,
                            easing: 'easeInOutQuart'
                        }
                    }
                });
            }
        };

        const createBarChart = (id, labels, datasets, stacked = false) => {
            const ctx = document.getElementById(id)?.getContext('2d');
            if (ctx && labels.length > 0) {
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: datasets
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: true } },
                        scales: {
                            x: { stacked: stacked },
                            y: { stacked: stacked, beginAtZero: true }
                        },
                        animation: {
                            duration: 2000,
                            easing: 'easeInOutQuart'
                        }
                    }
                });
            }
        };

        // Évolution Paiements
        createLineChart('evolutionChart', chartData.evolution.labels, [
            { label: 'Entrées', data: chartData.evolution.entrees, borderColor: '#3b82f6', backgroundColor: '#3b82f620', tension: 0.4, fill: true },
            { label: 'Sorties', data: chartData.evolution.sorties, borderColor: '#ef4444', backgroundColor: '#ef444420', tension: 0.4, fill: true }
        ]);

        // Tendances Mensuelles
        createBarChart('monthlyChart', chartData.monthly.labels, [
            { label: 'Entrées', data: chartData.monthly.entrees, backgroundColor: '#3b82f6' },
            { label: 'Sorties', data: chartData.monthly.sorties, backgroundColor: '#ef4444' }
        ]);

        // Méthodes de Paiement
        createBarChart('methodesChart', chartData.methodes.labels, chartData.methodes.datasets, true);

        // Évolution Mensuelle Adhésions
        createBarChart('evolutionMensuelleChart', chartData.evolutionMensuelle.labels, [
            { label: 'Adhésions', data: chartData.evolutionMensuelle.data, backgroundColor: '#10b981' }
        ]);
    </script>
</body>
</html>
<?php require_once '../includes/footer.php'; ?>