<?php
// pages/dashboard_directeur.php - VERSION PREMIUM AVEC TOP 5 COLORÉ
ob_start();
require_once '../includes/header.php';
checkSessionTimeout();
checkRole('directeur_departemental');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();
$periode = $_GET['periode'] ?? 'mois';
$departement_id = $_SESSION['departement'] ?? 1;

// INITIALISATION KPI
$total_adherents = 0;
$total_beneficiaires = 0;
$total_cotisations = 0;
$adhesions_en_attente = 0;
$remboursements_en_attente = 0;
$chart_data = [];

if (isset($pdo)) {
    try {
        // KPI principaux
        $stmt = $pdo->prepare("
            SELECT COUNT(DISTINCT u.id_utilisateur) as total 
            FROM utilisateurs u JOIN adhesions a ON u.id_utilisateur = a.id_utilisateur 
            WHERE u.departement = ? AND a.statut = 'active' AND u.statut = 'actif'
        ");
        $stmt->execute([$departement_id]);
        $total_adherents = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare("
            SELECT COUNT(*) as total 
            FROM beneficiaires b JOIN adhesions a ON b.id_adhesion = a.id_adhesion 
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
            WHERE u.departement = ? AND b.statut = 'actif' AND a.statut = 'active'
        ");
        $stmt->execute([$departement_id]);
        $total_beneficiaires = (int)$stmt->fetchColumn();

        $date_filter = match($periode) {
            'mois' => "DATE_SUB(CURDATE(), INTERVAL 30 DAY)",
            'trimestre' => "DATE_SUB(CURDATE(), INTERVAL 90 DAY)",
            'annee' => "DATE_SUB(CURDATE(), INTERVAL 365 DAY)",
            default => "DATE_SUB(CURDATE(), INTERVAL 30 DAY)"
        };

        $stmt = $pdo->prepare("
            SELECT COALESCE(SUM(p.montant_verse), 0) as total 
            FROM paiements p JOIN adhesions a ON p.id_adhesion = a.id_adhesion 
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
            WHERE u.departement = ? AND p.statut = 'paye' AND p.date_paiement >= $date_filter
        ");
        $stmt->execute([$departement_id]);
        $total_cotisations = (float)$stmt->fetchColumn();

        $stmt = $pdo->prepare("
            SELECT COUNT(*) as total 
            FROM adhesions a JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
            WHERE u.departement = ? AND a.statut = 'en_attente_validation'
        ");
        $stmt->execute([$departement_id]);
        $adhesions_en_attente = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare("
            SELECT COUNT(*) as total 
            FROM demandes_remboursement d JOIN adhesions a ON d.id_adhesion = a.id_adhesion
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
            WHERE u.departement = ? AND d.statut = 'en_attente'
        ");
        $stmt->execute([$departement_id]);
        $remboursements_en_attente = (int)$stmt->fetchColumn();

        // Données charts
        $chart_data = [
            'adhesions_evol' => [],
            'methodes_paiement' => [],
            'agents_perf' => [],
            'cotisations_periode' => []
        ];

        // Évolution adhésions
        $stmt = $pdo->prepare("
            SELECT DATE(a.date_adhesion) as date, COUNT(*) as count
            FROM adhesions a JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
            WHERE u.departement = ? AND a.statut = 'active'
            AND a.date_adhesion >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            GROUP BY DATE(a.date_adhesion) ORDER BY date ASC
        ");
        $stmt->execute([$departement_id]);
        $chart_data['adhesions_evol'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Méthodes de paiement
        $stmt = $pdo->prepare("
            SELECT p.methode, COUNT(*) as count, COALESCE(SUM(p.montant_verse), 0) as total_montant,
                   ROUND((COUNT(*) * 100.0 / (SELECT COUNT(*) FROM paiements p2 
                   JOIN adhesions a2 ON p2.id_adhesion = a2.id_adhesion
                   JOIN utilisateurs u2 ON a2.id_utilisateur = u2.id_utilisateur
                   WHERE u2.departement = ?)), 1) as pourcentage
            FROM paiements p JOIN adhesions a ON p.id_adhesion = a.id_adhesion 
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
            WHERE u.departement = ? AND p.statut = 'paye'
            GROUP BY p.methode ORDER BY total_montant DESC
        ");
        $stmt->execute([$departement_id, $departement_id]);
        $chart_data['methodes_paiement'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // TOP 5 AGENTS - Données pour couleurs distinctes
        $stmt = $pdo->prepare("
            SELECT CONCAT(u.prenom, ' ', u.nom) as agent, COUNT(a.id_adhesion) as adhesions
            FROM utilisateurs u LEFT JOIN adhesions a ON u.id_utilisateur = a.created_by AND a.statut = 'active'
            WHERE u.role = 'agent_mobilisateur' AND u.departement = ?
            GROUP BY u.id_utilisateur ORDER BY adhesions DESC LIMIT 5
        ");
        $stmt->execute([$departement_id]);
        $chart_data['agents_perf'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Cotisations récentes
        $stmt = $pdo->prepare("
            SELECT DATE(p.date_paiement) as date, SUM(p.montant_verse) as montant
            FROM paiements p JOIN adhesions a ON p.id_adhesion = a.id_adhesion 
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
            WHERE u.departement = ? AND p.statut = 'paye' 
            AND p.date_paiement >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            GROUP BY DATE(p.date_paiement) ORDER BY date ASC
        ");
        $stmt->execute([$departement_id]);
        $chart_data['cotisations_periode'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        $errors[] = "Erreur base de données.";
        error_log("Dashboard erreur: " . $e->getMessage());
    }
}

// Nom département
$nom_departement = $_SESSION['departement'] ?? 'Inconnu';
try {
    if (isset($pdo)) {
        $stmt = $pdo->prepare("SELECT nom FROM departements WHERE id_departement = ?");
        $stmt->execute([$departement_id]);
        $nom_dept = $stmt->fetchColumn();
        if ($nom_dept) $nom_departement = $nom_dept;
    }
} catch (PDOException $e) {}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🩺 Dashboard Directeur Premium - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        :root {
            /* PALETTE MÉDICALE LUXE */
            --primary-medical: linear-gradient(135deg, #1e3a8a, #3b82f6, #1d4ed8);
            --success-health: linear-gradient(135deg, #15803d, #22c55e, #16a34a);
            --warning-gold: linear-gradient(135deg, #d97706, #f59e0b, #b45309);
            --danger-alert: linear-gradient(135deg, #dc2626, #ef4444, #b91c1c);
            --purple-pharma: linear-gradient(135deg, #7c3aed, #a855f7, #9333ea);
            --teal-care: linear-gradient(135deg, #0f766e, #14b8a6, #0d9488);
            --glass-bg: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
            --shadow-glow: 0 25px 50px -12px rgba(59, 130, 246, 0.3);
            --shadow-hover: 0 35px 60px -15px rgba(59, 130, 246, 0.4);
            --bg-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        * { font-family: 'Inter', sans-serif; }
        body { 
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 50%, #f0f9ff 100%);
            min-height: 100vh; overflow-x: hidden;
            position: relative;
        }
        body::before {
            content: ''; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: radial-gradient(circle at 20% 50%, rgba(120, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 40% 80%, rgba(120, 219, 255, 0.1) 0%, transparent 50%);
            z-index: -1;
        }

        /* HEADER SPECTACULAIRE */
        .header-hero {
            background: var(--primary-medical);
            border-radius: 24px; padding: 2rem; color: white; margin-bottom: 2rem;
            position: relative; overflow: hidden; box-shadow: var(--shadow-glow);
            backdrop-filter: blur(20px);
        }
        .header-hero::before {
            content: ''; position: absolute; top: -50%; left: -50%; width: 200%; height: 200%;
            background: conic-gradient(from 0deg, transparent, rgba(255,255,255,0.1), transparent 30%);
            animation: rotate 20s linear infinite; opacity: 0.3;
        }
        @keyframes rotate { 100% { transform: rotate(360deg); } }
        .logo-hero {
            width: 80px; height: 80px; border-radius: 50%; background: var(--glass-bg);
            display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem;
            backdrop-filter: blur(10px); border: 2px solid var(--glass-border);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2); animation: pulse 2s infinite;
        }
        .logo-hero img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
        @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.05); } }
        .header-title { 
            font-size: 2.2rem; font-weight: 800; margin-bottom: 0.5rem;
            background: linear-gradient(45deg, #fff, #e0f2fe); -webkit-background-clip: text;
            -webkit-text-fill-color: transparent; text-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header-subtitle { 
            font-size: 1.1rem; opacity: 0.95; font-weight: 400; max-width: 700px; margin: 0 auto;
        }

        /* BOUTONS D'ACTION EN HAUT - GLASSMORPHISM */
        .actions-glass {
            background: var(--glass-bg); backdrop-filter: blur(20px); border-radius: 20px;
            padding: 1.5rem; margin-bottom: 2rem; border: 1px solid var(--glass-border);
            box-shadow: var(--shadow-glow);
        }
        .btn-glass {
            background: var(--glass-bg); backdrop-filter: blur(20px); border: 1px solid var(--glass-border);
            color: #1e40af; font-weight: 600; padding: 0.75rem 1.5rem; border-radius: 15px;
            transition: all 0.3s ease; margin: 0.25rem; position: relative; overflow: hidden;
        }
        .btn-glass::before {
            content: ''; position: absolute; top: 0; left: -100%; width: 100%; height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            transition: left 0.5s;
        }
        .btn-glass:hover::before { left: 100%; }
        .btn-glass:hover { 
            transform: translateY(-3px) scale(1.05); box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.2); color: #1e40af;
        }
        .btn-primary-glass { background: linear-gradient(135deg, rgba(59,130,246,0.2), rgba(59,130,246,0.1)); }
        .btn-success-glass { background: linear-gradient(135deg, rgba(34,197,94,0.2), rgba(34,197,94,0.1)); }
        .btn-warning-glass { background: linear-gradient(135deg, rgba(245,158,11,0.2), rgba(245,158,11,0.1)); }
        .btn-danger-glass { background: linear-gradient(135deg, rgba(239,68,68,0.2), rgba(239,68,68,0.1)); }
        .btn-info-glass { background: linear-gradient(135deg, rgba(14,165,233,0.2), rgba(14,165,233,0.1)); }
        .btn-secondary-glass { background: linear-gradient(135deg, rgba(107,114,128,0.2), rgba(107,114,128,0.1)); }

        /* KPI CARDS ANIMÉES */
        .kpi-grid { 
            display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); 
            gap: 1.5rem; margin-bottom: 2rem;
        }
        .kpi-card {
            background: rgba(255,255,255,0.9); border-radius: 10px; padding: 1.5rem;
            text-align: center; box-shadow: var(--shadow-glow); border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px); transition: all 0.4s ease;
            position: relative; overflow: hidden;
        }
        .kpi-card::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px;
            background: var(--primary-medical); transform: scaleX(0); transition: transform 0.3s ease;
        }
        .kpi-card:hover::before { transform: scaleX(1); }
        .kpi-card:hover { 
            transform: translateY(-8px) rotateX(5deg); box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.95);
        }
        .kpi-link {
            text-decoration: none; /* Supprime le soulignement */
            color: inherit; /* Conserve la couleur du texte */
            display: block; /* Remplit toute la carte */
        }
        .kpi-link:hover .kpi-card {
            transform: translateY(-8px) rotateX(5deg);
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.95);
        }
        .kpi-link:hover .kpi-icon {
            transform: scale(1.1) rotate(360deg);
        }
        .kpi-icon { 
            font-size: 2.5rem; width: 70px; height: 70px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1); transition: all 0.3s ease;
        }
        .kpi-value { 
            font-size: 2rem; font-weight: 800; margin-bottom: 0.5rem;
            background: var(--primary-medical); -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .kpi-label { font-size: 1rem; font-weight: 600; color: #1e293b; }

        /* CHARTS ÉLÉGANTS */
        .charts-grid { 
            display: grid; grid-template-columns: repeat(auto-fit, minmax(380px, 1fr)); 
            gap: 1.5rem; margin-bottom: 2rem;
        }
        .chart-card {
            background: rgba(255,255,255,0.9); border-radius: 20px; padding: 1.5rem;
            box-shadow: var(--shadow-glow); border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px); height: 400px; position: relative;
        }
        .chart-header {
            font-size: 1.1rem; font-weight: 700; margin-bottom: 1rem; color: #1e293b;
            display: flex; align-items: center; gap: 0.5rem;
            position: relative;
        }
        .chart-header::after {
            content: ''; position: absolute; bottom: -5px; left: 0; width: 50px; height: 3px;
            background: var(--primary-medical); border-radius: 2px;
        }
        .chart-icon { font-size: 1.3rem; }

        /* ALERTES ANIMÉES */
        .alert-custom {
            border: none; border-radius: 15px; padding: 1rem 1.5rem;
            box-shadow: var(--shadow-glow); backdrop-filter: blur(10px);
            animation: slideInDown 0.5s ease;
        }
        @keyframes slideInDown { from { transform: translateY(-50px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

        /* ANIMATIONS */
        .fade-in-up { 
            animation: fadeInUp 0.8s ease forwards; opacity: 0;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .bounce-in { animation: bounceIn 0.6s ease; }
        @keyframes bounceIn {
            0% { transform: scale(0.3); opacity: 0; }
            50% { transform: scale(1.05); }
            70% { transform: scale(0.9); }
            100% { transform: scale(1); opacity: 1; }
        }

        /* RESPONSIVE */
        @media (max-width: 768px) {
            .header-title { font-size: 1.8rem; }
            .logo-hero { width: 60px; height: 60px; }
            .kpi-grid, .charts-grid { grid-template-columns: 1fr; }
            .actions-glass { padding: 1rem; }
            .btn-glass { font-size: 0.85rem; padding: 0.5rem 1rem; }
        }
    </style>
</head>
<body>
    <div class="container py-4 px-3 position-relative">
        <!-- LOGO AVEC FONCTIONNEMENT CORRIGÉ -->
        <div class="logo-hero mb-4 mx-auto d-flex justify-content-center bounce-in">
            <img src="Uploads/photos/logo1.png" 
                 alt="Logo Mutuelle Santé Matam">
        </div>

        <!-- HEADER HERO -->
        <div class="header-hero fade-in-up" 
     style="text-align:center; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:40px 0;">
    
    <h1 class="header-title animate__animated animate__fadeInDown">
        🩺 Dashboard Directeur De 
        <strong style="color: yellow;">
            <?php echo strtoupper(htmlspecialchars($nom_departement)); ?>
        </strong>
    </h1>

    <p class="header-subtitle animate__animated animate__fadeInUp">
        Ensemble, bâtissons une couverture santé solide pour tous les habitants de • 
        <strong style="color: yellow;">
            <?php echo strtoupper(htmlspecialchars($nom_departement)); ?>
        </strong> •
    </p>
</div>


        <!-- BOUTONS D'ACTION EN HAUT -->
        <div class="actions-glass fade-in-up" style="animation-delay: 0.2s;">
            <div class="d-flex flex-wrap justify-content-center gap-2">
                <a href="validate_adhesion.php" class="btn btn-primary-glass btn-glass bounce-in" style="animation-delay: 0.3s;">
                    <i class="bi bi-check-circle-fill me-2"></i>Valider Adhésions
                </a>
                <a href="validate_remboursement.php" class="btn btn-success-glass btn-glass bounce-in" style="animation-delay: 0.4s;">
                    <i class="bi bi-file-medical-fill me-2"></i>Remboursements
                </a>
                <a href="list_adherents.php" class="btn btn-info-glass btn-glass bounce-in" style="animation-delay: 0.5s;">
                    <i class="bi bi-list-ul me-2"></i>Liste Adhérents
                </a>
                <a href="validate_beneficiaire.php" class="btn btn-warning-glass btn-glass bounce-in" style="animation-delay: 0.6s;">
                    <i class="bi bi-person-check-fill me-2"></i>Valider Bénéficiaire
                </a>
                <a href="add_agent.php" class="btn btn-secondary-glass btn-glass bounce-in" style="animation-delay: 0.7s;">
                    <i class="bi bi-person-plus-fill me-2"></i>Ajouter Agent
                </a>
                <a href="list_paiements.php" class="btn btn-danger-glass btn-glass bounce-in" style="animation-delay: 0.8s;">
                    <i class="bi bi-receipt me-2"></i>Suivi Paiements
                </a>
            </div>
            <div class="text-center mt-3">
                <small class="text-muted">
                    👆 Actions prioritaires • <?php echo $adhesions_en_attente; ?> adhésions en attente • 
                    <?php echo $remboursements_en_attente; ?> remboursements à valider
                </small>
            </div>
        </div>

        <!-- ALERTES -->
        <?php if (!empty($errors)): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-custom fade-in-up" style="animation-delay: 0.1s;">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- KPI CARDS ANIMÉES -->
        <div class="kpi-grid">
            <a href="list_adherents.php" class="kpi-link">
                <div class="kpi-card fade-in-up" style="animation-delay: 0.7s;">
                    <div class="kpi-icon" style="background: var(--primary-medical); color: white;">
                        <i class="bi bi-people-fill"></i>
                    </div>
                    <div class="kpi-value"><?php echo number_format($total_adherents); ?></div>
                    <div class="kpi-label">Adhérents Actifs</div>
                    <small class="text-primary">Couverture optimale ✨</small>
                </div>
            </a>
            <a href="validate_beneficiaire.php" class="kpi-link">
                <div class="kpi-card fade-in-up" style="animation-delay: 0.8s;">
                    <div class="kpi-icon" style="background: var(--success-health); color: white;">
                        <i class="bi bi-heart-fill"></i>
                    </div>
                    <div class="kpi-value text-success"><?php echo number_format($total_beneficiaires); ?></div>
                    <div class="kpi-label">Bénéficiaires</div>
                    <small class="text-success">Soins garantis ✅</small>
                </div>
            </a>
            <a href="list_paiements.php?periode=<?php echo htmlspecialchars($periode); ?>" class="kpi-link">
                <div class="kpi-card fade-in-up" style="animation-delay: 0.9s;">
                    <div class="kpi-icon" style="background: var(--warning-gold); color: white;">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                    <div class="kpi-value text-warning">
                        <?php echo number_format($total_cotisations/1000, 0); ?>k<small class="fs-6">FCFA</small>
                    </div>
                    <div class="kpi-label">Cotisations <?php echo strtoupper($periode); ?></div>
                    <small class="text-warning">Encaissements 💰</small>
                </div>
            </a>
            <a href="validate_adhesion.php" class="kpi-link">
                <div class="kpi-card fade-in-up" style="animation-delay: 1s;">
                    <div class="kpi-icon" style="background: var(--danger-alert); color: white;">
                        <i class="bi bi-hourglass-split"></i>
                    </div>
                    <div class="kpi-value text-danger"><?php echo $adhesions_en_attente; ?></div>
                    <div class="kpi-label">En Attente</div>
                    <small class="text-danger">À traiter urgent ⚡</small>
                </div>
            </a>
        </div>

        <!-- GRAPHIQUES PREMIUM -->
        <div class="charts-grid">
            <div class="chart-card fade-in-up" style="animation-delay: 1.1s;">
                <div class="chart-header">
                    <i class="bi bi-graph-up-arrow text-success chart-icon"></i>
                    Évolution Adhésions (30j)
                </div>
                <canvas id="chartAdhesions"></canvas>
            </div>
            <div class="chart-card fade-in-up" style="animation-delay: 1.2s;">
                <div class="chart-header">
                    <i class="bi bi-credit-card-2-front text-primary chart-icon"></i>
                    Méthodes de Paiement
                </div>
                <canvas id="chartMethodes"></canvas>
            </div>
            <div class="chart-card fade-in-up" style="animation-delay: 1.3s;">
                <div class="chart-header">
                    <i class="bi bi-trophy text-warning chart-icon"></i>
                    Top 5 Agents
                </div>
                <canvas id="chartAgents"></canvas>
            </div>
            <div class="chart-card fade-in-up" style="animation-delay: 1.4s;">
                <div class="chart-header">
                    <i class="bi bi-cash-stack text-info chart-icon"></i>
                    Cotisations (7j)
                </div>
                <canvas id="chartCotisations"></canvas>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.js"></script>
    <script>
        const chartData = <?php echo json_encode($chart_data); ?>;

        // COULEURS UNIQUES TOP 5 AGENTS
        const agentColors = [
            '#3b82f6', // 1er - Bleu royal ⭐
            '#10b981', // 2ème - Vert succès ✅
            '#f59e0b', // 3ème - Orange chaud 🔥
            '#8b5cf6', // 4ème - Violet élégant 💜
            '#06b6d4'  // 5ème - Cyan moderne 🌊
        ];

        // Charts avec TOP 5 COLORÉ
        const createChart = (id, type, dataKey, labelsKey, options = {}) => {
            const ctx = document.getElementById(id)?.getContext('2d');
            if (ctx && chartData[dataKey]?.length > 0) {
                
                // COULEURS SPÉCIALES POUR TOP 5 AGENTS
                let backgroundColors = type === 'doughnut' ? 
                    ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'] : 
                    'rgba(59, 130, 246, 0.2)';
                
                let borderColors = type === 'doughnut' ? undefined : '#3b82f6';
                let borderRadius = 0;
                let legendDisplay = true;
                let gridDisplay = true;
                let animationDelay = 0;
                
                // TOP 5 AGENTS : COULEURS UNIQUES + EFFETS SPÉCIAUX
                if (type === 'bar' && dataKey === 'agents_perf') {
                    backgroundColors = agentColors.slice(0, chartData[dataKey].length);
                    borderColors = agentColors.slice(0, chartData[dataKey].length);
                    borderRadius = 8; // Coins arrondis
                    legendDisplay = false; // Pas de légende
                    gridDisplay = false; // Pas de grille
                    animationDelay = (context) => context.dataIndex * 200; // Animation séquentielle
                }
                
                new Chart(ctx, {
                    type,
                    data: {
                        labels: chartData[dataKey].map(d => d[labelsKey]),
                        datasets: [{
                            data: chartData[dataKey].map(d => d.count || d.total_montant || d.adhesions || d.montant),
                            backgroundColor: backgroundColors,
                            borderColor: borderColors,
                            borderWidth: type === 'doughnut' ? 0 : 2,
                            borderRadius: borderRadius,
                            tension: type === 'line' ? 0.4 : 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { 
                            legend: { 
                                display: legendDisplay,
                                position: type === 'doughnut' ? 'bottom' : 'top',
                                labels: { padding: 20, usePointStyle: true }
                            }
                        },
                        animation: { 
                            duration: type === 'bar' && dataKey === 'agents_perf' ? 2500 : 2000, 
                            easing: type === 'bar' && dataKey === 'agents_perf' ? 'easeOutBounce' : 'easeInOutQuart',
                            delay: animationDelay
                        },
                        scales: { 
                            y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } },
                            x: { 
                                grid: { 
                                    color: 'rgba(0,0,0,0.05)',
                                    display: gridDisplay
                                },
                                ticks: {
                                    maxRotation: type === 'bar' && dataKey === 'agents_perf' ? 45 : 0
                                }
                            }
                        },
                        ...options
                    }
                });
            }
        };

        // Création charts
        createChart('chartAdhesions', 'line', 'adhesions_evol', 'date', {
            scales: { y: { beginAtZero: true } }
        });
        
        createChart('chartMethodes', 'doughnut', 'methodes_paiement', 'methode');
        
        // TOP 5 AVEC COULEURS UNIQUES
        createChart('chartAgents', 'bar', 'agents_perf', 'agent', {
            scales: { y: { beginAtZero: true } },
            plugins: { legend: { display: false } } // Redondant mais explicite
        });
        
        createChart('chartCotisations', 'line', 'cotisations_periode', 'date', {
            scales: { y: { beginAtZero: true } }
        });

        // Effets d'animation au scroll
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.animationPlayState = 'running';
                }
            });
        });
        document.querySelectorAll('.fade-in-up').forEach(el => observer.observe(el));
    </script>
</body>
</html>
<?php require_once '../includes/footer.php'; ob_end_flush(); ?>