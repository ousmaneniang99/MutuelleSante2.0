<?php
// pages/dashboard_prestataire.php
ob_start();
require_once '../includes/header.php';
checkRole('prestataire_soins');

$csrf_token = generateCsrfToken();

// === GESTION DE LA CONFIRMATION VIA AJAX ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm']) && verifyCsrfToken($_POST['csrf_token'])) {
    $id_demande = (int)$_POST['id_demande'];
    
    // Vérification que la demande appartient au prestataire
    $stmt_check = $pdo->prepare("SELECT id_demande FROM demandes_remboursement WHERE id_demande = ? AND id_prestataire = ? AND statut = 'en_validation'");
    $stmt_check->execute([$id_demande, $_SESSION['user_id']]); // Utilise user_id pour sécurité, ou id_prestataire si lié
    
    if ($stmt_check->fetch()) {
        $stmt = $pdo->prepare("UPDATE demandes_remboursement SET statut = 'approuve', date_validation = NOW() WHERE id_demande = ?");
        $success = $stmt->execute([$id_demande]);
        
        if ($success) {
            // Log optionnel (ex: audit trail)
            // logActivity("Confirmation remboursement", $id_demande, $_SESSION['user_id']);
            
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => 'Confirmation réussie']);
        } else {
            header('Content-Type: application/json');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Erreur lors de la mise à jour']);
        }
    } else {
        header('Content-Type: application/json');
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Accès non autorisé']);
    }
    exit;
}

// === VÉRIFICATION QUE formatFCFA EXISTE (SINON ON LA CRÉE EN DERNIER RECOURS) ===
if (!function_exists('formatFCFA')) {
    function formatFCFA($montant) {
        return number_format($montant, 0, ',', ' ') . ' FCFA';
    }
}

// === INFOS PRESTATAIRE ===
$stmt = $pdo->prepare("SELECT p.id_prestataire, p.nom AS nom_prestataire, p.logo, n.niveau 
                       FROM prestataires p JOIN niveau n ON p.id_niveau = n.id_niveau 
                       WHERE p.id_utilisateur = ?");
$stmt->execute([$_SESSION['user_id']]);
$prestataire = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$prestataire) { ob_end_clean(); header('Location: logout.php'); exit; }

$nom_prestataire = $prestataire['nom_prestataire'];
$logo_path = !empty($prestataire['logo']) && file_exists("../" . $prestataire['logo'])
    ? "../" . $prestataire['logo'] : "uploads/photos/prestataire.jpg";
$niveau = $prestataire['niveau'];
$id_prestataire = $prestataire['id_prestataire'];

// === KPI ===
$kpi = ['en_attente' => 0, 'a_confirmer' => 0, 'rembourse' => 0, 'beneficiaires' => 0];
$stmt = $pdo->prepare("SELECT 
    SUM(CASE WHEN dr.statut = 'en_attente' THEN 1 ELSE 0 END) AS en_attente,
    SUM(CASE WHEN dr.statut = 'en_validation' THEN 1 ELSE 0 END) AS a_confirmer,
    SUM(CASE WHEN dr.statut = 'approuve' THEN dr.montant_rembourse ELSE 0 END) AS rembourse,
    COUNT(DISTINCT dr.id_beneficiaire) AS beneficiaires
    FROM demandes_remboursement dr WHERE dr.id_prestataire = ?");
$stmt->execute([$id_prestataire]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
foreach ($row as $k => $v) $kpi[$k] = $v ?? 0;

// === PAIEMENTS À CONFIRMER PAR MOIS ===
$paiements_par_mois = [];
$formatter = new IntlDateFormatter('fr_FR', IntlDateFormatter::LONG, IntlDateFormatter::NONE);
$formatter->setPattern('MMMM yyyy');

try {
    $stmt = $pdo->prepare("SELECT DATE_FORMAT(dr.date_soin, '%Y-%m') AS mois, COUNT(*) AS total, SUM(dr.montant_rembourse) AS total_montant
        FROM demandes_remboursement dr WHERE dr.id_prestataire = ? AND dr.statut = 'en_validation'
        GROUP BY DATE_FORMAT(dr.date_soin, '%Y-%m') ORDER BY mois DESC");
    $stmt->execute([$id_prestataire]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $m) {
        $mois_key = $m['mois'];
        $date_obj = new DateTime("$mois_key-01");
        $mois_fr = ucfirst($formatter->format($date_obj));

        $stmt2 = $pdo->prepare("SELECT dr.id_demande, dr.date_soin, dr.montant_rembourse, dr.pieces_jointes,
            a.num_adherent, b.code_beneficiaire
            FROM demandes_remboursement dr
            JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
            JOIN beneficiaires b ON dr.id_beneficiaire = b.id_beneficiaire
            WHERE dr.id_prestataire=? AND dr.statut='en_validation' AND DATE_FORMAT(dr.date_soin, '%Y-%m')=?
            ORDER BY dr.date_soin DESC");
        $stmt2->execute([$id_prestataire, $mois_key]);
        $paiements_par_mois[$mois_key] = [
            'mois_fr' => $mois_fr,
            'total' => $m['total'],
            'total_montant' => $m['total_montant'],
            'demandes' => $stmt2->fetchAll(PDO::FETCH_ASSOC)
        ];
    }
} catch (Exception $e) { error_log("DB ERROR: " . $e->getMessage()); }

// === DÉTECTION PHARMACIE ===
$is_pharmacie = ($niveau === 'Pharmacie');
?>

<!DOCTYPE html>
<html lang="fr" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($nom_prestataire) ?> - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        :root {
            --p: #10b981;
            --ph: #34d399;
            --s: #059669;
            --glass: rgba(255, 255, 255, 0.25);
            --border: rgba(255, 255, 255, 0.18);
            --shadow: 0 8px 32px rgba(0, 0, 0, 0.12);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            --radius: 1.25rem;
            --trans: all 0.4s cubic-bezier(0.25, 0.1, 0.25, 1);
        }
        [data-bs-theme="dark"] {
            --glass: rgba(15, 23, 42, 0.6);
            --border: rgba(255, 255, 255, 0.1);
            --p: #22d3ee;
            --ph: #67e8f9;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            font-family: 'Inter', sans-serif;
            color: #0f172a;
            min-height: 100vh;
            transition: var(--trans);
            line-height: 1.6;
            overflow-x: hidden;
        }
        [data-bs-theme="dark"] body {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            color: #f1f5f9;
        }
        .c { 
            max-width: 1440px; 
            margin: auto; 
            padding: 2rem 1rem; 
        }
        @media (max-width: 576px) {
            .c { padding: 1rem 0.5rem; }
        }
        @media (min-width: 1200px) {
            .c { padding: 2.5rem 2rem; }
        }
        .h {
            background: linear-gradient(135deg, var(--p), var(--ph));
            color: #fff;
            padding: 2.5rem 0;
            position: relative;
            overflow: hidden;
            border-radius: 0 0 var(--radius) var(--radius);
            box-shadow: var(--shadow-lg);
            will-change: transform;
        }
        .h::before {
            content: '';
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at 20% 80%, rgba(255, 255, 255, 0.3), transparent 70%);
            animation: shimmer 4s infinite ease-in-out;
        }
        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%) scaleX(1); }
            50% { transform: translateX(100%) scaleX(1.1); }
        }
        .logo {
            width: 90px; height: 90px;
            object-fit: cover;
            border-radius: 1.5rem;
            border: 4px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            transition: var(--trans);
            animation: float 6s ease-in-out infinite;
            will-change: transform;
        }
        @media (max-width: 768px) {
            .logo { width: 70px; height: 70px; }
        }
        @media (max-width: 576px) {
            .logo { width: 60px; height: 60px; }
        }
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-8px); }
        }
        .logo:hover { transform: scale(1.05) rotate(3deg); }
        .niveau-badge {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(20px);
            padding: 0.8rem 1.6rem;
            border-radius: 50px;
            font-weight: 600;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            transition: var(--trans);
        }
        .niveau-badge:hover { background: rgba(255, 255, 255, 0.3); transform: scale(1.05); }
        .kpi {
            background: var(--glass);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 1.5rem 1rem;
            text-align: center;
            box-shadow: var(--shadow);
            transition: var(--trans);
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: center;
            height: 100%;
            will-change: transform;
        }
        .kpi::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; height: 4px;
            background: linear-gradient(90deg, var(--p), var(--ph));
        }
        .kpi:hover {
            transform: translateY(-8px) scale(1.02);
            box-shadow: var(--shadow-lg);
        }
        .kpi-icon {
            font-size: 2.5rem;
            background: linear-gradient(135deg, var(--p), var(--ph));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 0.75rem;
            opacity: 0; animation: fadeInUp 0.6s ease forwards;
        }
        @media (max-width: 768px) {
            .kpi-icon { font-size: 2rem; }
        }
        @media (max-width: 576px) {
            .kpi-icon { font-size: 1.75rem; }
        }
        .kpi-value { 
            font-size: 1.75rem; 
            font-weight: 800; 
            margin: 0.25rem 0; 
            color: var(--p); 
        }
        @media (max-width: 768px) {
            .kpi-value { font-size: 1.5rem; }
        }
        @media (max-width: 576px) {
            .kpi-value { font-size: 1.25rem; }
        }
        .action {
            background: var(--glass);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 1.75rem 0.75rem;
            text-align: center;
            transition: var(--trans);
            position: relative;
            overflow: hidden;
            text-decoration: none;
            color: inherit;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 0.75rem;
            height: 100%;
            will-change: transform;
        }
        @media (max-width: 768px) {
            .action { padding: 1.5rem 0.75rem; }
            .action i { font-size: 2.25rem; }
            .action span { font-size: 0.95rem; }
        }
        @media (max-width: 576px) {
            .action { padding: 1.25rem 0.5rem; }
            .action i { font-size: 2rem; }
            .action span { font-size: 0.9rem; }
        }
        .action::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.05), transparent);
            opacity: 0;
            transition: var(--trans);
        }
        .action:hover::before { opacity: 1; }
        .action:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-lg);
            color: var(--p);
        }
        .action i {
            font-size: 2.75rem;
            background: linear-gradient(135deg, var(--p), var(--ph));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: var(--trans);
        }
        .action:hover i { transform: scale(1.1); }
        .action span { font-weight: 600; font-size: 1rem; }
        .m {
            background: var(--glass);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            overflow: hidden;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            transition: var(--trans);
        }
        .m:hover { box-shadow: var(--shadow-lg); }
        .mh {
            background: linear-gradient(135deg, var(--p), var(--ph));
            color: #fff;
            padding: 1.5rem 2rem;
            font-weight: 700;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            transition: var(--trans);
        }
        @media (max-width: 768px) {
            .mh { padding: 1.2rem 1.5rem; flex-direction: column; align-items: flex-start; gap: 0.5rem; }
            .msv { font-size: 1.4rem; }
        }
        @media (max-width: 576px) {
            .mh { padding: 1rem 1rem; }
            .msv { font-size: 1.2rem; }
        }
        .mh:hover { background: linear-gradient(135deg, var(--ph), var(--p)); }
        .mh::after {
            content: '\f285';
            font-family: 'bootstrap-icons';
            font-size: 1.2rem;
            transition: transform 0.3s ease;
        }
        .mh.collapsed::after { transform: rotate(-90deg); }
        .msv { font-size: 1.8rem; font-weight: 800; }
        .tbl { font-size: 0.95rem; }
        .tbl th {
            background: var(--glass);
            backdrop-filter: blur(10px);
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.5px;
            font-weight: 600;
            padding: 1rem 0.5rem;
        }
        @media (max-width: 768px) {
            .tbl { font-size: 0.85rem; }
            .tbl th, .tbl td { padding: 0.5rem 0.25rem; text-align: center; }
        }
        @media (max-width: 576px) {
            .tbl th, .tbl td { padding: 0.4rem 0.2rem; font-size: 0.8rem; }
            .tbl th:nth-child(1), .tbl td:nth-child(1) { display: none; }
            .tbl th:nth-child(6), .tbl td:nth-child(6) { display: none; }
        }
        .btn-confirm {
            background: linear-gradient(135deg, #10b981, #059669);
            border: none;
            color: #fff;
            padding: 0.8rem 1.2rem;
            border-radius: 50px;
            font-weight: 600;
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.3);
            transition: var(--trans);
            width: 45px; height: 45px;
            display: flex; align-items: center; justify-content: center;
        }
        @media (max-width: 768px) {
            .btn-confirm { width: 40px; height: 40px; }
        }
        @media (max-width: 576px) {
            .btn-confirm { width: 35px; height: 35px; }
        }
        .btn-confirm:hover {
            transform: translateY(-2px) scale(1.05);
            box-shadow: 0 12px 35px rgba(16, 185, 129, 0.4);
        }
        .theme-toggle {
            position: fixed;
            bottom: 2.5rem;
            right: 2.5rem;
            background: linear-gradient(135deg, var(--p), var(--ph));
            color: #fff;
            width: 70px; height: 70px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 2rem;
            box-shadow: var(--shadow-lg);
            z-index: 1000;
            transition: var(--trans);
            border: none;
            cursor: pointer;
            will-change: transform;
        }
        @media (max-width: 576px) {
            .theme-toggle { width: 60px; height: 60px; font-size: 1.5rem; bottom: 1.5rem; right: 1.5rem; }
        }
        .theme-toggle:hover {
            transform: scale(1.1) rotate(180deg);
            box-shadow: 0 20px 40px rgba(16, 185, 129, 0.4);
        }
        .header-text { 
            flex: 1; 
        }
        @media (max-width: 768px) {
            .header-text h1 { font-size: 1.75rem; }
            .header-text p { font-size: 0.9rem; }
        }
        @media (max-width: 576px) {
            .header-text h1 { font-size: 1.5rem; }
            .header-text p { font-size: 0.85rem; }
        }
        .fade-in { animation: fadeIn 0.8s ease forwards; }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate__animated { --animate-duration: 0.6s; }
        .table-responsive { 
            --bs-table-bg: transparent; 
        }
        .table-hover tbody tr:hover { 
            background-color: rgba(16, 185, 129, 0.05); 
            transition: var(--trans);
        }
        .collapse {
            transition: height 0.35s ease;
        }
        .collapsing {
            transition: height 0.35s ease;
        }
        /* Style spécifique pour rendre "Vérifier" plus clair et proéminent */
        .action-verify {
            border: 2px solid var(--p) !important;
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), transparent) !important;
            animation: pulse-highlight 2s infinite !important;
        }
        @keyframes pulse-highlight {
            0%, 100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
            50% { box-shadow: 0 0 0 10px rgba(16, 185, 129, 0); }
        }
        .action-verify span {
            color: var(--p) !important;
            font-weight: 700 !important;
            font-size: 1.1rem !important;
        }
        .action-verify:hover span {
            color: #fff !important;
        }
        .action-verify::after {
            content: ' (Priorité : Vérifiez les bénéficiaires en attente)';
            font-size: 0.75rem;
            color: var(--p);
            font-weight: 500;
            margin-top: 0.25rem;
            display: block;
        }
        @media (max-width: 768px) {
            .action-verify::after {
                font-size: 0.7rem;
            }
        }
        .alert-validation {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(52, 211, 153, 0.05));
            backdrop-filter: blur(20px);
            border: 1px solid rgba(16, 185, 129, 0.2);
            border-radius: var(--radius);
            padding: 2.5rem;
            text-align: center;
            box-shadow: 0 10px 40px rgba(16, 185, 129, 0.15), var(--shadow);
            margin-bottom: 2rem;
            transition: var(--trans);
            position: relative;
            overflow: hidden;
            will-change: transform;
        }
        .alert-validation::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; height: 4px;
            background: linear-gradient(90deg, var(--p), var(--ph));
        }
        .alert-validation:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 15px 50px rgba(16, 185, 129, 0.2), var(--shadow-lg);
        }
        .alert-validation i {
            font-size: 4rem;
            background: linear-gradient(135deg, var(--p), var(--ph));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 1.5rem;
            opacity: 0;
            animation: fadeInUp 0.8s ease 0.2s forwards;
            display: block;
        }
        .alert-validation h5 {
            color: var(--p);
            font-weight: 700;
            margin-bottom: 0.75rem;
            font-size: 1.5rem;
            opacity: 0;
            animation: fadeInUp 0.8s ease 0.4s forwards;
        }
        .alert-validation p {
            color: #64748b;
            font-size: 1.1rem;
            line-height: 1.6;
            max-width: 600px;
            margin: 0 auto;
            opacity: 0;
            animation: fadeInUp 0.8s ease 0.6s forwards;
        }
        @media (max-width: 768px) {
            .alert-validation {
                padding: 2rem;
            }
            .alert-validation i {
                font-size: 3rem;
            }
            .alert-validation h5 {
                font-size: 1.25rem;
            }
            .alert-validation p {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body class="animate__animated animate__fadeIn">

<!-- HEADER -->
<div class="h animate__animated animate__slideInDown">
    <div class="c">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-4">
            <div class="d-flex align-items-center gap-4 flex-grow-1 header-text">
                <img src="<?= $logo_path ?>" alt="Logo" class="logo">
                <div>
                    <h1 class="display-4 fw-bold mb-0"><?= htmlspecialchars($nom_prestataire) ?></h1>
                    <p class="mb-0 opacity-90">Dashboard <?= $is_pharmacie ? 'Pharmacie' : 'Prestataire' ?></p>
                </div>
            </div>
            <div class="d-flex align-items-center gap-3">
                <span class="niveau-badge animate__animated animate__pulse animate__infinite"><?= htmlspecialchars($niveau) ?></span>
                <button class="theme-toggle" id="themeToggle"><i class="bi bi-moon-stars-fill"></i></button>
            </div>
        </div>
    </div>
</div>

<div class="c">

    <!-- KPI -->
    <div class="row g-4 mb-5">
        <div class="col-6 col-md-3">
            <div class="kpi animate__animated animate__fadeInUp" style="animation-delay: 0.1s;">
                <i class="bi bi-hourglass-split kpi-icon"></i>
                <div class="kpi-value"><?= $kpi['en_attente'] ?></div>
                <div class="small text-muted">En attente</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="kpi animate__animated animate__fadeInUp" style="animation-delay: 0.2s;">
                <i class="bi bi-clock-history kpi-icon"></i>
                <div class="kpi-value"><?= $kpi['a_confirmer'] ?></div>
                <div class="small text-muted">À confirmer</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="kpi animate__animated animate__fadeInUp" style="animation-delay: 0.3s;">
                <i class="bi bi-cash-coin kpi-icon"></i>
                <div class="kpi-value"><?= formatFCFA($kpi['rembourse']) ?></div>
                <div class="small text-muted">Reçus</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="kpi animate__animated animate__fadeInUp" style="animation-delay: 0.4s;">
                <i class="bi bi-people kpi-icon"></i>
                <div class="kpi-value"><?= $kpi['beneficiaires'] ?></div>
                <div class="small text-muted">Bénéficiaires</div>
            </div>
        </div>
    </div>

    <!-- ACTIONS RAPIDES - ADAPTÉES PAR NIVEAU -->
    <div class="row g-4 mb-5">
        <div class="col-6 col-md-4 col-lg-3">
            <a href="verify_beneficiaire.php" class="action action-verify animate__animated animate__fadeInUp" style="animation-delay: 0.1s;">
                <i class="bi bi-search"></i>
                <span>Vérifier un bénéficiaire</span>
            </a>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <a href="gestion_remboursements.php" class="action animate__animated animate__fadeInUp" style="animation-delay: 0.2s;">
                <i class="bi bi-cash-stack"></i>
                <span>Suivi paiements</span>
            </a>
        </div>

        <?php if (!$is_pharmacie): ?>
            <div class="col-6 col-md-4 col-lg-3">
                <a href="list_adherents_beneficiaires.php" class="action animate__animated animate__fadeInUp" style="animation-delay: 0.3s;">
                    <i class="bi bi-plus-circle"></i>
                    <span>Nouvelle prestation</span>
                </a>
            </div>
            <div class="col-6 col-md-4 col-lg-3">
                <a href="referencer_patient.php" class="action animate__animated animate__fadeInUp" style="animation-delay: 0.4s;">
                    <i class="bi bi-arrow-up-right-circle"></i>
                    <span>Référer patient</span>
                </a>
            </div>
            <div class="col-6 col-md-4 col-lg-3">
                <a href="referencements_destinataire.php" class="action animate__animated animate__fadeInUp" style="animation-delay: 0.5s;">
                    <i class="bi bi-send"></i>
                    <span>Mes référencements</span>
                </a>
            </div>
            <?php if ($niveau === 'Hôpital'): ?>
                <div class="col-6 col-md-4 col-lg-3">
                    <a href="referencements_destinataire.php" class="action animate__animated animate__fadeInUp" style="animation-delay: 0.6s;">
                        <i class="bi bi-inbox"></i>
                        <span>Reçus</span>
                    </a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- PAIEMENTS À CONFIRMER -->
    <?php if (!empty($paiements_par_mois)): ?>
        <?php foreach ($paiements_par_mois as $mois_key => $data): ?>
            <div class="m animate__animated animate__fadeInUp" style="animation-delay: <?= 0.6 + (array_search($mois_key, array_keys($paiements_par_mois)) * 0.1) ?>s;">
                <div class="mh collapsed" data-bs-toggle="collapse" data-bs-target="#m<?= $mois_key ?>">
                    <div><?= $data['mois_fr'] ?> <span class="badge bg-light text-dark ms-2"><?= $data['total'] ?></span></div>
                    <div class="msv"><?= formatFCFA($data['total_montant']) ?></div>
                </div>
                <div class="collapse" id="m<?= $mois_key ?>">
                    <div class="p-3">
                        <div class="table-responsive">
                            <table class="tbl table-hover mb-0 w-100">
                                <thead><tr>
                                    <th>ID</th><th>Adhérent</th><th>Code</th><th>Date</th><th>Montant</th><th>Fichier</th><th></th>
                                </tr></thead>
                                <tbody>
                                    <?php foreach ($data['demandes'] as $d): ?>
                                    <tr class="animate__animated animate__fadeIn">
                                        <td><strong>#<?= $d['id_demande'] ?></strong></td>
                                        <td><?= htmlspecialchars($d['num_adherent']) ?></td>
                                        <td><code><?= htmlspecialchars($d['code_beneficiaire']) ?></code></td>
                                        <td><?= date('d/m', strtotime($d['date_soin'])) ?></td>
                                        <td class="text-success fw-bold"><?= formatFCFA($d['montant_rembourse']) ?></td>
                                        <td>
                                            <?php if ($d['pieces_jointes'] && file_exists("../".$d['pieces_jointes'])): ?>
                                                <a href="../<?= htmlspecialchars($d['pieces_jointes']) ?>" target="_blank" class="text-info"><i class="bi bi-file-earmark-text"></i></a>
                                            <?php else: ?>—
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-confirm btn-sm confirm-btn" data-id="<?= $d['id_demande'] ?>">
                                                <i class="bi bi-check-lg"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="alert-validation animate__animated animate__fadeInUp">
            <i class="bi bi-check-circle"></i>
            <h5>Tous les remboursements sont à jour !</h5>
            <p>Aucun remboursement en attente de validation pour le moment. Vous pouvez vous concentrer sur d'autres tâches.</p>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Theme Toggle
    const tt = document.getElementById('themeToggle');
    tt.addEventListener('click', () => {
        const dark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
        document.documentElement.setAttribute('data-bs-theme', dark ? 'light' : 'dark');
        tt.innerHTML = dark ? '<i class="bi bi-moon-stars-fill"></i>' : '<i class="bi bi-sun-fill"></i>';
        localStorage.setItem('theme', dark ? 'light' : 'dark');
    });
    if (localStorage.getItem('theme') === 'dark') {
        document.documentElement.setAttribute('data-bs-theme', 'dark');
        tt.innerHTML = '<i class="bi bi-sun-fill"></i>';
    }

    // AJAX Confirmation with enhanced feedback
    document.querySelectorAll('.confirm-btn').forEach(btn => {
        btn.addEventListener('click', async function() {
            if (!confirm('Confirmer le paiement ?')) return;
            this.disabled = true;
            this.innerHTML = '<i class="bi bi-hourglass-split"></i>';
            this.classList.add('animate__animated', 'animate__pulse');

            const formData = new FormData();
            formData.append('csrf_token', '<?= $csrf_token ?>');
            formData.append('confirm', '1');
            formData.append('id_demande', this.dataset.id);

            try {
                const res = await fetch(window.location.href, { method: 'POST', body: formData });
                const data = await res.json();
                
                if (res.ok && data.success) {
                    this.closest('tr').classList.add('animate__animated', 'animate__fadeOut');
                    this.innerHTML = '<i class="bi bi-check-lg text-white"></i>';
                    setTimeout(() => {
                        this.closest('tr').remove();
                        // Optionnel: Recharger la page ou mettre à jour les KPIs via AJAX si nécessaire
                        // location.reload(); // Pour simplicité, mais peut être optimisé
                    }, 600);
                } else {
                    throw new Error(data.message || 'Erreur');
                }
            } catch (e) {
                this.disabled = false;
                this.innerHTML = '<i class="bi bi-x-lg"></i>';
                this.classList.remove('animate__animated', 'animate__pulse');
                alert('Erreur de confirmation: ' + e.message);
            }
        });
    });
</script>
</body>
</html>

<?php 
ob_end_flush();
require_once '../includes/footer.php'; 
?>