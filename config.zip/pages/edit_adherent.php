<?php
// pages/edit_adherent.php
require_once '../includes/header.php';
checkRole('agent_mobilisateur');

// Définir la base URL dynamiquement
$base_url = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/';
define('BASE_URL', $base_url); // Exemple : /santé/ ou /mutuelle/

$errors = [];
$success = null;
$debug_info = []; // Pour le débogage
$csrf_token = generateCsrfToken();
$id_adhesion = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Vérifier que le département de l'utilisateur est défini et valide
$departement = isset($_SESSION['departement']) ? (int)$_SESSION['departement'] : null;
if (!$departement) {
    $_SESSION['errors'] = ["Erreur : Aucun département défini pour l'utilisateur. Veuillez contacter l'administrateur."];
    header('Location: dashboard_agent.php');
    exit();
} else {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM departements WHERE id_departement = ?");
    $stmt->execute([$departement]);
    if ($stmt->fetchColumn() == 0) {
        $_SESSION['errors'] = ["Erreur : Le département de l'utilisateur est invalide."];
        header('Location: dashboard_agent.php');
        exit();
    }
}

// Charger les informations de l'adhérent
$stmt = $pdo->prepare("
    SELECT u.*, a.id_adhesion, a.num_adherent, a.type_adhesion, a.statut, a.old_card_photo, a.is_renewal 
    FROM utilisateurs u 
    LEFT JOIN adhesions a ON u.id_utilisateur = a.id_utilisateur 
    WHERE a.id_adhesion = ? AND a.created_by = ? AND u.role = 'adherent' AND u.departement = ?
");
$stmt->execute([$id_adhesion, $_SESSION['user_id'], $departement]);
$adherent = $stmt->fetch(PDO::FETCH_ASSOC);

// Vérifier si l'adhérent existe et si son statut est 'actif'
if (!$adherent) {
    $_SESSION['errors'] = ["Adhérent non trouvé ou accès non autorisé."];
    header('Location: dashboard_agent.php');
    exit;
}
if ($adherent['statut'] === 'actif') {
    $_SESSION['errors'] = ["Cet adhérent est déjà validé et ne peut pas être modifié."];
    header('Location: dashboard_agent.php');
    exit;
}

// Vérifier le chemin de la photo de l'adhérent pour le débogage
$photo_url = '';
if (!empty($adherent['photo_path'])) {
    $photo_full_path = realpath($adherent['photo_path']);
    if ($photo_full_path === false || !file_exists($photo_full_path)) {
        $debug_info[] = "Photo de l'adhérent introuvable sur le serveur : " . htmlspecialchars($adherent['photo_path'], ENT_QUOTES, 'UTF-8');
        $debug_info[] = "Chemin testé : " . htmlspecialchars($adherent['photo_path'], ENT_QUOTES, 'UTF-8');
    } else {
        $debug_info[] = "Photo de l'adhérent trouvée : " . htmlspecialchars($photo_full_path, ENT_QUOTES, 'UTF-8');
        $photo_url = BASE_URL . htmlspecialchars($adherent['photo_path'], ENT_QUOTES, 'UTF-8');
        $debug_info[] = "URL générée pour la photo de l'adhérent : " . htmlspecialchars($photo_url, ENT_QUOTES, 'UTF-8');
    }
} else {
    $debug_info[] = "Aucun chemin de photo d'adhérent défini dans la base de données.";
}

// Vérifier le chemin de la photo de la carte d'adhésion pour le débogage
$card_photo_url = '';
if (!empty($adherent['old_card_photo'])) {
    $card_photo_full_path = realpath($adherent['old_card_photo']);
    if ($card_photo_full_path === false || !file_exists($card_photo_full_path)) {
        $debug_info[] = "Photo de la carte d'adhésion introuvable sur le serveur : " . htmlspecialchars($adherent['old_card_photo'], ENT_QUOTES, 'UTF-8');
        $debug_info[] = "Chemin testé pour la carte : " . htmlspecialchars($adherent['old_card_photo'], ENT_QUOTES, 'UTF-8');
    } else {
        $debug_info[] = "Photo de la carte d'adhésion trouvée : " . htmlspecialchars($card_photo_full_path, ENT_QUOTES, 'UTF-8');
        $card_photo_url = BASE_URL . htmlspecialchars($adherent['old_card_photo'], ENT_QUOTES, 'UTF-8');
        $debug_info[] = "URL générée pour la photo de la carte : " . htmlspecialchars($card_photo_url, ENT_QUOTES, 'UTF-8');
    }
} else {
    $debug_info[] = "Aucun chemin de photo de carte d'adhésion défini dans la base de données.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_adherent'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
        $debug_info[] = "Échec de la validation CSRF.";
    } else {
        $nom = sanitize($_POST['nom'] ?? '');
        $prenom = sanitize($_POST['prenom'] ?? '');
        $email = !empty($_POST['email']) ? sanitize($_POST['email']) : null; // Use NULL for empty email
        $mot_de_passe = !empty($_POST['mot_de_passe']) ? password_hash($_POST['mot_de_passe'], PASSWORD_BCRYPT) : $adherent['mot_de_passe'];
        $numero_carte_identite = sanitize($_POST['numero_carte_identite'] ?? '');
        $date_naissance = sanitize($_POST['date_naissance'] ?? '');
        $lieu_naissance = sanitize($_POST['lieu_naissance'] ?? '');
        $telephone = sanitize($_POST['telephone'] ?? '');
        $profession = sanitize($_POST['profession'] ?? '');
        $type_adhesion = sanitize($_POST['type_adhesion'] ?? '');
        $photo = $_FILES['photo_path'] ?? null;
        $card_photo = ($adherent['is_renewal'] == 1 && isset($_FILES['old_card_photo'])) ? $_FILES['old_card_photo'] : null;

        // Validation des champs
        if (empty($nom) || empty($prenom) || empty($numero_carte_identite) || empty($date_naissance) || empty($telephone)) {
            $errors[] = "Tous les champs obligatoires doivent être remplis.";
        }
        if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "L'email est invalide.";
        }
        if (!validatePhone($telephone)) {
            $errors[] = "Le numéro de téléphone est invalide (9-15 chiffres).";
        }
        if (!empty($date_naissance) && strtotime($date_naissance) > strtotime('-18 years')) {
            $errors[] = "L'adhérent doit avoir au moins 18 ans.";
        }

        // Validation de l'unicité de l'email (only if email is provided)
        if (!empty($email)) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE email = ? AND id_utilisateur != ?");
            $stmt->execute([$email, $adherent['id_utilisateur']]);
            if ($stmt->fetchColumn() > 0) {
                $errors[] = "Cet email est déjà utilisé par un autre utilisateur.";
            }
        }

        // Validation de l'unicité du numéro de carte d'identité
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE numero_carte_identite = ? AND id_utilisateur != ?");
        $stmt->execute([$numero_carte_identite, $adherent['id_utilisateur']]);
        if ($stmt->fetchColumn() > 0) {
            $errors[] = "Ce numéro de carte d'identité est déjà utilisé.";
        }

        // Gestion de la photo de l'adhérent
        $photo_path = $adherent['photo_path']; // Conserver l'ancienne photo par défaut
        $maxFileSize = 2 * 1024 * 1024; // 2MB
        if ($photo && $photo['size'] > 0 && $photo['error'] === UPLOAD_ERR_OK) {
            $file_type = mime_content_type($photo['tmp_name']);
            if (!in_array($file_type, ['image/jpeg', 'image/png'])) {
                $errors[] = "Seuls les fichiers JPEG ou PNG sont autorisés pour la photo de l'adhérent.";
                $debug_info[] = "Type de fichier invalide pour la photo de l'adhérent : " . $file_type;
            } elseif ($photo['size'] > $maxFileSize) {
                $errors[] = "La photo de l'adhérent dépasse la taille maximale de 2 Mo.";
                $debug_info[] = "Taille du fichier de la photo de l'adhérent : " . $photo['size'] . " octets";
            } else {
                $upload_dir = '../Uploads/photos/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                    $debug_info[] = "Dossier créé pour la photo de l'adhérent : $upload_dir";
                }
                $file_name = 'photo_' . uniqid() . '_' . basename($photo['name']);
                $photo_path = $upload_dir . $file_name;
                if (!move_uploaded_file($photo['tmp_name'], $photo_path)) {
                    $errors[] = "Erreur lors de l'upload de la photo de l'adhérent.";
                    $debug_info[] = "Échec de l'upload de la photo de l'adhérent vers : $photo_path";
                    error_log("Échec de l'upload de la photo de l'adhérent dans edit_adherent.php : $photo_path");
                } elseif ($adherent['photo_path'] && file_exists($adherent['photo_path'])) {
                    unlink($adherent['photo_path']); // Supprimer l'ancienne photo
                    $debug_info[] = "Ancienne photo de l'adhérent supprimée : " . $adherent['photo_path'];
                }
                $debug_info[] = "Nouvelle photo de l'adhérent enregistrée : $photo_path";
            }
        }

        // Gestion de la photo de la carte d'adhésion (uniquement si is_renewal = 1)
        $card_photo_path = $adherent['old_card_photo']; // Conserver l'ancienne photo de la carte par défaut
        if ($adherent['is_renewal'] == 1 && $card_photo && $card_photo['size'] > 0 && $card_photo['error'] === UPLOAD_ERR_OK) {
            $file_type = mime_content_type($card_photo['tmp_name']);
            if (!in_array($file_type, ['image/jpeg', 'image/png'])) {
                $errors[] = "Seuls les fichiers JPEG ou PNG sont autorisés pour la photo de la carte d'adhésion.";
                $debug_info[] = "Type de fichier invalide pour la photo de la carte : " . $file_type;
            } elseif ($card_photo['size'] > $maxFileSize) {
                $errors[] = "La photo de la carte d'adhésion dépasse la taille maximale de 2 Mo.";
                $debug_info[] = "Taille du fichier de la photo de la carte : " . $card_photo['size'] . " octets";
            } else {
                $upload_dir = '../Uploads/card_photos/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                    $debug_info[] = "Dossier créé pour la photo de la carte : $upload_dir";
                }
                $file_name = 'card_photo_' . uniqid() . '_' . basename($card_photo['name']);
                $card_photo_path = $upload_dir . $file_name;
                if (!move_uploaded_file($card_photo['tmp_name'], $card_photo_path)) {
                    $errors[] = "Erreur lors de l'upload de la photo de la carte d'adhésion.";
                    $debug_info[] = "Échec de l'upload de la photo de la carte vers : $card_photo_path";
                    error_log("Échec de l'upload de la photo de la carte dans edit_adherent.php : $card_photo_path");
                } elseif ($adherent['old_card_photo'] && file_exists($adherent['old_card_photo'])) {
                    unlink($adherent['old_card_photo']); // Supprimer l'ancienne photo de la carte
                    $debug_info[] = "Ancienne photo de la carte supprimée : " . $adherent['old_card_photo'];
                }
                $debug_info[] = "Nouvelle photo de la carte enregistrée : $card_photo_path";
            }
        }

        if (empty($errors)) {
            try {
                $pdo->beginTransaction();

                // Mettre à jour utilisateur
                $stmt = $pdo->prepare("
                    UPDATE utilisateurs 
                    SET nom = ?, prenom = ?, email = ?, mot_de_passe = ?, 
                        numero_carte_identite = ?, photo_path = ?, date_naissance = ?, 
                        lieu_naissance = ?, telephone = ?, profession = ?, departement = ?, 
                        date_mise_a_jour = NOW()
                    WHERE id_utilisateur = ?
                ");
                $stmt->execute([
                    $nom, $prenom, $email, $mot_de_passe, $numero_carte_identite, 
                    $photo_path, $date_naissance, $lieu_naissance, $telephone, $profession,
                    $departement, $adherent['id_utilisateur']
                ]);

                // Mettre à jour adhesion
                $stmt = $pdo->prepare("
                    UPDATE adhesions 
                    SET type_adhesion = ?, old_card_photo = ?
                    WHERE id_adhesion = ?
                ");
                $stmt->execute([$type_adhesion, $card_photo_path, $id_adhesion]);

                // Log de l'activité
                logActivity($pdo, $_SESSION['user_id'], 'edit_adherent', "Adhérent ID $id_adhesion modifié (y compris photo de la carte)" . ($adherent['is_renewal'] == 1 ? " avec renouvellement" : ""));

                $pdo->commit();
                $success = "Adhérent mis à jour avec succès.";
                $debug_info[] = "Mise à jour réussie pour l'adhérent ID $id_adhesion";

                // Recharger les données
                $stmt = $pdo->prepare("
                    SELECT u.*, a.id_adhesion, a.num_adherent, a.type_adhesion, a.old_card_photo, a.is_renewal 
                    FROM utilisateurs u 
                    LEFT JOIN adhesions a ON u.id_utilisateur = a.id_utilisateur 
                    WHERE a.id_adhesion = ? AND a.created_by = ? AND u.role = 'adherent' AND u.departement = ?
                ");
                $stmt->execute([$id_adhesion, $_SESSION['user_id'], $departement]);
                $adherent = $stmt->fetch(PDO::FETCH_ASSOC);

                // Mettre à jour l'URL de la photo de l'adhérent après la mise à jour
                if (!empty($adherent['photo_path'])) {
                    $photo_full_path = realpath($adherent['photo_path']);
                    if ($photo_full_path === false || !file_exists($photo_full_path)) {
                        $debug_info[] = "Photo de l'adhérent introuvable après mise à jour : " . htmlspecialchars($adherent['photo_path'], ENT_QUOTES, 'UTF-8');
                    } else {
                        $debug_info[] = "Photo de l'adhérent trouvée après mise à jour : " . htmlspecialchars($photo_full_path, ENT_QUOTES, 'UTF-8');
                        $photo_url = BASE_URL . htmlspecialchars($adherent['photo_path'], ENT_QUOTES, 'UTF-8');
                        $debug_info[] = "URL générée après mise à jour pour la photo de l'adhérent : " . htmlspecialchars($photo_url, ENT_QUOTES, 'UTF-8');
                    }
                }

                // Mettre à jour l'URL de la photo de la carte après la mise à jour
                if (!empty($adherent['old_card_photo'])) {
                    $card_photo_full_path = realpath($adherent['old_card_photo']);
                    if ($card_photo_full_path === false || !file_exists($card_photo_full_path)) {
                        $debug_info[] = "Photo de la carte introuvable après mise à jour : " . htmlspecialchars($adherent['old_card_photo'], ENT_QUOTES, 'UTF-8');
                    } else {
                        $debug_info[] = "Photo de la carte trouvée après mise à jour : " . htmlspecialchars($card_photo_full_path, ENT_QUOTES, 'UTF-8');
                        $card_photo_url = BASE_URL . htmlspecialchars($adherent['old_card_photo'], ENT_QUOTES, 'UTF-8');
                        $debug_info[] = "URL générée après mise à jour pour la photo de la carte : " . htmlspecialchars($card_photo_url, ENT_QUOTES, 'UTF-8');
                    }
                }
            } catch (PDOException $e) {
                $pdo->rollBack();
                $errors[] = "Erreur lors de la mise à jour : " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
                $debug_info[] = "Erreur PDO : " . $e->getMessage();
                error_log("Erreur dans edit_adherent.php : " . $e->getMessage());
            }
        }
    }
}
?>

<div class="container">
    <h2 class="page-title text-center"><i class="bi bi-person-gear me-2"></i>Modifier un Adhérent</h2>

    <!-- Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if ($errors): ?>
        <?php foreach ($errors as $error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
    <?php if ($debug_info && isset($_SESSION['role']) && $_SESSION['role'] === 'directeur_departmental'): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <i class="bi bi-info-circle-fill me-2"></i>
            <strong>Debug Info (visible aux directeurs uniquement) :</strong><br>
            <?php echo implode('<br>', array_map(function($msg) { return htmlspecialchars($msg, ENT_QUOTES, 'UTF-8'); }, $debug_info)); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($adherent): ?>
        <!-- Adherent Form -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-person-fill-gear me-2"></i>Formulaire Adhérent
            </div>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data" id="adherent_form">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="mb-3">
                                <label for="num_adherent" class="form-label"><i class="bi bi-person-vcard me-2"></i>Numéro Adhérent</label>
                                <input type="text" class="form-control" id="num_adherent" value="<?php echo htmlspecialchars($adherent['num_adherent'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" disabled>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="mb-3">
                                <label for="nom" class="form-label"><i class="bi bi-person me-2"></i>Nom <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="nom" name="nom" value="<?php echo htmlspecialchars($adherent['nom'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="prenom" class="form-label"><i class="bi bi-person me-2"></i>Prénom <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="prenom" name="prenom" value="<?php echo htmlspecialchars($adherent['prenom'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label"><i class="bi bi-envelope me-2"></i>Email (facultatif)</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($adherent['email'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="mot_de_passe" class="form-label"><i class="bi bi-lock me-2"></i>Nouveau Mot de passe (facultatif)</label>
                                <input type="password" class="form-control" id="mot_de_passe" name="mot_de_passe" placeholder="Laisser vide pour ne pas modifier">
                            </div>
                            <div class="mb-3">
                                <label for="date_naissance" class="form-label"><i class="bi bi-calendar me-2"></i>Date de Naissance <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="date_naissance" name="date_naissance" value="<?php echo htmlspecialchars($adherent['date_naissance'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="mb-3">
                                <label for="lieu_naissance" class="form-label"><i class="bi bi-geo-alt me-2"></i>Lieu de Naissance</label>
                                <input type="text" class="form-control" id="lieu_naissance" name="lieu_naissance" value="<?php echo htmlspecialchars($adherent['lieu_naissance'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="telephone" class="form-label"><i class="bi bi-telephone me-2"></i>Téléphone <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo htmlspecialchars($adherent['telephone'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="numero_carte_identite" class="form-label"><i class="bi bi-person-vcard me-2"></i>Numéro Carte d'Identité <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="numero_carte_identite" name="numero_carte_identite" value="<?php echo htmlspecialchars($adherent['numero_carte_identite'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="profession" class="form-label"><i class="bi bi-briefcase me-2"></i>Profession</label>
                                <input type="text" class="form-control" id="profession" name="profession" value="<?php echo htmlspecialchars($adherent['profession'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="type_adhesion" class="form-label"><i class="bi bi-card-list me-2"></i>Type d'Adhésion <span class="text-danger">*</span></label>
                                <select class="form-select" id="type_adhesion" name="type_adhesion" required>
                                    <option value="groupe" <?php echo ($adherent['type_adhesion'] ?? '') === 'groupe' ? 'selected' : ''; ?>>Groupe</option>
                                    <option value="familiale" <?php echo ($adherent['type_adhesion'] ?? '') === 'familiale' ? 'selected' : ''; ?>>Familiale</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="photo_path" class="form-label"><i class="bi bi-image me-2"></i>Photo de l'Adhérent (JPEG/PNG, max 2MB, facultatif)</label>
                                <input type="file" class="form-control" id="photo_path" name="photo_path" accept="image/jpeg,image/png">
                                <div id="photoMessage" class="form-text">
                                    <?php if (!empty($adherent['photo_path']) && file_exists($adherent['photo_path'])): ?>
                                        <a href="<?php echo htmlspecialchars($photo_url, ENT_QUOTES, 'UTF-8'); ?>" target="_blank">Voir la photo de l'adhérent en grand</a>
                                    <?php else: ?>
                                        Aucune photo d'adhérent disponible.
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($adherent['photo_path']) && file_exists($adherent['photo_path'])): ?>
                                    <img id="photoPreview" src="<?php echo htmlspecialchars($photo_url, ENT_QUOTES, 'UTF-8'); ?>" alt="Aperçu de la photo de l'adhérent" style="max-width: 200px; height: auto; margin-top: 10px; border: 1px solid var(--primary); border-radius: 6px; display: block;">
                                <?php else: ?>
                                    <img id="photoPreview" src="#" alt="Aperçu de la photo de l'adhérent" style="display: none;">
                                <?php endif; ?>
                            </div>
                            <?php if ($adherent['is_renewal'] == 1): ?>
                                <div class="mb-3">
                                    <label for="old_card_photo" class="form-label"><i class="bi bi-credit-card me-2"></i>Photo de la Carte d'Adhésion (JPEG/PNG, max 2MB, facultatif)</label>
                                    <input type="file" class="form-control" id="old_card_photo" name="old_card_photo" accept="image/jpeg,image/png">
                                    <div id="cardPhotoMessage" class="form-text">
                                        <?php if (!empty($adherent['old_card_photo']) && file_exists($adherent['old_card_photo'])): ?>
                                            <a href="<?php echo htmlspecialchars($card_photo_url, ENT_QUOTES, 'UTF-8'); ?>" target="_blank">Voir la photo de la carte en grand</a>
                                        <?php else: ?>
                                            Aucune photo de carte d'adhésion disponible.
                                        <?php endif; ?>
                                    </div>
                                    <?php if (!empty($adherent['old_card_photo']) && file_exists($adherent['old_card_photo'])): ?>
                                        <img id="cardPhotoPreview" src="<?php echo htmlspecialchars($card_photo_url, ENT_QUOTES, 'UTF-8'); ?>" alt="Aperçu de la photo de la carte" style="max-width: 200px; height: auto; margin-top: 10px; border: 1px solid var(--primary); border-radius: 6px; display: block;">
                                    <?php else: ?>
                                        <img id="cardPhotoPreview" src="#" alt="Aperçu de la photo de la carte" style="display: none;">
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between mt-3">
                        <button type="submit" name="submit_adherent" class="btn btn-primary"><i class="bi bi-check-circle me-2"></i>Mettre à jour</button>
                        <a href="dashboard_agent.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Retour</a>
                    </div>
                </form>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            Aucun adhérent sélectionné ou accès non autorisé.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
</div>

<style>
    :root {
        --primary: #1d4ed8;
        --accent: #059669;
        --danger: #ef4444;
        --warning: #f59e0b;
        --secondary: #6b7280;
        --background: #f1f5f9;
        --card-bg: #ffffff;
        --success-dark: #047857;
    }

    .container {
        max-width: 900px;
        margin: 2rem auto;
        padding: 0 1rem;
    }

    .page-title {
        font-size: clamp(1.5rem, 5vw, 2rem);
        font-weight: 700;
        color: var(--primary);
        display: flex;
        align-items: center;
        gap: 0.5rem;
        text-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        margin-bottom: 1.5rem;
        animation: fadeIn 0.5s ease-in;
    }

    .card {
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        background: var(--card-bg);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-4px);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    }

    .card-header {
        background: linear-gradient(135deg, var(--primary), #3b82f6);
        color: white;
        font-weight: 600;
        border-radius: 12px 12px 0 0;
        padding: 1rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .card-body {
        padding: clamp(1rem, 3vw, 1.5rem);
    }

    .alert {
        border-radius: 8px;
        animation: slideIn 0.5s ease-in-out;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.75rem;
        font-size: clamp(0.85rem, 2.5vw, 0.9rem);
    }

    .form-control, .form-select {
        border-radius: 6px;
        padding: clamp(0.5rem, 2vw, 0.75rem);
        border: 1px solid var(--primary);
        font-size: clamp(0.85rem, 2.5vw, 0.95rem);
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
        height: auto;
        min-height: 38px;
    }

    .form-control:focus, .form-select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 8px rgba(29, 78, 216, 0.4);
    }

    .form-label {
        font-size: clamp(0.8rem, 2.5vw, 0.9rem);
        margin-bottom: 0.3rem;
        display: flex;
        align-items: center;
        gap: 0.3rem;
    }

    .btn-primary, .btn-secondary {
        border-radius: 6px;
        padding: clamp(0.5rem, 2vw, 0.75rem) 1rem;
        font-size: clamp(0.85rem, 2.5vw, 0.9rem);
        font-weight: 500;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.3rem;
        touch-action: manipulation;
    }

    .btn-primary {
        background-color: var(--primary);
        border: none;
    }

    .btn-primary:hover {
        background-color: #1e3a8a;
        transform: scale(1.05);
        box-shadow: 0 0 10px rgba(29, 78, 216, 0.4);
    }

    .btn-secondary {
        background-color: var(--secondary);
        border: none;
    }

    .btn-secondary:hover {
        background-color: #5a6268;
        transform: scale(1.05);
    }

    .form-text a {
        color: var(--primary);
        text-decoration: none;
        font-size: clamp(0.75rem, 2vw, 0.85rem);
    }

    .form-text a:hover {
        text-decoration: underline;
    }

    #photoPreview, #cardPhotoPreview {
        max-width: 200px;
        height: auto;
        margin-top: 10px;
        border: 1px solid var(--primary);
        border-radius: 6px;
    }

    .form-text {
        font-size: clamp(0.75rem, 2vw, 0.85rem);
        color: var(--secondary);
    }

    @keyframes slideIn {
        from { opacity: 0; transform: translateX(-15px); }
        to { opacity: 1; transform: translateX(0); }
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 768px) {
        .container {
            margin: 1rem;
            padding: 0 0.5rem;
        }

        .page-title {
            font-size: clamp(1.25rem, 4vw, 1.5rem);
            margin-bottom: 1rem;
        }

        .card {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
        }

        .card-header {
            padding: 0.75rem;
            font-size: clamp(0.9rem, 3vw, 1rem);
        }

        .card-body {
            padding: 1rem;
        }

        .form-control, .form-select {
            padding: 0.5rem;
            font-size: clamp(0.8rem, 2.5vw, 0.9rem);
            min-height: 36px;
        }

        .form-label {
            font-size: clamp(0.75rem, 2.5vw, 0.85rem);
        }

        .btn-primary, .btn-secondary {
            padding: 0.5rem 0.75rem;
            font-size: clamp(0.8rem, 2.5vw, 0.85rem);
        }

        .alert {
            padding: 0.5rem;
            font-size: clamp(0.8rem, 2.5vw, 0.85rem);
        }

        #photoPreview, #cardPhotoPreview {
            max-width: 150px;
        }

        .form-text {
            font-size: clamp(0.7rem, 2vw, 0.8rem);
        }
    }

    @media (max-width: 576px) {
        .container {
            margin: 0.5rem;
        }

        .page-title {
            font-size: clamp(1.1rem, 4vw, 1.3rem);
            flex-direction: column;
            align-items: flex-start;
        }

        .card {
            border-radius: 8px;
        }

        .card-header {
            padding: 0.5rem;
            font-size: clamp(0.85rem, 3vw, 0.95rem);
        }

        .form-control, .form-select {
            font-size: clamp(0.75rem, 2.5vw, 0.85rem);
            min-height: 34px;
        }

        .btn-primary, .btn-secondary {
            font-size: clamp(0.75rem, 2.5vw, 0.8rem);
            padding: 0.4rem 0.6rem;
        }

        .form-text {
            font-size: clamp(0.7rem, 2vw, 0.8rem);
        }

        #photoPreview, #cardPhotoPreview {
            max-width: 120px;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const photoInput = document.getElementById('photo_path');
        const photoPreview = document.getElementById('photoPreview');
        const photoMessage = document.getElementById('photoMessage');
        const cardPhotoInput = document.getElementById('old_card_photo');
        const cardPhotoPreview = document.getElementById('cardPhotoPreview');
        const cardPhotoMessage = document.getElementById('cardPhotoMessage');

        // Preview uploaded adherent photo
        photoInput?.addEventListener('change', function() {
            if (photoInput.files.length > 0 && photoInput.files[0].type.startsWith('image/')) {
                const file = photoInput.files[0];
                if (file.size > 2 * 1024 * 1024) {
                    alert('La photo de l\'adhérent dépasse la taille maximale de 2 Mo.');
                    photoInput.value = '';
                    photoPreview.style.display = '<?php echo !empty($adherent['photo_path']) && file_exists($adherent['photo_path']) ? 'block' : 'none'; ?>';
                    photoPreview.src = '<?php echo !empty($adherent['photo_path']) && file_exists($adherent['photo_path']) ? htmlspecialchars($photo_url, ENT_QUOTES, 'UTF-8') : '#'; ?>';
                    photoMessage.textContent = '<?php echo !empty($adherent['photo_path']) && file_exists($adherent['photo_path']) ? 'Voir la photo de l\'adhérent en grand' : 'Aucune photo d\'adhérent disponible.'; ?>';
                    return;
                }
                if (!['image/jpeg', 'image/png'].includes(file.type)) {
                    alert('Seuls les fichiers JPEG ou PNG sont autorisés pour la photo de l\'adhérent.');
                    photoInput.value = '';
                    photoPreview.style.display = '<?php echo !empty($adherent['photo_path']) && file_exists($adherent['photo_path']) ? 'block' : 'none'; ?>';
                    photoPreview.src = '<?php echo !empty($adherent['photo_path']) && file_exists($adherent['photo_path']) ? htmlspecialchars($photo_url, ENT_QUOTES, 'UTF-8') : '#'; ?>';
                    photoMessage.textContent = '<?php echo !empty($adherent['photo_path']) && file_exists($adherent['photo_path']) ? 'Voir la photo de l\'adhérent en grand' : 'Aucune photo d\'adhérent disponible.'; ?>';
                    return;
                }
                photoPreview.src = URL.createObjectURL(file);
                photoPreview.style.display = 'block';
                photoMessage.textContent = 'Nouvelle photo d\'adhérent sélectionnée';
            } else {
                photoPreview.style.display = '<?php echo !empty($adherent['photo_path']) && file_exists($adherent['photo_path']) ? 'block' : 'none'; ?>';
                photoPreview.src = '<?php echo !empty($adherent['photo_path']) && file_exists($adherent['photo_path']) ? htmlspecialchars($photo_url, ENT_QUOTES, 'UTF-8') : '#'; ?>';
                photoMessage.textContent = '<?php echo !empty($adherent['photo_path']) && file_exists($adherent['photo_path']) ? 'Voir la photo de l\'adhérent en grand' : 'Aucune photo d\'adhérent disponible.'; ?>';
            }
        });

        // Preview uploaded card photo (only if is_renewal = 1)
        if (cardPhotoInput) {
            cardPhotoInput.addEventListener('change', function() {
                if (cardPhotoInput.files.length > 0 && cardPhotoInput.files[0].type.startsWith('image/')) {
                    const file = cardPhotoInput.files[0];
                    if (file.size > 2 * 1024 * 1024) {
                        alert('La photo de la carte d\'adhésion dépasse la taille maximale de 2 Mo.');
                        cardPhotoInput.value = '';
                        cardPhotoPreview.style.display = '<?php echo !empty($adherent['old_card_photo']) && file_exists($adherent['old_card_photo']) ? 'block' : 'none'; ?>';
                        cardPhotoPreview.src = '<?php echo !empty($adherent['old_card_photo']) && file_exists($adherent['old_card_photo']) ? htmlspecialchars($card_photo_url, ENT_QUOTES, 'UTF-8') : '#'; ?>';
                        cardPhotoMessage.textContent = '<?php echo !empty($adherent['old_card_photo']) && file_exists($adherent['old_card_photo']) ? 'Voir la photo de la carte en grand' : 'Aucune photo de carte d\'adhésion disponible.'; ?>';
                        return;
                    }
                    if (!['image/jpeg', 'image/png'].includes(file.type)) {
                        alert('Seuls les fichiers JPEG ou PNG sont autorisés pour la photo de la carte d\'adhésion.');
                        cardPhotoInput.value = '';
                        cardPhotoPreview.style.display = '<?php echo !empty($adherent['old_card_photo']) && file_exists($adherent['old_card_photo']) ? 'block' : 'none'; ?>';
                        cardPhotoPreview.src = '<?php echo !empty($adherent['old_card_photo']) && file_exists($adherent['old_card_photo']) ? htmlspecialchars($card_photo_url, ENT_QUOTES, 'UTF-8') : '#'; ?>';
                        cardPhotoMessage.textContent = '<?php echo !empty($adherent['old_card_photo']) && file_exists($adherent['old_card_photo']) ? 'Voir la photo de la carte en grand' : 'Aucune photo de carte d\'adhésion disponible.'; ?>';
                        return;
                    }
                    cardPhotoPreview.src = URL.createObjectURL(file);
                    cardPhotoPreview.style.display = 'block';
                    cardPhotoMessage.textContent = 'Nouvelle photo de carte sélectionnée';
                } else {
                    cardPhotoPreview.style.display = '<?php echo !empty($adherent['old_card_photo']) && file_exists($adherent['old_card_photo']) ? 'block' : 'none'; ?>';
                    cardPhotoPreview.src = '<?php echo !empty($adherent['old_card_photo']) && file_exists($adherent['old_card_photo']) ? htmlspecialchars($card_photo_url, ENT_QUOTES, 'UTF-8') : '#'; ?>';
                    cardPhotoMessage.textContent = '<?php echo !empty($adherent['old_card_photo']) && file_exists($adherent['old_card_photo']) ? 'Voir la photo de la carte en grand' : 'Aucune photo de carte d\'adhésion disponible.'; ?>';
                }
            });
        }

        // Vérifier l'affichage initial de l'image de l'adhérent
        const initialPhotoSrc = '<?php echo !empty($adherent['photo_path']) && file_exists($adherent['photo_path']) ? htmlspecialchars($photo_url, ENT_QUOTES, 'UTF-8') : '#'; ?>';
        if (initialPhotoSrc !== '#') {
            const img = new Image();
            img.src = initialPhotoSrc;
            img.onload = function() {
                photoPreview.src = initialPhotoSrc;
                photoPreview.style.display = 'block';
                photoMessage.innerHTML = '<a href="' + initialPhotoSrc + '" target="_blank">Voir la photo de l\'adhérent en grand</a>';
                console.log('Image de l\'adhérent chargée avec succès : ' + initialPhotoSrc);
            };
            img.onerror = function() {
                console.error('Erreur de chargement de l\'image de l\'adhérent : ' + initialPhotoSrc);
                photoPreview.style.display = 'none';
                photoMessage.textContent = 'Erreur : La photo de l\'adhérent ne peut pas être chargée. Vérifiez le chemin ou les permissions.';
                console.log('Détails du chemin de la photo : <?php echo !empty($adherent['photo_path']) ? htmlspecialchars($adherent['photo_path'], ENT_QUOTES, 'UTF-8') : 'Aucun chemin défini'; ?>');
            };
        } else {
            console.log('Aucune photo d\'adhérent disponible ou fichier introuvable.');
        }

        // Vérifier l'affichage initial de l'image de la carte (only if is_renewal = 1)
        if (cardPhotoPreview) {
            const initialCardPhotoSrc = '<?php echo !empty($adherent['old_card_photo']) && file_exists($adherent['old_card_photo']) ? htmlspecialchars($card_photo_url, ENT_QUOTES, 'UTF-8') : '#'; ?>';
            if (initialCardPhotoSrc !== '#') {
                const img = new Image();
                img.src = initialCardPhotoSrc;
                img.onload = function() {
                    cardPhotoPreview.src = initialCardPhotoSrc;
                    cardPhotoPreview.style.display = 'block';
                    cardPhotoMessage.innerHTML = '<a href="' + initialCardPhotoSrc + '" target="_blank">Voir la photo de la carte en grand</a>';
                    console.log('Image de la carte chargée avec succès : ' + initialCardPhotoSrc);
                };
                img.onerror = function() {
                    console.error('Erreur de chargement de l\'image de la carte : ' + initialCardPhotoSrc);
                    cardPhotoPreview.style.display = 'none';
                    cardPhotoMessage.textContent = 'Erreur : La photo de la carte ne peut pas être chargée. Vérifiez le chemin ou les permissions.';
                    console.log('Détails du chemin de la carte : <?php echo !empty($adherent['old_card_photo']) ? htmlspecialchars($adherent['old_card_photo'], ENT_QUOTES, 'UTF-8') : 'Aucun chemin défini'; ?>');
                };
            } else {
                console.log('Aucune photo de carte d\'adhésion disponible ou fichier introuvable.');
            }
        }
    });
</script>

<?php require_once '../includes/footer.php'; ?>