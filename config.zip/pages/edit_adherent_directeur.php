<?php
// pages/edit_adherent_directeur.php
ob_start();
session_start();
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';

// Vérifier l'authentification et le rôle
checkAuth();
checkSessionTimeout();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'directeur_departmental') {
    $_SESSION['errors'] = ["Accès non autorisé. Rôle requis : Directeur départemental."];
    error_log("Accès non autorisé pour user_id: {$_SESSION['user_id']}, role: {$_SESSION['role']}");
    header('Location: /sante/pages/dashboard_directeur.php');
    exit;
}

// Initialiser les variables
$errors = $_SESSION['errors'] ?? [];
$success = $_SESSION['success'] ?? '';
unset($_SESSION['errors'], $_SESSION['success']);
$csrf_token = generateCsrfToken();
$id_adhesion = isset($_GET['id']) ? filter_var($_GET['id'], FILTER_VALIDATE_INT) : 0;

// Récupérer le nom du département
try {
    $stmt_dept = $pdo->prepare("SELECT nom_departement FROM departements WHERE id_departement = ?");
    $stmt_dept->execute([$_SESSION['departement']]);
    $nom_departement = $stmt_dept->fetchColumn() ?: 'Inconnu';
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération du département.";
    error_log("Erreur base de données pour département : " . $e->getMessage());
    $nom_departement = 'Inconnu';
}

// Récupérer tous les départements
try {
    $stmt_depts = $pdo->prepare("SELECT id_departement, nom_departement FROM departements ORDER BY nom_departement");
    $stmt_depts->execute();
    $departements = $stmt_depts->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des départements.";
    error_log("Erreur base de données pour départements : " . $e->getMessage());
    $departements = [];
}

// Récupérer les détails de l'adhérent
$adherent = null;
if ($id_adhesion > 0) {
    try {
        $query = "
            SELECT u.*, a.id_adhesion, a.num_adherent, a.type_adhesion, a.cotisation_annuelle, a.created_by, a.photo_path
            FROM utilisateurs u 
            JOIN adhesions a ON u.id_utilisateur = a.id_utilisateur 
            WHERE a.id_adhesion = ? AND u.role = 'adherent' AND u.departement = ? AND a.statut = 'active'
        ";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$id_adhesion, $_SESSION['departement']]);
        $adherent = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$adherent) {
            $errors[] = "Adhérent non trouvé, non validé, ou accès non autorisé.";
            error_log("Adhérent non trouvé ou non validé pour id_adhesion: $id_adhesion, user ID: {$_SESSION['user_id']}");
            header('Location: /sante/pages/dashboard_directeur.php');
            exit;
        }
    } catch (PDOException $e) {
        $errors[] = "Erreur lors de la récupération de l'adhérent.";
        error_log("Erreur base de données pour adhérent : " . $e->getMessage());
    }
}

// Traiter la soumission du formulaire (mise à jour)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_adherent'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Erreur de validation CSRF.";
        error_log("Échec validation CSRF pour user ID: {$_SESSION['user_id']}");
    } else {
        // Nettoyer et valider les entrées
        $nom = sanitize($_POST['nom'] ?? '');
        $prenom = sanitize($_POST['prenom'] ?? '');
        $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
        $mot_de_passe = !empty($_POST['mot_de_passe']) ? password_hash($_POST['mot_de_passe'], PASSWORD_BCRYPT) : $adherent['mot_de_passe'];
        $mot_de_passe_confirm = $_POST['mot_de_passe_confirm'] ?? '';
        $departement = filter_var($_POST['departement'] ?? 0, FILTER_VALIDATE_INT);
        $numero_carte_identite = sanitize($_POST['numero_carte_identite'] ?? '');
        $date_naissance = sanitize($_POST['date_naissance'] ?? '');
        $lieu_naissance = sanitize($_POST['lieu_naissance'] ?? '');
        $telephone = sanitize($_POST['telephone'] ?? '');
        $profession = sanitize($_POST['profession'] ?? '');
        $type_adhesion = sanitize($_POST['type_adhesion'] ?? '');
        $cotisation_annuelle = filter_var($_POST['cotisation_annuelle'] ?? 0, FILTER_VALIDATE_FLOAT);
        $photo = $_FILES['photo_path'] ?? null;

        // Validation des champs
        if (empty($nom) || empty($prenom) || empty($email) || !$departement || empty($numero_carte_identite) || empty($date_naissance) || empty($telephone)) {
            $errors[] = "Tous les champs obligatoires doivent être remplis.";
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "L'adresse email est invalide.";
        }
        if (!empty($_POST['mot_de_passe']) && $_POST['mot_de_passe'] !== $mot_de_passe_confirm) {
            $errors[] = "Les mots de passe ne correspondent pas.";
        }
        if ($cotisation_annuelle <= 0) {
            $errors[] = "La cotisation annuelle doit être positive.";
        }
        if (!validatePhone($telephone)) {
            $errors[] = "Le numéro de téléphone est invalide (9-15 chiffres).";
        }

        // Vérifier l'unicité de l'email
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE email = ? AND id_utilisateur != ?");
            $stmt->execute([$email, $adherent['id_utilisateur']]);
            if ($stmt->fetchColumn() > 0) {
                $errors[] = "Cet email est déjà utilisé par un autre utilisateur.";
            }
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la vérification de l'email.";
            error_log("Erreur vérification email : " . $e->getMessage());
        }

        // Gérer le téléversement de la photo
        $photo_path = $adherent['photo_path'] ?? '';
        if ($photo && $photo['size'] > 0) {
            $upload_result = uploadPhoto($photo);
            if (isset($upload_result['error'])) {
                $errors[] = $upload_result['error'];
                error_log("Échec téléversement photo pour adhérent ID: $id_adhesion");
            } else {
                if ($photo_path && file_exists($photo_path)) {
                    unlink($photo_path);
                }
                $photo_path = $upload_result['path'];
            }
        }

        // Mettre à jour l'adhérent si aucune erreur
        if (empty($errors)) {
            try {
                $pdo->beginTransaction();
                $stmt = $pdo->prepare("
                    UPDATE utilisateurs 
                    SET nom = ?, prenom = ?, email = ?, mot_de_passe = ?, departement = ?, 
                        numero_carte_identite = ?, date_naissance = ?, lieu_naissance = ?, 
                        telephone = ?, profession = ?
                    WHERE id_utilisateur = ?
                ");
                $stmt->execute([
                    $nom, $prenom, $email, $mot_de_passe, $departement, $numero_carte_identite,
                    $date_naissance, $lieu_naissance, $telephone, $profession, $adherent['id_utilisateur']
                ]);

                $stmt = $pdo->prepare("
                    UPDATE adhesions 
                    SET type_adhesion = ?, cotisation_annuelle = ?, photo_path = ?
                    WHERE id_adhesion = ? AND statut = 'active'
                ");
                $stmt->execute([$type_adhesion, $cotisation_annuelle, $photo_path, $id_adhesion]);

                if ($stmt->rowCount() === 0) {
                    $pdo->rollBack();
                    $errors[] = "L'adhésion n'est pas validée ou n'existe pas.";
                    error_log("Échec mise à jour adhésion ID $id_adhesion : non validée ou introuvable");
                } else {
                    $pdo->commit();
                    $success = "Adhérent mis à jour avec succès.";
                    logActivity($pdo, $_SESSION['user_id'], 'update_adherent', "Adhérent ID $id_adhesion mis à jour");
                }
            } catch (PDOException $e) {
                $pdo->rollBack();
                $errors[] = "Erreur lors de la mise à jour de l'adhérent.";
                error_log("Erreur base de données mise à jour adhérent ID $id_adhesion : " . $e->getMessage());
            }
        }
    }
}

// Gérer la suppression
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_adherent'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Erreur de validation CSRF.";
        error_log("Échec validation CSRF pour suppression, user ID: {$_SESSION['user_id']}");
    } else {
        try {
            $pdo->beginTransaction();
            $stmt_benef = $pdo->prepare("DELETE FROM beneficiaires WHERE id_adhesion = ?");
            $stmt_benef->execute([$id_adhesion]);
            $stmt = $pdo->prepare("DELETE FROM adhesions WHERE id_adhesion = ? AND statut = 'active'");
            $stmt->execute([$id_adhesion]);
            $stmt = $pdo->prepare("DELETE FROM utilisateurs WHERE id_utilisateur = ?");
            $stmt->execute([$adherent['id_utilisateur']]);

            if ($stmt->rowCount() > 0) {
                $pdo->commit();
                logActivity($pdo, $_SESSION['user_id'], 'delete_adherent', "Adhérent ID $id_adhesion et bénéficiaires supprimés");
                $_SESSION['success'] = "Adhérent et bénéficiaires supprimés avec succès.";
                header('Location: /sante/pages/dashboard_directeur.php');
                exit;
            } else {
                $pdo->rollBack();
                $errors[] = "Adhérent non trouvé ou non validé.";
                error_log("Échec suppression adhérent ID $id_adhesion : non validé ou introuvable");
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Erreur lors de la suppression de l'adhérent.";
            error_log("Erreur base de données suppression adhérent ID $id_adhesion : " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Éditer un Adhérent - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ... (même CSS que dans la version précédente) ... */
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="/sante/pages/dashboard_directeur.php">
                <img src="/sante/Uploads/photos/logo1.png" alt="Logo Mutuelle Santé Matam"> Mutuelle Santé Matam
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Basculer la navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/sante/pages/dashboard_directeur.php"><i class="bi bi-house"></i> Tableau de Bord</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/sante/pages/add_agent.php"><i class="bi bi-person-plus"></i> Ajouter Agent</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/sante/pages/validate_adhesion.php"><i class="bi bi-check-circle"></i> Valider Référencements</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/sante/pages/validate_remboursements.php"><i class="bi bi-wallet"></i> Valider Remboursements</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/sante/pages/list_agents.php"><i class="bi bi-person-lines-fill"></i> Liste des Agents</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/sante/pages/add_prestataire.php"><i class="bi bi-building"></i> Ajouter Prestataire</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['nom'] . ' ' . $_SESSION['prenom']); ?> (Directeur)
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="/sante/pages/profile.php"><i class="bi bi-person"></i> Profil</a></li>
                            <li><a class="dropdown-item" href="/sante/pages/logout.php"><i class="bi bi-box-arrow-right"></i> Déconnexion</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="hero-section" role="banner">
            <img src="/sante/Uploads/photos/logo1.png" alt="Logo de Mutuelle Santé Matam">
            <h1>Éditer un <span style="color: var(--accent);">Adhérent Validé</span></h1>
            <p>Modifiez les informations d'un adhérent validé pour le département <strong style="color: var(--accent);"><?php echo htmlspecialchars($nom_departement); ?></strong>.</p>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill"></i> <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
            </div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i> <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php if ($adherent): ?>
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-person-gear"></i> Modifier l'Adhérent #<?php echo htmlspecialchars($adherent['num_adherent']); ?>
                </div>
                <div class="card-body">
                    <form id="adherentForm" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                        <div class="row g-3">
                            <!-- ... (même formulaire que dans la version précédente) ... -->
                        </div>
                        <div class="mt-4 d-flex gap-2">
                            <button type="submit" name="submit_adherent" class="btn btn-primary"><i class="bi bi-save"></i> Mettre à jour</button>
                            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal"><i class="bi bi-trash"></i> Supprimer</button>
                            <a href="/sante/pages/dashboard_directeur.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Retour</a>
                        </div>
                    </form>
                </div>
            </div>

            <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="deleteModalLabel">Confirmer la suppression</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                        </div>
                        <div class="modal-body">
                            Êtes-vous sûr de vouloir supprimer l'adhérent #<?php echo htmlspecialchars($adherent['num_adherent']); ?> et tous ses bénéficiaires ? Cette action est irréversible.
                        </div>
                        <div class="modal-footer">
                            <form method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                                <button type="submit" name="delete_adherent" class="btn btn-danger">Supprimer</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-exclamation-circle"></i> Erreur
                </div>
                <div class="card-body">
                    <p class="text-danger">Aucun adhérent validé trouvé ou accès non autorisé.</p>
                    <a href="/sante/pages/dashboard_directeur.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Retour au tableau de bord</a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('adherentForm')?.addEventListener('submit', function (e) {
            const telephone = document.getElementById('telephone').value;
            const cotisation = document.getElementById('cotisation_annuelle').value;
            const password = document.getElementById('mot_de_passe').value;
            const passwordConfirm = document.getElementById('mot_de_passe_confirm').value;

            if (!/^\d{9,15}$/.test(telephone)) {
                e.preventDefault();
                alert('Le numéro de téléphone doit contenir entre 9 et 15 chiffres.');
            }
            if (cotisation <= 0) {
                e.preventDefault();
                alert('La cotisation annuelle doit être positive.');
            }
            if (password && password !== passwordConfirm) {
                e.preventDefault();
                alert('Les mots de passe ne correspondent pas.');
            }
        });
    </script>
</body>
</html>
<?php
require_once '../includes/footer.php';
ob_end_flush();
?>