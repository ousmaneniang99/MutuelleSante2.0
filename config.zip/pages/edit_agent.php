<?php
// pages/edit_agent.php
require_once '../includes/header.php';
checkRole('directeur_departemental');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();
$agent = null;

// Vérifier que le département de l'utilisateur est défini et valide
$departement = isset($_SESSION['departement']) ? (int)$_SESSION['departement'] : null;
if (!$departement) {
    $_SESSION['errors'] = ["Erreur : Aucun département défini pour l'utilisateur. Veuillez contacter l'administrateur."];
    header('Location: dashboard_directeur.php');
    exit();
} else {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM departements WHERE id_departement = ?");
    $stmt->execute([$departement]);
    if ($stmt->fetchColumn() == 0) {
        $_SESSION['errors'] = ["Erreur : Le département de l'utilisateur est invalide."];
        header('Location: dashboard_directeur.php');
        exit();
    }
}

// Récupérer l'ID de l'agent depuis l'URL
$id_utilisateur = filter_var($_GET['id'] ?? '', FILTER_VALIDATE_INT);
if (!$id_utilisateur) {
    $errors[] = "ID d'agent invalide.";
} else {
    try {
        // Récupérer les données de l'agent
        $stmt = $pdo->prepare("
            SELECT nom, prenom, date_naissance, lieu_naissance, adresse, telephone, email, 
                   numero_carte_identite, profession, photo_path, departement
            FROM utilisateurs 
            WHERE id_utilisateur = ? AND role = 'agent_mobilisateur' AND departement = ?
        ");
        $stmt->execute([$id_utilisateur, $departement]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$agent) {
            $errors[] = "Agent non trouvé, rôle incorrect ou n'appartient pas à votre département.";
        }
    } catch (PDOException $e) {
        $errors[] = "Erreur lors de la récupération de l'agent : " . htmlspecialchars($e->getMessage());
        error_log("Erreur dans edit_agent.php : " . $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($errors)) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
    } else {
        // Récupérer et nettoyer les données
        $nom = filter_var(trim($_POST['nom'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $prenom = filter_var(trim($_POST['prenom'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $date_naissance = trim($_POST['date_naissance'] ?? '');
        $lieu_naissance = filter_var(trim($_POST['lieu_naissance'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $adresse = filter_var(trim($_POST['adresse'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $telephone = filter_var(trim($_POST['telephone'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
        $numero_carte_identite = filter_var(trim($_POST['numero_carte_identite'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $profession = filter_var(trim($_POST['profession'] ?? ''), FILTER_SANITIZE_SPECIAL_CHARS);
        $photo_base64 = isset($_POST['photo_base64']) ? $_POST['photo_base64'] : null;

        // Gestion de la photo
        $photo_path = $agent['photo_path']; // Conserver l'ancienne photo par défaut
        $maxFileSize = 2 * 1024 * 1024; // 2MB
        if ($photo_base64 && strpos($photo_base64, 'data:image') === 0) {
            // Process base64 photo
            $photo_data = explode(',', $photo_base64);
            if (count($photo_data) === 2) {
                $image_data = base64_decode($photo_data[1]);
                if (strlen($image_data) > $maxFileSize) {
                    $errors[] = "La photo capturée dépasse la taille maximale de 2 Mo.";
                } else {
                    $upload_dir = '../Uploads/photos/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0755, true);
                    }
                    $file_name = 'photo_' . uniqid() . '.jpg';
                    $photo_path = $upload_dir . $file_name;
                    if (!file_put_contents($photo_path, $image_data)) {
                        $errors[] = "Erreur lors de l'enregistrement de la photo capturée.";
                    } elseif ($agent['photo_path'] && file_exists($agent['photo_path'])) {
                        unlink($agent['photo_path']); // Supprimer l'ancienne photo
                    }
                }
            } else {
                $errors[] = "Format de la photo capturée invalide.";
            }
        } elseif (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            // Handle uploaded file
            $file_type = mime_content_type($_FILES['photo']['tmp_name']);
            if (!in_array($file_type, ['image/jpeg', 'image/png'])) {
                $errors[] = "Seuls les fichiers JPG ou PNG sont autorisés.";
            } elseif ($_FILES['photo']['size'] > $maxFileSize) {
                $errors[] = "La photo téléversée dépasse la taille maximale de 2 Mo.";
            } else {
                $upload_dir = '../Uploads/photos/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                $file_name = 'photo_' . uniqid() . '_' . basename($_FILES['photo']['name']);
                $photo_path = $upload_dir . $file_name;
                if (!move_uploaded_file($_FILES['photo']['tmp_name'], $photo_path)) {
                    $errors[] = "Erreur lors de l'upload de la photo.";
                } elseif ($agent['photo_path'] && file_exists($agent['photo_path'])) {
                    unlink($agent['photo_path']); // Supprimer l'ancienne photo
                }
            }
        }

        // Validation des champs
        if (empty($nom) || empty($prenom) || empty($email) || empty($telephone) || empty($numero_carte_identite)) {
            $errors[] = "Les champs Nom, Prénom, Email, Téléphone et Numéro de Carte d'Identité sont obligatoires.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "L'email n'est pas valide.";
        } elseif (!empty($date_naissance) && !DateTime::createFromFormat('Y-m-d', $date_naissance)) {
            $errors[] = "La date de naissance n'est pas valide (format : AAAA-MM-JJ).";
        } elseif (!validatePhone($telephone)) {
            $errors[] = "Le numéro de téléphone est invalide (9-15 chiffres).";
        } else {
            try {
                // Vérifier l'unicité de l'email (exclure l'agent actuel)
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE email = ? AND id_utilisateur != ?");
                $stmt->execute([$email, $id_utilisateur]);
                if ($stmt->fetchColumn() > 0) {
                    $errors[] = "Cet email est déjà utilisé par un autre utilisateur.";
                }

                // Vérifier l'unicité du numéro de carte d'identité
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE numero_carte_identite = ? AND id_utilisateur != ?");
                $stmt->execute([$numero_carte_identite, $id_utilisateur]);
                if ($stmt->fetchColumn() > 0) {
                    $errors[] = "Ce numéro de carte d'identité est déjà utilisé.";
                }

                if (empty($errors)) {
                    // Mettre à jour l'agent
                    $stmt = $pdo->prepare("
                        UPDATE utilisateurs 
                        SET nom = ?, prenom = ?, date_naissance = ?, lieu_naissance = ?, 
                            adresse = ?, telephone = ?, email = ?, numero_carte_identite = ?, 
                            profession = ?, photo_path = ?, date_mise_a_jour = NOW()
                        WHERE id_utilisateur = ? AND role = 'agent_mobilisateur' AND departement = ?
                    ");
                    $stmt->execute([
                        $nom, $prenom, 
                        $date_naissance ?: null, 
                        $lieu_naissance ?: null, 
                        $adresse ?: null, 
                        $telephone, 
                        $email, 
                        $numero_carte_identite, 
                        $profession ?: null, 
                        $photo_path, 
                        $id_utilisateur, 
                        $departement
                    ]);

                    // Vérifier si la mise à jour a affecté une ligne
                    if ($stmt->rowCount() === 0) {
                        $errors[] = "Aucune modification effectuée ou agent non trouvé.";
                    } else {
                        // Log activité
                        logActivity($pdo, $_SESSION['user_id'], "Modification de l'agent : $nom $prenom ($email)");
                        $success = "Agent $nom $prenom modifié avec succès.";
                    }
                }
            } catch (PDOException $e) {
                $errors[] = "Erreur lors de la modification de l'agent : " . htmlspecialchars($e->getMessage());
                error_log("Erreur dans edit_agent.php : " . $e->getMessage());
            }
        }
    }
}
?>

<div class="container">
    <h2 class="page-title text-center"><i class="bi bi-person-gear me-2"></i>Modifier un Agent</h2>

    <!-- Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if ($errors): ?>
        <?php foreach ($errors as $error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Form -->
    <?php if ($agent): ?>
        <div class="card">
            <div class="card-header">
                <i class="bi bi-person-gear me-2"></i>Modifier l'Agent : <?php echo htmlspecialchars($agent['nom'] . ' ' . $agent['prenom']); ?>
            </div>
            <div class="card-body">
                <form method="POST" action="" enctype="multipart/form-data" id="agent_form">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                    <input type="hidden" name="photo_base64" id="photo_base64">
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <div class="mb-3">
                                <label for="nom" class="form-label"><i class="bi bi-person me-2"></i>Nom <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="nom" name="nom" value="<?php echo htmlspecialchars($agent['nom'] ?? ''); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="prenom" class="form-label"><i class="bi bi-person me-2"></i>Prénom <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="prenom" name="prenom" value="<?php echo htmlspecialchars($agent['prenom'] ?? ''); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label"><i class="bi bi-envelope me-2"></i>Email <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($agent['email'] ?? ''); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="telephone" class="form-label"><i class="bi bi-telephone me-2"></i>Téléphone <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo htmlspecialchars($agent['telephone'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="mb-3">
                                <label for="date_naissance" class="form-label"><i class="bi bi-calendar me-2"></i>Date de Naissance</label>
                                <input type="date" class="form-control" id="date_naissance" name="date_naissance" value="<?php echo htmlspecialchars($agent['date_naissance'] ?? ''); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="lieu_naissance" class="form-label"><i class="bi bi-geo-alt me-2"></i>Lieu de Naissance</label>
                                <input type="text" class="form-control" id="lieu_naissance" name="lieu_naissance" value="<?php echo htmlspecialchars($agent['lieu_naissance'] ?? ''); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="adresse" class="form-label"><i class="bi bi-house-door me-2"></i>Adresse</label>
                                <input type="text" class="form-control" id="adresse" name="adresse" value="<?php echo htmlspecialchars($agent['adresse'] ?? ''); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="numero_carte_identite" class="form-label"><i class="bi bi-person-vcard me-2"></i>Numéro de Carte d'Identité <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="numero_carte_identite" name="numero_carte_identite" value="<?php echo htmlspecialchars($agent['numero_carte_identite'] ?? ''); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="profession" class="form-label"><i class="bi bi-briefcase me-2"></i>Profession</label>
                                <input type="text" class="form-control" id="profession" name="profession" value="<?php echo htmlspecialchars($agent['profession'] ?? ''); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="photo" class="form-label"><i class="bi bi-image me-2"></i>Photo (JPEG/PNG, max 2MB, facultatif)</label>
                                <input type="file" class="form-control" id="photo" name="photo" accept="image/jpeg,image/png">
                                <button type="button" class="btn btn-secondary mt-2" data-bs-toggle="modal" data-bs-target="#capturePhotoModal"><i class="bi bi-camera me-2"></i>Prendre une photo</button>
                                <img id="photoPreview" src="<?php echo !empty($agent['photo_path']) && file_exists($agent['photo_path']) ? htmlspecialchars($agent['photo_path'], ENT_QUOTES, 'UTF-8') : '#'; ?>" alt="Aperçu de la photo" style="<?php echo !empty($agent['photo_path']) && file_exists($agent['photo_path']) ? 'display: block;' : 'display: none;'; ?>">
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between mt-3">
                        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-2"></i>Enregistrer</button>
                        <a href="dashboard_directeur.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Retour</a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Modal for capturing photo -->
        <div class="modal fade" id="capturePhotoModal" tabindex="-1" aria-labelledby="capturePhotoModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="capturePhotoModalLabel">Prendre une Photo</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center">
                        <video id="video" autoplay style="max-width: 100%; height: auto;"></video>
                        <canvas id="canvas" style="display: none;"></canvas>
                        <div class="mt-3">
                            <button type="button" id="captureButton" class="btn btn-primary"><i class="bi bi-camera me-2"></i>Capturer</button>
                            <button type="button" id="retakeButton" class="btn btn-secondary" style="display: none;"><i class="bi bi-arrow-repeat me-2"></i>Reprendre</button>
                            <button type="button" id="savePhotoButton" class="btn btn-success" style="display: none;" data-bs-dismiss="modal"><i class="bi bi-check-circle me-2"></i>Enregistrer la Photo</button>
                        </div>
                        <p id="cameraError" class="text-danger mt-3" style="display: none;"></p>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-danger text-center">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            Impossible de charger les informations de l'agent. Veuillez vérifier l'ID fourni.
        </div>
    <?php endif; ?>
</div>

<style>
    :root {
        --primary: #1d4ed8;
        --accent: #059669;
        --danger: #ef4444;
        --warning: #f59e0b;
        --secondary: #6b7280;
        --background: #f1f5f9;
        --card-bg: #ffffff;
        --success-dark: #047857;
    }

    .container {
        max-width: 900px;
        margin: 2rem auto;
        padding: 0 1rem;
    }

    .page-title {
        font-size: clamp(1.5rem, 5vw, 2rem);
        font-weight: 700;
        color: var(--primary);
        display: flex;
        align-items: center;
        gap: 0.5rem;
        text-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        margin-bottom: 1.5rem;
        animation: fadeIn 0.5s ease-in;
    }

    .card {
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        background: var(--card-bg);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-4px);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    }

    .card-header {
        background: linear-gradient(135deg, var(--primary), #3b82f6);
        color: white;
        font-weight: 600;
        border-radius: 12px 12px 0 0;
        padding: 1rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .card-body {
        padding: clamp(1rem, 3vw, 1.5rem);
    }

    .alert {
        border-radius: 8px;
        animation: slideIn 0.5s ease-in-out;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.75rem;
        font-size: clamp(0.85rem, 2.5vw, 0.9rem);
    }

    .form-control, .form-select {
        border-radius: 6px;
        padding: clamp(0.5rem, 2vw, 0.75rem);
        border: 1px solid var(--primary);
        font-size: clamp(0.85rem, 2.5vw, 0.95rem);
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
        height: auto;
        min-height: 38px;
    }

    .form-control:focus, .form-select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 8px rgba(29, 78, 216, 0.4);
    }

    .form-label {
        font-size: clamp(0.8rem, 2.5vw, 0.9rem);
        margin-bottom: 0.3rem;
        display: flex;
        align-items: center;
        gap: 0.3rem;
    }

    .btn-primary, .btn-secondary, .btn-success {
        border-radius: 6px;
        padding: clamp(0.5rem, 2vw, 0.75rem) 1rem;
        font-size: clamp(0.85rem, 2.5vw, 0.9rem);
        font-weight: 500;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.3rem;
        touch-action: manipulation;
    }

    .btn-primary {
        background-color: var(--primary);
        border: none;
    }

    .btn-primary:hover {
        background-color: #1e3a8a;
        transform: scale(1.05);
        box-shadow: 0 0 10px rgba(29, 78, 216, 0.4);
    }

    .btn-secondary:hover {
        background-color: #5a6268;
    }

    .btn-success:hover {
        background-color: #218838;
    }

    #photoPreview {
        max-width: 200px;
        height: auto;
        margin-top: 10px;
        border: 1px solid var(--primary);
        border-radius: 6px;
    }

    @keyframes slideIn {
        from { opacity: 0; transform: translateX(-15px); }
        to { opacity: 1; transform: translateX(0); }
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* Media Queries pour responsive */
    @media (max-width: 768px) {
        .container {
            margin: 1rem;
            padding: 0 0.5rem;
        }

        .page-title {
            font-size: clamp(1.25rem, 4vw, 1.5rem);
            margin-bottom: 1rem;
        }

        .card {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
        }

        .card-header {
            padding: 0.75rem;
            font-size: clamp(0.9rem, 3vw, 1rem);
        }

        .card-body {
            padding: 1rem;
        }

        .form-control, .form-select {
            padding: 0.5rem;
            font-size: clamp(0.8rem, 2.5vw, 0.9rem);
            min-height: 36px;
        }

        .form-label {
            font-size: clamp(0.75rem, 2.5vw, 0.85rem);
        }

        .btn-primary, .btn-secondary, .btn-success {
            padding: 0.5rem 0.75rem;
            font-size: clamp(0.8rem, 2.5vw, 0.85rem);
        }

        .alert {
            padding: 0.5rem;
            font-size: clamp(0.8rem, 2.5vw, 0.85rem);
        }

        #photoPreview {
            max-width: 150px;
        }
    }

    @media (max-width: 576px) {
        .container {
            margin: 0.5rem;
        }

        .page-title {
            font-size: clamp(1.1rem, 4vw, 1.3rem);
            flex-direction: column;
            align-items: flex-start;
        }

        .card {
            border-radius: 8px;
        }

        .card-header {
            padding: 0.5rem;
            font-size: clamp(0.85rem, 3vw, 0.95rem);
        }

        .form-control, .form-select {
            font-size: clamp(0.75rem, 2.5vw, 0.85rem);
            min-height: 34px;
        }

        .btn-primary, .btn-secondary, .btn-success {
            font-size: clamp(0.75rem, 2.5vw, 0.8rem);
            padding: 0.4rem 0.6rem;
        }

        #photoPreview {
            max-width: 120px;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const captureButton = document.getElementById('captureButton');
        const retakeButton = document.getElementById('retakeButton');
        const savePhotoButton = document.getElementById('savePhotoButton');
        const photoPreview = document.getElementById('photoPreview');
        const photoBase64Input = document.getElementById('photo_base64');
        const photoInput = document.getElementById('photo');
        let stream = null;

        // Start camera when modal is opened
        document.getElementById('capturePhotoModal')?.addEventListener('shown.bs.modal', async function() {
            try {
                stream = await navigator.mediaDevices.getUserMedia({ 
                    video: { 
                        facingMode: 'user',
                        width: { ideal: 640 },
                        height: { ideal: 480 }
                    } 
                });
                video.srcObject = stream;
                document.getElementById('cameraError').style.display = 'none';
                captureButton.style.display = 'inline-block';
                retakeButton.style.display = 'none';
                savePhotoButton.style.display = 'none';
            } catch (err) {
                console.error('Camera access error:', err);
                document.getElementById('cameraError').textContent = 'Impossible d\'accéder à la caméra. Vérifiez les autorisations ou utilisez une image téléversée.';
                document.getElementById('cameraError').style.display = 'block';
                captureButton.style.display = 'none';
            }
        });

        // Stop camera when modal is closed
        document.getElementById('capturePhotoModal')?.addEventListener('hidden.bs.modal', function() {
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
                stream = null;
            }
            video.srcObject = null;
            video.style.display = 'block';
            canvas.style.display = 'none';
        });

        // Capture photo
        captureButton?.addEventListener('click', function() {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0);
            const imageData = canvas.toDataURL('image/jpeg', 0.7);
            photoPreview.src = imageData;
            photoPreview.style.display = 'block';
            photoBase64Input.value = imageData;
            photoInput.value = '';
            captureButton.style.display = 'none';
            retakeButton.style.display = 'inline-block';
            savePhotoButton.style.display = 'inline-block';
            video.style.display = 'none';
            canvas.style.display = 'block';
        });

        // Retake photo
        retakeButton?.addEventListener('click', function() {
            video.style.display = 'block';
            canvas.style.display = 'none';
            captureButton.style.display = 'inline-block';
            retakeButton.style.display = 'none';
            savePhotoButton.style.display = 'none';
            photoPreview.style.display = '<?php echo !empty($agent['photo_path']) && file_exists($agent['photo_path']) ? 'block' : 'none'; ?>';
            photoPreview.src = '<?php echo !empty($agent['photo_path']) && file_exists($agent['photo_path']) ? htmlspecialchars($agent['photo_path'], ENT_QUOTES, 'UTF-8') : '#'; ?>';
            photoBase64Input.value = '';
        });

        // Preview uploaded image
        photoInput?.addEventListener('change', function() {
            if (photoInput.files.length > 0 && photoInput.files[0].type.startsWith('image/')) {
                photoBase64Input.value = '';
                photoPreview.src = URL.createObjectURL(photoInput.files[0]);
                photoPreview.style.display = 'block';
            } else {
                photoPreview.style.display = '<?php echo !empty($agent['photo_path']) && file_exists($agent['photo_path']) ? 'block' : 'none'; ?>';
                photoPreview.src = '<?php echo !empty($agent['photo_path']) && file_exists($agent['photo_path']) ? htmlspecialchars($agent['photo_path'], ENT_QUOTES, 'UTF-8') : '#'; ?>';
            }
        });
    });
</script>

<?php require_once '../includes/footer.php'; ?>