<?php
// pages/edit_beneficiaire.php
require_once '../includes/header.php';
checkRole('agent_mobilisateur');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();
$id_beneficiaire = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Charger les informations du bénéficiaire
$stmt = $pdo->prepare("
    SELECT b.*, a.num_adherent 
    FROM beneficiaires b 
    JOIN adhesions a ON b.id_adhesion = a.id_adhesion 
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
    WHERE b.id_beneficiaire = ? AND a.created_by = ? AND u.departement = ?
");
$stmt->execute([$id_beneficiaire, $_SESSION['user_id'], $_SESSION['departement']]);
$beneficiaire = $stmt->fetch(PDO::FETCH_ASSOC);

// Vérifier si le bénéficiaire existe et si son statut est 'actif'
if (!$beneficiaire) {
    $_SESSION['errors'] = ["Bénéficiaire non trouvé ou accès non autorisé."];
    header('Location: dashboard_agent.php');
    exit;
}
if ($beneficiaire['statut'] === 'actif') {
    $_SESSION['errors'] = ["Ce bénéficiaire est déjà validé et ne peut pas être modifié."];
    header('Location: dashboard_agent.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_beneficiaire'])) {
    if (!verifyCsrfToken($_POST['csrf_token'])) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
    } else {
        $nom = sanitize($_POST['nom']);
        $prenom = sanitize($_POST['prenom']);
        $date_naissance = sanitize($_POST['date_naissance']);
        $relation = sanitize($_POST['relation']);
        // PAS DE date_sortie - SUPPRIMÉE
        $photo_base64 = isset($_POST['photo_base64']) ? $_POST['photo_base64'] : null;
        $photo_path = $beneficiaire['photo_path'];

        // Validate inputs (SANS date_sortie)
        if (empty($nom) || empty($prenom) || empty($date_naissance) || empty($relation)) {
            $errors[] = "Tous les champs obligatoires doivent être remplis.";
        }

        // Handle photo (CAMÉRA IDENTIQUE + UPLOAD)
        if ($photo_base64 && strpos($photo_base64, 'data:image') === 0) {
            // Process base64 photo
            $photo_data = explode(',', $photo_base64);
            if (count($photo_data) === 2) {
                $image_data = base64_decode($photo_data[1]);
                if (strlen($image_data) > 2 * 1024 * 1024) { // 2MB limit
                    $errors[] = "La photo capturée dépasse la taille maximale de 2MB.";
                } else {
                    $file_name = 'photo_benef_' . uniqid() . '.jpg';
                    $upload_dir = '../Uploads/photos/';
                    $file_path = $upload_dir . $file_name;
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    if (file_put_contents($file_path, $image_data)) {
                        // Delete old photo if it exists
                        if ($photo_path && file_exists($photo_path)) {
                            unlink($photo_path);
                        }
                        $photo_path = $file_path;
                    } else {
                        $errors[] = "Erreur lors de l'enregistrement de la photo capturée.";
                    }
                }
            } else {
                $errors[] = "Format de la photo capturée invalide.";
            }
        } elseif (isset($_FILES['photo_path']) && $_FILES['photo_path']['size'] > 0) {
            if ($_FILES['photo_path']['size'] > 2 * 1024 * 1024) {
                $errors[] = "La photo téléversée dépasse la taille maximale de 2MB.";
            } elseif (!in_array($_FILES['photo_path']['type'], ['image/jpeg', 'image/png'])) {
                $errors[] = "La photo téléversée doit être au format JPEG ou PNG.";
            } else {
                $upload = uploadPhoto($_FILES['photo_path']);
                if (isset($upload['error'])) {
                    $errors[] = $upload['error'];
                } else {
                    // Delete old photo if it exists
                    if ($photo_path && file_exists($photo_path)) {
                        unlink($photo_path);
                    }
                    $photo_path = $upload['path'];
                }
            }
        } elseif (!$photo_path) {
            $errors[] = "Une photo est requise (téléversée ou capturée).";
        }

        if (empty($errors)) {
            try {
                $pdo->beginTransaction();
                // UPDATE SANS date_sortie
                $stmt = $pdo->prepare("
                    UPDATE beneficiaires 
                    SET nom = ?, prenom = ?, date_naissance = ?, relation = ?, 
                        statut = 'en_attente_approbation', photo_path = ?
                    WHERE id_beneficiaire = ?
                ");
                $stmt->execute([$nom, $prenom, $date_naissance, $relation, $photo_path, $id_beneficiaire]);

                // Log de l'activité (SANS date_sortie)
                logActivity($pdo, $_SESSION['user_id'], 'edit_beneficiaire', 
                    "Bénéficiaire ID $id_beneficiaire modifié");

                $pdo->commit();
                $success = "✅ Bénéficiaire mis à jour avec succès.";

                // Recharger les données
                $stmt = $pdo->prepare("
                    SELECT b.*, a.num_adherent 
                    FROM beneficiaires b 
                    JOIN adhesions a ON b.id_adhesion = a.id_adhesion 
                    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                    WHERE b.id_beneficiaire = ? AND a.created_by = ? AND u.departement = ?
                ");
                $stmt->execute([$id_beneficiaire, $_SESSION['user_id'], $_SESSION['departement']]);
                $beneficiaire = $stmt->fetch(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                $pdo->rollBack();
                $errors[] = "Erreur lors de la mise à jour : " . htmlspecialchars($e->getMessage());
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un Bénéficiaire - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1d4ed8;
            --accent: #059669;
            --danger: #ef4444;
            --warning: #f59e0b;
            --secondary: #6b7280;
            --background: #f1f5f9;
            --card-bg: #ffffff;
            --success-dark: #047857;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #e2e8f0 0%, #dbeafe 100%);
            background-size: 200% 200%;
            min-height: 100vh;
            animation: gradientShift 15s ease infinite;
        }

        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .container {
            max-width: 800px;
            margin: 3rem auto;
            padding: 0 1.5rem;
        }

        .page-title {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease-in;
            justify-content: center;
        }

        .card {
            border-radius: 16px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
            background: var(--card-bg);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary), #3b82f6);
            color: white;
            font-weight: 600;
            border-radius: 16px 16px 0 0;
            padding: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-body {
            padding: 2rem;
        }

        .alert {
            border-radius: 12px;
            animation: slideIn 0.5s ease-in-out;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem;
        }

        .form-control, .form-select {
            border-radius: 8px;
            padding: 0.75rem;
            border: 1px solid var(--primary);
            transition: border-color 0.3s ease, box-shadow 0.3s ease, transform 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 10px rgba(29, 78, 216, 0.5);
            transform: scale(1.02);
        }

        .btn-primary, .btn-secondary, .btn-success {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
            font-weight: 500;
            border: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
        }

        .btn-primary:hover {
            background-color: #1e3a8a;
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(29, 78, 216, 0.5);
        }

        .btn-secondary:hover {
            background-color: #4b5563;
            transform: scale(1.1);
        }

        .btn-success:hover {
            background-color: var(--success-dark);
            transform: scale(1.1);
        }

        /* CAMÉRA - AUCUNE MODIFICATION */
        #photoPreview, #photoPreviewCaptured {
            max-width: 150px;
            height: auto;
            margin-top: 10px;
            border: 1px solid var(--primary);
            border-radius: 6px;
        }

        .modal-body video, .modal-body canvas, .modal-body img {
            max-width: 100%;
            height: auto;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .container {
                margin: 1.5rem auto;
                padding: 0 1rem;
            }
            .page-title {
                font-size: 1.5rem;
            }
            .card-body {
                padding: 1.5rem 1rem;
            }
            #photoPreview, #photoPreviewCaptured {
                max-width: 120px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title"><i class="bi bi-person-gear me-2"></i>Modifier un Bénéficiaire</h2>

        <!-- Messages -->
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill"></i>
                <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php if ($beneficiaire): ?>
            <!-- Beneficiary Form -->
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-person-fill-gear me-2"></i>Formulaire Bénéficiaire
                    <span class="badge bg-light text-dark ms-auto"><?php echo htmlspecialchars($beneficiaire['statut']); ?></span>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                        <input type="hidden" name="photo_base64" id="photo_base64">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="num_adherent" class="form-label"><i class="bi bi-person-vcard me-2"></i>Numéro Adhérent</label>
                                    <input type="text" class="form-control" id="num_adherent" value="<?php echo htmlspecialchars($beneficiaire['num_adherent']); ?>" disabled>
                                </div>
                                <div class="mb-3">
                                    <label for="nom" class="form-label"><i class="bi bi-person me-2"></i>Nom *</label>
                                    <input type="text" class="form-control" id="nom" name="nom" value="<?php echo htmlspecialchars($beneficiaire['nom']); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="prenom" class="form-label"><i class="bi bi-person me-2"></i>Prénom *</label>
                                    <input type="text" class="form-control" id="prenom" name="prenom" value="<?php echo htmlspecialchars($beneficiaire['prenom']); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="date_naissance" class="form-label"><i class="bi bi-calendar me-2"></i>Date de Naissance *</label>
                                    <input type="date" class="form-control" id="date_naissance" name="date_naissance" value="<?php echo htmlspecialchars($beneficiaire['date_naissance']); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="relation" class="form-label"><i class="bi bi-link-45deg me-2"></i>Relation *</label>
                                    <select class="form-select" id="relation" name="relation" required>
                                        <option value="conjoint" <?php echo $beneficiaire['relation'] === 'conjoint' ? 'selected' : ''; ?>>Conjoint</option>
                                        <option value="enfant" <?php echo $beneficiaire['relation'] === 'enfant' ? 'selected' : ''; ?>>Enfant</option>
                                        <option value="adherent" <?php echo $beneficiaire['relation'] === 'adherent' ? 'selected' : ''; ?>>Adhérent</option>
                                        <option value="autre" <?php echo $beneficiaire['relation'] === 'autre' ? 'selected' : ''; ?>>Autre</option>
                                    </select>
                                </div>
                                <!-- PAS DE CHAMP date_sortie - SUPPRIMÉ -->
                                <div class="mb-3">
                                    <label for="photo_path" class="form-label"><i class="bi bi-image me-2"></i>Photo (JPEG/PNG, max 2MB) *</label>
                                    <?php if ($beneficiaire['photo_path']): ?>
                                        <div class="mb-2">
                                            <img id="photoPreview" src="<?php echo htmlspecialchars($beneficiaire['photo_path']); ?>" alt="Photo actuelle du bénéficiaire" style="max-width: 150px; height: auto; border: 1px solid var(--primary); border-radius: 6px;">
                                        </div>
                                    <?php endif; ?>
                                    <input type="file" class="form-control" id="photo_path" name="photo_path" accept="image/jpeg,image/png">
                                    <button type="button" class="btn btn-secondary mt-2 capture-photo" data-bs-toggle="modal" data-bs-target="#capturePhotoModal">
                                        <i class="bi bi-camera me-2"></i>📷 Capturer avec Caméra Arrière
                                    </button>
                                    <img id="photoPreviewCaptured" src="#" alt="Aperçu de la photo capturée" style="display: none; max-width: 150px; height: auto; margin-top: 10px; border: 1px solid var(--primary); border-radius: 6px;">
                                </div>
                            </div>
                        </div>
                        <button type="submit" name="submit_beneficiaire" class="btn btn-primary w-100">
                            <i class="bi bi-check-circle me-2"></i>Mettre à jour
                        </button>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill"></i>
                Bénéficiaire non trouvé ou accès non autorisé.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- MODAL CAMÉRA - IDENTIQUE -->
        <div class="modal fade" id="capturePhotoModal" tabindex="-1" aria-labelledby="capturePhotoModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" id="capturePhotoModalLabel">
                            <i class="bi bi-camera-video me-2"></i>📷 Caméra Arrière
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center">
                        <video id="video" autoplay style="max-width: 100%; height: auto;"></video>
                        <canvas id="canvas" style="display: none;"></canvas>
                        <div class="mt-3">
                            <button type="button" id="captureButton" class="btn btn-primary">
                                <i class="bi bi-camera me-2"></i>Capturer
                            </button>
                            <button type="button" id="retakeButton" class="btn btn-secondary" style="display: none;">
                                <i class="bi bi-arrow-repeat me-2"></i>Reprendre
                            </button>
                            <button type="button" id="savePhotoButton" class="btn btn-success" style="display: none;" data-bs-dismiss="modal">
                                <i class="bi bi-check-circle me-2"></i>Enregistrer la Photo
                            </button>
                        </div>
                        <p id="cameraError" class="text-danger mt-3" style="display: none;"></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <!-- JAVASCRIPT CAMÉRA - IDENTIQUE -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const video = document.getElementById('video');
            const canvas = document.getElementById('canvas');
            const captureButton = document.getElementById('captureButton');
            const retakeButton = document.getElementById('retakeButton');
            const savePhotoButton = document.getElementById('savePhotoButton');
            const photoBase64Input = document.getElementById('photo_base64');
            const photoInput = document.getElementById('photo_path');
            const photoPreview = document.getElementById('photoPreview');
            const photoPreviewCaptured = document.getElementById('photoPreviewCaptured');
            let stream = null;

            // Start camera when modal is opened - IDENTIQUE
            document.getElementById('capturePhotoModal')?.addEventListener('shown.bs.modal', async function() {
                try {
                    stream = await navigator.mediaDevices.getUserMedia({ 
                        video: { 
                            facingMode: 'environment', // Utiliser la caméra arrière
                            width: { ideal: 640 },
                            height: { ideal: 480 }
                        } 
                    });
                    video.srcObject = stream;
                    document.getElementById('cameraError').style.display = 'none';
                    captureButton.style.display = 'inline-block';
                    retakeButton.style.display = 'none';
                    savePhotoButton.style.display = 'none';
                } catch (err) {
                    console.error('Erreur d\'accès à la caméra:', err);
                    document.getElementById('cameraError').textContent = 'Impossible d\'accéder à la caméra. Vérifiez les autorisations ou utilisez une image téléversée.';
                    document.getElementById('cameraError').style.display = 'block';
                    captureButton.style.display = 'none';
                }
            });

            // Stop camera when modal is closed - IDENTIQUE
            document.getElementById('capturePhotoModal')?.addEventListener('hidden.bs.modal', function() {
                if (stream) {
                    stream.getTracks().forEach(track => track.stop());
                    stream = null;
                }
                video.srcObject = null;
                video.style.display = 'block';
                canvas.style.display = 'none';
            });

            // Capture photo - IDENTIQUE
            captureButton?.addEventListener('click', function() {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                canvas.getContext('2d').drawImage(video, 0, 0);
                const imageData = canvas.toDataURL('image/jpeg', 0.5);
                if (imageData.length > 2 * 1024 * 1024 * 1.33) {
                    alert('La photo capturée dépasse la taille maximale de 2MB.');
                    return;
                }
                photoPreviewCaptured.src = imageData;
                photoPreviewCaptured.style.display = 'block';
                photoBase64Input.value = imageData;
                photoInput.value = '';
                if (photoPreview) {
                    photoPreview.style.display = 'none';
                }
                captureButton.style.display = 'none';
                retakeButton.style.display = 'inline-block';
                savePhotoButton.style.display = 'inline-block';
                video.style.display = 'none';
                canvas.style.display = 'block';
            });

            // Retake photo - IDENTIQUE
            retakeButton?.addEventListener('click', function() {
                video.style.display = 'block';
                canvas.style.display = 'none';
                captureButton.style.display = 'inline-block';
                retakeButton.style.display = 'none';
                savePhotoButton.style.display = 'none';
                photoPreviewCaptured.style.display = 'none';
                photoBase64Input.value = '';
                if (photoPreview) {
                    photoPreview.style.display = 'block';
                }
            });

            // Handle file input change - IDENTIQUE
            photoInput?.addEventListener('change', function() {
                if (photoInput.files.length > 0) {
                    const file = photoInput.files[0];
                    if (file.size > 2 * 1024 * 1024) {
                        alert('La photo téléversée dépasse la taille maximale de 2MB.');
                        photoInput.value = '';
                        photoPreviewCaptured.style.display = 'none';
                        photoBase64Input.value = '';
                        if (photoPreview) {
                            photoPreview.style.display = 'block';
                        }
                        return;
                    }
                    if (!['image/jpeg', 'image/png'].includes(file.type)) {
                        alert('La photo téléversée doit être au format JPEG ou PNG.');
                        photoInput.value = '';
                        photoPreviewCaptured.style.display = 'none';
                        photoBase64Input.value = '';
                        if (photoPreview) {
                            photoPreview.style.display = 'block';
                        }
                        return;
                    }
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        photoPreviewCaptured.src = e.target.result;
                        photoPreviewCaptured.style.display = 'block';
                        photoBase64Input.value = '';
                        if (photoPreview) {
                            photoPreview.style.display = 'none';
                        }
                    };
                    reader.readAsDataURL(file);
                } else {
                    photoPreviewCaptured.style.display = 'none';
                    photoBase64Input.value = '';
                    if (photoPreview) {
                        photoPreview.style.display = 'block';
                    }
                }
            });

            // Validate form submission - IDENTIQUE (SANS date_sortie)
            document.querySelector('form')?.addEventListener('submit', function(e) {
                if (!photoBase64Input.value && (!photoInput.files || photoInput.files.length === 0) && !<?php echo json_encode($beneficiaire['photo_path']); ?>) {
                    alert('Veuillez fournir une photo (téléversée ou capturée).');
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>
<?php require_once '../includes/footer.php'; ?>