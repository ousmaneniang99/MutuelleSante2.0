<?php
ob_start();
session_start();
require_once '../includes/auth.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$errors = [];
$success = null;

// Log pour vérifier le chargement du fichier
error_log("Démarrage de forgot_password.php, chemin autoload : " . realpath('../vendor/autoload.php'));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['forgot_password'])) {
    $email = isset($_POST['email']) ? sanitize(trim($_POST['email'])) : '';

    if (empty($email)) {
        $errors[] = "L'email est requis.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "L'email est invalide.";
    }

    if (empty($errors)) {
        try {
            // Vérifier si l'email existe
            error_log("Vérification de l'email : $email");
            $stmt = $pdo->prepare("SELECT id_utilisateur, email FROM utilisateurs WHERE email = :email AND statut = 'actif'");
            $stmt->execute(['email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                $errors[] = "Aucun compte actif associé à l'email : " . htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
                error_log("Aucun utilisateur actif trouvé pour l'email : $email");
            } else {
                // Générer un jeton de réinitialisation
                $token = bin2hex(random_bytes(32));
                $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));
                error_log("Jeton généré : $token, expire à : $expires_at");

                // Supprimer les anciens jetons
                $stmt = $pdo->prepare("DELETE FROM password_resets WHERE email = :email");
                $stmt->execute(['email' => $email]);
                error_log("Anciens jetons supprimés pour l'email : $email");

                // Enregistrer le nouveau jeton
                $stmt = $pdo->prepare("
                    INSERT INTO password_resets (email, token, created_at, expires_at)
                    VALUES (:email, :token, NOW(), :expires_at)
                ");
                $stmt->execute([
                    'email' => $email,
                    'token' => $token,
                    'expires_at' => $expires_at
                ]);
                error_log("Nouveau jeton enregistré pour l'email : $email");

                // Enregistrer l'activité
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO logs_activites (id_utilisateur, action, details, date_action)
                        VALUES (:id_utilisateur, :action, :details, NOW())
                    ");
                    $stmt->execute([
                        'id_utilisateur' => $user['id_utilisateur'],
                        'action' => 'forgot_password',
                        'details' => "Demande de réinitialisation de mot de passe pour {$user['email']}"
                    ]);
                    error_log("Activité enregistrée pour l'email : $email");
                } catch (PDOException $e) {
                    error_log("Erreur log activité : " . $e->getMessage());
                }

                // Configurer PHPMailer
                $mail = new PHPMailer(true);
                try {
                    // Activer le débogage SMTP
                    $mail->SMTPDebug = 2;
                    $mail->Debugoutput = function($str, $level) { error_log("PHPMailer Debug [$level]: $str"); };

                    // Paramètres du serveur SMTP
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'ousmaneniang38@gmail.com';
                    $mail->Password = 'gjwq keiu ucsr pajw';
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    // Destinataire
                    $mail->setFrom('ousmaneniang38@gmail.com', 'Mutuelle Santé Matam');
                    $mail->addAddress($email);

                    // Contenu de l'email
                    $mail->isHTML(true);
                    $mail->Subject = 'Réinitialisation de votre mot de passe';
                    $reset_link = "https://salam.expresdigital.com/pages/reset_password.php?email=" . urlencode($email) . "&token=" . $token;
                    $mail->Body = "
                        <h2>Réinitialisation de mot de passe</h2>
                        <p>Vous avez demandé à réinitialiser votre mot de passe. Cliquez sur le lien ci-dessous pour procéder :</p>
                        <p><a href='$reset_link'>Réinitialiser mon mot de passe</a></p>
                        <p>Ce lien expire dans 1 heure.</p>
                        <p>Si vous n'avez pas fait cette demande, ignorez cet email.</p>
                    ";
                    $mail->AltBody = "Vous avez demandé à réinitialiser votre mot de passe. Visitez ce lien : $reset_link pour procéder. Ce lien expire dans 1 heure.";

                    $mail->send();
                    $success = "Un email de réinitialisation a été envoyé à votre adresse.";
                    error_log("Email de réinitialisation envoyé à : $email");
                } catch (Exception $e) {
                    $errors[] = "Erreur lors de l'envoi de l'email. Veuillez réessayer.";
                    error_log("Erreur PHPMailer : " . $mail->ErrorInfo);
                }
            }
        } catch (PDOException $e) {
            $errors[] = "Une erreur est survenue. Veuillez réessayer.";
            error_log("Erreur PDO : " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation Mot de Passe - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;
            --secondary: #4b5563;
            --accent: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --background: #f8fafc;
            --card-bg: #ffffff;
            --text: #1f2a44;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #e6effa 0%, #f4f7fa 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 1rem;
        }

        .reset-card {
            max-width: 450px;
            width: 100%;
            background: var(--card-bg);
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeIn 0.8s ease-in-out;
        }

        .reset-header {
            background: linear-gradient(135deg, var(--primary), #1e40af);
            padding: 2rem;
            text-align: center;
            color: white;
        }

        .reset-header img {
            max-width: 100px;
            border-radius: 50%;
            margin-bottom: 1rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }

        .reset-header h2 {
            font-size: 1.75rem;
            font-weight: 700;
            margin: 0;
        }

        .reset-header p {
            font-size: 1rem;
            opacity: 0.9;
            margin: 0.5rem 0 0;
        }

        .card-body {
            padding: 2rem;
        }

        .form-label {
            font-weight: 500;
            color: var(--text);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .form-control {
            border-radius: 8px;
            border: 1px solid #d1d5db;
            padding: 0.75rem 1rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 8px rgba(37, 99, 235, 0.2);
            outline: none;
        }

        .btn-primary {
            background: var(--primary);
            border: none;
            border-radius: 8px;
            padding: 0.75rem;
            font-weight: 500;
            font-size: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        .btn-primary:hover {
            background: #1e40af;
            transform: translateY(-2px);
        }

        .alert {
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            animation: slideIn 0.5s ease-in-out;
        }

        .alert-dismissible .btn-close {
            padding: 1rem;
        }

        .back-to-login {
            display: block;
            text-align: center;
            margin-top: 1rem;
            font-size: 0.875rem;
            color: var(--primary);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .back-to-login:hover {
            color: #1e40af;
            text-decoration: underline;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-10px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @media (max-width: 576px) {
            .reset-card {
                margin: 1rem;
            }
            .reset-header {
                padding: 1.5rem;
            }
            .reset-header img {
                max-width: 80px;
            }
            .reset-header h2 {
                font-size: 1.5rem;
            }
            .card-body {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="reset-card">
        <!-- Header -->
        <div class="reset-header">
            <img src="../Uploads/photos/logo1.png" alt="Logo de Mutuelle Santé Matam" aria-label="Logo de Mutuelle Santé Matam">
            <h2>Mutuelle Santé Matam</h2>
            <p>Réinitialisez votre mot de passe</p>
        </div>
        <!-- Form -->
        <div class="card-body">
            <?php if ($errors): ?>
                <?php foreach ($errors as $error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="email" class="form-label"><i class="bi bi-envelope"></i> Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required aria-describedby="emailHelp">
                </div>
                <button type="submit" name="forgot_password" class="btn btn-primary w-100"><i class="bi bi-send"></i> Envoyer le lien de réinitialisation</button>
            </form>
            <a href="login.php" class="back-to-login"><i class="bi bi-arrow-left"></i> Retour à la connexion</a>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
<?php
ob_end_flush();
?>