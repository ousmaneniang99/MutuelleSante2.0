<?php
ob_start(); // Start output buffering at the very beginning
require_once '../includes/header.php';
checkRole('admin'); // Restrict to admin role
require_once '../vendor/tecnickcom/tcpdf/tcpdf.php'; // TCPDF path in vendor

$errors = [];
$success = null;

// Check if id_beneficiaire is provided
if (!isset($_GET['id_beneficiaire']) || !is_numeric($_GET['id_beneficiaire'])) {
    $errors[] = "ID du bénéficiaire non valide.";
} else {
    $id_beneficiaire = (int) sanitize($_GET['id_beneficiaire']);

    // Fetch beneficiary details
    $query = "
        SELECT b.code_beneficiaire, b.nom, b.prenom, b.date_naissance, b.statut,
               a.num_adherent, a.type_adhesion, a.date_adhesion, a.date_expiration
        FROM beneficiaires b
        JOIN adhesions a ON b.id_adhesion = a.id_adhesion
        WHERE b.id_beneficiaire = ?
    ";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id_beneficiaire]);
    $beneficiaire = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$beneficiaire) {
        $errors[] = "Bénéficiaire non trouvé.";
    } else {
        // Clear output buffer before generating PDF
        ob_end_clean();

        // Generate PDF
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, [85, 54], true, 'UTF-8', false);

        // Set document information
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('Système de Gestion des Adhésions');
        $pdf->SetTitle('Carte de Bénéficiaire');
        $pdf->SetSubject('Carte de Bénéficiaire');
        $pdf->SetKeywords('carte, bénéficiaire, adhésion');

        // Remove default header/footer
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);

        // Set margins
        $pdf->SetMargins(5, 5, 5);
        $pdf->SetAutoPageBreak(false);

        // Add a page
        $pdf->AddPage();

        // Set font
        $pdf->SetFont('helvetica', '', 10);

        // Card design
        $pdf->SetFillColor(255, 255, 255);
        $pdf->Rect(0, 0, 85, 54, 'F'); // Background
        $pdf->SetLineStyle(['width' => 0.5, 'color' => [0, 123, 255]]);
        $pdf->Rect(0, 0, 85, 54); // Border

        // Title
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->SetXY(5, 5);
        $pdf->Cell(75, 0, 'Carte de Bénéficiaire', 0, 1, 'C');

        // Beneficiary details
        $pdf->SetFont('helvetica', '', 9);
        $pdf->SetXY(5, 12);
        $pdf->Cell(75, 0, 'Code: ' . htmlspecialchars($beneficiaire['code_beneficiaire']), 0, 1, 'L');
        $pdf->SetXY(5, 18);
        $pdf->Cell(75, 0, 'Nom: ' . htmlspecialchars($beneficiaire['nom'] . ' ' . $beneficiaire['prenom']), 0, 1, 'L');
        $pdf->SetXY(5, 24);
        $pdf->Cell(75, 0, 'Date de Naissance: ' . htmlspecialchars($beneficiaire['date_naissance']), 0, 1, 'L');
        $pdf->SetXY(5, 30);
        $pdf->Cell(75, 0, 'Numéro Adhérent: ' . htmlspecialchars($beneficiaire['num_adherent']), 0, 1, 'L');
        $pdf->SetXY(5, 36);
        $pdf->Cell(75, 0, 'Type d\'Adhésion: ' . htmlspecialchars($beneficiaire['type_adhesion']), 0, 1, 'L');
        $pdf->SetXY(5, 42);
        $pdf->Cell(75, 0, 'Statut: ' . htmlspecialchars($beneficiaire['statut'] === 'actif' ? 'Actif' : 'En attente'), 0, 1, 'L');
        $pdf->SetXY(5, 48);
        $pdf->Cell(75, 0, 'Valide du ' . htmlspecialchars($beneficiaire['date_adhesion']) . ' au ' . htmlspecialchars($beneficiaire['date_expiration']), 0, 1, 'L');

        // Output PDF
        $filename = 'carte_beneficiaire_' . htmlspecialchars($beneficiaire['code_beneficiaire']) . '.pdf';
        $pdf->Output($filename, 'D'); // Download PDF
        logActivity($pdo, $_SESSION['user_id'], 'generate_card', "Carte générée pour bénéficiaire ID: $id_beneficiaire");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Générer Carte de Bénéficiaire - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            border-bottom: none;
            padding: 1.5rem;
            font-size: 1.25rem;
            font-weight: 600;
            background-color: #007bff;
            color: white;
        }
        .card-body {
            padding: 2rem;
        }
        .alert {
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert i {
            font-size: 1.2rem;
        }
        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-card-text me-2"></i>Générer Carte de Bénéficiaire</h2>

        <!-- Messages -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i>
                <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <i class="bi bi-info-circle me-2"></i>Erreur
            </div>
            <div class="card-body">
                <p>Veuillez sélectionner un bénéficiaire depuis la liste des bénéficiaires pour générer une carte.</p>
                <a href="voir_beneficiaires.php" class="btn btn-primary"><i class="bi bi-arrow-left me-2"></i>Retour à la liste</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>

<?php
ob_end_flush(); // End output buffering for HTML output
require_once '../includes/footer.php';
?>