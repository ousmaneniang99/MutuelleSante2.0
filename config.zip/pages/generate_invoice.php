<?php
// pages/generate_invoice.php
require_once '../includes/header.php';
checkRole('prestataire_soins');

$errors = [];
$demande = null;

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $errors[] = "ID de la demande non valide.";
} else {
    $id_demande = intval($_GET['id']);
    try {
        // Fetch demande details
        $stmt = $pdo->prepare("
            SELECT dr.id_demande, dr.id_adhesion, dr.date_soin, dr.montant_facture, dr.pieces_jointes, dr.commentaire,
                   p.nom AS prestation_nom, p.taux_remboursement, b.nom AS beneficiaire_nom, b.prenom AS beneficiaire_prenom,
                   a.num_adherent, u.nom AS adherent_nom, u.prenom AS adherent_prenom
            FROM demandes_remboursement dr
            JOIN prestations p ON dr.id_prestation = p.id_prestation
            JOIN beneficiaires b ON dr.id_beneficiaire = b.id_beneficiaire
            JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
            WHERE dr.id_demande = ? AND dr.id_prestataire = ? AND dr.statut IN ('en_attente', 'en_validation')
        ");
        $stmt->execute([$id_demande, $_SESSION['user_id']]);
        $demande = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$demande) {
            $errors[] = "Demande non trouvée ou accès non autorisé.";
        }
    } catch (PDOException $e) {
        $errors[] = "Erreur lors de la récupération des données : " . htmlspecialchars($e->getMessage());
        error_log("Erreur dans generate_invoice.php : " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Générer une Facture</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .card-header {
            border-bottom: none;
            padding: 1.5rem;
            font-size: 1.25rem;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .alert {
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert i {
            font-size: 1.2rem;
        }
        .btn-info, .btn-secondary {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .btn-info:hover {
            background-color: #138496;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 2rem;
        }
        .invoice-details dt {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        .invoice-details dd {
            margin-bottom: 1.5rem;
            color: #495057;
        }
        .invoice-details .btn {
            margin-top: 0.5rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-receipt-cutoff me-2"></i>Générer une Facture</h2>

        <!-- Error Messages -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php elseif ($demande): ?>
            <!-- Invoice Details -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="bi bi-receipt me-2"></i>Détails de la Facture
                </div>
                <div class="card-body">
                    <dl class="invoice-details row">
                        <dt class="col-md-4">Demande</dt>
                        <dd class="col-md-8">#<?php echo htmlspecialchars($demande['id_demande']); ?></dd>

                        <dt class="col-md-4">Adhérent</dt>
                        <dd class="col-md-8"><?php echo htmlspecialchars($demande['adherent_nom'] . ' ' . $demande['adherent_prenom']); ?></dd>

                        <dt class="col-md-4">Numéro Adhésion</dt>
                        <dd class="col-md-8"><?php echo htmlspecialchars($demande['num_adherent']); ?></dd>

                        <dt class="col-md-4">Bénéficiaire</dt>
                        <dd class="col-md-8"><?php echo htmlspecialchars($demande['beneficiaire_nom'] . ' ' . $demande['beneficiaire_prenom']); ?></dd>

                        <dt class="col-md-4">Prestation</dt>
                        <dd class="col-md-8"><?php echo htmlspecialchars($demande['prestation_nom']); ?></dd>

                        <dt class="col-md-4">Date du Soin</dt>
                        <dd class="col-md-8"><?php echo htmlspecialchars($demande['date_soin']); ?></dd>

                        <dt class="col-md-4">Montant Facturé</dt>
                        <dd class="col-md-8"><?php echo htmlspecialchars(formatFCFA($demande['montant_facture'])); ?></dd>

                        <dt class="col-md-4">Taux de Remboursement</dt>
                        <dd class="col-md-8"><?php echo htmlspecialchars($demande['taux_remboursement']); ?>%</dd>

                        <dt class="col-md-4">Montant à Rembourser</dt>
                        <dd class="col-md-8"><?php echo htmlspecialchars(formatFCFA($demande['montant_facture'] * ($demande['taux_remboursement'] / 100))); ?></dd>

                        <dt class="col-md-4">Commentaire</dt>
                        <dd class="col-md-8"><?php echo htmlspecialchars($demande['commentaire'] ?? 'Aucun'); ?></dd>

                        <?php if ($demande['pieces_jointes']): ?>
                            <dt class="col-md-4">Pièces Jointes</dt>
                            <dd class="col-md-8">
                                <a href="<?php echo htmlspecialchars($demande['pieces_jointes']); ?>" target="_blank" class="btn btn-sm btn-info">
                                    <i class="bi bi-file-earmark-text me-1"></i>Voir
                                </a>
                            </dd>
                        <?php endif; ?>
                    </dl>
                    <div class="d-flex justify-content-end">
                        <a href="dashboard_prestataire.php" class="btn btn-secondary">
                            <i class="bi bi-arrow-left me-2"></i>Retour
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>