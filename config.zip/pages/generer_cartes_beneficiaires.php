<?php
// pages/generer_cartes_beneficiaires.php

session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../includes/functions.php';

checkRole('directeur_departemental');

$departement_id  = $_SESSION['departement']      ?? null;
$departement_nom = $_SESSION['departement_nom']  ?? '—';

if (!$departement_id) {
    die("Erreur critique : département non défini dans la session.");
}

// ────────────────────────────────────────────────
// Détection génération unique ou multiple
// ────────────────────────────────────────────────

$ids_to_generate = [];

if (isset($_GET['generate']) && is_numeric($_GET['generate'])) {
    $ids_to_generate = [(int)$_GET['generate']];
}
elseif (isset($_GET['multi_generate']) && !empty($_GET['ids']) && is_array($_GET['ids'])) {
    $ids_to_generate = array_filter($_GET['ids'], 'is_numeric');
    $ids_to_generate = array_map('intval', $ids_to_generate);
    $ids_to_generate = array_unique($ids_to_generate);
}

if (!empty($ids_to_generate)) {
    try {
        $placeholders = implode(',', array_fill(0, count($ids_to_generate), '?'));
        $stmt = $pdo->prepare("
            SELECT 
                b.id_beneficiaire, b.nom, b.prenom, b.date_naissance, b.relation,
                b.photo_path, b.code_beneficiaire,
                a.num_adherent, a.date_adhesion,
                d.nom AS departement_nom
            FROM beneficiaires b
            JOIN adhesions    a ON b.id_adhesion = a.id_adhesion
            JOIN departements d ON a.departement  = d.id_departement
            JOIN paiements    p ON p.id_adhesion  = a.id_adhesion
            WHERE b.id_beneficiaire IN ($placeholders)
              AND b.statut      = 'actif'
              AND a.departement = ?
              AND p.statut      = 'paye'
            ORDER BY b.nom, b.prenom
        ");

        $params = $ids_to_generate;
        $params[] = $departement_id;
        $stmt->execute($params);

        $selected = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($selected)) {
            die("Aucun bénéficiaire valide sélectionné.");
        }

        // ────────────────────────────────────────────────
        // AFFICHAGE DES CARTES
        // ────────────────────────────────────────────────
        ?>
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Cartes – <?= count($selected) ?> bénéficiaire(s)</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
            <style>
                body {
                    margin: 0;
                    padding: 0;
                    background: #f0f2f5;
                    font-family: Arial, Helvetica, sans-serif;
                }

                .card {
                    width: 85mm;
                    height: 55mm;
                    background: linear-gradient(135deg, #003366 0%, #005599 100%);
                    color: white;
                    overflow: hidden;
                    position: relative;
                    margin: 20mm auto;
                    border-radius: 3.2mm;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.35);
                    page-break-after: always;
                }

                .header {
                    height: 8.5mm;
                    background: rgba(0,0,0,0.58);
                    padding: 0.8mm 4mm;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    font-size: 0.72rem;
                }

                .title {
                    font-weight: bold;
                    letter-spacing: 0.4px;
                }

                .content {
                    padding: 2mm 4mm 1.5mm 4mm;
                    display: flex;
                    gap: 3mm;
                    height: 46.5mm;
                }

                .photo-container {
                    width: 32mm;
                    height: 39mm;
                    flex-shrink: 0;
                    margin-right: 2mm;
                }

                .photo {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                    border-radius: 2mm;
                    border: 1px solid rgba(255,255,255,0.65);
                    box-shadow: 0 2px 5px rgba(0,0,0,0.4);
                }

                .photo-placeholder {
                    background: #e5e7eb;
                    height: 100%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: #6b7280;
                    font-size: 0.75rem;
                }

                .info {
                    flex: 1;
                    font-size: 0.70rem;
                    line-height: 1.10;
                    padding-top: 0.5mm;
                }

                .nom {
                    font-size: 0.91rem;
                    font-weight: bold;
                    text-transform: uppercase;
                    margin: 0 0 1.1mm 0;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    max-width: 50mm;
                }

                .ligne {
                    display: flex;
                    align-items: baseline;
                    margin-bottom: 0.35mm;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }

                .label {
                    font-weight: 600;
                    opacity: 0.96;
                    flex: 0 0 30mm;
                    margin-right: 0;
                    padding-right: 0;
                }

                .valeur {
                    flex: 1;
                    margin-left: 0;
                    padding-left: 0;
                }

                .qr {
                    position: absolute;
                    bottom: 2.5mm;
                    right: 3.8mm;
                    width: 14.5mm;
                    height: 14.5mm;
                    background: white;
                    border-radius: 1.7mm;
                    padding: 0.7mm;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.4);
                }

                .qr img {
                    width: 100%;
                    height: 100%;
                    object-fit: contain;
                }

                .print-ctrl {
                    text-align: center;
                    padding: 12px;
                }

                @media print {
                    body { background: white !important; margin:0 !important; padding:0 !important; }
                    .print-ctrl { display: none !important; }
                    .card {
                        margin: 0 !important;
                        box-shadow: none !important;
                        border-radius: 0 !important;
                        width: 85mm !important;
                        height: 55mm !important;
                    }
                    @page {
                        size: landscape;
                        margin: 3mm 4mm;
                    }
                }
            </style>
        </head>
        <body>

            <div class="print-ctrl">
                <h5><?= count($selected) ?> carte(s) — 85×55 mm</h5>
                <button class="btn btn-primary px-5 py-2" onclick="window.print()">
                    <i class="bi bi-printer me-2"></i>Imprimer toutes
                </button>
                <p class="mt-2 small text-muted">
                    Paysage • 100% • Sans en-tête/pied de page
                </p>
            </div>

            <?php foreach ($selected as $b): ?>
            <div class="card">
                <div class="header">
                    <div class="title">MUTUELLE SANTÉ MATAM</div>
                    <div>Dépt. <?= htmlspecialchars($b['departement_nom'] ?? '—') ?></div>
                </div>

                <div class="content">
                    <div class="photo-container">
                        <?php if (!empty($b['photo_path']) && file_exists($b['photo_path'])): ?>
                            <img src="<?= htmlspecialchars($b['photo_path']) ?>" class="photo" alt="Photo bénéficiaire">
                        <?php else: ?>
                            <div class="photo-placeholder">
                                <i class="bi bi-person-fill fs-4"></i>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="info">
                        <div class="nom">
                            <?= htmlspecialchars($b['nom']) ?> <?= htmlspecialchars($b['prenom']) ?>
                        </div>

                        <div class="ligne">
                            <span class="label">N° Adhérent :</span>
                            <span class="valeur"><?= htmlspecialchars($b['num_adherent']) ?></span>
                        </div>
                        <div class="ligne">
                            <span class="label">N° Bénéficiaire :</span>
                            <span class="valeur"><?= htmlspecialchars($b['code_beneficiaire'] ?? '—') ?></span>
                        </div>
                        <div class="ligne">
                            <span class="label">Relation :</span>
                            <span class="valeur"><?= htmlspecialchars($b['relation'] ?: 'Adhérent') ?></span>
                        </div>
                        <div class="ligne">
                            <span class="label">Naissance :</span>
                            <span class="valeur"><?= $b['date_naissance'] ? date('d/m/Y', strtotime($b['date_naissance'])) : '—' ?></span>
                        </div>
                        <div class="ligne">
                            <span class="label">Adhésion :</span>
                            <span class="valeur"><?= date('d/m/Y', strtotime($b['date_adhesion'])) ?></span>
                        </div>
                    </div>
                </div>

                <div class="qr">
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=<?= urlencode($b['code_beneficiaire'] ?? $b['num_adherent']) ?>" alt="QR">
                </div>
            </div>
            <?php endforeach; ?>

        </body>
        </html>
        <?php
        exit;
    }
    catch (Exception $e) {
        die("Erreur génération : " . htmlspecialchars($e->getMessage()));
    }
}

// ────────────────────────────────────────────────
// Liste des bénéficiaires
// ────────────────────────────────────────────────

$search = trim($_GET['search'] ?? '');
$beneficiaires = [];
$error = null;

try {
    $sql = "
        SELECT 
            b.id_beneficiaire, b.nom, b.prenom, b.photo_path, b.code_beneficiaire,
            a.num_adherent
        FROM beneficiaires b
        JOIN adhesions a ON b.id_adhesion = a.id_adhesion
        WHERE b.statut = 'actif'
          AND a.departement = :dept
          AND EXISTS (
              SELECT 1 FROM paiements p 
              WHERE p.id_adhesion = a.id_adhesion 
                AND p.statut = 'paye'
          )
    ";
    $params = [':dept' => $departement_id];

    if ($search !== '') {
        $sql .= " AND (b.nom LIKE :s OR b.prenom LIKE :s OR a.num_adherent LIKE :s OR b.code_beneficiaire LIKE :s)";
        $params[':s'] = "%$search%";
    }

    $sql .= " ORDER BY b.nom, b.prenom";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $beneficiaires = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $error = $e->getMessage();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5">
    <h1 class="text-center mb-5 fw-bold text-primary">
        <i class="bi bi-id-card me-2"></i>Génération des Cartes
    </h1>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card shadow-sm mb-5">
        <div class="card-body">
            <form method="GET" class="d-flex gap-3 flex-wrap">
                <input type="search" name="search" class="form-control form-control-lg flex-grow-1"
                       placeholder="Nom, prénom, n° adhérent ou n° bénéficiaire..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="btn btn-primary btn-lg px-4">
                    <i class="bi bi-search me-2"></i>Rechercher
                </button>
                <?php if ($search): ?>
                    <a href="?" class="btn btn-outline-secondary btn-lg">Effacer</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <?php if (empty($beneficiaires)): ?>
        <div class="alert alert-info text-center py-5">
            <i class="bi bi-info-circle-fill fs-1 me-2"></i>Aucun bénéficiaire éligible trouvé
        </div>
    <?php else: ?>
        <form method="GET">
            <div class="d-flex justify-content-between mb-4 flex-wrap gap-3">
                <div><?= count($beneficiaires) ?> bénéficiaire(s) trouvé(s)</div>
                <div>
                    <button type="submit" name="multi_generate" value="1" class="btn btn-primary" disabled id="btnMulti">
                        <i class="bi bi-printer me-2"></i>Générer sélection
                    </button>
                    <button type="button" class="btn btn-outline-secondary" id="btnTout">Tout sélectionner</button>
                </div>
            </div>

            <div class="row g-4">
                <?php foreach ($beneficiaires as $b): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 shadow-sm position-relative">
                        <div class="position-absolute top-0 start-0 m-3">
                            <input type="checkbox" class="form-check-input" name="ids[]" 
                                   value="<?= $b['id_beneficiaire'] ?>" id="c_<?= $b['id_beneficiaire'] ?>">
                        </div>
                        <div class="card-body text-center pt-5">
                            <?php if (!empty($b['photo_path']) && file_exists($b['photo_path'])): ?>
                                <img src="<?= htmlspecialchars($b['photo_path']) ?>" class="rounded-circle mb-3" style="width:85px;height:85px;object-fit:cover;">
                            <?php else: ?>
                                <div class="rounded-circle bg-light d-flex align-items-center justify-content-center mb-3 mx-auto" style="width:85px;height:85px;">
                                    <i class="bi bi-person fs-1 text-muted"></i>
                                </div>
                            <?php endif; ?>

                            <h6 class="mb-1"><?= htmlspecialchars($b['nom']) ?> <?= htmlspecialchars($b['prenom']) ?></h6>
                            <p class="text-muted small mb-3">N° <?= htmlspecialchars($b['num_adherent']) ?></p>

                            <a href="?generate=<?= $b['id_beneficiaire'] ?>" target="_blank" class="btn btn-outline-primary btn-sm w-100">
                                <i class="bi bi-eye me-1"></i>Voir / Imprimer
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </form>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const checks = document.querySelectorAll('input[name="ids[]"]');
    const btn = document.getElementById('btnMulti');
    const tout = document.getElementById('btnTout');

    function maj() {
        const n = document.querySelectorAll('input[name="ids[]"]:checked').length;
        btn.disabled = n === 0;
        btn.innerHTML = n === 0 
            ? '<i class="bi bi-printer me-2"></i>Générer sélection'
            : `<i class="bi bi-printer me-2"></i>Imprimer ${n} carte${n>1?'s':''}`;
    }

    checks.forEach(c => c.addEventListener('change', maj));

    tout.addEventListener('click', () => {
        const toutCoche = document.querySelectorAll('input[name="ids[]"]:checked').length === checks.length;
        checks.forEach(c => c.checked = !toutCoche);
        maj();
        tout.textContent = toutCoche ? 'Tout sélectionner' : 'Tout désélectionner';
    });

    maj();
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>