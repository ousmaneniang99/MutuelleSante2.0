<?php
// pages/gestion_remboursements.php
ob_start();
require_once '../includes/header.php';
checkRole('prestataire_soins');

// Fallback function if not defined elsewhere
if (!function_exists('formatFCFA')) {
    function formatFCFA($amount) {
        return number_format($amount, 0, ',', ' ') . ' FCFA';
    }
}

// === INFOS PRESTATAIRE ===
$stmt = $pdo->prepare("
    SELECT p.id_prestataire, p.nom AS nom_prestataire, p.logo, n.niveau AS nom_niveau
    FROM prestataires p 
    LEFT JOIN niveau n ON p.id_niveau = n.id_niveau
    WHERE p.id_utilisateur = ?
");
$stmt->execute([$_SESSION['user_id']]);
$prestataire = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$prestataire) { header('Location: logout.php'); exit; }

$nom_prestataire = $prestataire['nom_prestataire'];
$logo_path = !empty($prestataire['logo']) && file_exists("../" . $prestataire['logo']) 
    ? "../" . $prestataire['logo'] 
    : "../assets/images/logo-default.png";
$nom_niveau = $prestataire['nom_niveau'] ?? 'Standard';
$id_prestataire = $prestataire['id_prestataire'];

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();

// === VALIDATION UNITAIRE (AJAX-LIKE VIA POST) ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['valider_unitaire']) && verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    $id_demande = intval($_POST['id_demande'] ?? 0);
    if ($id_demande > 0) {
        $stmt = $pdo->prepare("
            UPDATE demandes_remboursement 
            SET statut='approuve', validated_by=?, date_mise_a_jour=NOW() 
            WHERE id_demande=? AND id_prestataire=? AND statut='en_validation'
        ");
        if ($stmt->execute([$_SESSION['user_id'], $id_demande, $id_prestataire])) {
            $success = "Demande #$id_demande validée avec succès !";
        } else {
            $errors[] = "Échec de validation de la demande #$id_demande.";
        }
    }
    // Recharge avec filtres
    header("Location: gestion_remboursements.php?" . http_build_query($_GET));
    exit;
}

// === VALIDATION SÉLECTION (MASSE) ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['valider_selection']) && verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    $ids = array_filter(array_map('intval', $_POST['demande'] ?? []));
    if (count($ids) > 100) {
        $errors[] = "Trop de demandes sélectionnées (limite : 100).";
    } elseif (!empty($ids)) {
        $placeholders = str_repeat('?,', count($ids) - 1) . '?';
        $stmt = $pdo->prepare("
            UPDATE demandes_remboursement 
            SET statut='approuve', validated_by=?, date_mise_a_jour=NOW() 
            WHERE id_demande IN ($placeholders) AND id_prestataire=? AND statut='en_validation'
        ");
        $params = array_merge([$_SESSION['user_id']], $ids, [$id_prestataire]);
        if ($stmt->execute($params)) {
            $count = $stmt->rowCount();
            $success = "$count demande(s) validée(s) en masse !";
        }
    } else {
        $errors[] = "Aucune demande sélectionnée.";
    }
    header("Location: gestion_remboursements.php?" . http_build_query($_GET));
    exit;
}

// === EXPORT CSV ===
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $wp = buildWhere($id_prestataire, $_GET['statut'] ?? 'all', $_GET['date_debut'] ?? '', $_GET['date_fin'] ?? '', $_GET['search'] ?? '');
    $query = "
        SELECT dr.id_demande, dr.date_soin, dr.montant_facture, dr.montant_rembourse, dr.montant_a_payer,
               dr.statut, p.nom AS prestation, b.nom AS b_nom, b.prenom AS b_prenom,
               b.code_beneficiaire, a.num_adherent
        FROM demandes_remboursement dr
        JOIN prestations p ON dr.id_prestation = p.id_prestation
        JOIN beneficiaires b ON dr.id_beneficiaire = b.id_beneficiaire
        JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
    " . $wp['where'] . " ORDER BY dr.date_soin DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($wp['params']);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=remboursements_' . date('Y-m-d') . '.csv');
    $output = fopen('php://output', 'w');
    fputs($output, "\xEF\xBB\xBF");
    fputcsv($output, ['ID', 'Date', 'Adhérent', 'Bénéficiaire', 'Code', 'Prestation', 'Facturé', 'Remboursé', 'À payer', 'Statut'], ';');
    foreach ($data as $row) {
        fputcsv($output, [
            $row['id_demande'],
            date('d/m/Y', strtotime($row['date_soin'])),
            $row['num_adherent'],
            $row['b_nom'] . ' ' . $row['b_prenom'],
            $row['code_beneficiaire'],
            $row['prestation'],
            $row['montant_facture'],
            $row['montant_rembourse'],
            $row['montant_a_payer'],
            ucfirst(str_replace('_', ' ', $row['statut']))
        ], ';');
    }
    fclose($output);
    exit;
}

// === FONCTION WHERE ===
function buildWhere($id_prestataire, $statut, $debut, $fin, $search) {
    $w = " WHERE dr.id_prestataire = :id_prestataire";
    $p = [':id_prestataire' => $id_prestataire];
    if ($statut !== 'all') { $w .= " AND dr.statut = :statut"; $p[':statut'] = $statut; }
    if ($debut) { $w .= " AND dr.date_soin >= :debut"; $p[':debut'] = $debut; }
    if ($fin) { $w .= " AND dr.date_soin <= :fin"; $p[':fin'] = $fin . ' 23:59:59'; }
    if ($search) {
        $like = "%" . strtolower($search) . "%";
        $w .= " AND (LOWER(a.num_adherent) LIKE :s1 OR LOWER(b.nom) LIKE :s2 OR LOWER(b.prenom) LIKE :s3 OR LOWER(b.code_beneficiaire) LIKE :s4 OR LOWER(p.nom) LIKE :s5)";
        for ($i=1;$i<=5;$i++) $p[":s$i"] = $like;
    }
    return ['where' => $w, 'params' => $p];
}
$wp = buildWhere($id_prestataire, $_GET['statut'] ?? 'all', $_GET['date_debut'] ?? '', $_GET['date_fin'] ?? '', $_GET['search'] ?? '');

// === KPI ===
$k = [];
$q = [
    'total_demandes' => "SELECT COUNT(*) FROM demandes_remboursement dr" . $wp['where'],
    'total_facture' => "SELECT COALESCE(SUM(dr.montant_facture),0) FROM demandes_remboursement dr" . $wp['where'],
    'rembourse_confirme' => "SELECT COALESCE(SUM(dr.montant_rembourse),0) FROM demandes_remboursement dr" . $wp['where'] . " AND dr.statut='approuve'",
    'beneficiaires' => "SELECT COUNT(DISTINCT dr.id_beneficiaire) FROM demandes_remboursement dr" . $wp['where'],
];
foreach ($q as $key => $sql) {
    $s = $pdo->prepare($sql); $s->execute($wp['params']); $k[$key] = $s->fetchColumn();
}

// === DEMANDES PAR MOIS ===
$formatter = new IntlDateFormatter('fr_FR', IntlDateFormatter::LONG, IntlDateFormatter::NONE);
$formatter->setPattern('MMMM yyyy');

$demandes_par_mois = [];
try {
    $stmt = $pdo->prepare("
        SELECT DATE_FORMAT(dr.date_soin, '%Y-%m') AS mois, 
               COUNT(*) AS total,
               SUM(dr.montant_rembourse) AS total_rembourse,
               SUM(CASE WHEN dr.statut='en_validation' THEN dr.montant_rembourse ELSE 0 END) AS a_valider,
               SUM(CASE WHEN dr.statut='en_attente' THEN dr.montant_rembourse ELSE 0 END) AS en_attente_montant,
               COUNT(CASE WHEN dr.statut='en_attente' THEN 1 END) AS en_attente_count
        FROM demandes_remboursement dr
        WHERE dr.id_prestataire = ?
        GROUP BY DATE_FORMAT(dr.date_soin, '%Y-%m')
        ORDER BY mois DESC
    ");
    $stmt->execute([$id_prestataire]);
    $mois_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($mois_list as $m) {
        $mois_key = $m['mois'];
        $date_obj = new DateTime("$mois_key-01");
        $mois_fr = ucfirst($formatter->format($date_obj));

        $stmt = $pdo->prepare("
            SELECT dr.id_demande, dr.date_soin, dr.montant_facture, dr.montant_rembourse, dr.montant_a_payer,
                   dr.statut, dr.pieces_jointes, p.nom AS prestation, b.nom AS b_nom, b.prenom AS b_prenom,
                   b.code_beneficiaire, a.num_adherent
            FROM demandes_remboursement dr
            JOIN prestations p ON dr.id_prestation = p.id_prestation
            JOIN beneficiaires b ON dr.id_beneficiaire = b.id_beneficiaire
            JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
            WHERE dr.id_prestataire=? AND DATE_FORMAT(dr.date_soin, '%Y-%m') = ?
            ORDER BY dr.date_soin DESC
        ");
        $stmt->execute([$id_prestataire, $mois_key]);
        $demandes_par_mois[$mois_key] = [
            'mois_fr' => $mois_fr,
            'total' => $m['total'],
            'total_rembourse' => $m['total_rembourse'],
            'a_valider' => $m['a_valider'],
            'en_attente_montant' => $m['en_attente_montant'],
            'en_attente_count' => $m['en_attente_count'],
            'demandes' => $stmt->fetchAll(PDO::FETCH_ASSOC)
        ];
    }
} catch (Exception $e) {
    error_log("DB ERROR: " . $e->getMessage());
    $errors[] = "Erreur de chargement.";
}
?>

<!DOCTYPE html>
<html lang="fr" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($nom_prestataire) ?> - Gestion Remboursements</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root{--p:#1e40af;--ph:#2563eb;--s:#10b981;--sh:#059669;--w:#f59e0b;--d:#ef4444;--l:#f8fafc;--glass:#ffffff20;--border:#e2e8f060;--shadow:0 8px 32px #00000015;--radius:1.5rem;--transition:all .3s cubic-bezier(.4,0,.2,1)}
        [data-bs-theme="dark"]{--l:#0f172a;--glass:#1e293b40;--border:#334155;--p:#3b82f6;--s:#22d3ee}
        *{box-sizing:border-box;margin:0;padding:0}
        body{background:var(--l);font-family:'Inter',sans-serif;color:#1e293b;transition:var(--transition);min-height:100vh}
        [data-bs-theme="dark"] body{color:#e2e8f0}
        .c{max-width:1400px;margin:0 auto;padding:1.5rem}
        .h{background:linear-gradient(135deg,var(--p),var(--ph));color:#fff;padding:1.5rem 0;box-shadow:var(--shadow);position:relative;overflow:hidden}
        .h::before{content:'';position:absolute;inset:0;background:radial-gradient(circle at 30% 50%,#ffffff15,transparent 70%);pointer-events:none}
        .l{width:56px;height:56px;object-fit:contain;border-radius:1rem;border:3px solid #fff;box-shadow:0 4px 12px #0002}
        .t{font-size:1.6rem;font-weight:800;display:flex;align-items:center;gap:.6rem}
        .n{background:var(--glass);backdrop-filter:blur(8px);padding:.4rem .9rem;border-radius:2rem;font-size:.85rem;font-weight:600;display:flex;align-items:center;gap:.4rem;border:1px solid var(--border)}
        .f{background:var(--glass);backdrop-filter:blur(16px);border:1px solid var(--border);border-radius:var(--radius);padding:1rem;box-shadow:var(--shadow);margin-bottom:1.5rem}
        .fr{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:.75rem;align-items:end}
        .fr .form-control,.fr .form-select,.fr .btn{font-size:.85rem}
        .kg{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin:1.5rem 0}
        .kc{background:var(--glass);backdrop-filter:blur(12px);border:1px solid var(--border);padding:1.2rem;border-radius:var(--radius);text-align:center;box-shadow:var(--shadow);transition:var(--transition)}
        .kc:hover{transform:translateY(-6px);box-shadow:0 16px 40px #00000025}
        .kv{font-size:1.6rem;font-weight:800}
        .m{background:var(--glass);backdrop-filter:blur(16px);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;box-shadow:var(--shadow);margin-bottom:1.5rem}
        .mh{background:linear-gradient(135deg,var(--p),var(--ph));color:#fff;padding:1rem 1.5rem;font-weight:700;font-size:1.1rem;display:flex;justify-content:space-between;align-items:center;cursor:pointer}
        .mh::after{content:'\f282';font-family:'bootstrap-icons';font-size:1.2rem;transition:transform .3s}
        .mh.collapsed::after{transform:rotate(-90deg)}
        .ms{background:#f0f9ff;padding:.8rem 1.2rem;display:flex;justify-content:space-between;align-items:center;font-size:.95rem;border-bottom:1px solid var(--border)}
        .msv{font-size:1.5rem;font-weight:700;color:var(--s)}
        .tr{overflow-x:auto}
        .tbl{font-size:.85rem;min-width:800px}
        .tbl th{background:var(--glass);backdrop-filter:blur(8px);padding:.7rem .8rem;font-size:.75rem;text-transform:uppercase;letter-spacing:.6px}
        .tbl td{padding:.7rem .8rem;vertical-align:middle}
        .tbl tr:hover{background:#f0f9ff1a}
        .b{font-size:.7rem;padding:.3rem .6rem;border-radius:.6rem;font-weight:600}
        .btn-unit{background:#10b981;color:#fff;border:none;padding:.4rem .8rem;border-radius:1rem;font-size:.8rem;font-weight:600;transition:var(--transition)}
        .btn-unit:hover{background:#059669;transform:scale(1.05)}
        .btn-unit:disabled{opacity:.5;cursor:not-allowed}
        .chk{width:1.2rem;height:1.2rem}
        .btn-valider{background:linear-gradient(135deg,var(--s),var(--sh));color:#fff;border:none;padding:.75rem 1.5rem;border-radius:2rem;font-weight:600;font-size:.95rem;box-shadow:0 6px 18px #10b98140;transition:var(--transition);min-width:220px}
        .btn-valider:hover{background:#047857;transform:translateY(-2px)}
        .btn-valider:disabled{opacity:.5;cursor:not-allowed;transform:none}
        .btn-export{background:linear-gradient(135deg,var(--w),#d97706);color:#fff;border:none;padding:.7rem 1.4rem;border-radius:2rem;font-weight:600;font-size:.9rem;box-shadow:0 6px 18px #f59e0b40;transition:var(--transition)}
        .btn-export:hover{background:#c2410c;transform:translateY(-2px)}
        .month-header-check{background:var(--glass);backdrop-filter:blur(8px);padding:.4rem .8rem;border-radius:1rem;font-weight:600;font-size:.85rem;display:flex;align-items:center;gap:.4rem;cursor:pointer;transition:var(--transition)}
        .month-header-check:hover{background:#ffffff30}
        .somme-selection{background:linear-gradient(135deg,var(--s),var(--sh));color:#fff;padding:1rem;border-radius:var(--radius);text-align:center;box-shadow:var(--shadow);margin:1rem 0}
        .somme-selection .sv{font-size:2rem;font-weight:800}
        .badge-attente{background:#6c757d;color:#fff}
        .badge-validation{background:#f59e0b;color:#fff}
        .badge-approuve{background:#10b981;color:#fff}
        .toggle-dark{position:fixed;bottom:1.5rem;right:1.5rem;z-index:100}
        tbody tr{cursor:pointer;transition:background .2s}
        tbody tr:hover{background:#f0f9ff20 !important}
        @media(max-width:768px){
            .c{padding:1rem}
            .t{font-size:1.4rem}
            .l{width:48px;height:48px}
            .fr{grid-template-columns:1fr}
            .kg{grid-template-columns:repeat(2,1fr)}
            .tbl{min-width:600px;font-size:.8rem}
            .mh{flex-direction:column;text-align:center;gap:.5rem}
            .msv{font-size:1.3rem}
            .somme-selection .sv{font-size:1.6rem}
        }
        .alert{border-radius:var(--radius);padding:1rem 1.5rem;box-shadow:var(--shadow);border:none;backdrop-filter:blur(8px);margin-bottom:1rem}
    </style>
</head>
<body>

<!-- HEADER -->
<div class="h">
    <div class="c">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center gap-3">
                <img src="<?= $logo_path ?>" alt="" class="l">
                <div>
                    <div class="t"><i class="bi bi-hospital"></i> <?= htmlspecialchars($nom_prestataire) ?></div>
                    <div class="st">Gestion des remboursements</div>
                </div>
            </div>
            <div class="n"><i class="bi bi-award-fill"></i> <?= htmlspecialchars($nom_niveau) ?></div>
        </div>
    </div>
</div>

<div class="c">

    <!-- ALERTES -->
    <?php if($success): ?>
        <div class="alert alert-success d-flex align-items-center">
            <i class="bi bi-check-circle-fill me-3 fs-5"></i> <?= $success ?>
            <button class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php foreach($errors as $e): ?>
        <div class="alert alert-danger d-flex align-items-center">
            <i class="bi bi-exclamation-triangle-fill me-3 fs-5"></i> <?= htmlspecialchars($e) ?>
            <button class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    <?php endforeach; ?>

    <!-- FILTRES + EXPORT -->
    <div class="f">
        <form method="GET" class="fr" autocomplete="off">
            <select name="statut" class="form-select" onchange="this.form.submit()">
                <option value="all">Tous</option>
                <option value="en_attente" <?= ($_GET['statut']??'')==='en_attente'?'selected':'' ?>>En attente</option>
                <option value="en_validation" <?= ($_GET['statut']??'')==='en_validation'?'selected':'' ?>>À valider</option>
                <option value="approuve" <?= ($_GET['statut']??'')==='approuve'?'selected':'' ?>>Validé</option>
            </select>
            <input type="date" name="date_debut" class="form-control" value="<?= $_GET['date_debut']??'' ?>" onchange="this.form.submit()">
            <input type="date" name="date_fin" class="form-control" value="<?= $_GET['date_fin']??'' ?>" onchange="this.form.submit()">
            <div class="input-group">
                <span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="text" name="search" class="form-control" placeholder="Recherche..." value="<?= htmlspecialchars($_GET['search']??'') ?>">
            </div>
            <button type="submit" class="btn btn-primary"><i class="bi bi-funnel-fill"></i> Filtrer</button>
            <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'csv'])) ?>" class="btn btn-export">
                <i class="bi bi-file-earmark-spreadsheet"></i> CSV
            </a>
        </form>
    </div>

    <!-- KPI -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3"><div class="kc"><div class="kv"><?= $k['total_demandes'] ?></div><div class="kl">Demandes</div></div></div>
        <div class="col-6 col-md-3"><div class="kc"><div class="kv"><?= $k['beneficiaires'] ?></div><div class="kl">Bénéficiaires</div></div></div>
        <div class="col-6 col-md-3"><div class="kc"><div class="kv"><?= formatFCFA($k['total_facture']) ?></div><div class="kl">Facturé</div></div></div>
        <div class="col-6 col-md-3"><div class="kc"><div class="kv"><?= formatFCFA($k['rembourse_confirme']) ?></div><div class="kl">Reçu</div></div></div>
    </div>

    <!-- SOMME SÉLECTION -->
    <div class="somme-selection">
        <div class="sv" id="somme">0 FCFA</div>
        <div class="small">Sélection totale (<span id="count">0</span> demande(s))</div>
    </div>

    <!-- FORMULAIRE MASSE -->
    <form method="POST" id="formValidation" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
        <input type="hidden" name="valider_selection" value="1">

        <?php if (empty($demandes_par_mois)): ?>
            <div class="m"><div class="mh"><i class="bi bi-emoji-smile"></i> Aucune demande</div></div>
        <?php else: foreach ($demandes_par_mois as $mois_key => $data): ?>
            <div class="m">
                <div class="mh collapsed" data-bs-toggle="collapse" data-bs-target="#month<?= $mois_key ?>">
                    <div class="month-header-check">
                        <input type="checkbox" class="chk select-month-header" data-month="<?= $mois_key ?>" id="header-<?= $mois_key ?>">
                        <label for="header-<?= $mois_key ?>" style="cursor:pointer;margin:0">
                            <?= $data['mois_fr'] ?> <span class="badge bg-light text-dark ms-1"><?= $data['total'] ?></span>
                        </label>
                    </div>
                    <div class="d-flex gap-2 flex-wrap">
                        <?php if ($data['en_attente_count'] > 0): ?>
                            <span class="badge badge-attente"><i class="bi bi-clock"></i> <?= $data['en_attente_count'] ?> en attente</span>
                        <?php endif; ?>
                        <?php if ($data['a_valider'] > 0): ?>
                            <span class="text-warning"><strong><?= formatFCFA($data['a_valider']) ?></strong> à valider</span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="collapse" id="month<?= $mois_key ?>">
                    <div class="ms">
                        <div class="month-header-check">
                            <input type="checkbox" class="chk select-month" data-month="<?= $mois_key ?>" id="select-<?= $mois_key ?>">
                            <label for="select-<?= $mois_key ?>" style="cursor:pointer;margin:0">
                                <i class="bi bi-check2-square"></i> Cocher tout
                            </label>
                        </div>
                        <div class="text-success"><strong><?= formatFCFA($data['total_rembourse']) ?></strong></div>
                    </div>
                    <div class="tr">
                        <table class="tbl table-hover mb-0">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>ID</th>
                                    <th>Adhérent</th>
                                    <th>Bénéficiaire</th>
                                    <th>Prestation</th>
                                    <th>Montant</th>
                                    <th>Date</th>
                                    <th>Fichier</th>
                                    <th>Statut</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data['demandes'] as $d): ?>
                                <tr>
                                    <td>
                                        <?php if ($d['statut'] === 'en_validation'): ?>
                                            <input type="checkbox" name="demande[]" value="<?= $d['id_demande'] ?>" 
                                                   class="chk form-check-input chk-<?= $mois_key ?>" 
                                                   data-montant="<?= $d['montant_rembourse'] ?>">
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><strong>#<?= $d['id_demande'] ?></strong></td>
                                    <td><?= htmlspecialchars($d['num_adherent']) ?></td>
                                    <td><?= htmlspecialchars(substr($d['b_nom'].' '.$d['b_prenom'],0,18)) ?></td>
                                    <td><?= htmlspecialchars($d['prestation']) ?></td>
                                    <td class="text-success fw-bold"><?= formatFCFA($d['montant_rembourse']) ?></td>
                                    <td><?= date('d/m', strtotime($d['date_soin'])) ?></td>
                                    <td>
                                        <?php if($d['pieces_jointes'] && file_exists("../".$d['pieces_jointes'])): ?>
                                            <a href="../<?= htmlspecialchars($d['pieces_jointes']) ?>" target="_blank" class="btn btn-outline-info bx"><i class="bi bi-eye"></i></a>
                                        <?php else: ?>—
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="b <?= $d['statut']==='approuve' ? 'badge-approuve' : ($d['statut']==='en_validation' ? 'badge-validation' : 'badge-attente') ?>">
                                            <?= ucfirst(str_replace('_',' ',$d['statut'])) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($d['statut'] === 'en_validation'): ?>
                                            <form method="POST" style="display:inline" onsubmit="return confirm('Valider cette demande ?')">
                                                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                                <input type="hidden" name="valider_unitaire" value="1">
                                                <input type="hidden" name="id_demande" value="<?= $d['id_demande'] ?>">
                                                <button type="submit" class="btn btn-unit">
                                                    <i class="bi bi-check-lg"></i> Valider
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endforeach; endif; ?>

        <div class="text-center my-5">
            <button type="submit" class="btn btn-valider" id="btnValider" disabled>
                <i class="bi bi-check2-all"></i> Valider la sélection (<span id="count">0</span>)
            </button>
        </div>
    </form>
</div>

<button class="btn btn-outline-secondary btn-sm rounded-circle toggle-dark">
    <i class="bi bi-moon-stars-fill"></i>
</button>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const checkboxes = document.querySelectorAll('input[name="demande[]"]');
    const sommeEl = document.getElementById('somme');
    const countEls = document.querySelectorAll('#count');
    const btnValider = document.getElementById('btnValider');

    function updateSelection() {
        let total = 0, count = 0;
        checkboxes.forEach(cb => {
            if (cb.checked) { total += parseFloat(cb.dataset.montant) || 0; count++; }
        });
        sommeEl.textContent = total.toLocaleString('fr-FR') + ' FCFA';
        countEls.forEach(el => el.textContent = count);
        btnValider.disabled = count === 0;
        btnValider.innerHTML = `<i class="bi bi-check2-all"></i> Valider la sélection (${count})`;
    }

    checkboxes.forEach(cb => cb.addEventListener('change', function () {
        const monthClass = this.classList[2]; // 'chk-YYYY-MM'
        const month = monthClass ? monthClass.replace('chk-', '') : null;
        if (!month) return;
        const monthCheckboxes = document.querySelectorAll(`.chk-${month}`);
        const allChecked = [...monthCheckboxes].every(c => c.checked);
        const anyChecked = [...monthCheckboxes].some(c => c.checked);
        const header = document.getElementById(`header-${month}`);
        const inner = document.getElementById(`select-${month}`);
        if (header) { header.checked = allChecked; header.indeterminate = !allChecked && anyChecked; }
        if (inner) { inner.checked = allChecked; inner.indeterminate = !allChecked && anyChecked; }
        updateSelection();
    }));

    document.querySelectorAll('.select-month-header').forEach(header => {
        header.addEventListener('change', function () {
            const month = this.dataset.month;
            document.querySelectorAll(`.chk-${month}`).forEach(cb => cb.checked = this.checked);
            document.getElementById(`select-${month}`)?.dispatchEvent(new Event('change'));
            updateSelection();
        });
    });

    document.querySelectorAll('.select-month').forEach(inner => {
        inner.addEventListener('change', function () {
            const month = this.dataset.month;
            document.querySelectorAll(`.chk-${month}`).forEach(cb => cb.checked = this.checked);
            document.getElementById(`header-${month}`)?.dispatchEvent(new Event('change'));
            updateSelection();
        });
    });

    document.querySelectorAll('tbody tr').forEach(row => {
        row.addEventListener('click', function (e) {
            const checkbox = this.querySelector('input[name="demande[]"]');
            if (!checkbox || ['A','BUTTON','INPUT'].includes(e.target.tagName)) return;
            checkbox.checked = !checkbox.checked;
            checkbox.dispatchEvent(new Event('change'));
        });
    });

    // Dark mode toggle
    document.querySelector('.toggle-dark').addEventListener('click', () => {
        const html = document.documentElement;
        const currentTheme = html.getAttribute('data-bs-theme');
        html.setAttribute('data-bs-theme', currentTheme === 'dark' ? 'light' : 'dark');
    });

    updateSelection();
</script>
</body>
</html>

<?php ob_end_flush(); require_once '../includes/footer.php'; ?>