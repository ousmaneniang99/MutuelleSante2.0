<?php
// pages/get_paiement_info.php
require_once '../includes/header.php';
checkRole('agent_mobilisateur');

header('Content-Type: application/json');

if (!isset($_GET['id_adhesion'])) {
    echo json_encode(['error' => 'ID d\'adhésion requis']);
    exit;
}

$id_adhesion = intval($_GET['id_adhesion']);

// Fetch adhesion details
$stmt = $pdo->prepare("
    SELECT a.type_adhesion, 
           (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion) as beneficiaire_count,
           (SELECT SUM(montant_verse) FROM paiements p WHERE p.id_adhesion = a.id_adhesion AND p.statut = 'paye') as total_paye
    FROM adhesions a 
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
    WHERE a.id_adhesion = ? AND a.created_by = ? AND u.departement = ?
");
$stmt->execute([$id_adhesion, $_SESSION['user_id'], $_SESSION['departement']]);
$adhesion = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$adhesion) {
    echo json_encode(['error' => 'Adhésion non trouvée ou accès non autorisé']);
    exit;
}

echo json_encode([
    'type_adhesion' => $adhesion['type_adhesion'],
    'beneficiaire_count' => $adhesion['beneficiaire_count'],
    'total_paye' => $adhesion['total_paye'] ?: 0
]);
?>