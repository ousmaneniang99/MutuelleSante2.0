<?php
// pages/historique_adherent.php
require_once '../includes/header.php';
checkRole('prestataire_soins');

$id_adhesion = intval($_GET['id_adhesion'] ?? 0);
if ($id_adhesion <= 0) {
    header('Location: gestion_remboursements.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT a.num_adherent, b.nom, b.prenom, b.code_beneficiaire
    FROM adhesions a
    JOIN beneficiaires b ON a.id_adhesion = b.id_adhesion
    WHERE a.id_adhesion = ?
");
$stmt->execute([$id_adhesion]);
$adherent = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$adherent) {
    header('Location: gestion_remboursements.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT dr.*, p.nom AS prestation_nom, dr.statut, dr.date_soin, dr.montant_facture, dr.montant_rembourse
    FROM demandes_remboursement dr
    JOIN prestations p ON dr.id_prestation = p.id_prestation
    WHERE dr.id_adhesion = ? AND dr.id_prestataire = ?
    ORDER BY dr.date_soin DESC
");
$stmt->execute([$id_adhesion, $_SESSION['user_id']]);
$historique = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Historique - <?= htmlspecialchars($adherent['num_adherent']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5><i class="bi bi-person-lines-fill"></i> Historique de l'adhérent</h5>
        </div>
        <div class="card-body">
            <p><strong>Adhérent :</strong> <?= htmlspecialchars($adherent['num_adherent']) ?></p>
            <p><strong>Bénéficiaire :</strong> <?= htmlspecialchars("{$adherent['nom']} {$adherent['prenom']}") ?> (Code: <?= htmlspecialchars($adherent['code_beneficiaire']) ?>)</p>
            <hr>
            <h6>Demandes de remboursement (<?= count($historique) ?>)</h6>
            <?php if (empty($historique)): ?>
                <p class="text-muted">Aucune demande.</p>
            <?php else: ?>
                <ul class="list-group">
                    <?php foreach ($historique as $h): ?>
                        <li class="list-group-item">
                            <strong><?= date('d/m/Y', strtotime($h['date_soin'])) ?></strong> — <?= htmlspecialchars($h['prestation_nom']) ?>
                            <br><small>Facturé: <?= formatFCFA($h['montant_facture']) ?> | Remboursé: <?= formatFCFA($h['montant_rembourse']) ?> | Statut: <?= $h['statut'] ?></small>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            <a href="gestion_remboursements.php" class="btn btn-secondary mt-3"><i class="bi bi-arrow-left"></i> Retour</a>
        </div>
    </div>
</div>
</body>
</html>