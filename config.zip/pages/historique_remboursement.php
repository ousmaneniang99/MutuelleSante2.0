<?php
// pages/historique_remboursement.php
ob_start();
require_once '../includes/header.php';
checkRole('prestataire_soins');

$errors = [];
$csrf_token = generateCsrfToken();

// === INFOS PRESTATAIRE ===
$stmt = $pdo->prepare("SELECT p.id_prestataire, p.nom AS nom_prestataire, p.logo FROM prestataires p WHERE p.id_utilisateur = ?");
$stmt->execute([$_SESSION['user_id']]);
$prestataire = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$prestataire) { header('Location: logout.php'); exit; }

$nom_prestataire = $prestataire['nom_prestataire'];
$logo_path = !empty($prestataire['logo']) && file_exists("../" . $prestataire['logo']) ? "../" . $prestataire['logo'] : "../assets/images/logo-default.png";
$id_prestataire = $prestataire['id_prestataire'];

// === FILTRES & PAGINATION ===
$statut_filter = $_GET['statut'] ?? 'all';
$date_debut = $_GET['date_debut'] ?? '';
$date_fin = $_GET['date_fin'] ?? '';
$beneficiaire_filter = $_GET['beneficiaire'] ?? '';
$search = trim($_GET['search'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

// === BÉNÉFICIAIRES ===
$beneficiaires = [];
$stmt = $pdo->prepare("
    SELECT DISTINCT b.id_beneficiaire, b.nom, b.prenom, b.code_beneficiaire 
    FROM beneficiaires b 
    JOIN demandes_remboursement dr ON b.id_beneficiaire = dr.id_beneficiaire 
    WHERE dr.id_prestataire = ? 
    ORDER BY b.nom
");
$stmt->execute([$id_prestataire]);
$beneficiaires = $stmt->fetchAll(PDO::FETCH_ASSOC);

// === FONCTIONS WHERE & PARAMS (NOMMÉ) ===
function buildWhereAndParams($id_prestataire, $statut, $debut, $fin, $benef, $search, $for_count = false) {
    $where = " WHERE dr.id_prestataire = :id_prestataire";
    $params = [':id_prestataire' => $id_prestataire];

    if ($statut !== 'all') {
        $where .= " AND dr.statut = :statut";
        $params[':statut'] = $statut;
    }
    if ($debut) {
        $where .= " AND dr.date_soin >= :date_debut";
        $params[':date_debut'] = $debut;
    }
    if ($fin) {
        $where .= " AND dr.date_soin <= :date_fin";
        $params[':date_fin'] = $fin . ' 23:59:59';
    }
    if ($benef) {
        $where .= " AND dr.id_beneficiaire = :beneficiaire";
        $params[':beneficiaire'] = $benef;
    }
    if ($search && !$for_count) {
        $like = "%" . strtolower($search) . "%";
        $where .= " AND (LOWER(a.num_adherent) LIKE :search1 OR LOWER(b.code_beneficiaire) LIKE :search2 OR LOWER(b.nom) LIKE :search3 OR LOWER(b.prenom) LIKE :search4 OR LOWER(p.nom) LIKE :search5)";
        $params[':search1'] = $like;
        $params[':search2'] = $like;
        $params[':search3'] = $like;
        $params[':search4'] = $like;
        $params[':search5'] = $like;
    }

    return ['where' => $where, 'params' => $params];
}

// === TOTAL POUR PAGINATION ===
$wp = buildWhereAndParams($id_prestataire, $statut_filter, $date_debut, $date_fin, $beneficiaire_filter, $search, true);
$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM demandes_remboursement dr" . $wp['where']);
$total_stmt->execute($wp['params']);
$total = $total_stmt->fetchColumn();
$pages = ceil($total / $limit);

// === REQUÊTE PRINCIPALE (SANS validé par) ===
$wp = buildWhereAndParams($id_prestataire, $statut_filter, $date_debut, $date_fin, $beneficiaire_filter, $search);
$query = "
    SELECT dr.id_demande, dr.date_soin, dr.montant_facture, dr.montant_rembourse, dr.montant_a_payer, dr.pieces_jointes, dr.statut,
           b.code_beneficiaire, b.nom AS nom_b, b.prenom AS prenom_b,
           p.nom AS prestation, a.num_adherent,
           hr.commentaire
    FROM demandes_remboursement dr
    JOIN beneficiaires b ON dr.id_beneficiaire = b.id_beneficiaire
    JOIN prestations p ON dr.id_prestation = p.id_prestation
    JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
    LEFT JOIN historique_remboursements hr ON dr.id_demande = hr.id_demande AND hr.date_action = (
        SELECT MAX(h2.date_action) FROM historique_remboursements h2 WHERE h2.id_demande = dr.id_demande
    )
" . $wp['where'] . "
    ORDER BY dr.date_soin DESC
    LIMIT :limit OFFSET :offset
";

$stmt = $pdo->prepare($query);
foreach ($wp['params'] as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$historique = $stmt->fetchAll(PDO::FETCH_ASSOC);

// === CONFIRMER PAIEMENT REÇU (approuve) ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_payment']) && verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    $id_demande = (int)($_POST['id_demande'] ?? 0);
    if ($id_demande > 0) {
        $stmt = $pdo->prepare("UPDATE demandes_remboursement SET statut = 'approuve', validated_by = ?, date_mise_a_jour = NOW() WHERE id_demande = ? AND id_prestataire = ? AND statut = 'en_validation'");
        if ($stmt->execute([$_SESSION['user_id'], $id_demande, $id_prestataire]) && $stmt->rowCount()) {
            logActivity($pdo, $_SESSION['user_id'], "Paiement reçu pour demande #$id_demande");
            header("Location: historique_remboursement.php?success=1&page=$page"); exit;
        }
    }
    $errors[] = "Échec confirmation.";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historique - <?= htmlspecialchars($nom_prestataire) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <style>
        :root {
            --primary: #10b981; --success: #22c55e; --warning: #f59e0b; --danger: #ef4444; --info: #0ea5e9;
            --dark: #111827; --light: #f8fafc; --border: #e2e8f0; --radius: 1rem; --shadow: 0 4px 12px rgba(0,0,0,0.08);
            --transition: all 0.25s ease;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #f8fafc; font-family: 'Inter', sans-serif; color: var(--dark); min-height: 100vh; }

        .header { background: linear-gradient(135deg, var(--primary), #059669); color: white; padding: 1.5rem 0; box-shadow: 0 6px 16px rgba(16,185,129,0.12); }
        .logo { width: 52px; height: 52px; object-fit: contain; border-radius: 1rem; border: 3px solid rgba(255,255,255,0.3); }
        .title { font-weight: 700; font-size: 1.4rem; }
        .subtitle { font-size: 0.9rem; opacity: 0.95; }

        .container { max-width: 1350px; padding: 1.5rem 1rem; }

        .filter-card { background: white; border-radius: var(--radius); padding: 1rem; box-shadow: var(--shadow); margin-bottom: 1.5rem; }
        .filter-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 0.75rem; align-items: end; }

        .tbl-card { background: white; border-radius: var(--radius); overflow: hidden; box-shadow: var(--shadow); }
        .tbl-card .hdr { background: var(--primary); color: white; padding: 0.75rem 1.25rem; font-weight: 600; font-size: 1rem; display: flex; justify-content: space-between; align-items: center; }
        .tbl { margin: 0; font-size: 0.82rem; }
        .tbl th { background: #f0fdf4; color: #065f46; padding: 0.6rem 0.8rem; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.5px; }
        .tbl td { padding: 0.6rem 0.8rem; vertical-align: middle; }
        .tbl tr:hover { background: #f8fff9; }
        .badge { font-size: 0.68rem; padding: 0.18rem 0.45rem; border-radius: 0.45rem; font-weight: 600; }
        .badge-en_attente { background: #fffbeb; color: #92400e; }
        .badge-en_validation { background: #dbeafe; color: #1e40af; }
        .badge-approuve { background: #d1fae5; color: #065f46; }
        .badge-rejete { background: #fee2e2; color: #991b1b; }
        .badge-code { background: #e0f2fe; color: #0369a1; font-family: monospace; padding: 0.12rem 0.38rem; border-radius: 0.38rem; font-size: 0.72rem; }
        .btn-xs { padding: 0.18rem 0.38rem; font-size: 0.72rem; }
        .comment { max-width: 180px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 0.75rem; color: #64748b; }

        @media (max-width: 768px) {
            .title { font-size: 1.2rem; }
            .filter-row { grid-template-columns: 1fr; }
            .tbl { font-size: 0.7rem; }
            .tbl th, .tbl td { padding: 0.35rem; }
            .comment { max-width: 100px; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <div class="container">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center gap-3">
                <img src="<?= $logo_path ?>" alt="Logo" class="logo" data-aos="zoom-in">
                <div>
                    <h1 class="title" data-aos="fade-up" data-aos-delay="100">Historique Remboursements</h1>
                    <div class="subtitle" data-aos="fade-up" data-aos-delay="150"><?= htmlspecialchars($nom_prestataire) ?></div>
                </div>
            </div>
            <a href="dashboard_prestataire.php" class="btn btn-outline-light rounded-pill" data-aos="fade-left">
                <i class="bi bi-arrow-left"></i> Retour
            </a>
        </div>
    </div>
</div>

<div class="container">

    <!-- ALERTES EINZELN -->
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success d-flex align-items-center shadow-sm" data-aos="fade-up">
            <i class="bi bi-check-circle-fill me-2"></i> Paiement confirmé !
            <button class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php foreach ($errors as $e): ?>
        <div class="alert alert-danger d-flex align-items-center" data-aos="fade-up">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($e) ?>
            <button class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    <?php endforeach; ?>

    <!-- FILTRES -->
    <div class="filter-card" data-aos="fade-up" data-aos-delay="200">
        <form method="GET" class="filter-row">
            <select name="statut" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="all">Tous</option>
                <option value="en_attente" <?= $statut_filter === 'en_attente' ? 'selected' : '' ?>>En attente</option>
                <option value="en_validation" <?= $statut_filter === 'en_validation' ? 'selected' : '' ?>>À confirmer</option>
                <option value="approuve" <?= $statut_filter === 'approuve' ? 'selected' : '' ?>>Approuvé</option>
                <option value="rejete" <?= $statut_filter === 'rejete' ? 'selected' : '' ?>>Rejeté</option>
            </select>
            <select name="beneficiaire" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">Tous</option>
                <?php foreach ($beneficiaires as $b): ?>
                    <option value="<?= $b['id_beneficiaire'] ?>" <?= $beneficiaire_filter == $b['id_beneficiaire'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($b['nom'].' '.$b['prenom']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="date" name="date_debut" class="form-control form-control-sm" value="<?= $date_debut ?>" onchange="this.form.submit()">
            <input type="date" name="date_fin" class="form-control form-control-sm" value="<?= $date_fin ?>" onchange="this.form.submit()">
            <div class="input-group input-group-sm">
                <span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="text" name="search" class="form-control" placeholder="Recherche..." value="<?= htmlspecialchars($search) ?>">
            </div>
            <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-funnel"></i></button>
        </form>
    </div>

    <!-- TABLEAU COMPLET -->
    <div class="tbl-card" data-aos="fade-up" data-aos-delay="300">
        <div class="hdr">
            <span><i class="bi bi-table me-1"></i> Historique (<?= $total ?> entrées)</span>
            <a href="list_adherents_beneficiaires.php" class="btn btn-success btn-xs"><i class="bi bi-plus-circle"></i> Nouvelle</a>
        </div>
        <div class="table-responsive">
            <table class="tbl table-hover mb-0">
                <thead>
                    <tr>
                        <th>Adhérent</th>
                        <th>Code</th>
                        <th>Bénéficiaire</th>
                        <th>Prestation</th>
                        <th>Date soin</th>
                        <th>Montant facturé</th>
                        <th>Montant remboursé</th>
                        <th>Montant à payer</th>
                        <th>Fichier</th>
                        <th>Statut</th>
                        <th>Dernier commentaire</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($historique)): ?>
                        <tr><td colspan="12" class="text-center py-4 text-muted">Aucun résultat</td></tr>
                    <?php else: foreach ($historique as $h): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($h['num_adherent']) ?></strong></td>
                            <td><code class="badge-code"><?= htmlspecialchars($h['code_beneficiaire']) ?></code></td>
                            <td><?= htmlspecialchars(substr($h['nom_b'].' '.$h['prenom_b'], 0, 16)) ?></td>
                            <td><?= htmlspecialchars(substr($h['prestation'], 0, 18)) ?></td>
                            <td><?= date('d/m/Y', strtotime($h['date_soin'])) ?></td>
                            <td><?= formatFCFA($h['montant_facture']) ?></td>
                            <td class="text-success fw-bold"><?= formatFCFA($h['montant_rembourse']) ?></td>
                            <td class="text-warning"><?= formatFCFA($h['montant_a_payer']) ?></td>
                            <td>
                                <?php if ($h['pieces_jointes'] && file_exists("../".$h['pieces_jointes'])): ?>
                                    <a href="../<?= htmlspecialchars($h['pieces_jointes']) ?>" target="_blank" class="btn btn-outline-info btn-xs" title="Voir le fichier">
                                        <i class="bi bi-file-earmark-text"></i>
                                    </a>
                                <?php else: ?>—
                                <?php endif; ?>
                            </td>
                            <td><span class="badge badge-<?= $h['statut'] ?>"><?= ucfirst(str_replace('_', ' ', $h['statut'])) ?></span></td>
                            <td class="comment" title="<?= htmlspecialchars($h['commentaire'] ?? '') ?>">
                                <?= htmlspecialchars(substr($h['commentaire'] ?? '', 0, 30)) ?: '—' ?>
                            </td>
                            <td>
                                <?php if ($h['statut'] === 'en_validation'): ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                        <input type="hidden" name="id_demande" value="<?= $h['id_demande'] ?>">
                                        <input type="hidden" name="confirm_payment" value="1">
                                        <button type="submit" class="btn btn-success btn-xs" title="Confirmer le paiement reçu">
                                            <i class="bi bi-cash-coin"></i>
                                        </button>
                                    </form>
                                <?php else: ?>—
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>

        <!-- PAGINATION -->
        <?php if ($pages > 1): ?>
        <nav class="p-3">
            <ul class="pagination justify-content-center mb-0">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $page-1 ?>&<?= http_build_query(array_diff_key($_GET, ['page'=>1])) ?>">Précédent</a>
                </li>
                <?php for ($i = max(1, $page-2); $i <= min($pages, $page+2); $i++): ?>
                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query(array_diff_key($_GET, ['page'=>1])) ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $page >= $pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $page+1 ?>&<?= http_build_query(array_diff_key($_GET, ['page'=>1])) ?>">Suivant</a>
                </li>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
    AOS.init({ duration: 500, once: true });
</script>
</body>
</html>

<?php 
ob_end_flush();
require_once '../includes/footer.php'; 
?>