<?php
// pages/list_adherents.php
require_once '../includes/header.php';
checkRole('directeur_departemental');

$errors = [];
$adhesions = [];
$kpi = [
    'total_adhesions' => 0,
    'adhesions_actives' => 0,
    'total_cotisations' => 0
];
$agents = [];
$filters = [
    'statut' => $_GET['statut'] ?? '',
    'type_adhesion' => $_GET['type_adhesion'] ?? '',
    'agent_id' => $_GET['agent_id'] ?? '',
    'search' => $_GET['search'] ?? ''
];

// Fetch agents for filter dropdown
try {
    $stmt = $pdo->prepare("
        SELECT id_utilisateur, nom, prenom
        FROM utilisateurs
        WHERE role = 'agent_mobilisateur' AND departement = ?
        ORDER BY nom, prenom
    ");
    $stmt->execute([$_SESSION['departement']]);
    $agents = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des agents : " . htmlspecialchars($e->getMessage());
    error_log("Erreur dans list_adherents.php : " . $e->getMessage());
}

// Build adhesion query with filters
try {
    $query = "
        SELECT a.id_adhesion, a.num_adherent, a.statut, a.type_adhesion, a.date_adhesion,
               u.nom AS adherent_nom, u.prenom AS adherent_prenom,
               agent.nom AS agent_nom, agent.prenom AS agent_prenom,
               (SELECT SUM(montant_verse) FROM paiements p WHERE p.id_adhesion = a.id_adhesion AND p.statut = 'paye') AS total_paye
        FROM adhesions a
        JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
        JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
        WHERE agent.departement = ? AND agent.role = 'agent_mobilisateur'
    ";
    $params = [$_SESSION['departement']];

    // Apply filters
    if (!empty($filters['statut'])) {
        $query .= " AND a.statut = ?";
        $params[] = $filters['statut'];
    }
    if (!empty($filters['type_adhesion'])) {
        $query .= " AND a.type_adhesion = ?";
        $params[] = $filters['type_adhesion'];
    }
    if (!empty($filters['agent_id'])) {
        $query .= " AND a.created_by = ?";
        $params[] = $filters['agent_id'];
    }
    if (!empty($filters['search'])) {
        $query .= " AND (u.nom LIKE ? OR u.prenom LIKE ? OR a.num_adherent LIKE ?)";
        $search = '%' . $filters['search'] . '%';
        $params[] = $search;
        $params[] = $search;
        $params[] = $search;
    }

    $query .= " ORDER BY a.date_adhesion DESC";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $adhesions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate KPIs
    $kpi['total_adhesions'] = count($adhesions);
    $kpi['adhesions_actives'] = count(array_filter($adhesions, fn($a) => $a['statut'] === 'active'));
    $kpi['total_cotisations'] = array_sum(array_column($adhesions, 'total_paye') ?: [0]);
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des adhésions : " . htmlspecialchars($e->getMessage());
    error_log("Erreur dans list_adherents.php : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Adhérents - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }
        .container {
            max-width: 1200px;
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .card-header {
            border-bottom: none;
            padding: 1.5rem;
            font-size: 1.25rem;
            font-weight: 600;
            background: linear-gradient(90deg, #007bff, #0056b3);
            color: white;
        }
        .card-body {
            padding: 2rem;
        }
        .alert {
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert i {
            font-size: 1.2rem;
        }
        .form-control, .form-select {
            border-radius: 8px;
            padding: 0.75rem;
            border: 1px solid #ced4da;
            transition: border-color 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
        }
        .btn-primary {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-secondary, .btn-success, .btn-warning {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .btn-success:hover {
            background-color: #2e7d32;
        }
        .btn-warning:hover {
            background-color: #e0a800;
        }
        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 2rem;
        }
        .table {
            border-radius: 8px;
            overflow: hidden;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .table-hover tbody tr:hover {
            background-color: #f1f3f5;
        }
        .kpi-card .card-body {
            padding: 1.5rem;
            text-align: center;
        }
        .kpi-card .card-title {
            font-size: 1rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        .kpi-card .card-text {
            font-size: 1.5rem;
            font-weight: 600;
        }
        .search-container {
            position: relative;
        }
        .search-container i {
            position: absolute;
            top: 50%;
            left: 10px;
            transform: translateY(-50%);
            color: #6c757d;
        }
        .search-container input {
            padding-left: 35px;
        }
        .filter-container {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            align-items: center;
        }
        .filter-container .form-select, .filter-container .form-control {
            min-width: 200px;
        }
        .status-badge {
            padding: 0.25rem 0.5rem;
            border-radius: 5px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        .status-active { background-color: #d4edda; color: #155724; }
        .status-pending { background-color: #fff3cd; color: #856404; }
        .status-rejected { background-color: #f8d7da; color: #721c24; }
        @media (max-width: 576px) {
            .filter-container .form-select, .filter-container .form-control {
                min-width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-people me-2"></i>Liste des Adhérents</h2>

        <!-- Messages -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- KPI Cards -->
        <div class="row mb-4">
            <div class="col-md-4 mb-3">
                <div class="card kpi-card text-white bg-primary">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-card-list"></i>Total Adhésions</h5>
                        <p class="card-text"><?php echo htmlspecialchars($kpi['total_adhesions']); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card kpi-card text-white bg-success">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-check-circle"></i>Adhésions Actives</h5>
                        <p class="card-text"><?php echo htmlspecialchars($kpi['adhesions_actives']); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card kpi-card text-white bg-warning">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-currency-exchange"></i>Total Cotisations</h5>
                        <p class="card-text"><?php echo htmlspecialchars(formatFCFA($kpi['total_cotisations'])); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-header">
                <i class="bi bi-funnel me-2"></i>Filtres
            </div>
            <div class="card-body">
                <form method="GET" class="filter-container">
                    <div class="search-container">
                        <i class="bi bi-search"></i>
                        <input type="text" class="form-control" name="search" placeholder="Rechercher par nom ou numéro..." value="<?php echo htmlspecialchars($filters['search']); ?>">
                    </div>
                    <select class="form-select" name="statut">
                        <option value="">Tous les statuts</option>
                        <option value="active" <?php echo $filters['statut'] === 'active' ? 'selected' : ''; ?>>Actif</option>
                        <option value="en_attente_validation" <?php echo $filters['statut'] === 'en_attente_validation' ? 'selected' : ''; ?>>En attente</option>
                        <option value="rejete" <?php echo $filters['statut'] === 'rejete' ? 'selected' : ''; ?>>Rejeté</option>
                    </select>
                    <select class="form-select" name="type_adhesion">
                        <option value="">Tous les types</option>
                        <option value="Individuelle" <?php echo $filters['type_adhesion'] === 'Individuelle' ? 'selected' : ''; ?>>Individuelle</option>
                        <option value="Familiale" <?php echo $filters['type_adhesion'] === 'Familiale' ? 'selected' : ''; ?>>Familiale</option>
                    </select>
                    <select class="form-select" name="agent_id">
                        <option value="">Tous les agents</option>
                        <?php foreach ($agents as $agent): ?>
                            <option value="<?php echo htmlspecialchars($agent['id_utilisateur']); ?>" <?php echo $filters['agent_id'] === $agent['id_utilisateur'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($agent['nom'] . ' ' . $agent['prenom']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-funnel-fill me-2"></i>Filtrer</button>
                    <a href="list_adherents.php" class="btn btn-secondary"><i class="bi bi-x-circle me-2"></i>Réinitialiser</a>
                </form>
            </div>
        </div>

        <!-- Adhesions Table -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-card-list me-2"></i>Adhésions
                <span class="badge bg-primary ms-2"><?php echo count($adhesions); ?> trouvée(s)</span>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-adhesions">
                        <thead>
                            <tr>
                                <th><i class="bi bi-person-vcard me-2"></i>Numéro</th>
                                <th><i class="bi bi-person me-2"></i>Adhérent</th>
                                <th><i class="bi bi-card-list me-2"></i>Type</th>
                                <th><i class="bi bi-toggle-on me-2"></i>Statut</th>
                                <th><i class="bi bi-calendar me-2"></i>Date Adhésion</th>
                                <th><i class="bi bi-currency-exchange me-2"></i>Total Cotisations</th>
                                <th><i class="bi bi-person-plus me-2"></i>Agent</th>
                                <th><i class="bi bi-eye me-2"></i>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($adhesions)): ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4">
                                        <i class="bi bi-inbox fs-1 mb-3 text-muted"></i>
                                        <p class="text-muted">Aucune adhésion trouvée avec les filtres appliqués.</p>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($adhesions as $adhesion): ?>
                                    <?php 
                                    $statut = $adhesion['statut'];
                                    $statut_display = $statut === 'en_attente_validation' ? 'En attente' : 
                                                    ($statut === 'active' ? 'Actif' : 'Rejeté');
                                    $statut_class = $statut === 'active' ? 'status-active' : 
                                                  ($statut === 'en_attente_validation' ? 'status-pending' : 'status-rejected');
                                    ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'Non spécifié'); ?></strong></td>
                                        <td><?php echo htmlspecialchars(($adhesion['adherent_nom'] ?? 'Non spécifié') . ' ' . ($adhesion['adherent_prenom'] ?? '')); ?></td>
                                        <td><?php echo htmlspecialchars($adhesion['type_adhesion'] ?? 'Non spécifié'); ?></td>
                                        <td>
                                            <span class="status-badge <?php echo $statut_class; ?>">
                                                <?php echo $statut_display; ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('d/m/Y', strtotime($adhesion['date_adhesion'] ?? 'now')); ?></td>
                                        <td><strong><?php echo htmlspecialchars(formatFCFA($adhesion['total_paye'] ?: 0)); ?></strong></td>
                                        <td><?php echo htmlspecialchars(($adhesion['agent_nom'] ?? 'Non spécifié') . ' ' . ($adhesion['agent_prenom'] ?? '')); ?></td>
                                        <td>
                                            <a href="view_adhesion.php?id=<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" 
                                               class="btn btn-sm btn-primary" 
                                               title="Voir les détails">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Client-side search enhancement
        document.querySelector('input[name="search"]').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-adhesions tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>