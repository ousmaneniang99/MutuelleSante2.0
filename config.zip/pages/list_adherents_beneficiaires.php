<?php
// pages/list_adherents_beneficiaires.php
ob_start();
require_once '../includes/header.php';
checkRole('prestataire_soins');

$errors = [];
$results = [];
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 15;
$offset = ($page - 1) * $perPage;
$search = trim($_GET['search'] ?? '');
$csrf_token = generateCsrfToken();

// === INFOS PRESTATAIRE ===
$niveau = 'Standard';
$id_prestataire = null;
$logo_path = '../assets/images/logo-default.png';

try {
    $stmt = $pdo->prepare("
        SELECT p.id_prestataire, p.nom AS nom_prestataire, p.logo, n.niveau 
        FROM prestataires p 
        JOIN niveau n ON p.id_niveau = n.id_niveau 
        WHERE p.id_utilisateur = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $prest = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($prest) {
        $id_prestataire = $prest['id_prestataire'];
        $niveau = $prest['niveau'];
        $logo_path = !empty($prest['logo']) && file_exists("../" . $prest['logo'])
            ? "../" . $prest['logo']
            : $logo_path;
    }
} catch (Exception $e) {
    $errors[] = "Erreur récupération profil.";
}

if (!$id_prestataire) {
    $errors[] = "Profil prestataire incomplet.";
}

try {
    $where = [
        "LOWER(b.statut) = 'actif'",
        "(b.date_sortie IS NULL OR b.date_sortie > NOW())"
    ];
    $params = [];

    if ($niveau === 'Hôpital') {
        $where[] = "
            EXISTS (
                SELECT 1 FROM notes_referencement nr 
                WHERE nr.id_beneficiaire = b.id_beneficiaire 
                  AND nr.id_prestataire_destinataire = ? 
                  AND nr.statut = 'approuve' 
                  AND nr.consulte = 0
            )
        ";
        $params[] = $id_prestataire;
    }

    if ($search) {
        $like = "%" . strtolower($search) . "%";
        $where[] = "(LOWER(a.num_adherent) LIKE ? OR LOWER(u.nom) LIKE ? OR LOWER(u.prenom) LIKE ? OR LOWER(b.nom) LIKE ? OR LOWER(b.prenom) LIKE ? OR LOWER(b.code_beneficiaire) LIKE ?)";
        $params = array_merge($params, [$like, $like, $like, $like, $like, $like]);
    }

    $where_clause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

    // === COMPTE TOTAL ===
    $countSql = "
        SELECT COUNT(DISTINCT b.id_beneficiaire)
        FROM adhesions a
        JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
        JOIN beneficiaires b ON a.id_adhesion = b.id_adhesion
        " . ($niveau === 'Hôpital' ? "
        JOIN notes_referencement nr ON nr.id_beneficiaire = b.id_beneficiaire 
            AND nr.id_prestataire_destinataire = ? 
            AND nr.statut = 'approuve' 
            AND nr.consulte = 0
        " : "") . "
        $where_clause
    ";
    $countStmt = $pdo->prepare($countSql);
    $countParams = $params;
    if ($niveau === 'Hôpital') {
        array_unshift($countParams, $id_prestataire);
    }
    $countStmt->execute($countParams);
    $totalBeneficiaires = $countStmt->fetchColumn();
    $totalPages = max(1, ceil($totalBeneficiaires / $perPage));

    // === DONNÉES PAGINÉES ===
    $query = "
        SELECT DISTINCT
            a.id_adhesion, a.num_adherent, 
            u.nom AS adherent_nom, u.prenom AS adherent_prenom,
            COALESCE(d.nom, 'Non spécifié') AS departement,
            b.id_beneficiaire, b.code_beneficiaire, b.nom AS beneficiaire_nom, b.prenom AS beneficiaire_prenom,
            b.date_entree, b.date_sortie, b.statut,
            CASE 
                WHEN b.date_entree <= DATE_SUB(NOW(), INTERVAL 1 MONTH) 
                THEN 1 ELSE 0 
            END AS is_eligible"
        . ($niveau === 'Hôpital' ? ", nr.id_referencement" : ", NULL AS id_referencement") . "
        FROM adhesions a
        JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
        LEFT JOIN departements d ON a.departement = d.id_departement
        JOIN beneficiaires b ON a.id_adhesion = b.id_adhesion
        " . ($niveau === 'Hôpital' ? "
        JOIN notes_referencement nr ON nr.id_beneficiaire = b.id_beneficiaire 
            AND nr.id_prestataire_destinataire = ? 
            AND nr.statut = 'approuve' 
            AND nr.consulte = 0
        " : "") . "
        $where_clause
        ORDER BY is_eligible DESC, b.date_entree DESC, a.num_adherent, b.nom
        LIMIT ? OFFSET ?
    ";

    $stmt = $pdo->prepare($query);
    $paramIndex = 1;
    if ($niveau === 'Hôpital') {
        $stmt->bindValue($paramIndex++, $id_prestataire);
    }
    foreach ($params as $param) {
        $stmt->bindValue($paramIndex++, $param);
    }
    $stmt->bindValue($paramIndex++, $perPage, PDO::PARAM_INT);
    $stmt->bindValue($paramIndex++, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // === EXPORT CSV ===
    if (isset($_GET['export']) && $_GET['export'] === 'csv' && verifyCsrfToken($_GET['token'] ?? '')) {
        ob_end_clean();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="beneficiaires_region_' . ($niveau === 'Hôpital' ? 'hopital_' : '') . date('Ymd_His') . '.csv"');
        $output = fopen('php://output', 'w');
        fwrite($output, "\xEF\xBB\xBF");

        $csvHeader = ['Adhésion', 'Adhérent', 'Département', 'Code Bénéf.', 'Nom', 'Prénom', 'Date Entrée', 'Éligibilité'];
        if ($niveau === 'Hôpital') $csvHeader[] = 'Réf. #';
        fputcsv($output, $csvHeader);

        foreach ($results as $row) {
            $adherent = $row['adherent_nom'] . ' ' . $row['adherent_prenom'];
            $eligibilite = $row['is_eligible'] ? 'Éligible' : 'En observation';
            $csvLine = [
                $row['num_adherent'],
                $adherent,
                $row['departement'],
                $row['code_beneficiaire'],
                $row['beneficiaire_nom'],
                $row['beneficiaire_prenom'],
                date('d/m/Y', strtotime($row['date_entree'])),
                $eligibilite
            ];
            if ($niveau === 'Hôpital') {
                $csvLine[] = $row['id_referencement'] ?? '—';
            }
            fputcsv($output, $csvLine);
        }
        exit;
    }
} catch (Exception $e) {
    $errors[] = "Erreur : " . htmlspecialchars($e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $niveau === 'Hôpital' ? 'Bénéficiaires Référencés' : 'Bénéficiaires Région' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <style>
        :root {
            --primary: #10b981;
            --primary-light: #34d399;
            --success: #059669;
            --warning: #f59e0b;
            --danger: #ef4444;
            --dark: #0f172a;
            --light: #f8fafc;
            --gray: #64748b;
            --border: rgba(0,0,0,0.1);
            --glass: rgba(255,255,255,0.15);
            --shadow: 0 8px 32px rgba(0,0,0,0.12);
            --radius: 1.5rem;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
            font-family: 'Inter', sans-serif;
            color: var(--dark);
            min-height: 100vh;
        }

        .header {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            padding: 2rem 0;
            position: relative;
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(16,185,129,0.25);
        }

        .header::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><path d="M0,0 L100,30 L100,100 L0,100 Z" fill="rgba(255,255,255,0.1)"/></svg>') no-repeat bottom;
            background-size: cover;
        }

        .logo {
            width: 70px; height: 70px;
            object-fit: cover;
            border-radius: 18px;
            border: 4px solid rgba(255,255,255,0.3);
            box-shadow: 0 6px 20px rgba(0,0,0,0.2);
            transition: var(--transition);
        }

        .logo:hover { transform: scale(1.1) rotate(4deg); }

        .page-title {
            font-size: 1.8rem;
            font-weight: 800;
            margin: 0;
        }

        .glass-card {
            background: var(--glass);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            transition: var(--transition);
            padding: 1.5rem;
        }

        .glass-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }

        /* === TABLEAU RESPONSIVE === */
        .table-container {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            border-radius: var(--radius);
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
        }

        .table {
            min-width: 800px;
            margin: 0;
        }

        .table th {
            background: #ecfdf5;
            color: #065f46;
            font-weight: 600;
            font-size: 0.9rem;
            padding: 0.8rem 1rem;
            white-space: nowrap;
        }

        .table td {
            padding: 0.9rem 1rem;
            font-size: 0.9rem;
            vertical-align: middle;
        }

        .table tr:hover {
            background: rgba(16,185,129,0.05);
        }

        /* === CARTES MOBILE === */
        .beneficiaire-card {
            background: white;
            border-radius: 16px;
            padding: 1.2rem;
            margin-bottom: 1rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.06);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .beneficiaire-card .badge {
            font-size: 0.75rem;
            padding: 0.35rem 0.7rem;
        }

        .btn-action, .btn-history {
            font-size: 0.85rem;
            padding: 0.5rem 0.8rem;
            border-radius: 12px;
        }

        .btn-action {
            background: linear-gradient(135deg, var(--primary), var(--success));
            color: white;
            border: none;
            box-shadow: 0 4px 15px rgba(16,185,129,0.3);
        }

        .btn-history {
            background: rgba(0,0,0,0.1);
            color: var(--dark);
            border: 1.5px solid rgba(0,0,0,0.1);
        }

        .badge-eligible {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            padding: 0.4rem 0.8rem;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .badge-observation {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white;
            padding: 0.4rem 0.8rem;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .badge-ref {
            background: #e0e7ff;
            color: #4338ca;
            font-size: 0.7rem;
            padding: 0.3rem 0.6rem;
            border-radius: 50px;
        }

        .pagination .page-link {
            border-radius: 12px;
            padding: 0.5rem 0.9rem;
            font-size: 0.9rem;
            margin: 0 2px;
        }

        .pagination .page-item.active .page-link {
            background: linear-gradient(135deg, var(--primary), var(--success));
            border: none;
            color: white;
        }

        .empty-state i {
            font-size: 4rem;
            color: #94a3b8;
        }

        .alert {
            border-radius: 14px;
            padding: 1rem 1.2rem;
            font-size: 0.9rem;
        }

        /* === MOBILE === */
        @media (max-width: 768px) {
            .page-title { font-size: 1.5rem; }
            .header { padding: 1.5rem 0; }
            .logo { width: 60px; height: 60px; }

            /* Masquer le tableau */
            .table-container { display: none; }

            /* Afficher les cartes */
            .beneficiaire-card { display: block; }

            .glass-card .row > div {
                margin-bottom: 0.5rem;
            }

            .btn-action, .btn-history {
                width: 100%;
                margin: 0.25rem 0;
            }

            .pagination .page-link {
                padding: 0.4rem 0.7rem;
                font-size: 0.8rem;
            }
        }

        @media (min-width: 769px) {
            .beneficiaire-card { display: none; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="header position-relative">
    <div class="container position-relative">
        <div class="row align-items-center">
            <div class="col-3 col-md-2 text-center">
                <img src="<?= $logo_path ?>" alt="Logo" class="logo" data-aos="zoom-in">
            </div>
            <div class="col-6 col-md-8 text-center">
                <h1 class="page-title" data-aos="fade-up" data-aos-delay="100">
                    <?= $niveau === 'Hôpital' ? 'Référencés' : 'Région' ?>
                </h1>
                <p class="mb-0 small opacity-90" data-aos="fade-up" data-aos-delay="200">
                    <?= $niveau === 'Hôpital' ? 'Approuvés & non utilisés' : 'Tous actifs' ?>
                </p>
            </div>
            <div class="col-3 col-md-2 text-end">
                <a href="dashboard_prestataire.php" class="btn btn-outline-light btn-sm rounded-pill" data-aos="fade-left" data-aos-delay="300">
                    Retour
                </a>
            </div>
        </div>
    </div>
</div>

<div class="container mt-4">

    <!-- ERREURS -->
    <?php foreach ($errors as $e): ?>
        <div class="alert alert-danger" data-aos="fade-up">
            <?= htmlspecialchars($e) ?>
        </div>
    <?php endforeach; ?>

    <?php if (!empty($results)): ?>
        <!-- FILTRES -->
        <div class="glass-card mb-4" data-aos="fade-up" data-aos-delay="100">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-12 col-md-6">
                    <input type="text" name="search" class="form-control" 
                           placeholder="Recherche..." value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-6 col-md-3">
                    <button type="submit" class="btn btn-primary w-100">Filtrer</button>
                </div>
                <div class="col-6 col-md-3">
                    <a href="?export=csv&token=<?= $csrf_token ?>&search=<?= urlencode($search) ?>" 
                       class="btn btn-success w-100">CSV</a>
                </div>
            </form>
            <small class="text-muted d-block mt-2">
                Tous les départements de la région
            </small>
        </div>

        <!-- TABLEAU (DESKTOP) -->
        <div class="table-container d-none d-lg-block" data-aos="fade-up" data-aos-delay="200">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Adhésion</th>
                        <th>Adhérent</th>
                        <th>Dépt</th>
                        <th>Code</th>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Entrée</th>
                        <th>Éligibilité</th>
                        <?php if ($niveau === 'Hôpital'): ?><th>Réf.</th><?php endif; ?>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $row): 
                        $isEligible = (bool) $row['is_eligible'];
                    ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($row['num_adherent']) ?></strong></td>
                            <td class="text-success fw-semibold"><?= htmlspecialchars($row['adherent_nom'] . ' ' . $row['adherent_prenom']) ?></td>
                            <td><?= htmlspecialchars($row['departement']) ?></td>
                            <td><code class="bg-light px-2 py-1 rounded"><?= htmlspecialchars($row['code_beneficiaire']) ?></code></td>
                            <td><?= htmlspecialchars($row['beneficiaire_nom']) ?></td>
                            <td><?= htmlspecialchars($row['beneficiaire_prenom']) ?></td>
                            <td class="text-muted small"><?= date('d/m/Y', strtotime($row['date_entree'])) ?></td>
                            <td>
                                <?php if ($isEligible): ?>
                                    <span class="badge-eligible">Éligible</span>
                                <?php else: ?>
                                    <span class="badge-observation">Observation</span>
                                <?php endif; ?>
                            </td>
                            <?php if ($niveau === 'Hôpital'): ?>
                                <td><span class="badge-ref">#<?= htmlspecialchars($row['id_referencement']) ?></span></td>
                            <?php endif; ?>
                            <td>
                                <?php if ($isEligible): ?>
                                    <a href="register_prestation.php?id_adhesion=<?= $row['id_adhesion'] ?>&num_beneficiaire=<?= urlencode($row['code_beneficiaire']) ?>"
                                       class="btn btn-action">Prestation</a>
                                <?php else: ?>
                                    <button class="btn btn-action opacity-50" disabled>Prestation</button>
                                <?php endif; ?>
                                <a href="historique_adherent.php?id_adhesion=<?= $row['id_adhesion'] ?>"
                                   class="btn btn-history ms-1">Historique</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- CARTES (MOBILE) -->
        <div class="d-lg-none">
            <?php foreach ($results as $row): 
                $isEligible = (bool) $row['is_eligible'];
            ?>
                <div class="beneficiaire-card" data-aos="fade-up" data-aos-delay="50">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div>
                            <strong class="text-success"><?= htmlspecialchars($row['num_adherent']) ?></strong>
                            <small class="text-muted d-block"><?= htmlspecialchars($row['adherent_nom'] . ' ' . $row['adherent_prenom']) ?></small>
                        </div>
                        <div>
                            <?php if ($isEligible): ?>
                                <span class="badge-eligible">Éligible</span>
                            <?php else: ?>
                                <span class="badge-observation">Observation</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="small text-muted mb-2">
                        <strong><?= htmlspecialchars($row['code_beneficiaire']) ?></strong> • 
                        <?= htmlspecialchars($row['beneficiaire_nom'] . ' ' . $row['beneficiaire_prenom']) ?>
                        <?php if ($niveau === 'Hôpital'): ?>
                            <span class="badge-ref ms-1">#<?= htmlspecialchars($row['id_referencement']) ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="text-muted small mb-3">
                        Entrée: <?= date('d/m/Y', strtotime($row['date_entree'])) ?> • 
                        <?= htmlspecialchars($row['departement']) ?>
                    </div>
                    <div class="d-grid gap-2 d-md-flex">
                        <?php if ($isEligible): ?>
                            <a href="register_prestation.php?id_adhesion=<?= $row['id_adhesion'] ?>&num_beneficiaire=<?= urlencode($row['code_beneficiaire']) ?>"
                               class="btn btn-action">Prestation</a>
                        <?php else: ?>
                            <button class="btn btn-action opacity-50" disabled>Prestation</button>
                        <?php endif; ?>
                        <a href="historique_adherent.php?id_adhesion=<?= $row['id_adhesion'] ?>"
                           class="btn btn-history">Historique</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- PAGINATION -->
        <?php if ($totalPages > 1): ?>
            <nav class="mt-4" data-aos="fade-up" data-aos-delay="300">
                <ul class="pagination justify-content-center flex-wrap">
                    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="?page=<?= $page-1 ?>&search=<?= urlencode($search) ?>">Précédent</a>
                    </li>
                    <?php for ($i = max(1, $page-1); $i <= min($totalPages, $page+1); $i++): ?>
                        <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                        <a class="page-link" href="?page=<?= $page+1 ?>&search=<?= urlencode($search) ?>">Suivant</a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>

        <!-- RETOUR -->
        <div class="text-center mt-4" data-aos="fade-up" data-aos-delay="400">
            <a href="dashboard_prestataire.php" class="btn btn-outline-secondary rounded-pill px-4 py-2">
                Retour
            </a>
        </div>

    <?php else: ?>
        <div class="glass-card text-center py-5" data-aos="fade-up">
            <div class="empty-state">
                <h4 class="mt-3">Aucun bénéficiaire</h4>
                <p class="text-muted">
                    <?= $niveau === 'Hôpital' ? 'Aucun référencement valide.' : 'Aucun actif.' ?>
                </p>
                <a href="dashboard_prestataire.php" class="btn btn-outline-secondary rounded-pill px-4 py-2">
                    Retour
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
    AOS.init({ duration: 600, once: true, offset: 50 });
</script>
</body>
</html>

<?php 
ob_end_flush();
require_once '../includes/footer.php'; 
?>