<?php
// pages/list_agents.php
require_once '../includes/header.php';
checkRole('directeur_departemental');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();
$agents = [];

try {
    // Fetch all agents with adhesion counts and calculate performance score
    $stmt = $pdo->prepare("
        SELECT u.id_utilisateur, u.nom, u.prenom, u.email, u.telephone, u.statut,
               (SELECT COUNT(*) FROM adhesions a WHERE a.created_by = u.id_utilisateur AND a.statut = 'en_attente_validation' AND a.departement = u.departement) as adhesions_en_attente,
               (SELECT COUNT(*) FROM adhesions a WHERE a.created_by = u.id_utilisateur AND a.statut = 'active' AND a.departement = u.departement) as adhesions_actives,
               (SELECT COUNT(*) * 2 FROM adhesions a WHERE a.created_by = u.id_utilisateur AND a.statut = 'active' AND a.departement = u.departement) +
               (SELECT COUNT(*) FROM adhesions a WHERE a.created_by = u.id_utilisateur AND a.statut = 'en_attente_validation' AND a.departement = u.departement) as performance_score
        FROM utilisateurs u
        WHERE u.role = 'agent_mobilisateur' AND u.departement = ?
        ORDER BY performance_score DESC, u.nom, u.prenom
    ");
    $stmt->execute([$_SESSION['departement']]);
    $agents = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get top 3 performers
    $top_performers = array_slice($agents, 0, 5);

    // Handle status change
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_status'])) {
        if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
            $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
        } else {
            $id_agent = intval($_POST['id_agent'] ?? 0);
            $new_status = $_POST['new_status'] ?? '';

            if ($id_agent <= 0 || !in_array($new_status, ['actif', 'inactif'])) {
                $errors[] = "Données invalides pour le changement de statut.";
            } else {
                // Verify agent exists and belongs to the department
                $stmt = $pdo->prepare("
                    SELECT nom, prenom, statut 
                    FROM utilisateurs 
                    WHERE id_utilisateur = ? AND role = 'agent_mobilisateur' AND departement = ?
                ");
                $stmt->execute([$id_agent, $_SESSION['departement']]);
                $agent = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$agent) {
                    $errors[] = "Agent non trouvé ou accès non autorisé.";
                } elseif ($agent['statut'] === $new_status) {
                    $errors[] = "L'agent a déjà le statut '$new_status'.";
                } else {
                    // Update status
                    $stmt = $pdo->prepare("
                        UPDATE utilisateurs 
                        SET statut = ?, date_mise_a_jour = NOW() 
                        WHERE id_utilisateur = ?
                    ");
                    $stmt->execute([$new_status, $id_agent]);

                    // Log activity
                    logActivity($pdo, $_SESSION['user_id'], "Changement de statut de l'agent {$agent['nom']} {$agent['prenom']} à '$new_status'");
                    $success = "Statut de l'agent mis à jour avec succès.";
                    // Refresh agents list
                    $stmt = $pdo->prepare("
                        SELECT u.id_utilisateur, u.nom, u.prenom, u.email, u.telephone, u.statut,
                               (SELECT COUNT(*) FROM adhesions a WHERE a.created_by = u.id_utilisateur AND a.statut = 'en_attente_validation' AND a.departement = u.departement) as adhesions_en_attente,
                               (SELECT COUNT(*) FROM adhesions a WHERE a.created_by = u.id_utilisateur AND a.statut = 'active' AND a.departement = u.departement) as adhesions_actives,
                               (SELECT COUNT(*) * 2 FROM adhesions a WHERE a.created_by = u.id_utilisateur AND a.statut = 'active' AND a.departement = u.departement) +
                               (SELECT COUNT(*) FROM adhesions a WHERE a.created_by = u.id_utilisateur AND a.statut = 'en_attente_validation' AND a.departement = u.departement) as performance_score
                        FROM utilisateurs u
                        WHERE u.role = 'agent_mobilisateur' AND u.departement = ?
                        ORDER BY performance_score DESC, u.nom, u.prenom
                    ");
                    $stmt->execute([$_SESSION['departement']]);
                    $agents = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $top_performers = array_slice($agents, 0, 3);
                }
            }
        }
    }
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des données : " . htmlspecialchars($e->getMessage());
    error_log("Erreur dans list_agents.php : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Agents</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }
        .container {
            max-width: 1000px;
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .card-header {
            border-bottom: none;
            padding: 1.5rem;
            font-size: 1.25rem;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .alert {
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert i {
            font-size: 1.2rem;
        }
        .form-control {
            border-radius: 8px;
            padding: 0.75rem;
            border: 1px solid #ced4da;
            transition: border-color 0.3s ease;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
        }
        .btn-primary, .btn-warning, .btn-success, .btn-info {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-warning:hover {
            background-color: #e0a800;
        }
        .btn-success:hover {
            background-color: #2e7d32;
        }
        .btn-info:hover {
            background-color: #0288d1;
        }
        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 2rem;
        }
        .table {
            border-radius: 8px;
            overflow: hidden;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .table-hover tbody tr:hover {
            background-color: #f1f3f5;
        }
        .search-container {
            position: relative;
        }
        .search-container i {
            position: absolute;
            top: 50%;
            left: 10px;
            transform: translateY(-50%);
            color: #6c757d;
        }
        .search-container input {
            padding-left: 35px;
        }
        .top-performers-card {
            background: linear-gradient(135deg, #1d4ed8, #3b82f6);
            color: white;
            padding: 1.5rem;
            border-radius: 15px;
            margin-bottom: 2rem;
        }
        .top-performers-card h3 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        .top-performer-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.75rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            margin-bottom: 0.5rem;
        }
        .top-performer-item .badge {
            font-size: 0.9rem;
            padding: 0.5rem 0.75rem;
        }
        .tooltip-inner {
            background-color: #2c3e50;
            color: white;
            border-radius: 6px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-people me-2"></i>Liste des Agents</h2>

        <!-- Messages -->
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill"></i>
                <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Top Performers -->
        <?php if (!empty($top_performers)): ?>
            <div class="top-performers-card">
                <h3><i class="bi bi-trophy me-2"></i>Agents les Plus Performants</h3>
                <?php foreach ($top_performers as $index => $performer): ?>
                    <div class="top-performer-item">
                        <span class="badge <?php echo $index === 0 ? 'bg-warning' : ($index === 1 ? 'bg-secondary' : 'bg-bronze'); ?>">
                            <i class="bi bi-award me-1"></i><?php echo ($index + 1) . ($index === 0 ? 'er' : 'e'); ?>
                        </span>
                        <div>
                            <strong><?php echo htmlspecialchars($performer['nom'] . ' ' . $performer['prenom']); ?></strong><br>
                            <small>Adhésions Actives: <?php echo htmlspecialchars($performer['adhesions_actives']); ?> | En Attente: <?php echo htmlspecialchars($performer['adhesions_en_attente']); ?> | Score: <?php echo htmlspecialchars($performer['performance_score']); ?></small>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Agents Table -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <i class="bi bi-list me-2"></i>Agents Mobilisateurs
            </div>
            <div class="card-body">
                <div class="search-container mb-3">
                    <i class="bi bi-search"></i>
                    <input type="text" id="search_agent" class="form-control" placeholder="Rechercher un agent..." aria-label="Rechercher un agent">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-agents">
                        <thead>
                            <tr>
                                <th><i class="bi bi-person me-2"></i>Nom</th>
                                <th><i class="bi bi-person me-2"></i>Prénom</th>
                                <th><i class="bi bi-envelope me-2"></i>Email</th>
                                <th><i class="bi bi-telephone me-2"></i>Téléphone</th>
                                <th><i class="bi bi-hourglass-split me-2"></i>En Attente</th>
                                <th><i class="bi bi-check-circle me-2"></i>Actives</th>
                                <th><i class="bi bi-trophy me-2"></i>Score</th>
                                <th><i class="bi bi-toggle-on me-2"></i>Statut</th>
                                <th><i class="bi bi-gear me-2"></i>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($agents)): ?>
                                <tr>
                                    <td colspan="9" class="text-center">Aucun agent trouvé.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($agents as $index => $agent): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($agent['nom']); ?></td>
                                        <td><?php echo htmlspecialchars($agent['prenom']); ?>
                                            <?php if ($index < 3): ?>
                                                <span class="badge ms-2 <?php echo $index === 0 ? 'bg-warning' : ($index === 1 ? 'bg-secondary' : 'bg-bronze'); ?>">
                                                    <i class="bi bi-award"></i>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($agent['email']); ?></td>
                                        <td><?php echo htmlspecialchars($agent['telephone']); ?></td>
                                        <td><?php echo htmlspecialchars($agent['adhesions_en_attente']); ?></td>
                                        <td><?php echo htmlspecialchars($agent['adhesions_actives']); ?></td>
                                        <td>
                                            <span data-bs-toggle="tooltip" data-bs-placement="top" title="Score = (Adhésions Actives × 2) + Adhésions en Attente">
                                                <?php echo htmlspecialchars($agent['performance_score']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <form method="POST" action="" class="d-inline">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                                <input type="hidden" name="id_agent" value="<?php echo htmlspecialchars($agent['id_utilisateur']); ?>">
                                                <input type="hidden" name="new_status" value="<?php echo $agent['statut'] === 'actif' ? 'inactif' : 'actif'; ?>">
                                                <button type="submit" name="change_status" class="btn btn-sm <?php echo $agent['statut'] === 'actif' ? 'btn-warning' : 'btn-success'; ?>">
                                                    <i class="bi <?php echo $agent['statut'] === 'actif' ? 'bi-toggle-off' : 'bi-toggle-on'; ?> me-1"></i>
                                                    <?php echo $agent['statut'] === 'actif' ? 'Désactiver' : 'Activer'; ?>
                                                </button>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="view_agent.php?id=<?php echo htmlspecialchars($agent['id_utilisateur']); ?>" class="btn btn-sm btn-info"><i class="bi bi-eye me-1"></i>Voir</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <a href="add_agent.php" class="btn btn-primary mt-3"><i class="bi bi-person-plus me-2"></i>Ajouter un Agent</a>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Initialize tooltips
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

        // Search functionality for agents table
        document.getElementById('search_agent').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-agents tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>