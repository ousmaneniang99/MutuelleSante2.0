<?php
// pages/list_paiements.php
require_once '../includes/header.php';
checkRole('directeur_departemental');

$errors = [];
$paiements = [];
$kpi = [
    'total_paiements' => 0,
    'paiements_valides' => 0,
    'montant_adhesions_actives' => 0,
    'montant_adhesions_non_actives' => 0
];
$filters = [
    'statut' => $_GET['statut'] ?? '',
    'search' => $_GET['search'] ?? ''
];

try {
    // Requête principale pour les paiements
    $query = "
        SELECT p.id_paiement, p.montant_verse, p.date_paiement, p.statut,
               a.num_adherent, u.nom AS adherent_nom, u.prenom AS adherent_prenom
        FROM paiements p
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion
        JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
        JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
        WHERE agent.departement = ? AND agent.role = 'agent_mobilisateur'
    ";
    $params = [$_SESSION['departement']];

    // Appliquer les filtres
    if (!empty($filters['statut'])) {
        $query .= " AND p.statut = ?";
        $params[] = $filters['statut'];
    }
    if (!empty($filters['search'])) {
        $query .= " AND (u.nom LIKE ? OR u.prenom LIKE ? OR a.num_adherent LIKE ?)";
        $search = '%' . $filters['search'] . '%';
        $params[] = $search;
        $params[] = $search;
        $params[] = $search;
    }

    $query .= " ORDER BY p.date_paiement DESC";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $paiements = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculer les KPI
    // KPI : Total Adhésions avec Paiements
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT a.id_adhesion)
        FROM adhesions a
        JOIN paiements p ON p.id_adhesion = a.id_adhesion
        JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
        WHERE agent.departement = ? 
        AND agent.role = 'agent_mobilisateur'
    ");
    $stmt->execute([$_SESSION['departement']]);
    $kpi['total_paiements'] = $stmt->fetchColumn();

    // KPI : Paiements Valides (nombre de paiements pour adhésions actives)
    $stmt = $pdo->prepare("
        SELECT COUNT(p.id_paiement)
        FROM paiements p
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion
        JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
        WHERE p.statut = 'paye' 
        AND a.statut = 'active'
        AND agent.departement = ? 
        AND agent.role = 'agent_mobilisateur'
    ");
    $stmt->execute([$_SESSION['departement']]);
    $kpi['paiements_valides'] = $stmt->fetchColumn();

    // KPI : Montant des adhésions actives
    $stmt = $pdo->prepare("
        SELECT SUM(p.montant_verse)
        FROM paiements p
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion
        JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
        WHERE p.statut = 'paye' 
        AND a.statut = 'active'
        AND agent.departement = ? 
        AND agent.role = 'agent_mobilisateur'
    ");
    $stmt->execute([$_SESSION['departement']]);
    $kpi['montant_adhesions_actives'] = $stmt->fetchColumn() ?: 0;

    // KPI : Montant des adhésions non actives
    $stmt = $pdo->prepare("
        SELECT SUM(p.montant_verse)
        FROM paiements p
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion
        JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
        WHERE p.statut = 'paye' 
        AND a.statut != 'active'
        AND agent.departement = ? 
        AND agent.role = 'agent_mobilisateur'
    ");
    $stmt->execute([$_SESSION['departement']]);
    $kpi['montant_adhesions_non_actives'] = $stmt->fetchColumn() ?: 0;

} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des paiements : " . htmlspecialchars($e->getMessage());
    error_log("Erreur dans list_paiements.php : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Paiements - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }
        .container {
            max-width: 1200px;
            margin-top: 30px;
            margin-bottom: 30px;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }
        .card-header {
            border-bottom: none;
            padding: 1rem;
            font-size: 1.1rem;
            font-weight: 600;
            background: linear-gradient(90deg, #007bff, #0056b3);
            color: white;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .card-body {
            padding: 1.5rem;
        }
        .alert {
            border-radius: 8px;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .alert i {
            font-size: 1rem;
        }
        .form-control, .form-select {
            border-radius: 6px;
            padding: 0.6rem;
            border: 1px solid #ced4da;
            transition: border-color 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
        }
        .btn-primary, .btn-secondary {
            border-radius: 6px;
            padding: 0.4rem 0.8rem;
            font-weight: 500;
            font-size: 0.9rem;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }
        .page-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        .table {
            border-radius: 6px;
            overflow: hidden;
            background: #ffffff;
            box-shadow: 0 1px 6px rgba(0, 0, 0, 0.05);
        }
        .table th {
            background: linear-gradient(90deg, #007bff, #0056b3);
            color: white;
            font-weight: 600;
            padding: 0.8rem;
            border: none;
            font-size: 0.9rem;
        }
        .table td {
            padding: 0.8rem;
            vertical-align: middle;
            font-size: 0.9rem;
            border: none;
        }
        .table-hover tbody tr:hover {
            background-color: #f1f3f5;
        }
        .table i {
            font-size: 1rem;
            margin-right: 0.4rem;
            color: #007bff;
        }
        .kpi-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .kpi-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .kpi-card .card-body {
            padding: 1rem;
            text-align: center;
        }
        .kpi-card .card-title {
            font-size: 0.9rem;
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.4rem;
        }
        .kpi-card .card-text {
            font-size: 1.2rem;
            font-weight: 600;
        }
        .filter-container {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            align-items: center;
        }
        .filter-container .form-select, .filter-container .form-control {
            min-width: 180px;
        }
        .search-container {
            position: relative;
        }
        .search-container i {
            position: absolute;
            top: 50%;
            left: 10px;
            transform: translateY(-50%);
            color: #6c757d;
        }
        .search-container input {
            padding-left: 30px;
        }
        @media (max-width: 576px) {
            .container {
                padding: 1rem;
            }
            .page-title {
                font-size: 1.4rem;
            }
            .table th, .table td {
                font-size: 0.8rem;
                padding: 0.6rem;
            }
            .btn-primary, .btn-secondary {
                padding: 0.3rem 0.6rem;
                font-size: 0.8rem;
            }
            .filter-container .form-select, .filter-container .form-control {
                min-width: 100%;
            }
            .kpi-card .card-text {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title"><i class="bi bi-currency-exchange me-2"></i>Liste des Paiements</h2>

        <!-- Messages -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- KPI Cards -->
        <div class="row mb-3">
            <div class="col-md-3 col-sm-6 mb-2">
                <div class="card kpi-card text-white bg-primary">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-list-ul"></i>Total Adhésions avec Paiements</h5>
                        <p class="card-text"><?php echo htmlspecialchars($kpi['total_paiements']); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-2">
                <div class="card kpi-card text-white bg-success">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-check-circle"></i>Paiements Valides</h5>
                        <p class="card-text"><?php echo htmlspecialchars($kpi['paiements_valides']); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-2">
                <div class="card kpi-card text-white bg-success">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-toggle-on"></i>Paiements Adhésions Actives</h5>
                        <p class="card-text"><?php echo htmlspecialchars(formatFCFA($kpi['montant_adhesions_actives'])); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-2">
                <div class="card kpi-card text-white bg-danger">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-toggle-off"></i>Paiements Adhésions Non Actives</h5>
                        <p class="card-text"><?php echo htmlspecialchars(formatFCFA($kpi['montant_adhesions_non_actives'])); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="card mb-3">
            <div class="card-header">
                <i class="bi bi-funnel me-2"></i>Filtres
            </div>
            <div class="card-body">
                <form method="GET" class="filter-container">
                    <div class="search-container">
                        <i class="bi bi-search"></i>
                        <input type="text" class="form-control" name="search" placeholder="Rechercher par nom ou numéro..." value="<?php echo htmlspecialchars($filters['search']); ?>">
                    </div>
                    <select class="form-select" name="statut">
                        <option value="">Tous les statuts</option>
                        <option value="paye" <?php echo $filters['statut'] === 'paye' ? 'selected' : ''; ?>>Payé</option>
                        <option value="en_attente" <?php echo $filters['statut'] === 'en_attente' ? 'selected' : ''; ?>>En attente</option>
                        <option value="rejete" <?php echo $filters['statut'] === 'rejete' ? 'selected' : ''; ?>>Rejeté</option>
                    </select>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-funnel-fill me-2"></i>Filtrer</button>
                    <a href="list_paiements.php" class="btn btn-secondary"><i class="bi bi-x-circle me-2"></i>Réinitialiser</a>
                </form>
            </div>
        </div>

        <!-- Paiements Table -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-currency-exchange me-2"></i>Paiements
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-paiements">
                        <thead>
                            <tr>
                                <th><i class="bi bi-hash me-2"></i>ID</th>
                                <th><i class="bi bi-person-vcard me-2"></i>Numéro Adhérent</th>
                                <th><i class="bi bi-person me-2"></i>Adhérent</th>
                                <th><i class="bi bi-currency-exchange me-2"></i>Montant</th>
                                <th><i class="bi bi-calendar me-2"></i>Date</th>
                                <th><i class="bi bi-toggle-on me-2"></i>Statut</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($paiements)): ?>
                                <tr>
                                    <td colspan="6" class="text-center">Aucun paiement trouvé.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($paiements as $paiement): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($paiement['id_paiement']); ?></td>
                                        <td><?php echo htmlspecialchars($paiement['num_adherent']); ?></td>
                                        <td><?php echo htmlspecialchars(($paiement['adherent_nom'] ?? 'Non spécifié') . ' ' . ($paiement['adherent_prenom'] ?? '')); ?></td>
                                        <td><?php echo htmlspecialchars(formatFCFA($paiement['montant_verse'] ?: 0)); ?></td>
                                        <td><?php echo htmlspecialchars($paiement['date_paiement'] ?? 'Non spécifiée'); ?></td>
                                        <td><?php echo htmlspecialchars($paiement['statut'] === 'paye' ? 'Payé' : ($paiement['statut'] === 'en_attente' ? 'En attente' : 'Rejeté')); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Client-side search enhancement
        document.querySelector('input[name="search"]').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-paiements tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });
    </script>
</body>
</html>
<?php require_once '../includes/footer.php'; ?>