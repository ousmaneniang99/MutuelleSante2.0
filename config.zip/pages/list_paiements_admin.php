<?php
// pages/list_paiements.php
ob_start();
require_once '../includes/header.php';
checkSessionTimeout();
checkRole('admin');

$errors = [];
$paiements = [];
$total_pages = 0;
$departements = [];

// Paramètres de pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Récupérer le filtre de département
$departement_id = isset($_GET['departement_id']) && is_numeric($_GET['departement_id']) ? (int)$_GET['departement_id'] : 0;

// Restreindre à département de l'utilisateur pour comptables
if ($_SESSION['role'] === 'comptable' && isset($_SESSION['user_department'])) {
    $departement_id = (int)$_SESSION['user_department'];
}

// Récupérer la liste des départements pour le filtre
try {
    $stmt_depts = $pdo->query("SELECT id_departement, nom FROM departements ORDER BY nom ASC");
    $departements = $stmt_depts->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des départements : " . $e->getMessage();
    error_log("Erreur PDO dans list_paiements.php (départements) : " . $e->getMessage());
}

// Récupérer les paiements
if (empty($errors)) {
    try {
        // Construire la requête des paiements sans agent
        $query = "
            SELECT p.id_paiement, p.montant_verse, p.date_paiement, p.methode, p.statut,
                   a.num_adherent, u.nom, u.prenom, d.nom AS departement_nom
            FROM paiements p
            LEFT JOIN adhesions a ON p.id_adhesion = a.id_adhesion
            LEFT JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
            LEFT JOIN departements d ON u.departement = d.id_departement
            WHERE 1=1
        ";
        if ($departement_id > 0) {
            $query .= " AND u.departement = :departement_id";
        }
        $query .= " ORDER BY p.date_paiement DESC LIMIT :perPage OFFSET :offset";

        $stmt = $pdo->prepare($query);
        if ($departement_id > 0) {
            $stmt->bindValue(':departement_id', $departement_id, PDO::PARAM_INT);
        }
        $stmt->bindValue(':perPage', (int)$perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
        $stmt->execute();
        $paiements = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Compter le total des paiements
        $query_count = "
            SELECT COUNT(*) 
            FROM paiements p
            LEFT JOIN adhesions a ON p.id_adhesion = a.id_adhesion
            LEFT JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
            WHERE 1=1
        ";
        if ($departement_id > 0) {
            $query_count .= " AND u.departement = :departement_id";
        }
        $stmt_count = $pdo->prepare($query_count);
        if ($departement_id > 0) {
            $stmt_count->bindValue(':departement_id', $departement_id, PDO::PARAM_INT);
        }
        $stmt_count->execute();
        $total_paiements = $stmt_count->fetchColumn() ?: 0;
        $total_pages = ceil($total_paiements / $perPage);
    } catch (PDOException $e) {
        $errors[] = "Erreur lors de la récupération des paiements : " . $e->getMessage();
        error_log("Erreur PDO dans list_paiements.php (paiements) : " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiements Effectués - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-medical: linear-gradient(135deg, #1e3a8a, #3b82f6, #1d4ed8);
            --success-health: linear-gradient(135deg, #15803d, #22c55e, #16a34a);
            --warning-gold: linear-gradient(135deg, #d97706, #f59e0b, #b45309);
            --danger-alert: linear-gradient(135deg, #dc2626, #ef4444, #b91c1c);
            --glass-bg: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
            --shadow-glow: 0 25px 50px -12px rgba(59, 130, 246, 0.3);
            --shadow-hover: 0 35px 60px -15px rgba(59, 130, 246, 0.3);
            --text: #1e293b;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 50%, #f0f9ff 100%);
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 20% 50%, rgba(120, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 40% 80%, rgba(120, 219, 255, 0.1) 0%, transparent 50%);
            z-index: -1;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }

        .header-hero {
            background: var(--primary-medical);
            border-radius: 24px;
            padding: 2rem;
            color: white;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-glow);
            backdrop-filter: blur(20px);
            text-align: center;
        }

        .header-hero::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: conic-gradient(from 0deg, transparent, rgba(255,255,255,0.1), transparent 30%);
            animation: rotate 20s linear infinite;
            opacity: 0.3;
        }

        @keyframes rotate { 100% { transform: rotate(360deg); } }

        .header-title {
            font-size: 2.2rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            background: linear-gradient(45deg, #fff, #e0f2fe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-subtitle {
            font-size: 1.1rem;
            opacity: 0.95;
            font-weight: 400;
            max-width: 700px;
            margin: 0 auto;
        }

        .card {
            background: rgba(255,255,255,0.9);
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: var(--shadow-glow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px);
            transition: all 0.4s ease;
            margin-bottom: 2rem;
        }

        .card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.95);
        }

        .card-header {
            background: var(--primary-medical);
            color: white;
            font-weight: 600;
            border-radius: 10px 10px 0 0;
            padding: 0.75rem;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }

        .search-container {
            position: relative;
            max-width: 100%;
            margin-bottom: 1.5rem;
        }

        .search-input {
            border-radius: 10px;
            padding: 0.6rem 1rem 0.6rem 2.5rem;
            border: 1px solid var(--glass-border);
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            width: 100%;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            color: var(--text);
        }

        .search-input:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 6px rgba(59, 130, 246, 0.2);
            outline: none;
        }

        .search-icon {
            position: absolute;
            left: 0.8rem;
            top: 50%;
            transform: translateY(-50%);
            color: #6b7280;
            font-size: 1rem;
        }

        .filter-container {
            margin-bottom: 1.5rem;
        }

        .filter-select {
            border-radius: 10px;
            padding: 0.6rem 1rem;
            border: 1px solid var(--glass-border);
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            font-size: 0.9rem;
            transition: all 0.3s ease;
            color: var(--text);
        }

        .filter-select:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 6px rgba(59, 130, 246, 0.2);
            outline: none;
        }

        .table {
            background: rgba(255,255,255,0.9);
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
        }

        .table thead {
            background: rgba(229, 231, 235, 0.9);
            color: var(--text);
            font-weight: 600;
            font-size: 0.85rem;
        }

        .table tbody tr {
            transition: background 0.2s ease;
        }

        .table tbody tr:hover {
            background: rgba(243, 244, 246, 0.9);
        }

        .table td, .table th {
            padding: 0.75rem;
            font-size: 0.9rem;
            white-space: nowrap;
        }

        .badge {
            font-size: 0.8rem;
            padding: 0.4rem 0.8rem;
            border-radius: 12px;
        }

        .pagination .page-link {
            border-radius: 6px;
            margin: 0 3px;
            color: #3b82f6;
            border: 1px solid #d1d5db;
            font-size: 0.85rem;
            padding: 0.4rem 0.7rem;
            transition: all 0.3s ease;
        }

        .pagination .page-item.active .page-link {
            background: var(--primary-medical);
            border-color: #3b82f6;
            color: white;
        }

        .pagination .page-link:hover {
            background: #e5e7eb;
            color: #1e3a8a;
        }

        .alert {
            border-radius: 8px;
            padding: 0.6rem 1rem;
            margin-bottom: 0.75rem;
            font-size: 0.9rem;
            animation: slideIn 0.5s ease-in-out;
            display: flex;
            align-items: center;
            gap: 0.4rem;
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border: 1px solid var(--glass-border);
        }

        .modal-content {
            border-radius: 10px;
            box-shadow: var(--shadow-glow);
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(10px);
        }

        .modal-header {
            background: var(--primary-medical);
            color: white;
            border-radius: 10px 10px 0 0;
            padding: 0.75rem;
        }

        .modal-body {
            padding: 1.5rem;
        }

        .modal-footer {
            border-top: 1px solid #e5e7eb;
            padding: 0.75rem;
        }

        .fade-in-up {
            animation: fadeInUp 0.8s ease forwards;
            opacity: 0;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-15px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @media (max-width: 992px) {
            .container { padding: 1.5rem 0.75rem; }
            .header-title { font-size: 1.8rem; }
            .table td, .table th { font-size: 0.8rem; padding: 0.5rem; }
        }

        @media (max-width: 768px) {
            .table thead { display: none; }
            .table tbody tr {
                display: block;
                margin-bottom: 0.75rem;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                padding: 0.5rem;
                background: rgba(255,255,255,0.9);
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            }

            .table tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: 0.8rem;
                padding: 0.4rem 0.5rem;
                border: none;
            }

            .table tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                font-size: 0.8rem;
                color: #6b7280;
                width: 40%;
            }

            .table tbody td[data-label="Détails"] {
                display: flex;
                flex-wrap: wrap;
                gap: 0.4rem;
                justify-content: center;
            }

            .modal-dialog { margin: 0.5rem; max-width: 95%; }
        }

        @media (max-width: 576px) {
            .btn-primary { font-size: 0.75rem; padding: 0.3rem 0.6rem; }
            .alert { font-size: 0.8rem; padding: 0.5rem 0.75rem; }
            .modal-header { font-size: 0.9rem; }
            .modal-body p { font-size: 0.8rem; }
            .filter-select { font-size: 0.8rem; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header Hero -->
        <div class="header-hero fade-in-up">
            <h1 class="header-title animate__animated animate__fadeInDown">
                💰 Liste des Paiements Effectués
            </h1>
            <p class="header-subtitle animate__animated animate__fadeInUp">
                Vue globale des paiements effectués dans tous les départements de Matam
            </p>
        </div>

        <!-- Alerts -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i> <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Filtre par Département -->
        <?php if ($_SESSION['role'] === 'admin'): ?>
            <div class="filter-container fade-in-up" style="animation-delay: 0.2s;">
                <select id="departement_filter" class="form-select filter-select" aria-label="Filtrer par département">
                    <option value="0" <?php echo $departement_id == 0 ? 'selected' : ''; ?>>Tous les départements</option>
                    <?php foreach ($departements as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept['id_departement']); ?>" <?php echo $departement_id == $dept['id_departement'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept['nom']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        <?php endif; ?>

        <!-- Paiements -->
        <div class="card fade-in-up" style="animation-delay: 0.4s;">
            <div class="card-header">
                <i class="bi bi-cash-stack"></i> Liste des Paiements
            </div>
            <div class="card-body">
                <div class="search-container">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" id="search_paiement" class="form-control search-input" placeholder="Rechercher par nom, prénom, numéro ou département..." aria-label="Rechercher un paiement par nom, prénom, numéro adhérent ou département">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-paiements" id="paiements-table">
                        <thead>
                            <tr>
                                <th scope="col">Numéro Adhérent</th>
                                <th scope="col">Nom</th>
                                <th scope="col">Prénom</th>
                                <th scope="col">Département</th>
                                <th scope="col">Montant (FCFA)</th>
                                <th scope="col">Date</th>
                                <th scope="col">Méthode</th>
                                <th scope="col">Statut</th>
                                <th scope="col">Détails</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($paiements)): ?>
                                <tr><td colspan="9" class="text-center">Aucun paiement trouvé.</td></tr>
                            <?php else: ?>
                                <?php foreach ($paiements as $paiement): ?>
                                    <tr>
                                        <td data-label="Numéro Adhérent"><?php echo htmlspecialchars($paiement['num_adherent'] ?? 'N/A'); ?></td>
                                        <td data-label="Nom"><?php echo htmlspecialchars($paiement['nom'] ?? 'N/A'); ?></td>
                                        <td data-label="Prénom"><?php echo htmlspecialchars($paiement['prenom'] ?? 'N/A'); ?></td>
                                        <td data-label="Département"><?php echo htmlspecialchars($paiement['departement_nom'] ?? 'N/A'); ?></td>
                                        <td data-label="Montant (FCFA)"><?php echo number_format($paiement['montant_verse'] ?? 0, 0); ?></td>
                                        <td data-label="Date"><?php echo htmlspecialchars($paiement['date_paiement'] ? date('d/m/Y', strtotime($paiement['date_paiement'])) : 'N/A'); ?></td>
                                        <td data-label="Méthode"><?php echo htmlspecialchars($paiement['methode'] ?? 'N/A'); ?></td>
                                        <td data-label="Statut">
                                            <span class="badge bg-<?php echo ($paiement['statut'] == 'paye') ? 'success' : 'danger'; ?>">
                                                <?php echo ($paiement['statut'] == 'paye') ? 'Payé' : ucfirst($paiement['statut'] ?? 'N/A'); ?>
                                            </span>
                                        </td>
                                        <td data-label="Détails">
                                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#paiementModal<?php echo htmlspecialchars($paiement['id_paiement']); ?>" aria-label="Voir les détails du paiement <?php echo htmlspecialchars($paiement['id_paiement']); ?>">
                                                <i class="bi bi-eye"></i> Détails
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Pagination des paiements" class="mt-3">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&departement_id=<?php echo htmlspecialchars($departement_id); ?>" aria-label="Page précédente"><i class="bi bi-chevron-left"></i></a>
                            </li>
                            <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&departement_id=<?php echo htmlspecialchars($departement_id); ?>" aria-label="Page <?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&departement_id=<?php echo htmlspecialchars($departement_id); ?>" aria-label="Page suivante"><i class="bi bi-chevron-right"></i></a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>

        <!-- Modals pour Détails des Paiements -->
        <?php if (!empty($paiements)): ?>
            <?php foreach ($paiements as $paiement): ?>
                <div class="modal fade" id="paiementModal<?php echo htmlspecialchars($paiement['id_paiement']); ?>" tabindex="-1" aria-labelledby="paiementModalLabel<?php echo htmlspecialchars($paiement['id_paiement']); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="paiementModalLabel<?php echo htmlspecialchars($paiement['id_paiement']); ?>">
                                    Détails du Paiement #<?php echo htmlspecialchars($paiement['id_paiement']); ?>
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p><strong>Numéro Adhérent :</strong> <?php echo htmlspecialchars($paiement['num_adherent'] ?? 'N/A'); ?></p>
                                        <p><strong>Nom :</strong> <?php echo htmlspecialchars($paiement['nom'] ?? 'N/A'); ?></p>
                                        <p><strong>Prénom :</strong> <?php echo htmlspecialchars($paiement['prenom'] ?? 'N/A'); ?></p>
                                        <p><strong>Département :</strong> <?php echo htmlspecialchars($paiement['departement_nom'] ?? 'N/A'); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong>Montant :</strong> <?php echo number_format($paiement['montant_verse'] ?? 0, 0); ?> FCFA</p>
                                        <p><strong>Date :</strong> <?php echo htmlspecialchars($paiement['date_paiement'] ? date('d/m/Y H:i:s', strtotime($paiement['date_paiement'])) : 'N/A'); ?></p>
                                        <p><strong>Méthode :</strong> <?php echo htmlspecialchars($paiement['methode'] ?? 'N/A'); ?></p>
                                        <p><strong>Statut :</strong> 
                                            <span class="badge bg-<?php echo ($paiement['statut'] == 'paye') ? 'success' : 'danger'; ?>">
                                                <?php echo ($paiement['statut'] == 'paye') ? 'Payé' : ucfirst($paiement['statut'] ?? 'N/A'); ?>
                                            </span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" aria-label="Fermer">Fermer</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.js"></script>
    <script>
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }

        // Recherche des paiements
        const searchInput = document.getElementById('search_paiement');
        if (searchInput) {
            const searchFunc = debounce(function(e) {
                const search = e.target.value.toLowerCase();
                const rows = document.querySelectorAll('#paiements-table tbody tr');
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(search) ? '' : 'none';
                });
            }, 300);
            searchInput.addEventListener('input', searchFunc);
        }

        // Filtre par département
        const departementFilter = document.getElementById('departement_filter');
        if (departementFilter) {
            departementFilter.addEventListener('change', function() {
                const departementId = this.value;
                const url = new URL(window.location.href);
                url.searchParams.set('departement_id', departementId);
                url.searchParams.set('page', 1); // Réinitialiser la page
                window.location.href = url.toString();
            });
        }
    </script>
</body>
</html>
<?php
require_once __DIR__ . '/../includes/footer.php';
ob_end_flush();
?>