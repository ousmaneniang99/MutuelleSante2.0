<?php
// Inclusion du fichier header.php
require_once __DIR__ . '/../includes/header.php';

// Vérifier le rôle (ex. : comptable ou admin)
checkRole('comptable');  // Assurez-vous que cette fonction existe dans header.php

// Récupération des informations de session
$user_id = $_SESSION['user_id'];
$departement_id = $_SESSION['departement'];
// Récupérer le nom du département
try {
    $query_dept = "SELECT nom FROM departements WHERE id_departement = :departement_id";
    $stmt = $pdo->prepare($query_dept);
    $stmt->execute(['departement_id' => $departement_id]);
    $departement_nom = $stmt->fetchColumn() ?: 'Inconnu';
} catch (Exception $e) {
    $departement_nom = 'Inconnu';
}

// Initialisation des variables
$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$type_filter = isset($_GET['type']) ? sanitize($_GET['type']) : '';
$search_term = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$per_page = 10;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $per_page;
$errors = [];
$transactions = [];
$total_entrees = 0;
$total_sorties = 0;
$chart_data = [];
$total_pages = 1;

// Exportation CSV pour les transactions
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    try {
        $query_transactions = "
            SELECT * FROM (
                SELECT 
                    'entree' AS type, 
                    COALESCE(p.montant_verse, 0) AS montant, 
                    CONCAT('Cotisation adhésion #', a.id_adhesion) AS description, 
                    p.date_paiement AS date_transaction, 
                    CONCAT(u.nom, ' ', u.prenom) AS created_by_nom,
                    d.nom AS departement_nom,
                    p.methode AS methode,
                    p.reference_transaction AS reference_transaction
                FROM paiements p
                JOIN adhesions a ON p.id_adhesion = a.id_adhesion
                LEFT JOIN utilisateurs u ON p.created_by = u.id_utilisateur
                LEFT JOIN departements d ON a.departement = d.id_departement
                WHERE p.statut = 'paye'
                AND a.departement = :departement_id
                UNION ALL
                SELECT 
                    'sortie' AS type, 
                    COALESCE(dr.montant_rembourse, 0) AS montant, 
                    CONCAT('Remboursement #', dr.id_demande, ' - ', dr.commentaire) AS description,
                    dr.date_mise_a_jour AS date_transaction, 
                    CONCAT(u.nom, ' ', u.prenom) AS created_by_nom,
                    d.nom AS departement_nom,
                    'N/A' AS methode,
                    'N/A' AS reference_transaction
                FROM demandes_remboursement dr
                JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
                LEFT JOIN utilisateurs u ON dr.created_by = u.id_utilisateur  -- Assumant que demandes_remboursement a un champ created_by
                LEFT JOIN departements d ON a.departement = d.id_departement
                WHERE dr.statut = 'approuve'
                AND a.departement = :departement_id
            ) AS combined
            WHERE YEAR(date_transaction) = :year
            ORDER BY date_transaction DESC";
        $stmt = $pdo->prepare($query_transactions);
        $stmt->execute(['departement_id' => $departement_id, 'year' => $year]);
        $transactions_export = $stmt->fetchAll(PDO::FETCH_ASSOC);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="transactions_' . $departement_nom . '_' . $year . '.csv"');
        $output = fopen('php://output', 'w');
        fputs($output, "\xEF\xBB\xBF");
        fputcsv($output, ['Type', 'Montant (FCFA)', 'Description', 'Date', 'Créé par', 'Département', 'Méthode', 'Référence Transaction']);

        foreach ($transactions_export as $transaction) {
            fputcsv($output, [
                htmlspecialchars_decode($transaction['type'], ENT_QUOTES),
                number_format((float)$transaction['montant'], 2, ',', ' '),
                htmlspecialchars_decode($transaction['description'], ENT_QUOTES),
                htmlspecialchars_decode($transaction['date_transaction'], ENT_QUOTES),
                htmlspecialchars_decode($transaction['created_by_nom'] ?: 'N/A', ENT_QUOTES),
                htmlspecialchars_decode($transaction['departement_nom'] ?: 'N/A', ENT_QUOTES),
                htmlspecialchars_decode($transaction['methode'] ?: 'N/A', ENT_QUOTES),
                htmlspecialchars_decode($transaction['reference_transaction'] ?: 'N/A', ENT_QUOTES)
            ]);
        }
        fclose($output);
        exit;
    } catch (Exception $e) {
        $errors[] = "Erreur lors de l'exportation CSV : " . $e->getMessage();
    }
}

// Récupération des transactions et stats
try {
    // Conditions dynamiques pour filtres
    $where = "WHERE YEAR(date_transaction) = :year ";
    $params = ['departement_id' => $departement_id, 'year' => $year];
    if ($type_filter) {
        $where .= "AND type = :type_filter ";
        $params['type_filter'] = $type_filter;
    }
    if ($search_term) {
        $where .= "AND (description LIKE :search_term OR created_by_nom LIKE :search_term) ";
        $params['search_term'] = '%' . $search_term . '%';
    }

    // Compte total pour pagination
    $query_count = "
        SELECT COUNT(*) FROM (
            SELECT 
                'entree' AS type, 
                COALESCE(p.montant_verse, 0) AS montant, 
                p.date_paiement AS date_transaction
            FROM paiements p
            JOIN adhesions a ON p.id_adhesion = a.id_adhesion
            WHERE p.statut = 'paye'
            AND a.departement = :departement_id
            UNION ALL
            SELECT 
                'sortie' AS type, 
                COALESCE(dr.montant_rembourse, 0) AS montant, 
                dr.date_mise_a_jour AS date_transaction
            FROM demandes_remboursement dr
            JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
            WHERE dr.statut = 'approuve'
            AND a.departement = :departement_id
        ) AS combined
        $where";
    $stmt_count = $pdo->prepare($query_count);
    $stmt_count->execute($params);
    $total_rows = (int)$stmt_count->fetchColumn();
    $total_pages = ceil($total_rows / $per_page);

    // Transactions list (union entrees et sorties) avec pagination
    $query_transactions = "
        SELECT * FROM (
            SELECT 
                'entree' AS type, 
                COALESCE(p.montant_verse, 0) AS montant, 
                CONCAT('Cotisation adhésion #', a.id_adhesion) AS description, 
                p.date_paiement AS date_transaction, 
                CONCAT(u.nom, ' ', u.prenom) AS created_by_nom,
                d.nom AS departement_nom,
                p.methode AS methode,
                p.reference_transaction AS reference_transaction
            FROM paiements p
            JOIN adhesions a ON p.id_adhesion = a.id_adhesion
            LEFT JOIN utilisateurs u ON p.created_by = u.id_utilisateur
            LEFT JOIN departements d ON a.departement = d.id_departement
            WHERE p.statut = 'paye'
            AND a.departement = :departement_id
            UNION ALL
            SELECT 
                'sortie' AS type, 
                COALESCE(dr.montant_rembourse, 0) AS montant, 
                CONCAT('Remboursement #', dr.id_demande, ' - ', dr.commentaire) AS description, 
                dr.date_mise_a_jour AS date_transaction, 
                CONCAT(u.nom, ' ', u.prenom) AS created_by_nom,
                d.nom AS departement_nom,
                'N/A' AS methode,
                'N/A' AS reference_transaction
            FROM demandes_remboursement dr
            JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
            LEFT JOIN utilisateurs u ON dr.created_by = u.id_utilisateur  -- Assumant que demandes_remboursement a un champ created_by
            LEFT JOIN departements d ON a.departement = d.id_departement
            WHERE dr.statut = 'approuve'
            AND a.departement = :departement_id
        ) AS combined
        $where
        ORDER BY date_transaction DESC
        LIMIT $per_page OFFSET $offset";
    $stmt = $pdo->prepare($query_transactions);
    $stmt->execute($params);
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Total entrées et sorties
    $query_totals = "
        SELECT 
            COALESCE(SUM(CASE WHEN type = 'entree' THEN montant ELSE 0 END), 0) AS total_entrees,
            COALESCE(SUM(CASE WHEN type = 'sortie' THEN montant ELSE 0 END), 0) AS total_sorties
        FROM (
            SELECT 'entree' AS type, COALESCE(p.montant_verse, 0) AS montant, p.date_paiement AS date_transaction FROM paiements p JOIN adhesions a ON p.id_adhesion = a.id_adhesion WHERE p.statut = 'paye' AND a.departement = :departement_id
            UNION ALL
            SELECT 'sortie' AS type, COALESCE(dr.montant_rembourse, 0) AS montant, dr.date_mise_a_jour AS date_transaction FROM demandes_remboursement dr JOIN adhesions a ON dr.id_adhesion = a.id_adhesion WHERE dr.statut = 'approuve' AND a.departement = :departement_id
        ) AS combined
        WHERE YEAR(date_transaction) = :year";
    $stmt = $pdo->prepare($query_totals);
    $stmt->execute(['departement_id' => $departement_id, 'year' => $year]);
    $totals = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['total_entrees' => 0, 'total_sorties' => 0];
    $total_entrees = (float)($totals['total_entrees'] ?? 0);
    $total_sorties = (float)($totals['total_sorties'] ?? 0);

    // Données pour le chart (évolution mensuelle, avec mois en français)
    $query_chart = "
        SELECT 
            CASE MONTH(date_transaction)
                WHEN 1 THEN 'Janvier'
                WHEN 2 THEN 'Février'
                WHEN 3 THEN 'Mars'
                WHEN 4 THEN 'Avril'
                WHEN 5 THEN 'Mai'
                WHEN 6 THEN 'Juin'
                WHEN 7 THEN 'Juillet'
                WHEN 8 THEN 'Août'
                WHEN 9 THEN 'Septembre'
                WHEN 10 THEN 'Octobre'
                WHEN 11 THEN 'Novembre'
                WHEN 12 THEN 'Décembre'
            END AS month,
            COALESCE(SUM(CASE WHEN type = 'entree' THEN montant ELSE 0 END), 0) AS entrees,
            COALESCE(SUM(CASE WHEN type = 'sortie' THEN montant ELSE 0 END), 0) AS sorties
        FROM (
            SELECT 'entree' AS type, COALESCE(p.montant_verse, 0) AS montant, p.date_paiement AS date_transaction FROM paiements p JOIN adhesions a ON p.id_adhesion = a.id_adhesion WHERE p.statut = 'paye' AND a.departement = :departement_id
            UNION ALL
            SELECT 'sortie' AS type, COALESCE(dr.montant_rembourse, 0) AS montant, dr.date_mise_a_jour AS date_transaction FROM demandes_remboursement dr JOIN adhesions a ON dr.id_adhesion = a.id_adhesion WHERE dr.statut = 'approuve' AND a.departement = :departement_id
        ) AS combined
        WHERE YEAR(date_transaction) = :year
        GROUP BY MONTH(date_transaction)
        ORDER BY MONTH(date_transaction)";
    $stmt = $pdo->prepare($query_chart);
    $stmt->execute(['departement_id' => $departement_id, 'year' => $year]);
    $chart_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $errors[] = "Erreur lors de la récupération des données : " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>💼 Transactions Financières - <?php echo htmlspecialchars($departement_nom, ENT_QUOTES, 'UTF-8'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-medical: linear-gradient(135deg, #1e3a8a, #3b82f6, #1d4ed8);
            --success-health: linear-gradient(135deg, #15803d, #22c55e, #16a34a);
            --warning-gold: linear-gradient(135deg, #d97706, #f59e0b, #b45309);
            --danger-alert: linear-gradient(135deg, #dc2626, #ef4444, #b91c1c);
            --glass-bg: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
            --shadow-glow: 0 25px 50px -12px rgba(59, 130, 246, 0.3);
            --shadow-hover: 0 35px 60px -15px rgba(59, 130, 246, 0.3);
        }

        * { font-family: 'Inter', sans-serif; }
        body { 
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 50%, #f0f9ff 100%);
            min-height: 100vh; 
            overflow-x: hidden;
            position: relative;
        }
        body::before {
            content: ''; 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%;
            background: radial-gradient(circle at 20% 50%, rgba(120, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 40% 80%, rgba(120, 219, 255, 0.1) 0%, transparent 50%);
            z-index: -1;
        }

        /* HEADER HERO */
        .header-hero {
            background: var(--primary-medical);
            border-radius: 24px; 
            padding: 1.5rem; 
            color: white; 
            margin-bottom: 1.5rem;
            position: relative; 
            overflow: hidden; 
            box-shadow: var(--shadow-glow);
            backdrop-filter: blur(20px);
            text-align: center;
        }
        .header-hero::before {
            content: ''; 
            position: absolute; 
            top: -50%; 
            left: -50%; 
            width: 200%; 
            height: 200%;
            background: conic-gradient(from 0deg, transparent, rgba(255,255,255,0.1), transparent 30%);
            animation: rotate 20s linear infinite; 
            opacity: 0.3;
        }
        @keyframes rotate { 100% { transform: rotate(360deg); } }
        .logo-hero {
            width: 60px; 
            height: 60px; 
            border-radius: 50%; 
            background: var(--glass-bg);
            display: flex; 
            align-items: center; 
            justify-content: center; 
            margin: 0 auto 0.5rem;
            backdrop-filter: blur(10px); 
            border: 2px solid var(--glass-border);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2); 
            animation: pulse 2s infinite;
        }
        .logo-hero img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
        @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.05); } }
        .header-title { 
            font-size: 1.8rem; 
            font-weight: 800; 
            margin-bottom: 0.25rem;
            background: linear-gradient(45deg, #fff, #e0f2fe); 
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent; 
            text-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header-subtitle { 
            font-size: 1rem; 
            opacity: 0.95; 
            font-weight: 400; 
            max-width: 700px; 
            margin: 0 auto;
        }

        /* BOUTONS D'ACTION */
        .actions-glass {
            background: var(--glass-bg); 
            backdrop-filter: blur(20px); 
            border-radius: 20px;
            padding: 1rem; 
            margin-bottom: 1.5rem; 
            border: 1px solid var(--glass-border);
            box-shadow: var(--shadow-glow);
        }
        .btn-glass {
            background: var(--glass-bg); 
            backdrop-filter: blur(20px); 
            border: 1px solid var(--glass-border);
            color: #1e40af; 
            font-weight: 600; 
            padding: 0.5rem 1rem; 
            border-radius: 15px;
            transition: all 0.3s ease; 
            margin: 0.25rem; 
            position: relative; 
            overflow: hidden;
        }
        .btn-glass::before {
            content: ''; 
            position: absolute; 
            top: 0; 
            left: -100%; 
            width: 100%; 
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            transition: left 0.5s;
        }
        .btn-glass:hover::before { left: 100%; }
        .btn-glass:hover { 
            transform: translateY(-3px) scale(1.05); 
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.2); 
            color: #1e40af;
        }
        .btn-primary-glass { background: linear-gradient(135deg, rgba(59,130,246,0.2), rgba(59,130,246,0.1)); }
        .btn-success-glass { background: linear-gradient(135deg, rgba(34,197,94,0.2), rgba(34,197,94,0.1)); }
        .btn-info-glass { background: linear-gradient(135deg, rgba(14,165,233,0.2), rgba(14,165,233,0.1)); }

        /* KPI CARDS */
        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .kpi-card {
            background: rgba(255,255,255,0.9);
            border-radius: 10px;
            padding: 1rem;
            text-align: center;
            box-shadow: var(--shadow-glow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px);
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }
        .kpi-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-medical);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }
        .kpi-card:hover::before { transform: scaleX(1); }
        .kpi-card:hover {
            transform: translateY(-8px) rotateX(5deg);
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.95);
        }
        .kpi-link {
            text-decoration: none;
            color: inherit;
            display: block;
        }
        .kpi-link:hover .kpi-card {
            transform: translateY(-8px) rotateX(5deg);
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.95);
        }
        .kpi-link:hover .kpi-icon {
            transform: scale(1.1) rotate(360deg);
        }
        .kpi-icon {
            font-size: 2rem;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 0.5rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        .kpi-value {
            font-size: 1.5rem;
            font-weight: 800;
            margin-bottom: 0.25rem;
            background: var(--primary-medical);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: colorPulse 3s ease infinite alternate;
        }
        @keyframes colorPulse {
            0%, 100% { color: #1d4ed8; }
            50% { color: #3b82f6; }
        }
        .kpi-label {
            font-size: 0.9rem;
            font-weight: 600;
            color: #1e293b;
        }

        /* CHARTS */
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .chart-card {
            background: rgba(255,255,255,0.9);
            border-radius: 20px;
            padding: 1rem;
            box-shadow: var(--shadow-glow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px);
            height: 300px;
            position: relative;
            animation: fadeScaleIn 1s ease forwards;
        }
        @keyframes fadeScaleIn {
            0% { opacity: 0; transform: scale(0.9); }
            100% { opacity: 1; transform: scale(1); }
        }
        .chart-header {
            font-size: 1rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            position: relative;
        }
        .chart-header::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 50px;
            height: 3px;
            background: var(--primary-medical);
            border-radius: 2px;
            animation: expandLine 0.5s ease forwards;
        }
        @keyframes expandLine {
            0% { width: 0; }
            100% { width: 50px; }
        }
        .chart-icon { font-size: 1.2rem; animation: iconBounce 1s ease infinite; }
        @keyframes iconBounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }

        /* TABLE */
        .table-card {
            background: rgba(255,255,255,0.9);
            border-radius: 20px;
            padding: 1rem;
            box-shadow: var(--shadow-glow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px);
            position: relative;
            animation: fadeScaleIn 1s ease forwards;
        }
        .table-header {
            font-size: 1rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            position: relative;
        }
        .table-header::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 50px;
            height: 3px;
            background: var(--primary-medical);
            border-radius: 2px;
            animation: expandLine 0.5s ease forwards;
        }
        .table-icon { font-size: 1.2rem; animation: iconBounce 1s ease infinite; }

        /* ALERTES */
        .alert-custom {
            border: none;
            border-radius: 15px;
            padding: 1rem 1.5rem;
            box-shadow: var(--shadow-glow);
            backdrop-filter: blur(10px);
            animation: slideInDown 0.5s ease;
        }
        @keyframes slideInDown {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        /* ANIMATIONS */
        .fade-in-up { 
            animation: fadeInUp 0.8s ease forwards; 
            opacity: 0;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .bounce-in { animation: bounceIn 0.6s ease; }
        @keyframes bounceIn {
            0% { transform: scale(0.3); opacity: 0; }
            50% { transform: scale(1.05); }
            70% { transform: scale(0.9); }
            100% { transform: scale(1); opacity: 1; }
        }

        /* RESPONSIVE IMPROVEMENTS */
        @media (max-width: 1200px) {
            .kpi-grid { grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); }
            .charts-grid { grid-template-columns: 1fr; }
            .chart-card { height: 400px; }
        }

        @media (max-width: 992px) {
            .header-title { font-size: 2rem; }
            .kpi-grid { grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); }
            .charts-grid { grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); }
            .actions-glass { flex-direction: column; gap: 1rem; }
            .actions-glass .d-flex { flex-direction: column; width: 100%; }
            .actions-glass label { margin-bottom: 0.5rem; }
            .actions-glass .form-select, .actions-glass .form-control { width: 100%; }
            .actions-glass button, .actions-glass a { width: 100%; margin-top: 0.5rem; }
        }

        @media (max-width: 768px) {
            .container { padding-left: 1rem; padding-right: 1rem; }
            .header-hero { padding: 1rem; border-radius: 16px; }
            .header-title { font-size: 1.6rem; }
            .logo-hero { width: 50px; height: 50px; }
            .kpi-grid, .charts-grid { grid-template-columns: 1fr; }
            .kpi-card { padding: 1.25rem; }
            .kpi-icon { width: 45px; height: 45px; font-size: 1.8rem; }
            .kpi-value { font-size: 1.4rem; }
            .actions-glass { padding: 1rem; }
            .btn-glass { font-size: 0.85rem; padding: 0.5rem 1rem; }
            .table-responsive { font-size: 0.85rem; }
            .header-subtitle { font-size: 0.95rem; }
            .chart-card { height: 350px; padding: 1.25rem; }
            .chart-header { font-size: 0.95rem; }
            .table-card { padding: 1.25rem; }
            .table-header { font-size: 0.95rem; }
            .pagination { font-size: 0.85rem; }
        }

        @media (max-width: 576px) {
            .header-title { font-size: 1.4rem; }
            .header-subtitle { font-size: 0.85rem; }
            .kpi-card { padding: 1rem; }
            .kpi-icon { width: 40px; height: 40px; font-size: 1.6rem; }
            .chart-card { height: 300px; padding: 1rem; }
            .table th, .table td { padding: 0.5rem; font-size: 0.8rem; }
            .pagination { flex-wrap: wrap; justify-content: center; }
        }
    </style>
</head>
<body>
    <div class="container py-4 px-3 position-relative">
        <!-- LOGO -->
        <div class="logo-hero mb-4 mx-auto d-flex justify-content-center bounce-in">
            <img src="Uploads/photos/logo1.png" alt="Logo Mutuelle Santé Matam">
        </div>

        <!-- HEADER HERO -->
        <div class="header-hero fade-in-up">
            <h1 class="header-title animate__animated animate__fadeInDown">
                💼 Transactions Financières - <?php echo htmlspecialchars($departement_nom, ENT_QUOTES, 'UTF-8'); ?>
            </h1>
            <p class="header-subtitle animate__animated animate__fadeInUp">
                Année <?php echo $year; ?>
            </p>
        </div>

        <!-- ALERTES -->
        <?php if (!empty($errors)): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-custom fade-in-up" style="animation-delay: 0.1s;">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- ACTIONS: FILTRES ET EXPORTATION -->
        <div class="actions-glass fade-in-up" style="animation-delay: 0.2s;">
            <form method="GET" class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div class="d-flex align-items-center">
                    <label for="year" class="me-2 fw-bold text-dark">Année :</label>
                    <select id="year" name="year" class="form-select bg-white border border-glass-border rounded-3 py-1 px-2 shadow-sm" onchange="this.form.submit()">
                        <?php for ($i = date('Y'); $i >= date('Y') - 5; $i--): ?>
                            <option value="<?php echo $i; ?>" <?php echo $i == $year ? 'selected' : ''; ?>><?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="d-flex align-items-center">
                    <label for="type" class="me-2 fw-bold text-dark">Type :</label>
                    <select id="type" name="type" class="form-select bg-white border border-glass-border rounded-3 py-1 px-2 shadow-sm" onchange="this.form.submit()">
                        <option value="">Tous</option>
                        <option value="entree" <?php echo $type_filter == 'entree' ? 'selected' : ''; ?>>Entrées</option>
                        <option value="sortie" <?php echo $type_filter == 'sortie' ? 'selected' : ''; ?>>Sorties</option>
                    </select>
                </div>
                <div class="d-flex align-items-center flex-grow-1">
                    <label for="search" class="me-2 fw-bold text-dark">Recherche :</label>
                    <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search_term); ?>" class="form-control bg-white border border-glass-border rounded-3 py-1 px-2 shadow-sm" placeholder="Description ou Créateur">
                    <button type="submit" class="btn-glass btn-primary-glass ms-2">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
                <a href="?export=csv&year=<?php echo $year; ?>" class="btn-glass btn-success-glass">
                    <i class="bi bi-file-earmark-arrow-down me-1"></i>Exporter
                </a>
            </form>
        </div>

        <!-- KPI TOTALS -->
        <div class="kpi-grid">
            <div class="kpi-card fade-in-up" style="animation-delay: 0.3s;">
                <div class="kpi-icon" style="background: var(--success-health); color: white;">
                    <i class="bi bi-arrow-up-circle-fill"></i>
                </div>
                <div class="kpi-value text-success"><?php echo number_format($total_entrees, 2, ',', ' '); ?> FCFA</div>
                <div class="kpi-label">Total Entrées</div>
            </div>
            <div class="kpi-card fade-in-up" style="animation-delay: 0.4s;">
                <div class="kpi-icon" style="background: var(--danger-alert); color: white;">
                    <i class="bi bi-arrow-down-circle-fill"></i>
                </div>
                <div class="kpi-value text-danger"><?php echo number_format($total_sorties, 2, ',', ' '); ?> FCFA</div>
                <div class="kpi-label">Total Sorties</div>
            </div>
            <div class="kpi-card fade-in-up" style="animation-delay: 0.5s;">
                <div class="kpi-icon" style="background: var(--primary-medical); color: white;">
                    <i class="bi bi-wallet-fill"></i>
                </div>
                <div class="kpi-value"><?php echo number_format($total_entrees - $total_sorties, 2, ',', ' '); ?> FCFA</div>
                <div class="kpi-label">Solde Net</div>
            </div>
        </div>

        <!-- CHART ÉVOLUTION -->
        <div class="charts-grid">
            <div class="chart-card fade-in-up" style="animation-delay: 0.6s;">
                <div class="chart-header">
                    <i class="bi bi-bar-chart text-info chart-icon"></i>
                    Évolution Mensuelle (<?php echo $year; ?>)
                </div>
                <canvas id="evolutionChart"></canvas>
            </div>
        </div>

        <!-- TABLE DES TRANSACTIONS -->
        <div class="table-card fade-in-up" style="animation-delay: 0.7s;">
            <div class="table-header">
                <i class="bi bi-journal-text text-primary table-icon"></i>
                Liste des Transactions
            </div>
            <?php if (empty($transactions)): ?>
                <div class="alert alert-info alert-custom">
                    <i class="bi bi-info-circle-fill me-2"></i>Aucune transaction.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover table-striped bg-white rounded-3 shadow-sm">
                        <thead class="table-primary">
                            <tr>
                                <th>Type</th>
                                <th>Montant (FCFA)</th>
                                <th>Description</th>
                                <th>Date</th>
                                <th>Créé par</th>
                                <th>Méthode</th>
                                <th>Référence Transaction</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($transactions as $transaction): ?>
                                <tr class="<?php echo $transaction['type'] === 'entree' ? 'table-success' : 'table-danger'; ?>">
                                    <td><i class="bi <?php echo $transaction['type'] === 'entree' ? 'bi-arrow-up-circle-fill text-success' : 'bi-arrow-down-circle-fill text-danger'; ?> me-1"></i><?php echo htmlspecialchars($transaction['type']); ?></td>
                                    <td><?php echo number_format((float)$transaction['montant'], 2, ',', ' '); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['description']); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['date_transaction']); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['created_by_nom'] ?: 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['methode'] ?: 'N/A'); ?></td>
                                    <td><?php echo ($transaction['methode'] === 'wave') ? htmlspecialchars($transaction['reference_transaction'] ?: 'N/A') : 'N/A'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Pagination" class="mt-3">
                        <ul class="pagination justify-content-center">
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?year=<?php echo $year; ?>&type=<?php echo urlencode($type_filter); ?>&search=<?php echo urlencode($search_term); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.js"></script>
    <script>
        const chartData = {
            labels: <?php echo json_encode(array_column($chart_data, 'month')); ?>,
            entrees: <?php echo json_encode(array_column($chart_data, 'entrees')); ?>,
            sorties: <?php echo json_encode(array_column($chart_data, 'sorties')); ?>
        };

        const createBarChart = (id, labels, datasets) => {
            const ctx = document.getElementById(id)?.getContext('2d');
            if (ctx && labels.length > 0) {
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: datasets
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: true } },
                        scales: { y: { beginAtZero: true } },
                        animation: { duration: 2000, easing: 'easeInOutQuart' }
                    }
                });
            }
        };

        createBarChart('evolutionChart', chartData.labels, [
            { label: 'Entrées', data: chartData.entrees, backgroundColor: '#22c55e' },
            { label: 'Sorties', data: chartData.sorties, backgroundColor: '#ef4444' }
        ]);
    </script>
</body>
</html>
<?php require_once '../includes/footer.php'; ?>