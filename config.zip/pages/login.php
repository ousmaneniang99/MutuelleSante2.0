<?php
// pages/login.php
ob_start(); // Démarrer le buffer de sortie
// Vérifier l'existence des fichiers requis
require_once '../includes/auth.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Initialiser les variables
$errors = [];
$success = null;

// Traiter la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = isset($_POST['email']) ? sanitize(trim($_POST['email'])) : '';
    $mot_de_passe = isset($_POST['mot_de_passe']) ? trim($_POST['mot_de_passe']) : '';

    // Validation des champs
    if (empty($email)) {
        $errors[] = "L'email est requis.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "L'email est invalide.";
    }
    if (empty($mot_de_passe)) {
        $errors[] = "Le mot de passe est requis.";
    }

    // Si aucune erreur de validation, tenter la connexion
    if (empty($errors)) {
        try {
            // Requête pour récupérer l'utilisateur
            $stmt = $pdo->prepare("
                SELECT id_utilisateur, nom, prenom, email, mot_de_passe, role, departement, statut 
                FROM utilisateurs 
                WHERE email = :email
            ");
            $stmt->execute(['email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // Vérifier si l'utilisateur existe
            if (!$user) {
                $errors[] = "Aucun compte associé à l'email : " . htmlspecialchars($email);
            } elseif ($user['statut'] !== 'actif') {
                $errors[] = "Votre compte est inactif. Contactez l'administrateur.";
            } elseif (!password_verify($mot_de_passe, $user['mot_de_passe'])) {
                $errors[] = "Mot de passe incorrect pour l'email : " . htmlspecialchars($email);
            } else {
                // Connexion réussie : initialiser la session
                $_SESSION['user_id'] = $user['id_utilisateur'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['departement'] = $user['departement'];
                $_SESSION['nom'] = $user['nom'];
                $_SESSION['prenom'] = $user['prenom'];
                $_SESSION['last_activity'] = time();

                // Enregistrer l'activité dans logs_activites
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO logs_activites (id_utilisateur, action, details, date_action) 
                        VALUES (:id_utilisateur, :action, :details, NOW())
                    ");
                    $stmt->execute([
                        'id_utilisateur' => $user['id_utilisateur'],
                        'action' => 'login',
                        'details' => "Connexion réussie pour {$user['email']}"
                    ]);
                } catch (PDOException $e) {
                    $errors[] = "Erreur lors de l'enregistrement de l'activité.";
                }

                // Rediriger selon le rôle
                $redirect_urls = [
                    'coordinateur_regional' => '../directeur/dashboard_coordinateur.php',
                    'agent_mobilisateur' => 'dashboard_agent.php',
                    'directeur_departemental' => 'dashboard_directeur.php',
                    'prestataire_soins' => 'dashboard_prestataire.php',
                    'comptable' => 'dashboard_comptable.php',
                    'admin' => 'dashboard_admin.php' // Ajout du rôle admin
                ];
                $redirect = $redirect_urls[$user['role']] ?? 'dashboard.php';
                header("Location: $redirect");
                ob_end_flush();
                exit();
            }
        } catch (PDOException $e) {
            $errors[] = "Une erreur est survenue. Veuillez réessayer.";
            error_log("Erreur de connexion à la base de données : " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Mutuelle Santé Matam</title>
    <link rel="icon" type="image/png" href="Uploads/photos/logo1.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;
            --secondary: #4b5563;
            --accent: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --background: #f8fafc;
            --card-bg: #ffffff;
            --text: #1f2a44;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #e6effa 0%, #f4f7fa 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 1rem;
        }

        .login-card {
            max-width: 450px;
            width: 100%;
            background: var(--card-bg);
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeIn 0.8s ease-in-out;
        }

        .login-header {
            background: linear-gradient(135deg, var(--primary), #1e40af);
            padding: 2rem;
            text-align: center;
            color: white;
        }

        .login-header img {
            max-width: 100px;
            border-radius: 50%;
            margin-bottom: 1rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }

        .login-header h2 {
            font-size: 1.75rem;
            font-weight: 700;
            margin: 0;
        }

        .login-header p {
            font-size: 1rem;
            opacity: 0.9;
            margin: 0.5rem 0 0;
        }

        .card-body {
            padding: 2rem;
        }

        .form-label {
            font-weight: 500;
            color: var(--text);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .form-control {
            border-radius: 8px;
            border: 1px solid #d1d5db;
            padding: 0.75rem 1rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 8px rgba(37, 99, 235, 0.2);
            outline: none;
        }

        .btn-primary {
            background: var(--primary);
            border: none;
            border-radius: 8px;
            padding: 0.75rem;
            font-weight: 500;
            font-size: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        .btn-primary:hover {
            background: #1e40af;
            transform: translateY(-2px);
        }

        .alert {
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            animation: slideIn 0.5s ease-in-out;
        }

        .alert-dismissible .btn-close {
            padding: 1rem;
        }

        .input-group-text {
            cursor: pointer;
            background: #f1f5f9;
            border: 1px solid #d1d5db;
            border-radius: 0 8px 8px 0;
        }

        .forgot-password {
            display: block;
            text-align: right;
            margin-top: 0.5rem;
            font-size: 0.875rem;
            color: var(--primary);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .forgot-password:hover {
            color: #1e40af;
            text-decoration: underline;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-10px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @media (max-width: 576px) {
            .login-card {
                margin: 1rem;
            }
            .login-header {
                padding: 1.5rem;
            }
            .login-header img {
                max-width: 80px;
            }
            .login-header h2 {
                font-size: 1.5rem;
            }
            .card-body {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-card">
        <!-- Login Header with Logo -->
        <div class="login-header">
            <img src="Uploads/photos/logo1.png" alt="Logo de Mutuelle Santé Matam" aria-label="Logo de Mutuelle Santé Matam">
            <h2>Mutuelle Santé Matam</h2>
            <p>Connectez-vous pour gérer vos adhésions et prestations</p>
        </div>
        <!-- Login Form -->
        <div class="card-body">
            <?php if ($errors): ?>
                <?php foreach ($errors as $error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
            <?php if (isset($_GET['error']) && $_GET['error'] === 'not_authenticated'): ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    Veuillez vous connecter pour accéder à cette page.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <?php if (isset($_GET['error']) && $_GET['error'] === 'session_expired'): ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    Votre session a expiré. Veuillez vous reconnecter.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="email" class="form-label"><i class="bi bi-envelope"></i> Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="mot_de_passe" class="form-label"><i class="bi bi-key"></i> Mot de passe</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="mot_de_passe" name="mot_de_passe" required>
                        <span class="input-group-text" onclick="togglePassword()" aria-label="Afficher/masquer le mot de passe">
                            <i class="bi bi-eye" id="togglePasswordIcon"></i>
                        </span>
                    </div>
                    <a href="forgot_password.php" class="forgot-password">Mot de passe oublié ?</a>
                </div>
                <button type="submit" name="login" class="btn btn-primary w-100"><i class="bi bi-box-arrow-in-right"></i> Se connecter</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('mot_de_passe');
            const toggleIcon = document.getElementById('togglePasswordIcon');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('bi-eye');
                toggleIcon.classList.add('bi-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('bi-eye-slash');
                toggleIcon.classList.add('bi-eye');
            }
        }
    </script>
</body>
</html>
<?php
ob_end_flush(); // Vider le buffer de sortie
?>