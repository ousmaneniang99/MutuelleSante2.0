<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
define('INCLUDE_CHECK', true);
require_once '../includes/functions.php';

// Destroy the session
session_unset();
session_destroy();

// Clear any flash messages
setFlashMessage('success', 'Vous avez été déconnecté avec succès.');

// Redirect to login page
header('Location: login.php');
exit;
?>