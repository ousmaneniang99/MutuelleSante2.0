<?php
// pages/manage_users.php
ob_start();
require_once '../includes/header.php';
checkSessionTimeout();
checkRole('admin');

$errors = [];
$agents = [];
$total_pages = 0;
$departements = [];

// Paramètres de pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Filtre par département
$departement_filter = isset($_GET['departement']) && is_numeric($_GET['departement']) && $_GET['departement'] > 0 ? (int)$_GET['departement'] : 'all';
$departement_where = ($departement_filter !== 'all') ? "AND u.departement = :departement" : "";

// Récupérer la liste des départements pour le filtre
try {
    $stmt = $pdo->prepare("SELECT id_departement, nom FROM departements ORDER BY nom ASC");
    $stmt->execute();
    $departements = $stmt->fetchAll(PDO::FETCH_KEY_PAIR); // id => nom for quick lookup
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des départements.";
    error_log("Erreur PDO : " . $e->getMessage());
}

// Récupérer les agents
try {
    $query = "
        SELECT u.id_utilisateur, u.nom, u.prenom, u.email, u.telephone, u.departement, u.statut,
               (SELECT COUNT(*) FROM adhesions a WHERE a.created_by = u.id_utilisateur) AS adhesions_count
        FROM utilisateurs u
        WHERE u.role = 'agent_mobilisateur'
        $departement_where
        ORDER BY adhesions_count DESC, u.nom ASC, u.prenom ASC
        LIMIT :perPage OFFSET :offset
    ";
    $stmt = $pdo->prepare($query);
    if ($departement_filter !== 'all') {
        $stmt->bindValue(':departement', (int)$departement_filter, PDO::PARAM_INT);
    }
    $stmt->bindValue(':perPage', (int)$perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
    $stmt->execute();
    $agents = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Compter le total des agents
    $query_count = "
        SELECT COUNT(*) 
        FROM utilisateurs u
        WHERE u.role = 'agent_mobilisateur'
        $departement_where
    ";
    $stmt_count = $pdo->prepare($query_count);
    if ($departement_filter !== 'all') {
        $stmt_count->bindValue(':departement', (int)$departement_filter, PDO::PARAM_INT);
    }
    $stmt_count->execute();
    $total_agents = $stmt_count->fetchColumn() ?: 0;
    $total_pages = ceil($total_agents / $perPage);
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des agents : " . $e->getMessage();
    error_log("Erreur PDO dans manage_users.php : " . $e->getMessage() . " - Departement Filter: " . $departement_filter);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Agents - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-medical: linear-gradient(135deg, #1e3a8a, #3b82f6, #1d4ed8);
            --success-health: linear-gradient(135deg, #15803d, #22c55e, #16a34a);
            --warning-gold: linear-gradient(135deg, #d97706, #f59e0b, #b45309);
            --danger-alert: linear-gradient(135deg, #dc2626, #ef4444, #b91c1c);
            --glass-bg: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
            --shadow-glow: 0 25px 50px -12px rgba(59, 130, 246, 0.3);
            --shadow-hover: 0 35px 60px -15px rgba(59, 130, 246, 0.3);
            --text: #1e293b;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 50%, #f0f9ff 100%);
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 20% 50%, rgba(120, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 40% 80%, rgba(120, 219, 255, 0.1) 0%, transparent 50%);
            z-index: -1;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }

        .header-hero {
            background: var(--primary-medical);
            border-radius: 24px;
            padding: 2rem;
            color: white;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-glow);
            backdrop-filter: blur(20px);
            text-align: center;
        }

        .header-hero::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: conic-gradient(from 0deg, transparent, rgba(255,255,255,0.1), transparent 30%);
            animation: rotate 20s linear infinite;
            opacity: 0.3;
        }

        @keyframes rotate { 100% { transform: rotate(360deg); } }

        .header-title {
            font-size: 2.2rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            background: linear-gradient(45deg, #fff, #e0f2fe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-subtitle {
            font-size: 1.1rem;
            opacity: 0.95;
            font-weight: 400;
            max-width: 700px;
            margin: 0 auto;
        }

        .card {
            background: rgba(255,255,255,0.9);
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: var(--shadow-glow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px);
            transition: all 0.4s ease;
            margin-bottom: 2rem;
        }

        .card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.95);
        }

        .card-header {
            background: var(--primary-medical);
            color: white;
            font-weight: 600;
            border-radius: 10px 10px 0 0;
            padding: 0.75rem;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }

        .filter-container {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            border: 1px solid var(--glass-border);
            box-shadow: var(--shadow-glow);
        }

        .form-select, .btn-filter {
            border-radius: 8px;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .form-select:focus, .btn-filter:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 6px rgba(59, 130, 246, 0.2);
            outline: none;
        }

        .btn-filter {
            background: var(--primary-medical);
            color: white;
            border: none;
        }

        .btn-filter:hover {
            background: #1e3a8a;
            transform: scale(1.03);
            box-shadow: 0 3px 10px rgba(37, 99, 235, 0.2);
        }

        .search-container {
            position: relative;
            max-width: 100%;
            margin-bottom: 1.5rem;
        }

        .search-input {
            border-radius: 10px;
            padding: 0.6rem 1rem 0.6rem 2.5rem;
            border: 1px solid var(--glass-border);
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            width: 100%;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            color: var(--text);
        }

        .search-input:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 6px rgba(59, 130, 246, 0.2);
            outline: none;
        }

        .search-icon {
            position: absolute;
            left: 0.8rem;
            top: 50%;
            transform: translateY(-50%);
            color: #6b7280;
            font-size: 1rem;
        }

        .table {
            background: var(--card-bg);
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
        }

        .table thead {
            background: rgba(229, 231, 235, 0.9);
            color: var(--text);
            font-weight: 600;
            font-size: 0.85rem;
        }

        .table tbody tr {
            transition: background 0.2s ease;
        }

        .table tbody tr:hover {
            background: rgba(243, 244, 246, 0.9);
        }

        .table td, .table th {
            padding: 0.75rem;
            font-size: 0.9rem;
            white-space: nowrap;
        }

        .badge {
            font-size: 0.8rem;
            padding: 0.4rem 0.8rem;
            border-radius: 12px;
        }

        .pagination .page-link {
            border-radius: 6px;
            margin: 0 3px;
            color: #3b82f6;
            border: 1px solid #d1d5db;
            font-size: 0.85rem;
            padding: 0.4rem 0.7rem;
            transition: all 0.3s ease;
        }

        .pagination .page-item.active .page-link {
            background: var(--primary-medical);
            border-color: #3b82f6;
            color: white;
        }

        .pagination .page-link:hover {
            background: #e5e7eb;
            color: #1e3a8a;
        }

        .alert {
            border-radius: 8px;
            padding: 0.6rem 1rem;
            margin-bottom: 0.75rem;
            font-size: 0.9rem;
            animation: slideIn 0.5s ease-in-out;
            display: flex;
            align-items: center;
            gap: 0.4rem;
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border: 1px solid var(--glass-border);
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-15px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @media (max-width: 992px) {
            .container { padding: 1.5rem 0.75rem; }
            .header-title { font-size: 1.8rem; }
            .table td, .table th { font-size: 0.8rem; padding: 0.5rem; }
        }

        @media (max-width: 768px) {
            .table thead { display: none; }
            .table tbody tr {
                display: block;
                margin-bottom: 0.75rem;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                padding: 0.5rem;
                background: var(--card-bg);
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            }

            .table tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: 0.8rem;
                padding: 0.4rem 0.5rem;
                border: none;
            }

            .table tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                font-size: 0.8rem;
                color: #6b7280;
                width: 40%;
            }

            .table tbody td[data-label="Détails"] {
                display: flex;
                flex-wrap: wrap;
                gap: 0.4rem;
                justify-content: center;
            }
        }

        @media (max-width: 576px) {
            .btn-primary { font-size: 0.75rem; padding: 0.3rem 0.6rem; }
            .alert { font-size: 0.8rem; padding: 0.5rem 0.75rem; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header Hero -->
        <div class="header-hero fade-in-up">
            <h1 class="header-title animate__animated animate__fadeInDown">
                👥 Gestion des Agents
            </h1>
            <p class="header-subtitle animate__animated animate__fadeInUp">
                Consultez et gérez les agents mobilisateurs de la mutuelle santé de Matam
            </p>
        </div>

        <!-- Alerts -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i> <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Filtre par département -->
        <div class="filter-container fade-in-up" style="animation-delay: 0.2s;">
            <div class="card-header mb-3">
                <i class="bi bi-filter"></i> Filtrer par Département
            </div>
            <form method="GET" action="">
                <input type="hidden" name="page" value="1">
                <div class="row g-3">
                    <div class="col-md-4">
                        <select class="form-select" name="departement" aria-label="Sélectionner un département">
                            <option value="all" <?php echo $departement_filter === 'all' ? 'selected' : ''; ?>>Tous les départements</option>
                            <?php foreach ($departements as $id => $nom): ?>
                                <option value="<?php echo htmlspecialchars($id); ?>" <?php echo $departement_filter === $id ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($nom); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-filter w-100"><i class="bi bi-search"></i> Filtrer</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Liste des Agents -->
        <div class="card fade-in-up" style="animation-delay: 0.4s;">
            <div class="card-header">
                <i class="bi bi-person-lines-fill"></i> Liste des Agents Mobilisateurs
            </div>
            <div class="card-body">
                <div class="search-container">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" id="search_agents" class="form-control search-input" placeholder="Rechercher un agent..." aria-label="Rechercher un agent par nom, prénom, email ou téléphone">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped" id="agents-table">
                        <thead>
                            <tr>
                                <th scope="col">Nom</th>
                                <th scope="col">Prénom</th>
                                <th scope="col">Email</th>
                                <th scope="col">Téléphone</th>
                                <th scope="col">Département</th>
                                <th scope="col">Statut</th>
                                <th scope="col">Adhésions Créées</th>
                                <th scope="col">Détails</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($agents)): ?>
                                <tr><td colspan="8" class="text-center">Aucun agent trouvé.</td></tr>
                            <?php else: ?>
                                <?php foreach ($agents as $agent): ?>
                                    <tr>
                                        <td data-label="Nom"><?php echo htmlspecialchars($agent['nom'] ?? 'N/A'); ?></td>
                                        <td data-label="Prénom"><?php echo htmlspecialchars($agent['prenom'] ?? 'N/A'); ?></td>
                                        <td data-label="Email"><?php echo htmlspecialchars($agent['email'] ?? 'N/A'); ?></td>
                                        <td data-label="Téléphone"><?php echo htmlspecialchars($agent['telephone'] ?? 'N/A'); ?></td>
                                        <td data-label="Département"><?php echo isset($agent['departement']) && isset($departements[$agent['departement']]) ? htmlspecialchars($departements[$agent['departement']]) : 'N/A'; ?></td>
                                        <td data-label="Statut">
                                            <span class="badge bg-<?php echo ($agent['statut'] === 'actif') ? 'success' : 'danger'; ?>">
                                                <?php echo htmlspecialchars(ucfirst($agent['statut'] ?? 'N/A')); ?>
                                            </span>
                                        </td>
                                        <td data-label="Adhésions Créées"><?php echo htmlspecialchars($agent['adhesions_count'] ?? 0); ?></td>
                                        <td data-label="Détails">
                                            <a href="voir.php?agent_id=<?php echo htmlspecialchars($agent['id_utilisateur']); ?>" class="btn btn-primary btn-sm" aria-label="Voir les adhésions de <?php echo htmlspecialchars($agent['nom'] . ' ' . $agent['prenom']); ?>">
                                                <i class="bi bi-eye"></i> Adhésions
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Pagination des agents" class="mt-3">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&departement=<?php echo htmlspecialchars($departement_filter); ?>" aria-label="Page précédente"><i class="bi bi-chevron-left"></i></a>
                            </li>
                            <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&departement=<?php echo htmlspecialchars($departement_filter); ?>" aria-label="Page <?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&departement=<?php echo htmlspecialchars($departement_filter); ?>" aria-label="Page suivante"><i class="bi bi-chevron-right"></i></a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.js"></script>
    <script>
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }

        const searchInput = document.getElementById('search_agents');
        if (searchInput) {
            const searchFunc = debounce(function(e) {
                const search = e.target.value.toLowerCase();
                const rows = document.querySelectorAll('#agents-table tbody tr');
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(search) ? '' : 'none';
                });
            }, 300);
            searchInput.addEventListener('input', searchFunc);
        }
    </script>
</body>
</html>
<?php
require_once __DIR__ . '/../includes/footer.php';
ob_end_flush();
?>