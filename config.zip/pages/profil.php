<?php
// pages/profil.php
require_once '../includes/header.php';

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();
$user = null;

// Fetch user details
try {
    $stmt = $pdo->prepare("
        SELECT nom, prenom, email, telephone, role, photo_path, date_naissance, lieu_naissance, adresse, numero_carte_identite, profession
        FROM utilisateurs
        WHERE id_utilisateur = ? AND statut = 'actif'
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $errors[] = "Utilisateur non trouvé ou compte désactivé.";
    }
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des données : " . htmlspecialchars($e->getMessage());
    error_log("Erreur dans profil.php : " . $e->getMessage());
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
    } else {
        $current_password = trim($_POST['current_password'] ?? '');
        $new_password = trim($_POST['new_password'] ?? '');
        $confirm_password = trim($_POST['confirm_password'] ?? '');

        // Validate inputs
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $errors[] = "Tous les champs de mot de passe sont obligatoires.";
        } elseif ($new_password !== $confirm_password) {
            $errors[] = "Les nouveaux mots de passe ne correspondent pas.";
        } elseif (strlen($new_password) < 8) {
            $errors[] = "Le nouveau mot de passe doit comporter au moins 8 caractères.";
        } else {
            // Verify current password
            try {
                $stmt = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id_utilisateur = ?");
                $stmt->execute([$_SESSION['user_id']]);
                $stored_password = $stmt->fetchColumn();

                if (!password_verify($current_password, $stored_password)) {
                    $errors[] = "Le mot de passe actuel est incorrect.";
                } else {
                    // Update password
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE utilisateurs SET mot_de_passe = ?, date_mise_a_jour = NOW() WHERE id_utilisateur = ?");
                    $stmt->execute([$hashed_password, $_SESSION['user_id']]);

                    // Log activity
                    logActivity($pdo, $_SESSION['user_id'], "Modification du mot de passe");
                    $success = "Mot de passe modifié avec succès.";
                }
            } catch (PDOException $e) {
                $errors[] = "Erreur lors de la modification du mot de passe : " . htmlspecialchars($e->getMessage());
                error_log("Erreur dans profil.php : " . $e->getMessage());
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Utilisateur - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .card-header {
            border-bottom: none;
            padding: 1.5rem;
            font-size: 1.25rem;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .alert {
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert i {
            font-size: 1.2rem;
        }
        .form-control {
            border-radius: 8px;
            padding: 0.75rem;
            border: 1px solid #ced4da;
            transition: border-color 0.3s ease;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
        }
        .btn-primary, .btn-secondary {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 2rem;
        }
        .user-photo {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid #ced4da;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 1rem;
        }
        .user-photo-container {
            text-align: center;
        }
        .modal-content {
            border-radius: 10px;
        }
        .modal-body img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-person-circle me-2"></i>Mon Profil</h2>

        <!-- Messages -->
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill"></i>
                <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php if ($user): ?>
            <!-- User Information -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <i class="bi bi-person-circle me-2"></i>Informations Personnelles
                </div>
                <div class="card-body">
                    <div class="user-photo-container">
                        <img src="<?php echo !empty($user['photo_path']) && file_exists($user['photo_path']) ? htmlspecialchars($user['photo_path']) : 'https://via.placeholder.com/150?text=Utilisateur'; ?>" 
                             alt="Photo de <?php echo htmlspecialchars(($user['nom'] ?? 'Utilisateur') . ' ' . ($user['prenom'] ?? '')); ?>" 
                             class="user-photo"
                             data-bs-toggle="modal" 
                             data-bs-target="#photoModal"
                             style="cursor: pointer;"
                             onerror="this.src='https://via.placeholder.com/150?text=Utilisateur';">
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong><i class="bi bi-person me-2"></i>Nom :</strong> <?php echo htmlspecialchars($user['nom'] ?? 'Non spécifié'); ?></p>
                            <p><strong><i class="bi bi-person me-2"></i>Prénom :</strong> <?php echo htmlspecialchars($user['prenom'] ?? 'Non spécifié'); ?></p>
                            <p><strong><i class="bi bi-envelope me-2"></i>Email :</strong> <?php echo htmlspecialchars($user['email'] ?? 'Non spécifié'); ?></p>
                            <p><strong><i class="bi bi-telephone me-2"></i>Téléphone :</strong> <?php echo htmlspecialchars($user['telephone'] ?? 'Non spécifié'); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong><i class="bi bi-person-badge me-2"></i>Rôle :</strong> 
                                <?php echo htmlspecialchars(
                                    $user['role'] === 'coordinateur_regional' ? 'Coordinateur Régional' :
                                    ($user['role'] === 'directeur_departemental' ? 'Directeur Départemental' :
                                    ($user['role'] === 'agent_mobilisateur' ? 'Agent Mobilisateur' : 'Prestataire de Soins'))
                                ); ?>
                            </p>
                            <p><strong><i class="bi bi-calendar me-2"></i>Date de Naissance :</strong> <?php echo htmlspecialchars($user['date_naissance'] ?? 'Non spécifiée'); ?></p>
                            <p><strong><i class="bi bi-geo-alt me-2"></i>Lieu de Naissance :</strong> <?php echo htmlspecialchars($user['lieu_naissance'] ?? 'Non spécifié'); ?></p>
                            <p><strong><i class="bi bi-house-door me-2"></i>Adresse :</strong> <?php echo htmlspecialchars($user['adresse'] ?? 'Non spécifiée'); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong><i class="bi bi-person-vcard me-2"></i>Numéro de Carte d'Identité :</strong> <?php echo htmlspecialchars($user['numero_carte_identite'] ?? 'Non spécifié'); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong><i class="bi bi-briefcase me-2"></i>Profession :</strong> <?php echo htmlspecialchars($user['profession'] ?? 'Non spécifiée'); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Password Change Form -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="bi bi-lock me-2"></i>Modifier le Mot de Passe
                </div>
                <div class="card-body">
                    <form method="POST" id="password_form">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                        <input type="hidden" name="change_password" value="1">
                        <div class="mb-3">
                            <label for="current_password" class="form-label"><i class="bi bi-lock me-2"></i>Mot de Passe Actuel <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" id="current_password" name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="new_password" class="form-label"><i class="bi bi-lock me-2"></i>Nouveau Mot de Passe <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label"><i class="bi bi-lock me-2"></i>Confirmer le Nouveau Mot de Passe <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        <div class="d-flex justify-content-between">
                            <button type="submit" class="btn btn-primary"><i class="bi bi-save me-2"></i>Modifier le Mot de Passe</button>
                            <a href="dashboard_<?php echo htmlspecialchars($_SESSION['role'] === 'directeur_departemental' ? 'directeur' : ($_SESSION['role'] === 'agent_mobilisateur' ? 'agent' : 'prestataire')); ?>.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Retour</a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Modal for enlarged photo -->
            <div class="modal fade" id="photoModal" tabindex="-1" aria-labelledby="photoModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="photoModalLabel">Photo de Profil</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body text-center">
                            <img src="<?php echo !empty($user['photo_path']) && file_exists($user['photo_path']) ? htmlspecialchars($user['photo_path']) : 'https://via.placeholder.com/150?text=Utilisateur'; ?>" 
                                 alt="Photo de <?php echo htmlspecialchars(($user['nom'] ?? 'Utilisateur') . ' ' . ($user['prenom'] ?? '')); ?>" 
                                 class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Client-side validation for password change
        document.getElementById('password_form').addEventListener('submit', function(e) {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;

            if (newPassword.length < 8) {
                alert('Le nouveau mot de passe doit comporter au moins 8 caractères.');
                e.preventDefault();
            } else if (newPassword !== confirmPassword) {
                alert('Les nouveaux mots de passe ne correspondent pas.');
                e.preventDefault();
            }
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>