<?php
// pages/record_payment.php
require_once '../includes/header.php';
checkRole('agent_mobilisateur');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_adhesion = intval($_POST['id_adhesion']);
    $montant_verse = floatval($_POST['montant_verse']);
    $methode = sanitize($_POST['methode']);
    $reference = generateReceiptNumber();

    $stmt = $pdo->prepare("INSERT INTO paiements (id_adhesion, date_paiement, montant_verse, methode, statut, reference_transaction) 
                           VALUES (?, CURDATE(), ?, ?, 'paye', ?)");
    $stmt->execute([$id_adhesion, $montant_verse, $methode, $reference]);

    $stmt = $pdo->prepare("SELECT a.num_adherent, u.nom, u.prenom 
                           FROM adhesions a 
                           JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                           WHERE a.id_adhesion = ?");
    $stmt->execute([$id_adhesion]);
    $adhesion = $stmt->fetch();

    $success = "Paiement enregistré. Reçu: $reference";
    $receipt = [
        'reference' => $reference,
        'num_adherent' => $adhesion['num_adherent'],
        'nom' => $adhesion['nom'],
        'prenom' => $adhesion['prenom'],
        'montant' => formatCurrency($montant_verse),
        'methode' => $methode,
        'date' => date('Y-m-d')
    ];
}

$stmt_adhesions = $pdo->prepare("SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom 
                                 FROM adhesions a 
                                 JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                                 WHERE u.departement = ? AND a.statut IN ('en_attente_validation', 'active')");
$stmt_adhesions->execute([$_SESSION['departement']]);
$adhesions = $stmt_adhesions->fetchAll();
?>
<h2 class="mb-4">Enregistrer un Paiement</h2>
<?php if (isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
    <div class="card mb-4">
        <div class="card-header">Reçu de Paiement</div>
        <div class="card-body">
            <p><strong>Référence:</strong> <?php echo $receipt['reference']; ?></p>
            <p><strong>Adhérent:</strong> <?php echo $receipt['num_adherent'] . ' - ' . $receipt['nom'] . ' ' . $receipt['prenom']; ?></p>
            <p><strong>Montant:</strong> <?php echo $receipt['montant']; ?></p>
            <p><strong>Méthode:</strong> <?php echo $receipt['methode']; ?></p>
            <p><strong>Date:</strong> <?php echo $receipt['date']; ?></p>
            <button onclick="window.print()" class="btn btn-secondary">Imprimer Reçu</button>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-body">
        <form method="POST">
            <div class="mb-3">
                <label for="id_adhesion" class="form-label">Adhésion</label>
                <select class="form-control" id="id_adhesion" name="id_adhesion" required>
                    <option value="">Sélectionner une adhésion</option>
                    <?php foreach ($adhesions as $adhesion): ?>
                        <option value="<?php echo $adhesion['id_adhesion']; ?>">
                            <?php echo $adhesion['num_adherent'] . ' - ' . $adhesion['nom'] . ' ' . $adhesion['prenom']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="montant_verse" class="form-label">Montant Versé</label>
                <input type="number" step="0.01" class="form-control" id="montant_verse" name="montant_verse" required>
            </div>
            <div class="mb-3">
                <label for="methode" class="form-label">Méthode de Paiement</label>
                <select class="form-control" id="methode" name="methode" required>
                    <option value="mobile_money">Mobile Money</option>
                    <option value="espece">Espèces</option>
                    <option value="virement">Virement</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Enregistrer</button>
        </form>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>