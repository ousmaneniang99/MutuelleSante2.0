<?php
// pages/referencements_destinataire.php
ob_start();
require_once '../includes/header.php';
checkRole('prestataire_soins'); 

$errors = [];
$referencements = [];

// === RÉCUPÉRER L'ID DU PRESTATAIRE CONNECTÉ ===
$id_prestataire = null;
$logo_path = '../assets/images/logo-default.png';

try {
    $stmt = $pdo->prepare("
        SELECT p.id_prestataire, p.nom AS nom_prestataire, p.logo, n.niveau 
        FROM prestataires p 
        JOIN niveau n ON p.id_niveau = n.id_niveau 
        WHERE p.id_utilisateur = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $prestataire = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$prestataire) throw new Exception("Profil incomplet.");

    $id_prestataire = $prestataire['id_prestataire'];
    $logo_path = !empty($prestataire['logo']) && file_exists("../" . $prestataire['logo'])
        ? "../" . $prestataire['logo']
        : $logo_path;

} catch (Exception $e) {
    $errors[] = "Erreur système.";
}

if (!$id_prestataire) {
    $errors[] = "Compte non rattaché à un prestataire.";
}

// === CHARGER LES RÉFÉRENCEMENTS REÇUS ===
if (empty($errors)) {
    try {
        $stmt = $pdo->prepare("
            SELECT 
                r.id_referencement, r.date_referencement, r.referencement AS fichier, r.statut, r.commentaire,
                r.consulte, r.date_consultation,
                b.code_beneficiaire, b.nom AS nom_benef, b.prenom AS prenom_benef,
                ps.nom AS source_nom,
                u.nom AS directeur_nom
            FROM notes_referencement r
            JOIN beneficiaires b ON r.id_beneficiaire = b.id_beneficiaire
            JOIN prestataires ps ON r.id_prestataire_source = ps.id_prestataire
            LEFT JOIN utilisateurs u ON r.approved_by = u.id_utilisateur
            WHERE r.id_prestataire_destinataire = ? 
              AND r.statut IN ('approuve', 'rejete')
            ORDER BY r.date_referencement DESC
        ");
        $stmt->execute([$id_prestataire]);
        $referencements = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $errors[] = "Erreur chargement.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Référencements Reçus - <?= htmlspecialchars($prestataire['nom_prestataire'] ?? 'Hôpital') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <style>
        :root {
            --primary: #10b981;
            --primary-light: #34d399;
            --success: #059669;
            --warning: #f59e0b;
            --danger: #ef4444;
            --dark: #0f172a;
            --light: #f8fafc;
            --gray: #64748b;
            --border: rgba(0,0,0,0.1);
            --glass: rgba(255,255,255,0.15);
            --shadow: 0 8px 32px rgba(0,0,0,0.12);
            --radius: 1.5rem;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
            font-family: 'Inter', sans-serif;
            color: var(--dark);
            min-height: 100vh;
        }

        .header {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            padding: 2.5rem 0;
            position: relative;
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(16,185,129,0.25);
        }

        .header::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><path d="M0,0 L100,30 L100,100 L0,100 Z" fill="rgba(255,255,255,0.1)"/></svg>') no-repeat bottom;
            background-size: cover;
        }

        .logo {
            width: 80px; height: 80px;
            object-fit: cover;
            border-radius: 20px;
            border: 4px solid rgba(255,255,255,0.3);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
            transition: var(--transition);
        }

        .logo:hover { transform: scale(1.08) rotate(3deg); }

        .page-title {
            font-size: 2.2rem;
            font-weight: 800;
            margin: 0;
        }

        .glass-card {
            background: var(--glass);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .glass-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }

        .table-card {
            background: white;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .table-header {
            background: linear-gradient(135deg, var(--primary), var(--success));
            color: white;
            padding: 1.5rem 2rem;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .table th {
            background: var(--primary);
            color: white;
            font-weight: 600;
            border: none;
        }

        .table td {
            vertical-align: middle;
            padding: 1.2rem 1.5rem;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        .table tr:hover {
            background: rgba(16,185,129,0.05);
            transform: scale(1.01);
            transition: var(--transition);
        }

        .badge-approuve {
            background: linear-gradient(135deg, var(--success), #10b981);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.85rem;
            box-shadow: 0 4px 15px rgba(16,185,129,0.3);
        }

        .badge-rejete {
            background: linear-gradient(135deg, var(--danger), #f87171);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.85rem;
            box-shadow: 0 4px 15px rgba(239,68,68,0.3);
        }

        .badge-utilise {
            background: var(--warning);
            color: white;
            font-size: 0.75rem;
            padding: 0.3rem 0.8rem;
            border-radius: 50px;
        }

        .file-link {
            color: var(--success);
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }

        .file-link:hover {
            color: var(--primary);
            text-decoration: underline;
        }

        .info-box {
            background: #fefce8;
            border-left: 5px solid var(--warning);
            padding: 1.2rem;
            border-radius: 12px;
            margin: 0.5rem 0;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
        }

        .empty-state i {
            font-size: 5rem;
            color: #94a3b8;
            margin-bottom: 1.5rem;
        }

        .empty-state h3 {
            font-weight: 700;
            color: var(--success);
            margin-bottom: 1rem;
        }

        .btn-refresh, .btn-back {
            border-radius: 50px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            transition: var(--transition);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .btn-refresh {
            background: linear-gradient(135deg, var(--primary), var(--success));
            color: white;
            border: none;
        }

        .btn-refresh:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(16,185,129,0.3);
        }

        .btn-back {
            background: white;
            color: var(--dark);
            border: 1.5px solid rgba(0,0,0,0.1);
        }

        .btn-back:hover {
            background: #f1f5f9;
            transform: translateY(-2px);
        }

        .alert {
            border-radius: 14px;
            padding: 1rem 1.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 12px;
            border: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .alert-danger { background: #fee2e2; color: #991b1b; }

        @media (max-width: 768px) {
            .page-title { font-size: 1.8rem; }
            .table-header { font-size: 1.1rem; padding: 1rem; }
            .table td { padding: 1rem; font-size: 0.9rem; }
            .btn-refresh, .btn-back { width: 100%; margin: 0.5rem 0; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="header position-relative">
    <div class="container position-relative">
        <div class="row align-items-center">
            <div class="col-md-2 text-center">
                <img src="<?= $logo_path ?>" alt="Logo" class="logo" data-aos="zoom-in">
            </div>
            <div class="col-md-8 text-center">
                <h1 class="page-title" data-aos="fade-up" data-aos-delay="100">
                    Référencements Reçus
                </h1>
                <p class="mb-0 opacity-90" data-aos="fade-up" data-aos-delay="200">
                    Historique des transferts vers votre établissement
                </p>
            </div>
            <div class="col-md-2 text-end">
                <a href="dashboard_prestataire.php" class="btn btn-outline-light rounded-pill px-4 py-2" data-aos="fade-left" data-aos-delay="300">
                    <i class="bi bi-arrow-left"></i> Retour
                </a>
            </div>
        </div>
    </div>
</div>

<div class="container mt-4">

    <!-- ERREURS -->
    <?php foreach ($errors as $e): ?>
        <div class="alert alert-danger" data-aos="fade-up">
            <i class="bi bi-exclamation-triangle-fill"></i> <?= htmlspecialchars($e) ?>
        </div>
    <?php endforeach; ?>

    <!-- LISTE -->
    <?php if (!empty($referencements)): ?>
        <div class="table-card" data-aos="fade-up" data-aos-delay="100">
            <div class="table-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-inbox-fill me-2"></i> Référencements reçus (<?= count($referencements) ?>)</span>
                <a href="referencements_destinataire.php" class="text-white text-decoration-none">
                    <i class="bi bi-arrow-clockwise"></i> Actualiser
                </a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Bénéficiaire</th>
                            <th>Source</th>
                            <th>Document</th>
                            <th>Statut</th>
                            <th>Consultation</th>
                            <th>Décideur</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($referencements as $r): ?>
                            <tr data-aos="fade-up" data-aos-delay="50">
                                <td><strong><?= date('d/m/Y', strtotime($r['date_referencement'])) ?></strong></td>
                                <td>
                                    <div class="fw-bold text-success"><?= htmlspecialchars($r['code_beneficiaire']) ?></div>
                                    <small class="text-muted"><?= htmlspecialchars($r['nom_benef'] . ' ' . $r['prenom_benef']) ?></small>
                                </td>
                                <td><span class="fw-semibold"><?= htmlspecialchars($r['source_nom']) ?></span></td>
                                <td>
                                    <?php if ($r['fichier'] && file_exists('../' . $r['fichier'])): ?>
                                        <a href="../<?= htmlspecialchars($r['fichier']) ?>" target="_blank" class="file-link">
                                            <i class="bi bi-file-earmark-check"></i> Voir
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted"><i class="bi bi-file-x"></i> —</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($r['statut'] === 'approuve'): ?>
                                        <span class="badge-approuve">
                                            <i class="bi bi-check-circle"></i> Approuvé
                                        </span>
                                    <?php else: ?>
                                        <span class="badge-rejete">
                                            <i class="bi bi-x-circle"></i> Rejeté
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($r['statut'] === 'approuve' && $r['consulte'] == 1): ?>
                                        <span class="badge badge-utilise">
                                            <i class="bi bi-check2"></i> Utilisé
                                        </span>
                                        <small class="d-block text-muted">
                                            <?= $r['date_consultation'] ? date('d/m/Y', strtotime($r['date_consultation'])) : '—' ?>
                                        </small>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <small class="text-muted"><?= htmlspecialchars($r['directeur_nom'] ?? 'Système') ?></small>
                                </td>
                            </tr>

                            <!-- COMMENTAIRE REJET -->
                            <?php if ($r['statut'] === 'rejete' && !empty($r['commentaire'])): ?>
                                <tr data-aos="fade-up" data-aos-delay="100">
                                    <td colspan="7" class="p-0">
                                        <div class="info-box mx-3 my-2">
                                            <h6 class="mb-2"><i class="bi bi-chat-left-text-fill text-danger"></i> Commentaire du directeur :</h6>
                                            <p class="mb-0 text-muted"><?= nl2br(htmlspecialchars($r['commentaire'])) ?></p>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php else: ?>
        <div class="glass-card text-center py-5" data-aos="fade-up">
            <div class="empty-state">
                <i class="bi bi-inbox"></i>
                <h3 class="mt-3">Aucun référencement reçu</h3>
                <p class="text-muted mb-4">Vous serez notifié dès qu’un patient vous sera transféré.</p>
                
            </div>
        </div>
    <?php endif; ?>

    <!-- BOUTONS -->
    <div class="text-center mt-4" data-aos="fade-up" data-aos-delay="200">
        <a href="referencements_destinataire.php" class="btn btn-refresh me-3">
            <i class="bi bi-arrow-clockwise"></i> Actualiser
        </a>
        <a href="dashboard_prestataire.php" class="btn btn-back">
            <i class="bi bi-arrow-left"></i> Tableau de bord
        </a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
    AOS.init({ duration: 800, once: true });
</script>
</body>
</html>

<?php 
ob_end_flush(); 
require_once '../includes/footer.php'; 
?>