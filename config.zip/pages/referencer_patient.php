<?php
// pages/referencer_patient.php
ob_start();
require_once '../includes/header.php';
checkRole('prestataire_soins');

$errors = [];
$success = '';
$csrf_token = generateCsrfToken();

// === INFOS PRESTATAIRE ===
$id_prestataire = null;
$niveau_source = null;
$logo_path = '../assets/images/logo-default.png';

try {
    $stmt = $pdo->prepare("
        SELECT p.id_prestataire, p.id_niveau, p.nom AS nom_prestataire, p.logo, n.niveau 
        FROM prestataires p 
        JOIN niveau n ON p.id_niveau = n.id_niveau 
        WHERE p.id_utilisateur = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $prestataire = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$prestataire) throw new Exception("Profil incomplet.");
    
    $id_prestataire = $prestataire['id_prestataire'];
    $niveau_source = $prestataire['id_niveau'];
    $niveau_source_label = $prestataire['niveau'];
    $logo_path = !empty($prestataire['logo']) && file_exists("../" . $prestataire['logo'])
        ? "../" . $prestataire['logo']
        : $logo_path;

} catch (Exception $e) {
    $errors[] = "Erreur accès structure.";
}

if (!$id_prestataire || !$niveau_source) {
    die("Structure non configurée.");
}

// === RÈGLES HIÉRARCHIE ===
$allowed_niveaux = [];
$niveau_dest_label = '';

switch ($niveau_source) {
    case 1: $allowed_niveaux = [2]; $niveau_dest_label = 'Centre de santé'; break;
    case 2: $allowed_niveaux = [3]; $niveau_dest_label = 'Hôpital'; break;
    case 3: $allowed_niveaux = [3]; $niveau_dest_label = 'Hôpital'; break;
    default: $errors[] = "Niveau invalide.";
}

// === BÉNÉFICIAIRES ===
$beneficiaires = [];
try {
    $stmt = $pdo->prepare("
        SELECT b.id_beneficiaire, b.code_beneficiaire, b.nom, b.prenom, a.num_adherent
        FROM beneficiaires b
        JOIN adhesions a ON b.id_adhesion = a.id_adhesion
        WHERE a.departement = ?
          AND b.statut = 'actif'
          AND b.date_entree <= DATE_SUB(NOW(), INTERVAL 1 MONTH)
          AND (b.date_sortie IS NULL OR b.date_sortie > NOW())
        ORDER BY b.nom, b.prenom
    ");
    $stmt->execute([$_SESSION['departement']]);
    $beneficiaires = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $errors[] = "Erreur chargement bénéficiaires.";
}

// === STRUCTURES DESTINATAIRES ===
$prestataires_dest = [];
if (!empty($allowed_niveaux)) {
    try {
        $placeholders = str_repeat('?,', count($allowed_niveaux) - 1) . '?';
        $sql = "SELECT id_prestataire, nom FROM prestataires WHERE id_prestataire != ? AND id_niveau IN ($placeholders) AND statut = 'actif' ORDER BY nom";
        $params = array_merge([$id_prestataire], $allowed_niveaux);
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $prestataires_dest = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $errors[] = "Erreur chargement structures.";
    }
}

// === TRAITEMENT FORMULAIRE ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrfToken($_POST['token'] ?? '')) {
    $id_beneficiaire = (int)($_POST['id_beneficiaire'] ?? 0);
    $id_dest = (int)($_POST['id_prestataire_destinataire'] ?? 0);

    if ($id_beneficiaire <= 0) $errors[] = "Sélectionnez un patient.";
    if ($id_dest <= 0) $errors[] = "Sélectionnez une structure.";

    if ($id_dest > 0) {
        $stmt = $pdo->prepare("SELECT id_niveau FROM prestataires WHERE id_prestataire = ?");
        $stmt->execute([$id_dest]);
        if (!in_array($stmt->fetchColumn(), $allowed_niveaux)) {
            $errors[] = "Structure non autorisée.";
        }
    }

    $fichier_path = '';
    if (empty($errors)) {
        if (!isset($_FILES['referencement']) || $_FILES['referencement']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = "Fichier requis.";
        } else {
            $file = $_FILES['referencement'];
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
            $max_size = 5 * 1024 * 1024;

            if (!in_array($ext, $allowed)) {
                $errors[] = "Format non autorisé.";
            } elseif ($file['size'] > $max_size) {
                $errors[] = "Fichier trop volumineux.";
            } else {
                $upload_dir = __DIR__ . '/../uploads/referencements/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

                $filename = "ref_" . $id_prestataire . "_" . time() . "_" . uniqid() . "." . $ext;
                $fichier_path = 'uploads/referencements/' . $filename;
                $full_path = $upload_dir . $filename;

                if (!move_uploaded_file($file['tmp_name'], $full_path)) {
                    $errors[] = "Échec de l'upload.";
                }
            }
        }
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("
                INSERT INTO notes_referencement
                (date_referencement, referencement, statut, id_prestataire_source, id_prestataire_destinataire, id_beneficiaire)
                VALUES (CURDATE(), ?, 'en_attente_approbation', ?, ?, ?)
            ");
            $stmt->execute([$fichier_path, $id_prestataire, $id_dest, $id_beneficiaire]);
            $pdo->commit();
            $success = "Référencement envoyé avec succès !";
            $_POST = [];
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Erreur envoi : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Référencement - <?= htmlspecialchars($niveau_source_label) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <style>
        :root {
            --primary: #10b981;
            --primary-light: #34d399;
            --success: #059669;
            --warning: #f59e0b;
            --danger: #ef4444;
            --dark: #0f172a;
            --light: #f8fafc;
            --gray: #64748b;
            --border: rgba(0,0,0,0.1);
            --glass: rgba(255,255,255,0.15);
            --shadow: 0 8px 32px rgba(0,0,0,0.12);
            --radius: 1.5rem;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
            font-family: 'Inter', sans-serif;
            color: var(--dark);
            min-height: 100vh;
        }

        .header {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            padding: 2.5rem 0;
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><path d="M0,0 L100,30 L100,100 L0,100 Z" fill="rgba(255,255,255,0.1)"/></svg>') no-repeat bottom;
            background-size: cover;
        }

        .logo {
            width: 80px; height: 80px;
            object-fit: cover;
            border-radius: 20px;
            border: 4px solid rgba(255,255,255,0.3);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
            transition: var(--transition);
        }

        .logo:hover { transform: scale(1.08) rotate(3deg); }

        .page-title {
            font-size: 2.2rem;
            font-weight: 800;
            margin: 0;
        }

        .glass-card {
            background: var(--glass);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 2rem;
            transition: var(--transition);
        }

        .glass-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }

        .form-control, .form-select {
            background: rgba(255,255,255,0.8);
            border: 1.5px solid rgba(0,0,0,0.1);
            border-radius: 14px;
            padding: 0.9rem 1.2rem;
            font-size: 1rem;
            transition: var(--transition);
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(16,185,129,0.25);
            background: white;
        }

        .file-input {
            border: 2px dashed rgba(0,0,0,0.15);
            border-radius: 18px;
            padding: 2.5rem;
            text-align: center;
            cursor: pointer;
            background: rgba(255,255,255,0.7);
            transition: var(--transition);
            position: relative;
        }

        .file-input:hover, .file-input.dragover {
            border-color: var(--primary);
            background: rgba(16,185,129,0.1);
            transform: scale(1.02);
        }

        .file-input input { position: absolute; left: -9999px; }

        .btn-upload, .btn-camera {
            background: linear-gradient(135deg, var(--primary), var(--success));
            color: white;
            border: none;
            border-radius: 14px;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: var(--transition);
            box-shadow: 0 4px 15px rgba(16,185,129,0.3);
        }

        .btn-upload:hover, .btn-camera:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(16,185,129,0.4);
        }

        .btn-send {
            background: linear-gradient(135deg, var(--primary), var(--success));
            color: white;
            border: none;
            border-radius: 14px;
            padding: 0.9rem 2.5rem;
            font-weight: 700;
            font-size: 1.1rem;
            transition: var(--transition);
            box-shadow: 0 6px 20px rgba(16,185,129,0.4);
        }

        .btn-send:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(16,185,129,0.5);
        }

        .alert {
            border-radius: 14px;
            padding: 1rem 1.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 12px;
            border: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .alert-success { background: #d1fae5; color: #065f46; }
        .alert-danger { background: #fee2e2; color: #991b1b; }

        .file-preview {
            max-height: 280px;
            border-radius: 14px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }

        @media (max-width: 768px) {
            .page-title { font-size: 1.8rem; }
            .glass-card { padding: 1.5rem; }
            .btn-send { width: 100%; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="header position-relative">
    <div class="container position-relative">
        <div class="row align-items-center">
            <div class="col-md-2 text-center">
                <img src="<?= $logo_path ?>" alt="Logo" class="logo" data-aos="zoom-in">
            </div>
            <div class="col-md-8 text-center">
                <h1 class="page-title" data-aos="fade-up" data-aos-delay="100">
                    Référencement Patient
                </h1>
                <p class="mb-0 opacity-90" data-aos="fade-up" data-aos-delay="200">
                    De <strong><?= htmlspecialchars($niveau_source_label) ?></strong> to <strong><?= htmlspecialchars($niveau_dest_label) ?></strong>
                </p>
            </div>
            <div class="col-md-2 text-end">
                <a href="dashboard_prestataire.php" class="btn btn-outline-light rounded-pill px-4 py-2" data-aos="fade-left" data-aos-delay="300">
                    <i class="bi bi-arrow-left"></i> Retour
                </a>
            </div>
        </div>
    </div>
</div>

<div class="container mt-4">

    <!-- SUCCESS -->
    <?php if ($success): ?>
        <div class="alert alert-success" data-aos="fade-up">
            <i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($success) ?>
            <button class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- ERREURS -->
    <?php foreach ($errors as $e): ?>
        <div class="alert alert-danger" data-aos="fade-up">
            <i class="bi bi-exclamation-triangle-fill"></i> <?= htmlspecialchars($e) ?>
            <button class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    <?php endforeach; ?>

    <!-- FORMULAIRE -->
    <div class="glass-card" data-aos="fade-up" data-aos-delay="100">
        <form method="POST" enctype="multipart/form-data" id="ref-form">
            <input type="hidden" name="token" value="<?= $csrf_token ?>">
            <div class="row g-4">

                <!-- PATIENT -->
                <div class="col-md-6">
                    <label class="form-label fw-bold">
                        <i class="bi bi-person-fill"></i> Patient <span class="text-danger">*</span>
                    </label>
                    <select name="id_beneficiaire" class="form-select form-select-lg" required>
                        <option value="">Sélectionner...</option>
                        <?php foreach ($beneficiaires as $b): ?>
                            <option value="<?= $b['id_beneficiaire'] ?>">
                                <?= htmlspecialchars("{$b['code_beneficiaire']} - {$b['nom']} {$b['prenom']} (Adh: {$b['num_adherent']})") ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- DESTINATAIRE -->
                <div class="col-md-6">
                    <label class="form-label fw-bold">
                        <i class="bi bi-hospital-fill"></i> Destinataire <span class="text-danger">*</span>
                    </label>
                    <select name="id_prestataire_destinataire" class="form-select form-select-lg" required>
                        <option value="">Choisir...</option>
                        <?php foreach ($prestataires_dest as $p): ?>
                            <option value="<?= $p['id_prestataire'] ?>"><?= htmlspecialchars($p['nom']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- FICHIER -->
                <div class="col-12">
                    <label class="form-label fw-bold">
                        <i class="bi bi-file-earmark-medical-fill"></i> Document <span class="text-danger">*</span>
                    </label>
                    <div class="file-input">
                        <!-- Caméra arrière activée sur mobile -->
                        <input type="file" name="referencement" id="file-upload" accept="image/*,application/pdf" 
                               capture="environment" required>
                        <div class="upload-content">
                            <i class="bi bi-cloud-upload fs-1 text-success"></i>
                            <p class="mt-3 fw-semibold">Glissez ou cliquez</p>
                            <p class="text-muted small">PDF, JPG, PNG — max 5 Mo</p>
                            <div class="d-flex justify-content-center gap-2 mt-3">
                                <button type="button" class="btn btn-upload" onclick="document.getElementById('file-upload').click()">
                                    <i class="bi bi-folder2-open"></i> Parcourir
                                </button>
                                <button type="button" class="btn btn-camera" id="camera-btn">
                                    <i class="bi bi-camera"></i> Photo
                                </button>
                            </div>
                        </div>
                        <div id="preview" class="mt-3"></div>
                    </div>
                </div>

                <!-- ENVOYER -->
                <div class="col-12 text-end">
                    <button type="submit" class="btn btn-send">
                        <i class="bi bi-send-fill"></i> Envoyer le Référencement
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- RETOUR -->
    <div class="text-center mt-4" data-aos="fade-up" data-aos-delay="200">
        <a href="dashboard_prestataire.php" class="btn btn-outline-secondary rounded-pill px-5 py-3">
            <i class="bi bi-arrow-left"></i> Tableau de bord
        </a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
    AOS.init({ duration: 800, once: true });

    // File Upload
    const fileInput = document.getElementById('file-upload');
    const preview = document.getElementById('preview');
    const uploadContent = document.querySelector('.upload-content');
    const cameraBtn = document.getElementById('camera-btn');
    const dropZone = document.querySelector('.file-input');

    // Caméra arrière activée
    if (/Mobi|Android/i.test(navigator.userAgent)) {
        fileInput.setAttribute('capture', 'environment');
    }

    dropZone.addEventListener('click', e => { if (!e.target.closest('button')) fileInput.click(); });
    cameraBtn.addEventListener('click', () => { 
        fileInput.setAttribute('accept', 'image/*');
        fileInput.click();
    });

    fileInput.addEventListener('change', function() {
        const file = this.files[0];
        if (!file) return;
        uploadContent.style.display = 'none';
        preview.innerHTML = '';

        const reader = new FileReader();
        reader.onload = e => {
            if (file.type === 'application/pdf') {
                preview.innerHTML = `
                    <div class="text-center p-4 bg-white rounded border shadow-sm">
                        <i class="bi bi-file-earmark-pdf fs-1 text-danger"></i>
                        <p class="mt-2 fw-semibold">${file.name}</p>
                    </div>`;
            } else {
                preview.innerHTML = `<img src="${e.target.result}" class="img-fluid rounded shadow-sm file-preview">`;
            }
        };
        reader.readAsDataURL(file);
    });

    // Drag & Drop
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(ev => dropZone.addEventListener(ev, e => { e.preventDefault(); e.stopPropagation(); }));
    ['dragenter', 'dragover'].forEach(ev => dropZone.addEventListener(ev, () => dropZone.classList.add('dragover')));
    ['dragleave', 'drop'].forEach(ev => dropZone.addEventListener(ev, () => dropZone.classList.remove('dragover')));
    dropZone.addEventListener('drop', e => {
        const files = e.dataTransfer.files;
        if (files.length) { fileInput.files = files; fileInput.dispatchEvent(new Event('change')); }
    });
</script>
</body>
</html>

<?php ob_end_flush(); require_once '../includes/footer.php'; ?>