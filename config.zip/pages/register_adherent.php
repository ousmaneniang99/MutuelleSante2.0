<?php
// pages/register_adherent.php
ob_start(); // Démarrer le buffer de sortie pour éviter les erreurs de headers
require_once '../includes/header.php';
checkRole('agent_mobilisateur');

$errors = [];
$success = null;
$adhesion_id = isset($_SESSION['pending_adhesion_id']) ? $_SESSION['pending_adhesion_id'] : null;
$csrf_token = generateCsrfToken();

// Calculer la date de sortie (date actuelle + 1 an)
$date_sortie = date('Y-m-d', strtotime('+1 year'));

// Chemins des images QR code
$qr_codes = [
    'wave' => '../Uploads/documents/wave.jpg',
    'orange_money' => '../Uploads/documents/OM.jpg'
];

// Vérifier l'existence des fichiers QR code
foreach ($qr_codes as $method => $path) {
    if (!file_exists($path)) {
        $_SESSION['errors'] = ["L'image QR code pour $method est introuvable."];
        header('Location: dashboard_agent.php');
        ob_end_flush();
        exit();
    }
}

// Fetch tarifs
$stmt = $pdo->prepare("SELECT type_adhesion, cotisation_base, tarif_beneficiaire FROM tarifs WHERE date_fin IS NULL");
$stmt->execute();
$tarifs = $stmt->fetchAll(PDO::FETCH_ASSOC);
$tarifs_map = array_column($tarifs, null, 'type_adhesion');
if (empty($tarifs_map)) {
    $_SESSION['errors'] = ["Aucun tarif défini. Veuillez contacter l'administrateur."];
    header('Location: dashboard_agent.php');
    ob_end_flush();
    exit();
}

// Map département ID to prefix
$departement_prefixes = [
    1 => 'MT', // Matam
    2 => 'KA', // Kanel
    3 => 'RN'  // Ranerou
];

// Vérifier que le département de l'agent est défini et valide
$agent_departement = isset($_SESSION['departement']) ? (int)$_SESSION['departement'] : null;
if (!$agent_departement || !isset($departement_prefixes[$agent_departement])) {
    $_SESSION['errors'] = ["Erreur : Département de l'agent invalide ou non défini."];
    header('Location: dashboard_agent.php');
    ob_end_flush();
    exit();
}

// Handle adherent submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_adherent']) && empty($errors)) {
    if (!verifyCsrfToken($_POST['csrf_token'])) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
    } else {
        $nom = sanitize($_POST['nom'] ?? '');
        $prenom = sanitize($_POST['prenom'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $mot_de_passe = !empty($_POST['mot_de_passe']) ? password_hash($_POST['mot_de_passe'], PASSWORD_BCRYPT) : null;
        $departement = $agent_departement; // Forcer le département à celui de l'agent
        $numero_carte_identite = sanitize($_POST['numero_carte_identite'] ?? '');
        $date_naissance = sanitize($_POST['date_naissance'] ?? '');
        $lieu_naissance = sanitize($_POST['lieu_naissance'] ?? '');
        $telephone = sanitize($_POST['telephone'] ?? '');
        $profession = sanitize($_POST['profession'] ?? '');
        $type_adhesion = sanitize($_POST['type_adhesion'] ?? '');

        // Validate inputs
        if (empty($nom) || empty($prenom) || empty($numero_carte_identite) || empty($date_naissance) || empty($telephone) || empty($type_adhesion)) {
            $errors[] = "Tous les champs obligatoires doivent être remplis.";
        }
        if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "L'email est invalide.";
        }
        if (!validatePhone($telephone)) {
            $errors[] = "Le numéro de téléphone est invalide (9-15 chiffres).";
        }
        if (strtotime($date_naissance) > strtotime('-18 years')) {
            $errors[] = "L'adhérent doit avoir au moins 18 ans.";
        }
        if (!isset($tarifs_map[$type_adhesion])) {
            $errors[] = "Type d'adhésion invalide ou tarif non défini.";
        }

        if (empty($errors)) {
            try {
                $pdo->beginTransaction();

                // Check if email or numero_carte_identite exists
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM utilisateurs WHERE email = ? OR numero_carte_identite = ?");
                $stmt->execute([$email ?: null, $numero_carte_identite]);
                if ($stmt->fetchColumn() > 0) {
                    $errors[] = "L'email ou le numéro de carte d'identité existe déjà.";
                } else {
                    // Insert utilisateur (sans photo_path)
                    $stmt = $pdo->prepare("
                        INSERT INTO utilisateurs (
                            nom, prenom, email, mot_de_passe, role, departement, 
                            numero_carte_identite, date_naissance, lieu_naissance, 
                            telephone, profession, date_inscription, statut
                        ) VALUES (?, ?, ?, ?, 'adherent', ?, ?, ?, ?, ?, ?, CURDATE(), 'actif')
                    ");
                    $stmt->execute([
                        $nom, $prenom, $email ?: null, $mot_de_passe, $departement, 
                        $numero_carte_identite, $date_naissance, $lieu_naissance, 
                        $telephone, $profession
                    ]);
                    $id_utilisateur = $pdo->lastInsertId();

                    // Generate num_adherent with department-specific prefix
                    $prefix = $departement_prefixes[$departement] ?? 'ADH';
                    $num_adherent = $prefix . str_pad($id_utilisateur, 6, '0', STR_PAD_LEFT) . rand(100, 999);

                    // Insert adhesion
                    $stmt = $pdo->prepare("
                        INSERT INTO adhesions (
                            id_utilisateur, num_adherent, date_adhesion, type_adhesion, 
                            cotisation_annuelle, date_expiration, statut, created_by, departement
                        ) VALUES (?, ?, CURDATE(), ?, ?, DATE_ADD(CURDATE(), INTERVAL 1 YEAR), 'en_attente_validation', ?, ?)
                    ");
                    $stmt->execute([
                        $id_utilisateur, $num_adherent, $type_adhesion, 
                        $tarifs_map[$type_adhesion]['cotisation_base'], $_SESSION['user_id'], $departement
                    ]);
                    $adhesion_id = $pdo->lastInsertId();

                    // Store adhesion_id and adherent data in session
                    $_SESSION['pending_adhesion_id'] = $adhesion_id;
                    $_SESSION['pending_type_adhesion'] = $type_adhesion;
                    $_SESSION['adherent_data'] = [
                        'nom' => $nom,
                        'prenom' => $prenom,
                        'date_naissance' => $date_naissance
                    ];

                    // Log activity
                    logActivity($pdo, $_SESSION['user_id'], 'register_adherent', "Adhérent ID $id_utilisateur, adhésion $num_adherent enregistrée temporairement");

                    $pdo->commit();
                    // Rediriger immédiatement pour éviter l'affichage du message de succès
                    header("Location: register_adherent.php");
                    ob_end_flush();
                    exit();
                }
            } catch (PDOException $e) {
                $pdo->rollBack();
                error_log("Erreur PDO : " . $e->getMessage());
                $errors[] = "Une erreur s'est produite lors de l'enregistrement. Veuillez réessayer.";
            }
        }
    }
}

// Handle beneficiaries with payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_beneficiaires']) && $adhesion_id) {
    if (!verifyCsrfToken($_POST['csrf_token'])) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
    } else {
        $beneficiaires = $_POST['beneficiaires'] ?? [];
        $montant_verse = floatval($_POST['montant_verse'] ?? 0);
        $methode = sanitize($_POST['methode'] ?? '');
        $reference_transaction = sanitize($_POST['reference_transaction'] ?? '');

        // Fetch adhesion details
        $stmt = $pdo->prepare("SELECT type_adhesion, id_utilisateur FROM adhesions WHERE id_adhesion = ?");
        $stmt->execute([$adhesion_id]);
        $adhesion = $stmt->fetch(PDO::FETCH_ASSOC);
        $min_beneficiaires = 3;
        $max_beneficiaires = 20;
        $new_count = count($beneficiaires);

        if ($new_count < $min_beneficiaires) {
            try {
                $pdo->beginTransaction();
                // Delete utilisateur (adhesion will be deleted via ON DELETE CASCADE)
                $stmt = $pdo->prepare("DELETE FROM utilisateurs WHERE id_utilisateur = ?");
                $stmt->execute([$adhesion['id_utilisateur']]);
                // Log activity
                logActivity($pdo, $_SESSION['user_id'], 'delete_adherent', "Adhérent ID {$adhesion['id_utilisateur']} supprimé car moins de $min_beneficiaires bénéficiaires");
                $pdo->commit();

                // Clear session
                unset($_SESSION['pending_adhesion_id']);
                unset($_SESSION['pending_type_adhesion']);
                unset($_SESSION['adherent_data']);

                $errors[] = "L'adhérent a été supprimé car moins de $min_beneficiaires bénéficiaires ont été fournis. Veuillez recommencer.";
                // Redirect to reset the form
                header("Location: register_adherent.php");
                ob_end_flush();
                exit();
            } catch (PDOException $e) {
                $pdo->rollBack();
                error_log("Erreur PDO lors de la suppression : " . $e->getMessage());
                $errors[] = "Erreur lors de la suppression de l'adhérent. Veuillez réessayer.";
            }
        } else {
            // Calculate required cotisation
            $cotisation_base = $tarifs_map[$adhesion['type_adhesion']]['cotisation_base'];
            $tarif_beneficiaire = $tarifs_map[$adhesion['type_adhesion']]['tarif_beneficiaire'];
            $cotisation_due = $cotisation_base + ($new_count * $tarif_beneficiaire);

            // Validate payment inputs
            if (empty($montant_verse) || empty($methode) || empty($reference_transaction)) {
                $errors[] = "Tous les champs de paiement doivent être remplis.";
            } elseif ($montant_verse != $cotisation_due) {
                $errors[] = "Le montant versé ($montant_verse FCFA) doit être exactement égal à la cotisation requise ($cotisation_due FCFA).";
            } else {
                try {
                    $pdo->beginTransaction();

                    // Insert payment
                    $montant_restant = 0;
                    $cotisation_avance = 0;
                    $stmt = $pdo->prepare("
                        INSERT INTO paiements (
                            id_adhesion, date_paiement, periodicite, cotisation_due, 
                            montant_verse, montant_restant, cotisation_avance, methode, 
                            statut, reference_transaction, created_by
                        ) VALUES (?, CURDATE(), 'annuelle', ?, ?, ?, ?, ?, 'en_attente', ?, ?)
                    ");
                    $stmt->execute([
                        $adhesion_id, $cotisation_due, $montant_verse, $montant_restant, 
                        $cotisation_avance, $methode, $reference_transaction, $_SESSION['user_id']
                    ]);

                    // Insert beneficiaries
                    foreach ($beneficiaires as $index => $b) {
                        $nom_b = sanitize($b['nom'] ?? '');
                        $prenom_b = sanitize($b['prenom'] ?? '');
                        $date_naissance_b = sanitize($b['date_naissance'] ?? '');
                        $relation = sanitize($b['relation'] ?? '');
                        $code_beneficiaire = 'BEN' . str_pad($adhesion_id, 6, '0', STR_PAD_LEFT) . rand(100, 999);
                        $photo_base64 = isset($b['photo_base64']) ? $b['photo_base64'] : null;
                        $photo_path = null;

                        if (empty($nom_b) || empty($prenom_b) || empty($date_naissance_b) || empty($relation)) {
                            $errors[] = "Tous les champs obligatoires des bénéficiaires doivent être remplis.";
                            continue;
                        }
                        if (strtotime($date_sortie) <= strtotime($date_naissance_b)) {
                            $errors[] = "La date de sortie doit être postérieure à la date de naissance.";
                            continue;
                        }

                        // Handle photo
                        if ($photo_base64 && strpos($photo_base64, 'data:image') === 0) {
                            $photo_data = explode(',', $photo_base64);
                            if (count($photo_data) === 2) {
                                $image_data = base64_decode($photo_data[1]);
                                if (strlen($image_data) > 2 * 1024 * 1024) {
                                    $errors[] = "La photo capturée pour le bénéficiaire " . ($index + 1) . " dépasse la taille maximale de 2MB.";
                                } else {
                                    $file_name = 'photo_benef_' . uniqid() . '.jpg';
                                    $upload_dir = '../Uploads/photos/';
                                    $file_path = $upload_dir . $file_name;
                                    if (!is_dir($upload_dir)) {
                                        mkdir($upload_dir, 0777, true);
                                    }
                                    if (file_put_contents($file_path, $image_data)) {
                                        $photo_path = $file_path;
                                    } else {
                                        $errors[] = "Erreur lors de l'enregistrement de la photo capturée pour le bénéficiaire " . ($index + 1) . ".";
                                    }
                                }
                            } else {
                                $errors[] = "Format de la photo capturée invalide pour le bénéficiaire " . ($index + 1) . ".";
                            }
                        } elseif (isset($_FILES['beneficiaires']['name'][$index]['photo_path']) && $_FILES['beneficiaires']['size'][$index]['photo_path'] > 0) {
                            $file = [
                                'name' => $_FILES['beneficiaires']['name'][$index]['photo_path'],
                                'type' => $_FILES['beneficiaires']['type'][$index]['photo_path'],
                                'tmp_name' => $_FILES['beneficiaires']['tmp_name'][$index]['photo_path'],
                                'error' => $_FILES['beneficiaires']['error'][$index]['photo_path'],
                                'size' => $_FILES['beneficiaires']['size'][$index]['photo_path']
                            ];
                            if ($file['size'] > 2 * 1024 * 1024) {
                                $errors[] = "La photo téléversée pour le bénéficiaire " . ($index + 1) . " dépasse la taille maximale de 2MB.";
                            } else {
                                $upload = uploadPhoto($file);
                                if (isset($upload['error'])) {
                                    $errors[] = $upload['error'];
                                } else {
                                    $photo_path = $upload['path'];
                                }
                            }
                        } else {
                            $errors[] = "Une photo est requise pour le bénéficiaire " . ($index + 1) . " (téléversée ou capturée).";
                            continue;
                        }

                        if (empty($errors)) {
                            $stmt = $pdo->prepare("
                                INSERT INTO beneficiaires (
                                    id_adhesion, nom, prenom, date_naissance, relation, 
                                    code_beneficiaire, date_entree, date_sortie, statut, photo_path
                                ) VALUES (?, ?, ?, ?, ?, ?, CURDATE(), ?, 'en_attente_approbation', ?)
                            ");
                            $stmt->execute([
                                $adhesion_id, $nom_b, $prenom_b, $date_naissance_b, 
                                $relation, $code_beneficiaire, $date_sortie, $photo_path
                            ]);

                            // Log activity
                            logActivity($pdo, $_SESSION['user_id'], 'register_beneficiaire', "Bénéficiaire ajouté pour adhésion ID $adhesion_id");
                        }
                    }

                    if (empty($errors)) {
                        $pdo->commit();
                        // Clear session
                        unset($_SESSION['pending_adhesion_id']);
                        unset($_SESSION['pending_type_adhesion']);
                        unset($_SESSION['adherent_data']);
                        // Redirect immediately after success
                        header("Location: dashboard_agent.php");
                        ob_end_flush();
                        exit();
                    } else {
                        $pdo->rollBack();
                    }
                } catch (PDOException $e) {
                    $pdo->rollBack();
                    error_log("Erreur PDO : " . $e->getMessage());
                    $errors[] = "Une erreur s'est produite lors de l'enregistrement. Veuillez réessayer.";
                }
            }
        }
    }
}
?>

<div class="container">
    <h2 class="page-title text-center"><i class="bi bi-person-plus me-2"></i>Enregistrer un Adhérent</h2>

    <!-- Messages -->
    <?php if ($errors): ?>
        <?php foreach ($errors as $error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <?php if (empty($errors) && !$adhesion_id): ?>
        <!-- Adherent Form -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-person-plus-fill me-2"></i>Formulaire Adhérent
            </div>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data" id="adherent_form">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                    <input type="hidden" name="departement" value="<?php echo htmlspecialchars($agent_departement ?? ''); ?>">
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <div class="mb-3">
                                <label for="nom" class="form-label"><i class="bi bi-person me-2"></i>Nom <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="nom" name="nom" value="<?php echo htmlspecialchars($_POST['nom'] ?? ''); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="prenom" class="form-label"><i class="bi bi-person me-2"></i>Prénom <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="prenom" name="prenom" value="<?php echo htmlspecialchars($_POST['prenom'] ?? ''); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label"><i class="bi bi-envelope me-2"></i>Email (optionnel)</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="date_naissance" class="form-label"><i class="bi bi-calendar me-2"></i>Date de Naissance <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="date_naissance" name="date_naissance" value="<?php echo htmlspecialchars($_POST['date_naissance'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="mb-3">
                                <label for="lieu_naissance" class="form-label"><i class="bi bi-geo-alt me-2"></i>Lieu de Naissance (optionnel)</label>
                                <input type="text" class="form-control" id="lieu_naissance" name="lieu_naissance" value="<?php echo htmlspecialchars($_POST['lieu_naissance'] ?? ''); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="telephone" class="form-label"><i class="bi bi-telephone me-2"></i>Téléphone <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo htmlspecialchars($_POST['telephone'] ?? ''); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="profession" class="form-label"><i class="bi bi-briefcase me-2"></i>Profession (optionnel)</label>
                                <input type="text" class="form-control" id="profession" name="profession" value="<?php echo htmlspecialchars($_POST['profession'] ?? ''); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="numero_carte_identite" class="form-label"><i class="bi bi-person-vcard me-2"></i>Numéro Carte d'Identité <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="numero_carte_identite" name="numero_carte_identite" value="<?php echo htmlspecialchars($_POST['numero_carte_identite'] ?? ''); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="type_adhesion" class="form-label"><i class="bi bi-card-list me-2"></i>Type d'Adhésion <span class="text-danger">*</span></label>
                                <select class="form-select" id="type_adhesion" name="type_adhesion" required>
                                    <option value="groupe" <?php echo ($_POST['type_adhesion'] ?? '') === 'groupe' ? 'selected' : ''; ?>>Groupe (<?php echo htmlspecialchars(formatFCFA($tarifs_map['groupe']['cotisation_base'] ?? 0)); ?> + <?php echo htmlspecialchars(formatFCFA($tarifs_map['groupe']['tarif_beneficiaire'] ?? 0)); ?>/bénéficiaire)</option>
                                    <option value="familiale" <?php echo ($_POST['type_adhesion'] ?? '') === 'familiale' ? 'selected' : ''; ?>>Familiale (<?php echo htmlspecialchars(formatFCFA($tarifs_map['familiale']['cotisation_base'] ?? 0)); ?> + <?php echo htmlspecialchars(formatFCFA($tarifs_map['familiale']['tarif_beneficiaire'] ?? 0)); ?>/bénéficiaire)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="submit_adherent" class="btn btn-primary w-100 mt-3"><i class="bi bi-check-circle me-2"></i>Enregistrer Adhérent</button>
                </form>
            </div>
        </div>
    <?php else: ?>
        <!-- Beneficiaries Form with Payment -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-people me-2"></i>Ajouter des Bénéficiaires pour l'Adhésion #<?php echo htmlspecialchars($adhesion_id ?? ''); ?>
            </div>
            <div class="card-body">
                <form method="POST" id="beneficiaires_form" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                    <!-- Payment Information -->
                    <div id="payment_info" class="mb-3 alert alert-info">
                        <p><strong><i class="bi bi-currency-exchange me-2"></i>Cotisation de Base :</strong> <span id="cotisation_base">0.00</span> FCFA</p>
                        <p><strong><i class="bi bi-currency-exchange me-2"></i>Tarif par Bénéficiaire :</strong> <span id="tarif_beneficiaire">0.00</span> FCFA</p>
                        <p><strong><i class="bi bi-people me-2"></i>Nombre de Bénéficiaires :</strong> <span id="beneficiaire_count">0</span></p>
                        <p><strong><i class="bi bi-wallet2 me-2"></i>Cotisation Totale Requise :</strong> <span id="cotisation_due">0.00</span> FCFA</p>
                    </div>
                    <!-- Payment Form -->
                    <h5 class="mt-4"><i class="bi bi-credit-card me-2"></i>Paiement pour Adhésion et Bénéficiaires</h5>
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <div class="mb-3">
                                <label for="montant_verse" class="form-label"><i class="bi bi-wallet2 me-2"></i>Montant Versé (FCFA) <span class="text-danger">*</span></label>
                                <input type="number" step="0.01" class="form-control" id="montant_verse" name="montant_verse" required>
                            </div>
                            <div class="mb-3">
                                <label for="methode" class="form-label"><i class="bi bi-credit-card me-2"></i>Méthode de Paiement <span class="text-danger">*</span></label>
                                <select class="form-select" id="methode" name="methode" required>
                                    <option value="espece">Espèces</option>
                                    <option value="orange_money">Orange Money</option>
                                    <option value="wave">Wave</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="mb-3">
                                <label for="reference_transaction" class="form-label"><i class="bi bi-receipt me-2"></i>Référence de Transaction <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="reference_transaction" name="reference_transaction" required>
                            </div>
                            <div id="qrcode_beneficiaires" class="qrcode-container" style="display: none;"></div>
                        </div>
                    </div>
                    <!-- Beneficiaries List -->
                    <div id="beneficiaires_list"></div>
                    <div class="d-flex justify-content-between mb-3">
                        <button type="button" id="add_beneficiaire" class="btn btn-secondary"><i class="bi bi-plus-circle me-2"></i>Ajouter un autre bénéficiaire</button>
                        <button type="submit" name="submit_beneficiaires" id="submit_beneficiaires" class="btn btn-primary" disabled><i class="bi bi-check-circle me-2"></i>Enregistrer Bénéficiaires</button>
                    </div>
                </form>
            </div>
        </div>
        <!-- Modal for capturing photo -->
        <div class="modal fade" id="capturePhotoModal" tabindex="-1" aria-labelledby="capturePhotoModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="capturePhotoModalLabel">Prendre une Photo</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center">
                        <video id="video" autoplay style="max-width: 100%; height: auto;"></video>
                        <canvas id="canvas" style="display: none;"></canvas>
                        <div class="mt-3">
                            <button type="button" id="captureButton" class="btn btn-primary"><i class="bi bi-camera me-2"></i>Capturer</button>
                            <button type="button" id="retakeButton" class="btn btn-secondary" style="display: none;"><i class="bi bi-arrow-repeat me-2"></i>Reprendre</button>
                            <button type="button" id="savePhotoButton" class="btn btn-success" style="display: none;" data-bs-dismiss="modal"><i class="bi bi-check-circle me-2"></i>Enregistrer la Photo</button>
                        </div>
                        <p id="cameraError" class="text-danger mt-3" style="display: none;"></p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal for enlarged QR code -->
        <div class="modal fade" id="qrCodeModal" tabindex="-1" aria-labelledby="qrCodeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="qrCodeModalLabel">QR Code de Paiement</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center">
                        <img id="enlargedQrCode" src="" alt="QR Code" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
    :root {
        --primary: #1d4ed8;
        --accent: #059669;
        --danger: #ef4444;
        --warning: #f59e0b;
        --secondary: #6b7280;
        --background: #f1f5f9;
        --card-bg: #ffffff;
        --text: #111827;
        --success-dark: #047857;
    }

    .container {
        max-width: 900px;
        margin: 2rem auto;
        padding: 0 1rem;
    }

    .page-title {
        font-size: clamp(1.5rem, 5vw, 2rem);
        font-weight: 700;
        color: var(--primary);
        display: flex;
        align-items: center;
        gap: 0.5rem;
        text-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        margin-bottom: 1.5rem;
        animation: fadeIn 0.5s ease-in;
    }

    .card {
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        background: var(--card-bg);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-4px);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    }

    .card-header {
        background: linear-gradient(135deg, var(--primary), #3b82f6);
        color: white;
        font-weight: 600;
        border-radius: 12px 12px 0 0;
        padding: 1rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .card-body {
        padding: clamp(1rem, 3vw, 1.5rem);
    }

    .alert {
        border-radius: 8px;
        animation: slideIn 0.5s ease-in-out;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.75rem;
        font-size: clamp(0.85rem, 2.5vw, 0.9rem);
    }

    .alert-info {
        background-color: #e7f3fe;
        border-color: #b6d4fe;
    }

    .form-control, .form-select {
        border-radius: 6px;
        padding: clamp(0.5rem, 2vw, 0.75rem);
        border: 1px solid var(--primary);
        font-size: clamp(0.85rem, 2.5vw, 0.95rem);
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
        height: auto;
        min-height: 38px;
    }

    .form-control:focus, .form-select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 8px rgba(29, 78, 216, 0.4);
    }

    .form-control[readonly] {
        background-color: #e9ecef;
        cursor: not-allowed;
    }

    .form-label {
        font-size: clamp(0.8rem, 2.5vw, 0.9rem);
        margin-bottom: 0.3rem;
        display: flex;
        align-items: center;
        gap: 0.3rem;
    }

    .btn-primary, .btn-secondary, .btn-danger {
        border-radius: 6px;
        padding: clamp(0.5rem, 2vw, 0.75rem) 1rem;
        font-size: clamp(0.85rem, 2.5vw, 0.9rem);
        font-weight: 500;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.3rem;
        touch-action: manipulation;
    }

    .btn-primary {
        background-color: var(--primary);
        border: none;
    }

    .btn-primary:hover {
        background-color: #1e3a8a;
        transform: scale(1.05);
        box-shadow: 0 0 10px rgba(29, 78, 216, 0.4);
    }

    .btn-secondary:hover {
        background-color: #5a6268;
    }

    .btn-danger:hover {
        background-color: #c82333;
    }

    .qrcode-container {
        text-align: center;
        padding: 1rem;
        background-color: #f8f9fa;
        border-radius: 10px;
    }

    .qrcode-container img {
        cursor: pointer;
        max-width: 150px;
        height: auto;
        transition: transform 0.3s ease;
    }

    .qrcode-container img:hover {
        transform: scale(1.1);
    }

    .modal-content {
        border-radius: 10px;
    }

    .modal-body img, .modal-body video, .modal-body canvas {
        max-width: 100%;
        height: auto;
    }

    #photoPreview {
        max-width: 200px;
        height: auto;
        margin-top: 10px;
        border: 1px solid var(--primary);
        border-radius: 6px;
    }

    .beneficiaire {
        border: 1px solid #e9ecef;
        border-radius: 10px;
        background-color: #fff;
        padding: 1rem;
    }

    @keyframes slideIn {
        from { opacity: 0; transform: translateX(-15px); }
        to { opacity: 1; transform: translateX(0); }
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* Media Queries pour responsive */
    @media (max-width: 768px) {
        .container {
            margin: 1rem;
            padding: 0 0.5rem;
        }

        .page-title {
            font-size: clamp(1.25rem, 4vw, 1.5rem);
            margin-bottom: 1rem;
        }

        .card {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
        }

        .card-header {
            padding: 0.75rem;
            font-size: clamp(0.9rem, 3vw, 1rem);
        }

        .card-body {
            padding: 1rem;
        }

        .form-control, .form-select {
            padding: 0.5rem;
            font-size: clamp(0.8rem, 2.5vw, 0.9rem);
            min-height: 36px;
        }

        .form-label {
            font-size: clamp(0.75rem, 2.5vw, 0.85rem);
        }

        .btn-primary, .btn-secondary, .btn-danger {
            padding: 0.5rem 0.75rem;
            font-size: clamp(0.8rem, 2.5vw, 0.85rem);
        }

        .alert {
            padding: 0.5rem;
            font-size: clamp(0.8rem, 2.5vw, 0.85rem);
        }

        .qrcode-container img {
            max-width: 120px;
        }

        #photoPreview {
            max-width: 150px;
        }
    }

    @media (max-width: 576px) {
        .container {
            margin: 0.5rem;
        }

        .page-title {
            font-size: clamp(1.1rem, 4vw, 1.3rem);
            flex-direction: column;
            align-items: flex-start;
        }

        .card {
            border-radius: 8px;
        }

        .card-header {
            padding: 0.5rem;
            font-size: clamp(0.85rem, 3vw, 0.95rem);
        }

        .form-control, .form-select {
            font-size: clamp(0.75rem, 2.5vw, 0.85rem);
            min-height: 34px;
        }

        .btn-primary, .btn-secondary, .btn-danger {
            font-size: clamp(0.75rem, 2.5vw, 0.8rem);
            padding: 0.4rem 0.6rem;
        }

        .qrcode-container img {
            max-width: 100px;
        }

        #photoPreview {
            max-width: 120px;
        }
    }
</style>

<script>
    const tarifs = <?php echo json_encode($tarifs_map); ?>;
    const qrCodes = <?php echo json_encode($qr_codes); ?>;
    const adhesionId = <?php echo json_encode($adhesion_id); ?>;
    const typeAdhesion = <?php echo json_encode($adhesion_id ? ($_SESSION['pending_type_adhesion'] ?? '') : null); ?>;
    const dateSortie = '<?php echo htmlspecialchars($date_sortie); ?>';
    const minBeneficiaires = 3;
    const maxBeneficiaires = 20;
    const adherentData = <?php echo json_encode(isset($_SESSION['adherent_data']) ? $_SESSION['adherent_data'] : null); ?>;
    let beneficiaireCount = 0;
    let currentBeneficiaireIndex = null;

    function generateBeneficiaireForm(index) {
        // Pré-remplir le premier bénéficiaire avec les données de l'adhérent
        const isAdherent = index === 0 && adherentData;
        const nom = isAdherent ? adherentData.nom : '';
        const prenom = isAdherent ? adherentData.prenom : '';
        const dateNaissance = isAdherent ? adherentData.date_naissance : '';
        const relation = isAdherent ? 'adherent' : '';

        return `
            <div class="beneficiaire mb-4">
                <h5>Bénéficiaire ${index + 1}${isAdherent ? ' (Adhérent)' : ''}</h5>
                <div class="row g-3">
                    <div class="col-12 col-md-6">
                        <div class="mb-3">
                            <label for="beneficiaires[${index}][nom]" class="form-label"><i class="bi bi-person me-2"></i>Nom <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="beneficiaires[${index}][nom]" value="${nom}" required>
                        </div>
                        <div class="mb-3">
                            <label for="beneficiaires[${index}][prenom]" class="form-label"><i class="bi bi-person me-2"></i>Prénom <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="beneficiaires[${index}][prenom]" value="${prenom}" required>
                        </div>
                        <div class="mb-3">
                            <label for="beneficiaires[${index}][date_naissance]" class="form-label"><i class="bi bi-calendar me-2"></i>Date de Naissance <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="beneficiaires[${index}][date_naissance]" value="${dateNaissance}" required>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="mb-3">
                            <label for="beneficiaires[${index}][relation]" class="form-label"><i class="bi bi-link-45deg me-2"></i>Relation <span class="text-danger">*</span></label>
                            <select class="form-select" name="beneficiaires[${index}][relation]" required>
                                <option value="adherent" ${relation === 'adherent' ? 'selected' : ''}>Adhérent</option>
                                <option value="conjoint" ${relation === 'conjoint' ? 'selected' : ''}>Conjoint</option>
                                <option value="enfant" ${relation === 'enfant' ? 'selected' : ''}>Enfant</option>
                                <option value="autre" ${relation === 'autre' ? 'selected' : ''}>Autre</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="beneficiaires[${index}][date_sortie]" class="form-label"><i class="bi bi-calendar-x me-2"></i>Date de Sortie (fixée à 1 an)</label>
                            <input type="date" class="form-control" name="beneficiaires[${index}][date_sortie]" value="${dateSortie}" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="beneficiaires[${index}][photo_path]" class="form-label"><i class="bi bi-image me-2"></i>Photo (JPEG/PNG, max 2MB) <span class="text-danger">*</span></label>
                            <input type="file" class="form-control" id="photo_path_${index}" name="beneficiaires[${index}][photo_path]" accept="image/jpeg,image/png">
                            <button type="button" class="btn btn-secondary mt-2 capture-photo" data-index="${index}" data-bs-toggle="modal" data-bs-target="#capturePhotoModal"><i class="bi bi-camera me-2"></i>Prendre une photo</button>
                            <input type="hidden" name="beneficiaires[${index}][photo_base64]" id="photo_base64_${index}">
                            <img id="photoPreview_${index}" src="#" alt="Aperçu de la photo" style="display: none; max-width: 150px; height: auto; margin-top: 10px; border: 1px solid #007bff; border-radius: 6px;">
                        </div>
                    </div>
                </div>
                ${index === 0 ? '' : '<button type="button" class="btn btn-danger btn-sm remove-beneficiaire mt-2"><i class="bi bi-trash me-2"></i>Supprimer</button>'}
            </div>`;
    }

    function updatePaymentInfoBeneficiaires() {
        if (!adhesionId) {
            document.getElementById('payment_info').style.display = 'none';
            document.getElementById('qrcode_beneficiaires').style.display = 'none';
            document.getElementById('submit_beneficiaires').disabled = true;
            return;
        }

        const tarifBeneficiaire = parseFloat(tarifs[typeAdhesion].tarif_beneficiaire);
        const cotisationBase = parseFloat(tarifs[typeAdhesion].cotisation_base);
        const cotisationDue = cotisationBase + (beneficiaireCount * tarifBeneficiaire);
        const methode = document.getElementById('methode')?.value;

        document.getElementById('cotisation_base').textContent = cotisationBase.toFixed(2);
        document.getElementById('tarif_beneficiaire').textContent = tarifBeneficiaire.toFixed(2);
        document.getElementById('beneficiaire_count').textContent = beneficiaireCount;
        document.getElementById('cotisation_due').textContent = cotisationDue.toFixed(2);
        document.getElementById('payment_info').style.display = 'block';
        document.getElementById('submit_beneficiaires').disabled = beneficiaireCount < minBeneficiaires;

        // Update QR Code
        const qrcodeContainer = document.getElementById('qrcode_beneficiaires');
        qrcodeContainer.innerHTML = '';
        if (methode === 'orange_money' || methode === 'wave') {
            const qrCodePath = qrCodes[methode];
            qrcodeContainer.style.display = 'block';
            qrcodeContainer.innerHTML = `<img src="${qrCodePath}" alt="QR Code ${methode}" data-bs-toggle="modal" data-bs-target="#qrCodeModal" data-qr-src="${qrCodePath}">`;
        } else {
            qrcodeContainer.style.display = 'none';
        }
    }

    document.getElementById('methode')?.addEventListener('change', updatePaymentInfoBeneficiaires);

    document.getElementById('add_beneficiaire')?.addEventListener('click', function() {
        if (beneficiaireCount >= maxBeneficiaires) {
            alert('Limite de bénéficiaires atteinte (' + maxBeneficiaires + ').');
            return;
        }
        document.getElementById('beneficiaires_list').insertAdjacentHTML('beforeend', generateBeneficiaireForm(beneficiaireCount));
        beneficiaireCount++;
        updatePaymentInfoBeneficiaires();
    });

    document.getElementById('beneficiaires_list')?.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-beneficiaire') || e.target.closest('.remove-beneficiaire')) {
            if (beneficiaireCount <= minBeneficiaires) {
                alert('Vous devez conserver au moins ' + minBeneficiaires + ' bénéficiaires.');
                return;
            }
            if (confirm('Voulez-vous supprimer ce bénéficiaire ?')) {
                e.target.closest('.beneficiaire').remove();
                beneficiaireCount--;
                updatePaymentInfoBeneficiaires();
            }
        }
        if (e.target.classList.contains('capture-photo') || e.target.closest('.capture-photo')) {
            currentBeneficiaireIndex = e.target.closest('.capture-photo').getAttribute('data-index');
        }
    });

    document.getElementById('qrcode_beneficiaires')?.addEventListener('click', function(e) {
        if (e.target.tagName === 'IMG') {
            const qrSrc = e.target.getAttribute('data-qr-src');
            document.getElementById('enlargedQrCode').src = qrSrc;
        }
    });

    // Initial call to set up beneficiary forms
    document.addEventListener('DOMContentLoaded', function() {
        if (adhesionId) {
            const beneficiairesList = document.getElementById('beneficiaires_list');
            beneficiaireCount = minBeneficiaires;
            for (let i = 0; i < minBeneficiaires; i++) {
                beneficiairesList.insertAdjacentHTML('beforeend', generateBeneficiaireForm(i));
            }
            updatePaymentInfoBeneficiaires();
        }

        // Camera capture functionality
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const captureButton = document.getElementById('captureButton');
        const retakeButton = document.getElementById('retakeButton');
        const savePhotoButton = document.getElementById('savePhotoButton');
        let stream = null;

        // Start camera when modal is opened
        document.getElementById('capturePhotoModal')?.addEventListener('shown.bs.modal', async function() {
            try {
                stream = await navigator.mediaDevices.getUserMedia({ 
                    video: { 
                        facingMode: 'environment',
                        width: { ideal: 640 },
                        height: { ideal: 480 }
                    } 
                });
                video.srcObject = stream;
                document.getElementById('cameraError').style.display = 'none';
                captureButton.style.display = 'inline-block';
                retakeButton.style.display = 'none';
                savePhotoButton.style.display = 'none';
            } catch (err) {
                console.error('Camera access error:', err);
                document.getElementById('cameraError').textContent = 'Impossible d\'accéder à la caméra. Vérifiez les autorisations ou utilisez une image téléversée.';
                document.getElementById('cameraError').style.display = 'block';
                captureButton.style.display = 'none';
            }
        });

        // Stop camera when modal is closed
        document.getElementById('capturePhotoModal')?.addEventListener('hidden.bs.modal', function() {
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
                stream = null;
            }
            video.srcObject = null;
            video.style.display = 'block';
            canvas.style.display = 'none';
        });

        // Capture photo
        captureButton?.addEventListener('click', function() {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0);
            const imageData = canvas.toDataURL('image/jpeg', 0.5);
            if (currentBeneficiaireIndex !== null) {
                const photoPreview = document.getElementById(`photoPreview_${currentBeneficiaireIndex}`);
                const photoBase64Input = document.getElementById(`photo_base64_${currentBeneficiaireIndex}`);
                const photoInput = document.getElementById(`photo_path_${currentBeneficiaireIndex}`);
                photoPreview.src = imageData;
                photoPreview.style.display = 'block';
                photoBase64Input.value = imageData;
                photoInput.value = '';
                captureButton.style.display = 'none';
                retakeButton.style.display = 'inline-block';
                savePhotoButton.style.display = 'inline-block';
                video.style.display = 'none';
                canvas.style.display = 'block';
            }
        });

        // Retake photo
        retakeButton?.addEventListener('click', function() {
            video.style.display = 'block';
            canvas.style.display = 'none';
            captureButton.style.display = 'inline-block';
            retakeButton.style.display = 'none';
            savePhotoButton.style.display = 'none';
            if (currentBeneficiaireIndex !== null) {
                const photoPreview = document.getElementById(`photoPreview_${currentBeneficiaireIndex}`);
                const photoBase64Input = document.getElementById(`photo_base64_${currentBeneficiaireIndex}`);
                photoPreview.style.display = 'none';
                photoBase64Input.value = '';
            }
        });

        // Clear captured photo if a file is selected
        document.getElementById('beneficiaires_list')?.addEventListener('change', function(e) {
            if (e.target.type === 'file' && e.target.name.includes('photo_path')) {
                const index = e.target.name.match(/\[(\d+)\]/)[1];
                const photoBase64Input = document.getElementById(`photo_base64_${index}`);
                const photoPreview = document.getElementById(`photoPreview_${index}`);
                if (e.target.files.length > 0) {
                    photoBase64Input.value = '';
                    photoPreview.style.display = 'none';
                }
            }
        });

        // Validate form submission
        document.getElementById('beneficiaires_form')?.addEventListener('submit', function(e) {
            let hasPhoto = true;
            for (let i = 0; i < beneficiaireCount; i++) {
                const photoBase64Input = document.getElementById(`photo_base64_${i}`);
                const photoInput = document.getElementById(`photo_path_${i}`);
                if (!photoBase64Input.value && (!photoInput.files || photoInput.files.length === 0)) {
                    hasPhoto = false;
                    alert(`Veuillez fournir une photo pour le bénéficiaire ${i + 1} (téléversée ou capturée).`);
                }
            }
            if (!hasPhoto) {
                e.preventDefault();
            }
        });
    });
</script>

<?php
ob_end_flush(); // Vider le buffer de sortie à la fin
require_once '../includes/footer.php';
?>