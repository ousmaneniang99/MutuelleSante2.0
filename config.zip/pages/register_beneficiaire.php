<?php
// pages/register_beneficiaire.php
ob_start();
require_once '../includes/header.php';
checkRole('agent_mobilisateur');

$errors = [];
$csrf_token = generateCsrfToken();

// Calculer la date de sortie (date actuelle + 1 an)
$date_sortie = date('Y-m-d', strtotime('+1 year'));

// Chemins des images QR code
$qr_codes = [
    'wave' => '../Uploads/documents/wave.jpg',
    'orange_money' => '../Uploads/documents/OM.jpg'
];

// Vérifier l'existence des fichiers QR code
foreach ($qr_codes as $method => $path) {
    if (!file_exists($path)) {
        $errors[] = "L'image QR code pour $method est introuvable.";
    }
}

// Fetch tariffs
$stmt = $pdo->prepare("SELECT type_adhesion, tarif_beneficiaire FROM tarifs WHERE date_fin IS NULL");
$stmt->execute();
$tarifs = $stmt->fetchAll(PDO::FETCH_ASSOC);
$tarifs_map = array_column($tarifs, null, 'type_adhesion');

// Fetch adhesions created by the agent
$stmt_adhesions = $pdo->prepare("
    SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom, u.date_naissance, a.type_adhesion, a.is_renewal,
           (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion) as beneficiaire_count
    FROM adhesions a 
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
    WHERE u.departement = ? AND a.created_by = ?
");
$stmt_adhesions->execute([$_SESSION['departement'], $_SESSION['user_id']]);
$adhesions = $stmt_adhesions->fetchAll(PDO::FETCH_ASSOC);

// Handle beneficiary submission with payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_beneficiaires'])) {
    if (!verifyCsrfToken($_POST['csrf_token'])) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
    } else {
        $id_adhesion = intval($_POST['id_adhesion']);
        $beneficiaires = $_POST['beneficiaires'] ?? [];
        $montant_verse = floatval($_POST['montant_verse']);
        $methode = sanitize($_POST['methode']);
        $reference_transaction = sanitize($_POST['reference_transaction']);

        // Verify adhesion exists and was created by the agent
        $stmt = $pdo->prepare("
            SELECT a.id_adhesion, a.type_adhesion, a.is_renewal, u.nom, u.prenom, u.date_naissance,
                   (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion) as beneficiaire_count 
            FROM adhesions a 
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
            WHERE a.id_adhesion = ? AND a.created_by = ? AND u.departement = ?
        ");
        $stmt->execute([$id_adhesion, $_SESSION['user_id'], $_SESSION['departement']]);
        $adhesion = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$adhesion) {
            $errors[] = "Adhésion non trouvée ou accès non autorisé.";
        } else {
            $existing_beneficiaire_count = $adhesion['beneficiaire_count'];
            $new_beneficiaire_count = count($beneficiaires);
            $total_beneficiaire_count = $existing_beneficiaire_count + $new_beneficiaire_count;

            // Adjust for adherent as beneficiary if no beneficiaries exist
            if ($existing_beneficiaire_count == 0) {
                $total_beneficiaire_count += 1; // Include adherent as first beneficiary
                $new_beneficiaire_count += 1; // Include adherent in new count
            }

            $min_beneficiaires = 3;
            $max_beneficiaires = 20;

            if ($new_beneficiaire_count < $min_beneficiaires - $existing_beneficiaire_count) {
                $errors[] = "Vous devez ajouter au moins " . ($min_beneficiaires - $existing_beneficiaire_count) . " bénéficiaire(s) pour atteindre le minimum de $min_beneficiaires.";
            } elseif ($total_beneficiaire_count > $max_beneficiaires) {
                $errors[] = "Le nombre total de bénéficiaires ($total_beneficiaire_count) dépasse la limite de $max_beneficiaires.";
            } else {
                // Calculate required payment
                $tarif_beneficiaire = $tarifs_map[$adhesion['type_adhesion']]['tarif_beneficiaire'] ?? 3500.00;
                $cotisation_base = ($existing_beneficiaire_count == 0 && !$adhesion['is_renewal']) ? 1000.00 : 0.00;
                $cotisation_adherent = $existing_beneficiaire_count == 0 ? 3500.00 : 0.00;

                // Calculate cotisation_due
                if ($existing_beneficiaire_count == 0) {
                    $cotisation_due = $cotisation_base + $cotisation_adherent + (($new_beneficiaire_count - 1) * $tarif_beneficiaire);
                } else {
                    $cotisation_due = $new_beneficiaire_count * $tarif_beneficiaire;
                }

                // Validate payment inputs
                if (empty($montant_verse) || empty($methode) || empty($reference_transaction)) {
                    $errors[] = "Tous les champs de paiement doivent être remplis.";
                } elseif ($montant_verse < $cotisation_due) {
                    $errors[] = "Le montant versé ($montant_verse FCFA) est inférieur à la cotisation requise ($cotisation_due FCFA) pour $new_beneficiaire_count bénéficiaire(s)" . ($existing_beneficiaire_count == 0 ? " (incluant l'adhérent comme bénéficiaire) plus la cotisation d'adhésion de $cotisation_base FCFA." : ".");
                } elseif ($montant_verse <= 0) {
                    $errors[] = "Le montant versé doit être supérieur à 0.";
                } else {
                    // Start transaction
                    try {
                        $pdo->beginTransaction();

                        // Insert payment
                        $montant_restant = 0;
                        $cotisation_avance = $montant_verse > $cotisation_due ? $montant_verse - $cotisation_due : 0;
                        $stmt = $pdo->prepare("
                            INSERT INTO paiements (
                                id_adhesion, date_paiement, periodicite, cotisation_due, 
                                montant_verse, montant_restant, cotisation_avance, methode, 
                                statut, reference_transaction, created_by
                            ) VALUES (?, CURDATE(), 'annuelle', ?, ?, ?, ?, ?, 'en_attente', ?, ?)
                        ");
                        $stmt->execute([
                            $id_adhesion, $cotisation_due, $montant_verse, $montant_restant, 
                            $cotisation_avance, $methode, $reference_transaction, $_SESSION['user_id']
                        ]);

                        // If no beneficiaries exist, add adherent as first beneficiary
                        if ($existing_beneficiaire_count == 0) {
                            $nom = sanitize($adhesion['nom']);
                            $prenom = sanitize($adhesion['prenom']);
                            $date_naissance = sanitize($adhesion['date_naissance']);
                            $relation = 'adherent';
                            $code_beneficiaire = 'BEN' . str_pad($id_adhesion, 6, '0', STR_PAD_LEFT) . rand(100, 999);
                            $photo_path = null; // Adherent's photo is already stored in utilisateurs table

                            if (empty($nom) || empty($prenom) || empty($date_naissance)) {
                                $errors[] = "Les informations de l'adhérent (nom, prénom, date de naissance) doivent être complètes.";
                            } elseif (strtotime($date_sortie) <= strtotime($date_naissance)) {
                                $errors[] = "La date de sortie de l'adhérent doit être postérieure à sa date de naissance.";
                            } else {
                                $stmt = $pdo->prepare("
                                    INSERT INTO beneficiaires (
                                        id_adhesion, nom, prenom, date_naissance, relation, 
                                        code_beneficiaire, date_entree, date_sortie, statut, photo_path
                                    ) VALUES (?, ?, ?, ?, ?, ?, CURDATE(), ?, 'en_attente_approbation', ?)
                                ");
                                $stmt->execute([
                                    $id_adhesion, $nom, $prenom, $date_naissance, 
                                    $relation, $code_beneficiaire, $date_sortie, $photo_path
                                ]);

                                // Log activity for adherent
                                logActivity($pdo, $_SESSION['user_id'], 'add_beneficiaire', "Adhérent ajouté comme bénéficiaire pour adhésion ID $id_adhesion");
                            }
                        }

                        // Insert other beneficiaries
                        foreach ($beneficiaires as $index => $b) {
                            $nom = sanitize($b['nom']);
                            $prenom = sanitize($b['prenom']);
                            $date_naissance = sanitize($b['date_naissance']);
                            $relation = sanitize($b['relation']);
                            $code_beneficiaire = 'BEN' . str_pad($id_adhesion, 6, '0', STR_PAD_LEFT) . rand(100, 999);
                            $photo_base64 = isset($b['photo_base64']) ? $b['photo_base64'] : null;
                            $photo_path = null;

                            // Validate inputs
                            if (empty($nom) || empty($prenom) || empty($date_naissance) || empty($relation)) {
                                $errors[] = "Tous les champs obligatoires des bénéficiaires doivent être remplis.";
                                continue;
                            }
                            if (strtotime($date_sortie) <= strtotime($date_naissance)) {
                                $errors[] = "La date de sortie doit être postérieure à la date de naissance.";
                                continue;
                            }

                            // Handle photo
                            if ($photo_base64 && strpos($photo_base64, 'data:image') === 0) {
                                $photo_data = explode(',', $photo_base64);
                                if (count($photo_data) === 2) {
                                    $image_data = base64_decode($photo_data[1]);
                                    if (strlen($image_data) > 2 * 1024 * 1024) {
                                        $errors[] = "La photo capturée pour le bénéficiaire " . ($index + 1) . " dépasse la taille maximale de 2MB.";
                                    } else {
                                        $file_name = 'photo_benef_' . uniqid() . '.jpg';
                                        $upload_dir = '../Uploads/photos/';
                                        $file_path = $upload_dir . $file_name;
                                        if (!is_dir($upload_dir)) {
                                            mkdir($upload_dir, 0777, true);
                                        }
                                        if (file_put_contents($file_path, $image_data)) {
                                            $photo_path = $file_path;
                                        } else {
                                            $errors[] = "Erreur lors de l'enregistrement de la photo capturée pour le bénéficiaire " . ($index + 1) . ".";
                                        }
                                    }
                                } else {
                                    $errors[] = "Format de la photo capturée invalide pour le bénéficiaire " . ($index + 1) . ".";
                                }
                            } elseif (isset($_FILES['beneficiaires']['name'][$index]['photo_path']) && $_FILES['beneficiaires']['size'][$index]['photo_path'] > 0) {
                                $file = [
                                    'name' => $_FILES['beneficiaires']['name'][$index]['photo_path'],
                                    'type' => $_FILES['beneficiaires']['type'][$index]['photo_path'],
                                    'tmp_name' => $_FILES['beneficiaires']['tmp_name'][$index]['photo_path'],
                                    'error' => $_FILES['beneficiaires']['error'][$index]['photo_path'],
                                    'size' => $_FILES['beneficiaires']['size'][$index]['photo_path']
                                ];
                                if ($file['size'] > 2 * 1024 * 1024) {
                                    $errors[] = "La photo téléversée pour le bénéficiaire " . ($index + 1) . " dépasse la taille maximale de 2MB.";
                                } else {
                                    $upload = uploadPhoto($file);
                                    if (isset($upload['error'])) {
                                        $errors[] = $upload['error'];
                                    } else {
                                        $photo_path = $upload['path'];
                                    }
                                }
                            } else {
                                $errors[] = "Une photo est requise pour le bénéficiaire " . ($index + 1) . " (téléversée ou capturée).";
                                continue;
                            }

                            if (empty($errors)) {
                                $stmt = $pdo->prepare("
                                    INSERT INTO beneficiaires (
                                        id_adhesion, nom, prenom, date_naissance, relation, 
                                        code_beneficiaire, date_entree, date_sortie, statut, photo_path
                                    ) VALUES (?, ?, ?, ?, ?, ?, CURDATE(), ?, 'en_attente_approbation', ?)
                                ");
                                $stmt->execute([
                                    $id_adhesion, $nom, $prenom, $date_naissance, 
                                    $relation, $code_beneficiaire, $date_sortie, $photo_path
                                ]);

                                // Log activity
                                logActivity($pdo, $_SESSION['user_id'], 'add_beneficiaire', "Bénéficiaire ajouté pour adhésion ID $id_adhesion");
                            }
                        }

                        if (empty($errors)) {
                            $pdo->commit();
                            header("Location: dashboard_agent.php");
                            ob_end_flush();
                            exit();
                        } else {
                            $pdo->rollBack();
                        }
                    } catch (PDOException $e) {
                        $pdo->rollBack();
                        $errors[] = "Erreur lors de l'enregistrement : " . htmlspecialchars($e->getMessage());
                    }
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter des Bénéficiaires</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .card-header {
            border-bottom: none;
            padding: 1.5rem;
            font-size: 1.25rem;
            font-weight: 600;
        }
        .card-body {
            padding: 2rem;
        }
        .alert {
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert i {
            font-size: 1.2rem;
        }
        .form-control, .form-select {
            border-radius: 8px;
            padding: 0.75rem;
            border: 1px solid #ced4da;
            transition: border-color 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
        }
        .form-control[readonly] {
            background-color: #e9ecef;
            cursor: not-allowed;
        }
        .input-group .form-control {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
        }
        .btn-primary, .btn-danger, .btn-secondary {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover { background-color: #0056b3; }
        .btn-danger:hover { background-color: #c82333; }
        .btn-secondary:hover { background-color: #5a6268; }
        .beneficiaire {
            border: 1px solid #e9ecef;
            border-radius: 10px;
            background-color: #fff;
            padding: 1rem;
        }
        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 2rem;
        }
        .qrcode-container {
            text-align: center;
            padding: 1rem;
            background-color: #f8f9fa;
            border-radius: 10px;
        }
        .qrcode-container img {
            cursor: pointer;
            max-width: 150px;
            height: auto;
            transition: transform 0.3s ease;
        }
        .qrcode-container img:hover {
            transform: scale(1.1);
        }
        .modal-content {
            border-radius: 10px;
        }
        .modal-body img, .modal-body video, .modal-body canvas {
            max-width: 100%;
            height: auto;
        }
        #photoPreview {
            max-width: 150px;
            height: auto;
            margin-top: 10px;
            border: 1px solid #007bff;
            border-radius: 6px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-people me-2"></i>Ajouter des Bénéficiaires</h2>

        <!-- Messages -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Beneficiary Form -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <i class="bi bi-person-plus-fill me-2"></i>Formulaire Bénéficiaires
            </div>
            <div class="card-body">
                <form method="POST" id="beneficiaires_form" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                    <div class="mb-3">
                        <label for="id_adhesion" class="form-label"><i class="bi bi-card-list me-2"></i>Sélectionner une Adhésion *</label>
                        <select class="form-select" id="id_adhesion" name="id_adhesion" required>
                            <option value="">Choisir une adhésion</option>
                            <?php foreach ($adhesions as $adhesion): ?>
                                <option value="<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" 
                                        data-nom="<?php echo htmlspecialchars($adhesion['nom']); ?>" 
                                        data-prenom="<?php echo htmlspecialchars($adhesion['prenom']); ?>" 
                                        data-date-naissance="<?php echo htmlspecialchars($adhesion['date_naissance']); ?>" 
                                        data-is-renewal="<?php echo htmlspecialchars($adhesion['is_renewal']); ?>">
                                    <?php echo htmlspecialchars($adhesion['num_adherent'] . ' - ' . $adhesion['nom'] . ' ' . $adhesion['prenom'] . ' (' . $adhesion['type_adhesion'] . ', ' . $adhesion['beneficiaire_count'] . ' bénéficiaires)'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <!-- Payment Information -->
                    <div id="payment_info" class="mb-3" style="display: none;">
                        <div class="alert alert-info">
                            <p><strong><i class="bi bi-currency-exchange me-2"></i>Tarif par Bénéficiaire :</strong> <span id="tarif_beneficiaire">0.00</span> FCFA</p>
                            <p><strong><i class="bi bi-people me-2"></i>Nombre de Bénéficiaires :</strong> <span id="beneficiaire_count">0</span> <span id="adherent_info"></span></p>
                            <p><strong><i class="bi bi-wallet2 me-2"></i>Cotisation d'Adhésion :</strong> <span id="cotisation_adhesion">0.00</span></p>
                            <p><strong><i class="bi bi-wallet2 me-2"></i>Cotisation Totale Requise :</strong> <span id="cotisation_due">0.00</span> FCFA</p>
                        </div>
                    </div>
                    <!-- Payment Form -->
                    <div class="mb-4">
                        <h5><i class="bi bi-credit-card me-2"></i>Paiement pour les Bénéficiaires</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="montant_verse" class="form-label">Montant Versé (FCFA) *</label>
                                    <input type="number" step="0.01" class="form-control" id="montant_verse" name="montant_verse" required>
                                </div>
                                <div class="mb-3">
                                    <label for="methode" class="form-label">Méthode de Paiement *</label>
                                    <select class="form-select" id="methode" name="methode" required>
                                        <option value="espece">Espèces</option>
                                        <option value="orange_money">Orange Money</option>
                                        <option value="wave">Wave</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="reference_transaction" class="form-label">Référence de Transaction *</label>
                                    <input type="text" class="form-control" id="reference_transaction" name="reference_transaction" required>
                                </div>
                                <div id="qrcode" class="qrcode-container" style="display: none;"></div>
                            </div>
                        </div>
                    </div>
                    <!-- Beneficiaries Form -->
                    <div id="beneficiaires_list"></div>
                    <div class="d-flex justify-content-between mb-3">
                        <button type="button" id="add_beneficiaire" class="btn btn-secondary"><i class="bi bi-plus-circle me-2"></i>Ajouter un autre bénéficiaire</button>
                        <button type="submit" name="submit_beneficiaires" id="submit_beneficiaires" class="btn btn-primary" disabled><i class="bi bi-check-circle me-2"></i>Enregistrer Bénéficiaires</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal for capturing photo -->
    <div class="modal fade" id="capturePhotoModal" tabindex="-1" aria-labelledby="capturePhotoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="capturePhotoModalLabel">Prendre une Photo</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <video id="video" autoplay style="max-width: 100%; height: auto;"></video>
                    <canvas id="canvas" style="display: none;"></canvas>
                    <div class="mt-3">
                        <button type="button" id="captureButton" class="btn btn-primary"><i class="bi bi-camera me-2"></i>Capturer</button>
                        <button type="button" id="retakeButton" class="btn btn-secondary" style="display: none;"><i class="bi bi-arrow-repeat me-2"></i>Reprendre</button>
                        <button type="button" id="savePhotoButton" class="btn btn-success" style="display: none;" data-bs-dismiss="modal"><i class="bi bi-check-circle me-2"></i>Enregistrer la Photo</button>
                    </div>
                    <p id="cameraError" class="text-danger mt-3" style="display: none;"></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for enlarged QR code -->
    <div class="modal fade" id="qrCodeModal" tabindex="-1" aria-labelledby="qrCodeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="qrCodeModalLabel">QR Code de Paiement</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <img id="enlargedQrCode" src="" alt="QR Code" class="img-fluid">
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        let beneficiaireCount = 0;
        const minBeneficiaires = 3;
        const maxBeneficiaires = 20;
        const dateSortie = '<?php echo $date_sortie; ?>';
        const beneficiaireCounts = <?php echo json_encode(array_column($adhesions, 'beneficiaire_count', 'id_adhesion')); ?>;
        const typeAdhesions = <?php echo json_encode(array_column($adhesions, 'type_adhesion', 'id_adhesion')); ?>;
        const isRenewals = <?php echo json_encode(array_column($adhesions, 'is_renewal', 'id_adhesion')); ?>;
        const adherentData = <?php echo json_encode(array_column($adhesions, null, 'id_adhesion')); ?>;
        const tarifs = <?php echo json_encode($tarifs_map); ?>;
        const qrCodes = <?php echo json_encode($qr_codes); ?>;
        let currentBeneficiaireIndex = null;

        function generateAdherentForm(nom, prenom, date_naissance) {
            return `
                <div class="beneficiaire mb-4 border p-3 rounded">
                    <h5>Bénéficiaire 1 (Adhérent Principal)</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Nom</label>
                                <input type="text" class="form-control" value="${nom}" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Prénom</label>
                                <input type="text" class="form-control" value="${prenom}" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Date de Naissance</label>
                                <input type="date" class="form-control" value="${date_naissance}" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Relation</label>
                                <input type="text" class="form-control" value="Adhérent" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Date de Sortie (fixée à 1 an)</label>
                                <input type="date" class="form-control" value="${dateSortie}" readonly>
                            </div>
                        </div>
                    </div>
                </div>`;
        }

        function generateBeneficiaireForm(index) {
            return `
                <div class="beneficiaire mb-4 border p-3 rounded">
                    <h5>Bénéficiaire ${index + 2}</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="beneficiaires[${index}][nom]" class="form-label">Nom *</label>
                                <input type="text" class="form-control" name="beneficiaires[${index}][nom]" required>
                            </div>
                            <div class="mb-3">
                                <label for="beneficiaires[${index}][prenom]" class="form-label">Prénom *</label>
                                <input type="text" class="form-control" name="beneficiaires[${index}][prenom]" required>
                            </div>
                            <div class="mb-3">
                                <label for="beneficiaires[${index}][date_naissance]" class="form-label">Date de Naissance *</label>
                                <input type="date" class="form-control" name="beneficiaires[${index}][date_naissance]" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="beneficiaires[${index}][relation]" class="form-label">Relation *</label>
                                <select class="form-select" name="beneficiaires[${index}][relation]" required>
                                    <option value="conjoint">Conjoint</option>
                                    <option value="enfant">Enfant</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="beneficiaires[${index}][date_sortie]" class="form-label">Date de Sortie (fixée à 1 an)</label>
                                <input type="date" class="form-control" name="beneficiaires[${index}][date_sortie]" value="${dateSortie}" readonly>
                            </div>
                            <div class="mb-3">
                                <label for="beneficiaires[${index}][photo_path]" class="form-label"><i class="bi bi-image me-2"></i>Photo (JPEG/PNG, max 2MB) *</label>
                                <input type="file" class="form-control" id="photo_path_${index}" name="beneficiaires[${index}][photo_path]" accept="image/jpeg,image/png">
                                <button type="button" class="btn btn-secondary mt-2 capture-photo" data-index="${index}" data-bs-toggle="modal" data-bs-target="#capturePhotoModal"><i class="bi bi-camera me-2"></i>Prendre une photo</button>
                                <input type="hidden" name="beneficiaires[${index}][photo_base64]" id="photo_base64_${index}">
                                <img id="photoPreview_${index}" src="#" alt="Aperçu de la photo" style="display: none;">
                            </div>
                        </div>
                    </div>
                    <button type="button" class="btn btn-danger btn-sm remove-beneficiaire"><i class="bi bi-trash me-2"></i>Supprimer</button>
                </div>`;
        }

        function updateBeneficiaireForms() {
            const idAdhesion = document.getElementById('id_adhesion').value;
            const beneficiairesList = document.getElementById('beneficiaires_list');
            beneficiairesList.innerHTML = ''; // Clear previous forms
            beneficiaireCount = 0;

            if (!idAdhesion) {
                document.getElementById('payment_info').style.display = 'none';
                document.getElementById('qrcode').style.display = 'none';
                document.getElementById('submit_beneficiaires').disabled = true;
                return;
            }

            const existingCount = parseInt(beneficiaireCounts[idAdhesion] || 0);
            const adherent = adherentData[idAdhesion];

            // Show adherent form if no beneficiaries exist
            if (existingCount === 0) {
                beneficiairesList.insertAdjacentHTML('beforeend', generateAdherentForm(
                    adherent.nom || '',
                    adherent.prenom || '',
                    adherent.date_naissance || ''
                ));
            }

            const formsToGenerate = Math.max(minBeneficiaires - (existingCount === 0 ? 1 : existingCount), 0);
            beneficiaireCount = formsToGenerate;

            for (let i = 0; i < formsToGenerate; i++) {
                beneficiairesList.insertAdjacentHTML('beforeend', generateBeneficiaireForm(i));
            }

            updatePaymentInfo();
        }

        function updatePaymentInfo() {
            const idAdhesion = document.getElementById('id_adhesion').value;
            const methode = document.getElementById('methode').value;

            if (!idAdhesion) {
                document.getElementById('payment_info').style.display = 'none';
                document.getElementById('qrcode').style.display = 'none';
                document.getElementById('submit_beneficiaires').disabled = true;
                return;
            }

            const typeAdhesion = typeAdhesions[idAdhesion] || 'individuelle';
            const existingCount = parseInt(beneficiaireCounts[idAdhesion] || 0);
            const isRenewal = parseInt(isRenewals[idAdhesion] || 0);
            const tarifBeneficiaire = parseFloat(tarifs[typeAdhesion]?.tarif_beneficiaire || 3500.00);
            const cotisationBase = (existingCount === 0 && !isRenewal) ? 1000.00 : 0.00;
            const cotisationAdherent = existingCount === 0 ? 3500.00 : 0.00;

            // Calculate total beneficiaries and cotisation due
            const totalBeneficiaireCount = existingCount === 0 ? beneficiaireCount + 1 : beneficiaireCount + existingCount;
            const cotisationDue = (existingCount === 0 ? cotisationBase + cotisationAdherent + (beneficiaireCount * tarifBeneficiaire) : beneficiaireCount * tarifBeneficiaire);

            document.getElementById('tarif_beneficiaire').textContent = tarifBeneficiaire.toFixed(2);
            document.getElementById('beneficiaire_count').textContent = totalBeneficiaireCount;
            document.getElementById('adherent_info').textContent = existingCount === 0 ? '(incluant l\'adhérent)' : '';
            document.getElementById('cotisation_adhesion').textContent = cotisationBase > 0 ? '1000.00 (Requis)' : '0.00 (Non requis)';
            document.getElementById('cotisation_due').textContent = cotisationDue.toFixed(2);
            document.getElementById('payment_info').style.display = 'block';
            document.getElementById('submit_beneficiaires').disabled = totalBeneficiaireCount < minBeneficiaires;

            // Update QR Code
            const qrcodeContainer = document.getElementById('qrcode');
            qrcodeContainer.innerHTML = '';
            if (methode === 'orange_money' || methode === 'wave') {
                const qrCodePath = qrCodes[methode];
                qrcodeContainer.style.display = 'block';
                qrcodeContainer.innerHTML = `<img src="${qrCodePath}" alt="QR Code ${methode}" data-bs-toggle="modal" data-bs-target="#qrCodeModal" data-qr-src="${qrCodePath}">`;
            } else {
                qrcodeContainer.style.display = 'none';
            }
        }

        document.getElementById('id_adhesion').addEventListener('change', updateBeneficiaireForms);
        document.getElementById('methode').addEventListener('change', updatePaymentInfo);

        document.getElementById('add_beneficiaire').addEventListener('click', function() {
            const idAdhesion = document.getElementById('id_adhesion').value;
            if (!idAdhesion) {
                alert('Veuillez sélectionner une adhésion.');
                return;
            }
            const existingCount = parseInt(beneficiaireCounts[idAdhesion] || 0);
            const totalCount = existingCount === 0 ? beneficiaireCount + 1 : beneficiaireCount + existingCount;
            if (totalCount >= maxBeneficiaires) {
                alert('Limite de bénéficiaires atteinte pour cette adhésion (' + maxBeneficiaires + ').');
                return;
            }
            document.getElementById('beneficiaires_list').insertAdjacentHTML('beforeend', generateBeneficiaireForm(beneficiaireCount));
            beneficiaireCount++;
            updatePaymentInfo();
        });

        document.getElementById('beneficiaires_list').addEventListener('click', function(e) {
            if (e.target.classList.contains('remove-beneficiaire') || e.target.closest('.remove-beneficiaire')) {
                const idAdhesion = document.getElementById('id_adhesion').value;
                const existingCount = parseInt(beneficiaireCounts[idAdhesion] || 0);
                const totalCount = existingCount === 0 ? beneficiaireCount + 1 : beneficiaireCount + existingCount;
                if (totalCount <= minBeneficiaires) {
                    alert('Vous devez conserver au moins ' + minBeneficiaires + ' bénéficiaires (incluant l\'adhérent si aucun bénéficiaire existant).');
                    return;
                }
                if (confirm('Voulez-vous supprimer ce bénéficiaire ?')) {
                    e.target.closest('.beneficiaire').remove();
                    beneficiaireCount--;
                    updatePaymentInfo();
                }
            }
            if (e.target.classList.contains('capture-photo') || e.target.closest('.capture-photo')) {
                currentBeneficiaireIndex = e.target.closest('.capture-photo').getAttribute('data-index');
            }
        });

        // Handle QR code click to show in modal
        document.getElementById('qrcode').addEventListener('click', function(e) {
            if (e.target.tagName === 'IMG') {
                const qrSrc = e.target.getAttribute('data-qr-src');
                document.getElementById('enlargedQrCode').src = qrSrc;
            }
        });

        // Camera capture functionality
        document.addEventListener('DOMContentLoaded', function() {
            updateBeneficiaireForms();

            const video = document.getElementById('video');
            const canvas = document.getElementById('canvas');
            const captureButton = document.getElementById('captureButton');
            const retakeButton = document.getElementById('retakeButton');
            const savePhotoButton = document.getElementById('savePhotoButton');
            let stream = null;

            // Start camera when modal is opened
            document.getElementById('capturePhotoModal')?.addEventListener('shown.bs.modal', async function() {
                try {
                    stream = await navigator.mediaDevices.getUserMedia({ 
                        video: { 
                            facingMode: 'environment',
                            width: { ideal: 640 },
                            height: { ideal: 480 }
                        } 
                    });
                    video.srcObject = stream;
                    document.getElementById('cameraError').style.display = 'none';
                    captureButton.style.display = 'inline-block';
                    retakeButton.style.display = 'none';
                    savePhotoButton.style.display = 'none';
                } catch (err) {
                    console.error('Camera access error:', err);
                    document.getElementById('cameraError').textContent = 'Impossible d\'accéder à la caméra. Vérifiez les autorisations ou utilisez une image téléversée.';
                    document.getElementById('cameraError').style.display = 'block';
                    captureButton.style.display = 'none';
                }
            });

            // Stop camera when modal is closed
            document.getElementById('capturePhotoModal')?.addEventListener('hidden.bs.modal', function() {
                if (stream) {
                    stream.getTracks().forEach(track => track.stop());
                    stream = null;
                }
                video.srcObject = null;
                video.style.display = 'block';
                canvas.style.display = 'none';
            });

            // Capture photo
            captureButton?.addEventListener('click', function() {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                canvas.getContext('2d').drawImage(video, 0, 0);
                const imageData = canvas.toDataURL('image/jpeg', 0.5);
                if (currentBeneficiaireIndex !== null) {
                    const photoPreview = document.getElementById(`photoPreview_${currentBeneficiaireIndex}`);
                    const photoBase64Input = document.getElementById(`photo_base64_${currentBeneficiaireIndex}`);
                    const photoInput = document.getElementById(`photo_path_${currentBeneficiaireIndex}`);
                    photoPreview.src = imageData;
                    photoPreview.style.display = 'block';
                    photoBase64Input.value = imageData;
                    photoInput.value = '';
                    captureButton.style.display = 'none';
                    retakeButton.style.display = 'inline-block';
                    savePhotoButton.style.display = 'inline-block';
                    video.style.display = 'none';
                    canvas.style.display = 'block';
                }
            });

            // Retake photo
            retakeButton?.addEventListener('click', function() {
                video.style.display = 'block';
                canvas.style.display = 'none';
                captureButton.style.display = 'inline-block';
                retakeButton.style.display = 'none';
                savePhotoButton.style.display = 'none';
                if (currentBeneficiaireIndex !== null) {
                    const photoPreview = document.getElementById(`photoPreview_${currentBeneficiaireIndex}`);
                    const photoBase64Input = document.getElementById(`photo_base64_${currentBeneficiaireIndex}`);
                    photoPreview.style.display = 'none';
                    photoBase64Input.value = '';
                }
            });

            // Clear captured photo if a file is selected
            document.getElementById('beneficiaires_list').addEventListener('change', function(e) {
                if (e.target.type === 'file' && e.target.name.includes('photo_path')) {
                    const index = e.target.name.match(/\[(\d+)\]/)[1];
                    const photoBase64Input = document.getElementById(`photo_base64_${index}`);
                    const photoPreview = document.getElementById(`photoPreview_${index}`);
                    if (e.target.files.length > 0) {
                        photoBase64Input.value = '';
                        photoPreview.style.display = 'none';
                    }
                }
            });

            // Validate form submission
            document.getElementById('beneficiaires_form')?.addEventListener('submit', function(e) {
                let hasPhoto = true;
                for (let i = 0; i < beneficiaireCount; i++) {
                    const photoBase64Input = document.getElementById(`photo_base64_${i}`);
                    const photoInput = document.getElementById(`photo_path_${i}`);
                    if (!photoBase64Input.value && (!photoInput.files || photoInput.files.length === 0)) {
                        hasPhoto = false;
                        alert(`Veuillez fournir une photo pour le bénéficiaire ${i + 2} (téléversée ou capturée).`);
                    }
                }
                if (!hasPhoto) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>

<?php
ob_end_flush();
require_once '../includes/footer.php';
?>