<?php
// pages/register_prestataire.php
require_once '../includes/header.php';
checkRole('directeur_departemental');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();

// === CONFIG UPLOAD ===
$upload_dir = '../uploads/prestataires/';
$default_logo = 'uploads/photos/prestataire.jpg'; // LOGO PAR DÉFAUT
$allowed_types = ['image/jpeg', 'image/jpg', 'image/png'];
$max_size = 2 * 1024 * 1024; // 2 Mo

// Créer dossier si inexistant
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// === CHARGER NIVEAUX ===
try {
    $stmt = $pdo->query("SELECT id_niveau, niveau FROM niveau ORDER BY id_niveau");
    $niveaux = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $niveaux = [];
    $errors[] = "Impossible de charger les niveaux.";
    error_log("Erreur niveaux : " . $e->getMessage());
}

// === TRAITEMENT FORMULAIRE ===
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Erreur de sécurité (CSRF).";
    } else {
        $email = trim(strtolower($_POST['email'] ?? ''));
        $nom_prestataire = trim($_POST['nom_prestataire'] ?? '');
        $adresse = trim($_POST['adresse'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $id_niveau = (int)($_POST['id_niveau'] ?? 0);
        $logo_path = $default_logo; // Par défaut

        // === VALIDATION ===
        if (empty($email) || empty($nom_prestataire) || empty($adresse) || empty($telephone) || $id_niveau <= 0) {
            $errors[] = "Tous les champs sont obligatoires.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Email invalide.";
        } elseif (!preg_match('/^\+?\d{1,4}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}$/', $telephone)) {
            $errors[] = "Téléphone invalide.";
        } elseif (empty($niveaux) || !in_array($id_niveau, array_column($niveaux, 'id_niveau'))) {
            $errors[] = "Niveau invalide.";
        }

        // === UPLOAD LOGO (si fourni) ===
        if (empty($errors) && isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['logo'];
            if (!in_array($file['type'], $allowed_types)) {
                $errors[] = "Logo : JPG ou PNG uniquement.";
            } elseif ($file['size'] > $max_size) {
                $errors[] = "Logo trop lourd (max 2 Mo).";
            } else {
                $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $filename = uniqid('logo_') . '.' . $ext;
                $logo_path = 'uploads/prestataires/' . $filename;
                if (!move_uploaded_file($file['tmp_name'], '../' . $logo_path)) {
                    $errors[] = "Échec de l'enregistrement du logo.";
                    $logo_path = $default_logo; // Retour au défaut
                }
            }
        }

        // === ENREGISTREMENT ===
        if (empty($errors)) {
            try {
                $pdo->beginTransaction();

                // Vérifier email unique
                $stmt = $pdo->prepare("SELECT id_utilisateur FROM utilisateurs WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetch()) {
                    $errors[] = "Cet email est déjà utilisé.";
                } else {
                    // Créer utilisateur
                    $default_password = 'password123';
                    $hashed = password_hash($default_password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("
                        INSERT INTO utilisateurs (email, mot_de_passe, role, departement, statut)
                        VALUES (?, ?, 'prestataire_soins', ?, 'actif')
                    ");
                    $stmt->execute([$email, $hashed, $_SESSION['departement']]);
                    $id_utilisateur = $pdo->lastInsertId();

                    // Créer prestataire
                    $stmt = $pdo->prepare("
                        INSERT INTO prestataires 
                        (id_prestataire, nom, logo, adresse, telephone, statut, id_utilisateur, id_niveau)
                        VALUES (?, ?, ?, ?, ?, 'actif', ?, ?)
                    ");
                    $stmt->execute([
                        $id_utilisateur,
                        $nom_prestataire,
                        $logo_path,
                        $adresse,
                        $telephone,
                        $id_utilisateur,
                        $id_niveau
                    ]);

                    $pdo->commit();

                    // Niveau nom
                    $niveau_nom = $niveaux[array_search($id_niveau, array_column($niveaux, 'id_niveau'))]['niveau'] ?? 'Inconnu';

                    // Log & Notif
                    logActivity($pdo, $_SESSION['user_id'], "Création prestataire : $nom_prestataire ($email)");
                    sendNotification($pdo, $id_utilisateur, "Bienvenue !\nPrestataire: $nom_prestataire\nEmail: $email\nMot de passe: $default_password", 'info');

                    // Affichage succès
                    $logo_display = $logo_path === $default_logo 
                        ? "<em class='text-muted'>Logo par défaut</em>" 
                        : "<img src='../$logo_path' class='img-thumbnail' style='max-height:80px; margin-top:10px;' alt='Logo'>";

                    $success = "
                        <strong>$nom_prestataire</strong> créé avec succès !<br>
                        Email: <code>$email</code><br>
                        Mot de passe: <code>$default_password</code><br>
                        Niveau: <strong>$niveau_nom</strong><br>
                        Logo: $logo_display
                    ";
                }
            } catch (Exception $e) {
                $pdo->rollBack();
                $errors[] = "Erreur système. Réessayez.";
                error_log("register_prestataire.php ERROR: " . $e->getMessage());
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter Prestataire - Mutuelle Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root{--p:#1e40af;--ph:#3b82f6;--glass:rgba(255,255,255,0.2);--border:rgba(255,255,255,0.25);--shadow:0 12px 40px rgba(0,0,0,0.15);--radius:1.8rem;--trans:all .4s ease}
        [data-bs-theme="dark"]{--glass:rgba(15,23,42,0.7);--border:rgba(255,255,255,0.15);--p:#60a5fa;--ph:#93c5fd}
        *{box-sizing:border-box;margin:0;padding:0}
        body{background:linear-gradient(135deg,#f0f9ff,#e0f2fe);font-family:'Inter',sans-serif;color:#1e293b;min-height:100vh;transition:var(--trans)}
        [data-bs-theme="dark"] body{background:linear-gradient(135deg,#0f172a,#1e293b);color:#e2e8f0}
        .c{max-width:800px;margin:3rem auto;padding:1.5rem}
        .card{background:var(--glass);backdrop-filter:blur(20px);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow);overflow:hidden}
        .card-header{background:linear-gradient(135deg,var(--p),var(--ph));color:#fff;padding:1.8rem 2rem;font-weight:700;font-size:1.4rem;display:flex;align-items:center;gap:1rem}
        .card-body{padding:2.5rem}
        .form-label{font-weight:600;color:var(--dark)}
        .form-control,.form-select{background:rgba(255,255,255,0.7);border:1.5px solid #cbd5e1;border-radius:1rem;padding:.8rem 1.2rem;transition:var(--trans)}
        .form-control:focus,.form-select:focus{border-color:var(--p);box-shadow:0 0 0 .3rem rgba(30,64,175,.25);background:#fff}
        .input-group-text{background:#f8fafc;border-radius:1rem 0 0 1rem;color:var(--p)}
        .btn-primary{background:linear-gradient(135deg,var(--p),var(--ph));border:none;border-radius:1rem;padding:.8rem 2rem;font-weight:600;transition:var(--trans);box-shadow:0 6px 20px rgba(30,64,175,.3)}
        .btn-primary:hover{transform:translateY(-3px);box-shadow:0 12px 30px rgba(30,64,175,.4)}
        .btn-secondary{background:#6b7280;color:#fff;border-radius:1rem;padding:.8rem 1.8rem}
        .alert{border-radius:1rem;padding:1.2rem 1.5rem;margin-bottom:1.5rem;border:none;box-shadow:var(--shadow)}
        .alert code{background:rgba(0,0,0,.1);padding:.3rem .6rem;border-radius:.6rem;font-family:monospace}
        .preview-img{max-height:100px;margin-top:12px;border-radius:1rem;box-shadow:0 4px 15px rgba(0,0,0,.2);transition:var(--trans)}
        .theme-toggle{position:fixed;bottom:2rem;right:2rem;background:var(--p);color:#fff;width:60px;height:60px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.8rem;box-shadow:0 10px 30px rgba(30,64,175,.5);z-index:1000;transition:var(--trans)}
        .theme-toggle:hover{transform:scale(1.15) rotate(20deg)}
        .page-title{font-size:2.4rem;font-weight:800;color:var(--p);text-align:center;margin-bottom:2rem;text-shadow:0 2px 10px rgba(30,64,175,.2)}
        @media(max-width:768px){.c{padding:1rem}.page-title{font-size:2rem}}
    </style>
</head>
<body>

<div class="c">
    <h2 class="page-title">
        <i class="bi bi-hospital-fill"></i> Ajouter un Prestataire
    </h2>

    <!-- SUCCÈS -->
    <?php if ($success): ?>
        <div class="alert alert-success">
            <i class="bi bi-check-circle-fill fs-4"></i>
            <?= $success ?>
        </div>
    <?php endif; ?>

    <!-- ERREURS -->
    <?php foreach ($errors as $e): ?>
        <div class="alert alert-danger">
            <i class="bi bi-exclamation-triangle-fill fs-4"></i>
            <?= htmlspecialchars($e) ?>
        </div>
    <?php endforeach; ?>

    <!-- FORMULAIRE -->
    <div class="card">
        <div class="card-header">
            <i class="bi bi-person-plus-fill"></i> Nouveau Prestataire
        </div>
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data" novalidate>
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

                <!-- Nom -->
                <div class="mb-4">
                    <label class="form-label">Nom du prestataire</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-building"></i></span>
                        <input type="text" name="nom_prestataire" class="form-control" required 
                               value="<?= $_POST['nom_prestataire'] ?? '' ?>" placeholder="Ex: Poste de Santé Matam">
                    </div>
                </div>

                <!-- Logo -->
                <div class="mb-4">
                    <label class="form-label">Logo (optionnel)</label>
                    <input type="file" name="logo" class="form-control" accept="image/jpeg,image/jpg,image/png">
                    <div class="form-text">JPG/PNG - Max 2 Mo</div>
                    <div id="preview"></div>
                </div>

                <!-- Email -->
                <div class="mb-4">
                    <label class="form-label">Email (identifiant)</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input type="email" name="email" class="form-control" required 
                               value="<?= $_POST['email'] ?? '' ?>" placeholder="ex: poste.matam@sante.sn">
                    </div>
                </div>

                <!-- Adresse -->
                <div class="mb-4">
                    <label class="form-label">Adresse</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-geo-alt"></i></span>
                        <textarea name="adresse" class="form-control" rows="2" required 
                                  placeholder="Quartier Central, Matam"><?= $_POST['adresse'] ?? '' ?></textarea>
                    </div>
                </div>

                <!-- Téléphone -->
                <div class="mb-4">
                    <label class="form-label">Téléphone</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-telephone"></i></span>
                        <input type="text" name="telephone" class="form-control" required 
                               value="<?= $_POST['telephone'] ?? '' ?>" placeholder="+221 77 123 45 67">
                    </div>
                </div>

                <!-- Niveau -->
                <div class="mb-4">
                    <label class="form-label">Niveau sanitaire</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-building"></i></span>
                        <select name="id_niveau" class="form-select" required>
                            <option value="">Choisir...</option>
                            <?php foreach ($niveaux as $n): ?>
                                <option value="<?= $n['id_niveau'] ?>" 
                                    <?= ($_POST['id_niveau'] ?? '') == $n['id_niveau'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($n['niveau']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="d-flex gap-3 justify-content-end">
                    <a href="dashboard_directeur.php" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Retour
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle"></i> Créer
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Thème Toggle -->
<button class="theme-toggle" id="themeToggle">
    <i class="bi bi-moon-stars-fill"></i>
</button>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Thème
    const tt = document.getElementById('themeToggle');
    tt.addEventListener('click', () => {
        const isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
        document.documentElement.setAttribute('data-bs-theme', isDark ? 'light' : 'dark');
        tt.innerHTML = isDark ? '<i class="bi bi-moon-stars-fill"></i>' : '<i class="bi bi-sun-fill"></i>';
        localStorage.setItem('theme', isDark ? 'light' : 'dark');
    });
    if (localStorage.getItem('theme') === 'dark') {
        document.documentElement.setAttribute('data-bs-theme', 'dark');
        tt.innerHTML = '<i class="bi bi-sun-fill"></i>';
    }

    // Aperçu logo
    document.querySelector('[name="logo"]').addEventListener('change', e => {
        const file = e.target.files[0];
        const preview = document.getElementById('preview');
        preview.innerHTML = '';
        if (file) {
            const reader = new FileReader();
            reader.onload = ev => {
                const img = new Image();
                img.src = ev.target.result;
                img.className = 'preview-img';
                preview.appendChild(img);
            };
            reader.readAsDataURL(file);
        }
    });
</script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>