<?php
//pages/register_prestation.php
require_once '../includes/header.php';
checkRole('prestataire_soins');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();
$prestations = [];
$beneficiaires = [];
$preselected_beneficiaire_id = null;
$ref_id = 0;

$search_code = trim((string)filter_input(INPUT_GET, 'search_code', FILTER_DEFAULT) ?? '');
$num_beneficiaire = trim((string)filter_input(INPUT_GET, 'num_beneficiaire', FILTER_DEFAULT) ?? '');
$id_adhesion = filter_input(INPUT_GET, 'id_adhesion', FILTER_VALIDATE_INT) ?? 0;
$today = date('Y-m-d');

// === INFOS PRESTATAIRE ===
$stmt = $pdo->prepare("
    SELECT p.id_prestataire, p.id_niveau, n.niveau, p.logo 
    FROM prestataires p 
    JOIN niveau n ON p.id_niveau = n.id_niveau 
    WHERE p.id_utilisateur = ?
");
$stmt->execute([$_SESSION['user_id']]);
$prestataire = $stmt->fetch(PDO::FETCH_ASSOC);

$logo_path = 'uploads/photos/prestataire.jpg';
if ($prestataire && !empty($prestataire['logo']) && file_exists("../" . $prestataire['logo'])) {
    $logo_path = $prestataire['logo'];
}

if (!$prestataire) {
    $errors[] = "Profil prestataire incomplet.";
    $niveau = 'Standard';
    $id_prestataire = null;
    $id_niveau = null;
} else {
    $niveau = $prestataire['niveau'];
    $id_prestataire = $prestataire['id_prestataire'];
    $id_niveau = $prestataire['id_niveau'];
}

try {
    // === PRESTATIONS DISPONIBLES ===
    if ($id_niveau) {
        $stmt = $pdo->prepare("
            SELECT id_prestation, nom, description, taux_remboursement 
            FROM prestations 
            WHERE id_niveau = ? AND taux_remboursement BETWEEN 0 AND 100
            ORDER BY nom
        ");
        $stmt->execute([$id_niveau]);
        $prestations = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (empty($prestations)) {
            $errors[] = "Aucune prestation disponible pour votre niveau.";
        }
    }

    // === BÉNÉFICIAIRES SELON TYPE PRESTATAIRE ===
    if (empty($errors)) {
        if ($niveau === 'Hôpital') {
            $sql = "
                SELECT DISTINCT 
                    b.id_beneficiaire, b.nom, b.prenom, b.code_beneficiaire, 
                    a.id_adhesion, a.num_adherent, nr.id_referencement
                FROM beneficiaires b
                JOIN adhesions a ON b.id_adhesion = a.id_adhesion
                JOIN notes_referencement nr ON nr.id_beneficiaire = b.id_beneficiaire
                WHERE nr.id_prestataire_destinataire = ?
                  AND nr.statut = 'approuve' 
                  AND nr.consulte = 0
                  AND b.statut = 'actif'
                  AND (b.date_sortie IS NULL OR b.date_sortie > ?)
            ";
            $params = [$id_prestataire, $today];
        } else {
            $sql = "
                SELECT 
                    b.id_beneficiaire, b.nom, b.prenom, b.code_beneficiaire, 
                    a.id_adhesion, a.num_adherent
                FROM beneficiaires b
                JOIN adhesions a ON b.id_adhesion = a.id_adhesion
                WHERE b.statut = 'actif'
                  AND (b.date_sortie IS NULL OR b.date_sortie > ?)
            ";
            $params = [$today];
        }

        if ($search_code !== '') {
            $sql .= " AND b.code_beneficiaire LIKE ?";
            $params[] = "%$search_code%";
        }

        $sql .= " ORDER BY b.nom, b.prenom";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $beneficiaires = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // === PRÉ-SÉLECTION BÉNÉFICIAIRE + RÉFÉRENCEMENT VALIDE (HÔPITAL) ===
    if ($num_beneficiaire && $id_adhesion && empty($errors)) {
        $sql = "
            SELECT 
                b.id_beneficiaire, b.statut AS b_statut, b.date_sortie,
                nr.id_referencement, nr.consulte
            FROM beneficiaires b
            JOIN adhesions a ON b.id_adhesion = a.id_adhesion
            LEFT JOIN notes_referencement nr ON nr.id_beneficiaire = b.id_beneficiaire 
                AND nr.id_prestataire_destinataire = ? 
                AND nr.statut = 'approuve'
        ";
        $params = [$id_prestataire, $num_beneficiaire, $id_adhesion];
        if ($niveau === 'Hôpital') {
            $sql .= " AND nr.consulte = 0";
        }
        $sql .= " WHERE b.code_beneficiaire = ? AND a.id_adhesion = ?";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $info = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$info) {
            $errors[] = "Bénéficiaire non trouvé.";
        } elseif ($info['b_statut'] !== 'actif' || ($info['date_sortie'] && $info['date_sortie'] <= $today)) {
            $errors[] = "Bénéficiaire non éligible (inactif ou sorti).";
        } elseif ($niveau === 'Hôpital') {
            if (!$info['id_referencement'] || $info['consulte'] == 1) {
                $errors[] = "Référencement invalide ou déjà utilisé. Nouvelle référence requise.";
            } else {
                $ref_id = $info['id_referencement'];
                $preselected_beneficiaire_id = $info['id_beneficiaire'];
            }
        } else {
            $preselected_beneficiaire_id = $info['id_beneficiaire'];
        }
    }

    // === TRAITEMENT FORMULAIRE ===
    $form_submitted_successfully = false;
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_prestations'])) {
        if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
            $errors[] = "Token de sécurité invalide.";
        } else {
            $id_beneficiaire = filter_input(INPUT_POST, 'id_beneficiaire', FILTER_VALIDATE_INT) ?? 0;
            $date_soin = trim((string)filter_input(INPUT_POST, 'date_soin', FILTER_DEFAULT) ?? $today);
            $prestation_ids = $_POST['id_prestation'] ?? [];
            $montant_factures = $_POST['montant_facture'] ?? [];
            $commentaire = trim($_POST['commentaire'] ?? '');

            if ($id_beneficiaire <= 0) $errors[] = "Sélectionnez un bénéficiaire.";
            if (empty($prestation_ids)) $errors[] = "Ajoutez au moins une prestation.";

            // === VÉRIF RÉFÉRENCEMENT HÔPITAL (consulte = 0) ===
            if ($niveau === 'Hôpital') {
                $stmt = $pdo->prepare("
                    SELECT id_referencement 
                    FROM notes_referencement 
                    WHERE id_beneficiaire = ? 
                      AND id_prestataire_destinataire = ? 
                      AND statut = 'approuve' 
                      AND consulte = 0
                ");
                $stmt->execute([$id_beneficiaire, $id_prestataire]);
                $valid_ref = $stmt->fetchColumn();
                if (!$valid_ref) {
                    $errors[] = "Référencement invalide ou déjà consommé.";
                } else {
                    $ref_id = $valid_ref;
                }
            }

            // === LIGNES PRESTATIONS ===
            $valid_lines = [];
            foreach ($prestation_ids as $idx => $id_p_str) {
                $id_p = (int)$id_p_str;
                $mont_f = (float)($montant_factures[$idx] ?? 0);

                if ($id_p <= 0 || $mont_f <= 0 || $mont_f > 1000000) {
                    $errors[] = "Ligne " . ($idx + 1) . " invalide.";
                    continue;
                }

                $taux = 0;
                $nom_prestation = 'Inconnue';
                foreach ($prestations as $p) {
                    if ((int)$p['id_prestation'] === $id_p) {
                        $taux = (float)$p['taux_remboursement'];
                        $nom_prestation = $p['nom'] . ($p['description'] ? ' (' . $p['description'] . ')' : '');
                        break;
                    }
                }
                if ($taux === 0) {
                    $errors[] = "Prestation non reconnue (ligne " . ($idx + 1) . ").";
                    continue;
                }

                $mont_r = round($mont_f * $taux / 100, 2);
                $mont_ap = round($mont_f - $mont_r, 2);

                $valid_lines[] = [
                    'id_p' => $id_p,
                    'mont_f' => $mont_f,
                    'taux' => $taux,
                    'mont_r' => $mont_r,
                    'mont_ap' => $mont_ap,
                    'nom_prestation' => $nom_prestation
                ];
            }

            if (empty($valid_lines)) $errors[] = "Aucune prestation valide.";

            // === PIÈCES JOINTES ===
            $upload_subdir = 'Uploads/documents/';   // ← Chemin relatif depuis la racine du site
            $upload_dir = __DIR__ . '/../' . $upload_subdir; // Chemin physique pour l'écriture
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            $pieces_jointes = null; // Ce qui sera stocké en base
            $allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
            $maxSize = 5 * 1024 * 1024; // 5 Mo

            // Photo capturée (webcam)
            if (!empty($_POST['captured_photo'])) {
                $data = trim($_POST['captured_photo']);
                if (preg_match('/^data:image\/(jpeg|png);base64,(.*)$/i', $data, $m)) {
                    $ext = $m[1];
                    $binary = base64_decode($m[2]);
                    if ($binary !== false && strlen($binary) <= $maxSize) {
                        $file_name = uniqid('photo_', true) . '.' . $ext;
                        $dest_physical = $upload_dir . $file_name;

                        if (file_put_contents($dest_physical, $binary)) {
                            $pieces_jointes = $upload_subdir . $file_name; // ← RELATIF !
                        } else {
                            $errors[] = "Échec de l'enregistrement de la photo.";
                        }
                    } else {
                        $errors[] = "Photo invalide ou trop lourde.";
                    }
                }
            }

            // Fichier uploadé classique
            elseif (isset($_FILES['pieces_jointes']) && $_FILES['pieces_jointes']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['pieces_jointes'];
                $mime = mime_content_type($file['tmp_name']);
                if (in_array($mime, $allowedTypes) && $file['size'] <= $maxSize) {
                    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                    if (in_array($ext, ['pdf', 'jpg', 'jpeg', 'png'])) {
                        $file_name = uniqid('doc_', true) . '.' . $ext;
                        $dest_physical = $upload_dir . $file_name;

                        if (move_uploaded_file($file['tmp_name'], $dest_physical)) {
                            $pieces_jointes = $upload_subdir . $file_name; // ← RELATIF !
                        } else {
                            $errors[] = "Échec du déplacement du fichier.";
                        }
                    } else {
                        $errors[] = "Format de fichier non autorisé.";
                    }
                } else {
                    $errors[] = "Fichier invalide ou trop lourd (max 5 Mo).";
                }
            }

            if (empty($errors) && $pieces_jointes === null) {
                $errors[] = "Pièce jointe obligatoire. Fournissez un fichier ou une photo.";
            }

            // === ENREGISTREMENT + EXPIRATION DANS notes_referencement ===
            if (empty($errors)) {
                $pdo->beginTransaction();
                try {
                    $stmt = $pdo->prepare("SELECT id_adhesion FROM beneficiaires WHERE id_beneficiaire = ?");
                    $stmt->execute([$id_beneficiaire]);
                    $id_adhesion_db = $stmt->fetchColumn();
                    if (!$id_adhesion_db) throw new Exception("Adhésion introuvable.");

                    $total_f = $total_r = $total_ap = 0;
                    $success_lines = [];

                    foreach ($valid_lines as $line) {
                        $stmt = $pdo->prepare("
                            INSERT INTO demandes_remboursement 
                            (id_adhesion, id_beneficiaire, id_prestataire, id_prestation, date_soin, 
                             montant_facture, montant_rembourse, montant_a_payer, statut, pieces_jointes, commentaire, created_by)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'en_attente', ?, ?, ?)
                        ");
                        $stmt->execute([
                            $id_adhesion_db,
                            $id_beneficiaire,
                            $id_prestataire,
                            $line['id_p'],
                            $date_soin,
                            $line['mont_f'],
                            $line['mont_r'],
                            $line['mont_ap'],
                            $pieces_jointes,
                            $commentaire,
                            $_SESSION['user_id']
                        ]);

                        logActivity($pdo, $_SESSION['user_id'], "Prestation '{$line['nom_prestation']}' enregistrée");
                        sendNotification($pdo, $_SESSION['user_id'], "À payer: " . number_format($line['mont_ap'], 2) . " FCFA", 'remboursement');

                        $success_lines[] = "<strong>{$line['nom_prestation']}</strong><br>
                            Facturé: " . number_format($line['mont_f'], 2) . " | Remboursé: " . number_format($line['mont_r'], 2) . " | À payer: " . number_format($line['mont_ap'], 2) . " FCFA";

                        $total_f += $line['mont_f'];
                        $total_r += $line['mont_r'];
                        $total_ap += $line['mont_ap'];
                    }

                    if ($niveau === 'Hôpital' && $ref_id > 0) {
                        $stmt = $pdo->prepare("
                            UPDATE notes_referencement 
                            SET statut = 'expiré', consulte = 1, date_consultation = ? 
                            WHERE id_referencement = ? 
                              AND id_prestataire_destinataire = ?
                        ");
                        $stmt->execute([$date_soin, $ref_id, $id_prestataire]);
                    }

                    $pdo->commit();

                    $success = implode('<br><br>', $success_lines) . "<br><hr><strong>Totaux :</strong><br>
                        Facturé: " . number_format($total_f, 2) . " FCFA<br>
                        Remboursé: " . number_format($total_r, 2) . " FCFA<br>
                        À payer: " . number_format($total_ap, 2) . " FCFA";

                    if ($niveau === 'Hôpital') {
                        $success .= "<br><span class='text-danger'><strong>Référencement expiré après prestation.</strong></span>";
                    }

                    $form_submitted_successfully = true;
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $errors[] = "Échec enregistrement : " . $e->getMessage();
                    error_log("register_prestation.php - Transaction failed: " . $e->getMessage());
                }
            }
        }
    }

    // Prepare form data for display
    if ($form_submitted_successfully) {
        $posted_ids = [];
        $posted_monts = [];
        $commentaire_display = '';
        $date_soin_display = $today;
        $num = 1;
    } else {
        $posted_ids = $_POST['id_prestation'] ?? [];
        $posted_monts = $_POST['montant_facture'] ?? [];
        $commentaire_display = $_POST['commentaire'] ?? '';
        $date_soin_display = trim((string)($_POST['date_soin'] ?? $today));
        $num = max(1, count($posted_ids));
    }
} catch (Exception $e) {
    $errors[] = "Erreur système : " . htmlspecialchars($e->getMessage());
    error_log("register_prestation.php: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#1e40af">
    <title>Enregistrement des Prestations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <link rel="manifest" href="manifest.json">
    <style>
        :root {
            --primary: #1e40af;
            --primary-light: #3b82f6;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --dark: #0f172a;
            --light: #f8fafc;
            --gray: #475569;
            /* Darker gray for better contrast */
            --border: rgba(0, 0, 0, 0.1);
            --glass: rgba(255, 255, 255, 0.15);
            --shadow: 0 8px 32px rgba(0, 0, 0, 0.12);
            --shadow-lg: 0 12px 40px rgba(0, 0, 0, 0.15);
            --radius: 1.25rem;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --form-bg: rgba(255, 255, 255, 0.8);
            --form-text: #0f172a;
            --label-color: #475569;
        }

        [data-theme="dark"] {
            --primary: #60a5fa;
            /* Lighter for better contrast on dark */
            --primary-light: #93c5fd;
            --dark: #f8fafc;
            --light: #0f172a;
            --glass: rgba(15, 23, 42, 0.7);
            --border: rgba(255, 255, 255, 0.1);
            --shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
            --form-bg: rgba(15, 23, 42, 0.8);
            --form-text: #f8fafc;
            --label-color: #e2e8f0;
            /* Lighter gray for dark mode */
        }

        @media (prefers-reduced-motion: reduce) {
            * {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            font-family: 'Inter', sans-serif;
            color: var(--dark);
            min-height: 100vh;
            transition: var(--transition);
            padding-bottom: 2rem;
            line-height: 1.6;
        }

        [data-theme="dark"] body {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
        }

        .header {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            padding: 1rem;
            border-bottom-left-radius: 2rem;
            border-bottom-right-radius: 2rem;
            box-shadow: var(--shadow-lg);
            margin-bottom: 1rem;
            position: relative;
            overflow: hidden;
        }

        .logo {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 12px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
            transition: var(--transition);
        }

        .logo:hover {
            transform: scale(1.05) rotate(2deg);
        }

        .page-title {
            font-size: clamp(1.2rem, 4vw, 1.6rem);
            font-weight: 800;
            margin: 0;
            text-shadow: 0 1px 8px rgba(0, 0, 0, 0.2);
        }

        .neumorphic {
            background: var(--light);
            border-radius: var(--radius);
            box-shadow:
                6px 6px 12px rgba(0, 0, 0, 0.08),
                -6px -6px 12px rgba(255, 255, 255, 0.8);
            padding: 1.5rem;
            transition: var(--transition);
            margin-bottom: 1rem;
        }

        [data-theme="dark"] .neumorphic {
            background: var(--light);
            box-shadow:
                6px 6px 12px rgba(0, 0, 0, 0.25),
                -6px -6px 12px rgba(255, 255, 255, 0.08);
        }

        .form-control,
        .form-select {
            border-radius: 12px;
            padding: 0.875rem 1rem;
            border: 1px solid var(--border);
            background: var(--form-bg);
            color: var(--form-text);
            backdrop-filter: blur(8px);
            font-size: 1rem;
            transition: var(--transition);
            box-shadow: inset 1px 1px 3px rgba(0, 0, 0, 0.04);
            min-height: 3rem;
            /* Larger touch target */
        }

        .form-control:focus,
        .form-select:focus {
            outline: 2px solid var(--primary);
            outline-offset: 2px;
            box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.25);
            background: var(--form-text)==#0f172a ? rgba(255, 255, 255, 0.9): rgba(15, 23, 42, 0.9);
            transform: translateY(-1px);
        }

        .form-control::placeholder {
            color: var(--gray);
            opacity: 1;
        }

        .form-label {
            position: absolute;
            top: 0.875rem;
            left: 1rem;
            font-size: 1rem;
            color: var(--label-color);
            pointer-events: none;
            transition: 0.2s ease all;
            transform-origin: 0 0;
            z-index: 1;
        }

        .form-control:focus~.form-label,
        .form-control:not(:placeholder-shown)~.form-label,
        .form-select:focus~.form-label,
        .form-select:not([value=""])~.form-label {
            top: -0.5rem;
            left: 0.75rem;
            font-size: 0.75rem;
            color: var(--primary);
            background: var(--light);
            padding: 0 0.375rem;
            font-weight: 600;
        }

        .btn-neo {
            border-radius: 12px;
            padding: 0.875rem 1.5rem;
            /* Larger padding */
            font-weight: 600;
            font-size: 1rem;
            box-shadow:
                3px 3px 6px rgba(0, 0, 0, 0.08),
                -3px -3px 6px rgba(255, 255, 255, 0.8);
            transition: var(--transition);
            min-height: 3rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .btn-neo:focus {
            outline: 2px solid var(--primary);
            outline-offset: 2px;
        }

        .btn-neo:hover {
            transform: translateY(-1px);
            box-shadow:
                4px 4px 8px rgba(0, 0, 0, 0.12),
                -4px -4px 8px rgba(255, 255, 255, 0.9);
        }

        .total-box {
            background: var(--form-bg);
            color: var(--form-text);
            border-radius: 12px;
            padding: 1rem;
            text-align: center;
            box-shadow:
                3px 3px 6px rgba(0, 0, 0, 0.08),
                -3px -3px 6px rgba(255, 255, 255, 0.8);
            font-size: 0.9rem;
            transition: var(--transition);
            border: 1px solid var(--border);
        }

        .total-box strong {
            font-size: 1.3rem;
            font-weight: 800;
        }

        .badge-pro {
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            color: white;
            font-size: 0.75rem;
            padding: 0.5rem 0.875rem;
            border-radius: 50px;
            font-weight: 600;
        }

        /* Dark Mode Toggle */
        .theme-toggle {
            width: 44px;
            height: 24px;
            background: #cbd5e1;
            border-radius: 50px;
            position: relative;
            cursor: pointer;
            transition: 0.3s;
        }

        .theme-toggle::before {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: white;
            top: 2px;
            left: 2px;
            transition: 0.3s;
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.15);
        }

        [data-theme="dark"] .theme-toggle {
            background: #3b82f6;
        }

        [data-theme="dark"] .theme-toggle::before {
            transform: translateX(20px);
        }

        /* Section Headers */
        .section-header {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
            font-weight: 600;
            color: var(--primary);
            font-size: 1.1rem;
        }

        .section-header i {
            font-size: 1.2rem;
            color: var(--primary-light);
        }

        /* Prestation Rows */
        .prestation-row {
            background: var(--form-bg);
            color: var(--form-text);
            box-shadow: inset 1px 1px 3px rgba(0, 0, 0, 0.04);
            transition: var(--transition);
            border: 1px solid var(--border);
        }

        .prestation-row:hover {
            background: color-mix(in srgb, var(--form-bg) 95%, var(--primary) 5%);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }

        /* Responsive Adjustments */
        @media (max-width: 576px) {
            .header {
                padding: 0.75rem;
                border-radius: 1.5rem;
            }

            .logo {
                width: 40px;
                height: 40px;
            }

            .page-title {
                font-size: 1.1rem;
            }

            .neumorphic {
                padding: 1rem;
            }

            .form-control,
            .form-select {
                padding: 0.75rem 0.875rem;
                font-size: 0.95rem;
            }

            .total-box {
                padding: 0.875rem;
            }

            .total-box strong {
                font-size: 1.2rem;
            }

            .prestation-row .row>* {
                margin-bottom: 0.5rem;
            }

            .btn-grid {
                grid-template-columns: 1fr;
                gap: 0.75rem;
            }
        }

        @media (min-width: 768px) {
            .page-title {
                font-size: 1.6rem;
            }

            .logo {
                width: 55px;
                height: 55px;
            }

            .btn-grid {
                grid-template-columns: unset;
                justify-content: flex-end;
                gap: 1rem;
            }
        }

        /* Improved Alert Styling */
        .alert {
            border: none;
            border-radius: 12px;
            box-shadow: var(--shadow);
            font-weight: 500;
            padding: 1rem 1.25rem;
            margin-bottom: 1rem;
        }

        .alert i {
            flex-shrink: 0;
            font-size: 1.25rem;
        }

        .alert[role="status"] {
            border-left: 4px solid;
        }

        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }

        /* Skip link */
        .skip-link {
            position: absolute;
            top: -40px;
            left: 6px;
            background: var(--primary);
            color: white;
            padding: 8px;
            z-index: 100;
            border-radius: 0 0 4px 4px;
        }

        .skip-link:focus {
            top: 6px;
        }
    </style>
</head>

<body data-theme="light">

    <a href="#main-content" class="skip-link">Aller au contenu principal</a>

    <!-- HEADER -->
    <header class="header">
        <div class="container-fluid px-3">
            <div class="row align-items-center g-2">
                <div class="col-auto">
                    <img src="<?= $logo_path ?>" alt="Logo de l'entreprise" class="logo" data-aos="zoom-in">
                </div>
                <div class="col text-center">
                    <h1 class="page-title mb-1" data-aos="fade-up" data-aos-delay="100">
                        Enregistrement des Prestations
                    </h1>
                    <?php if ($niveau === 'Hôpital'): ?>
                        <span class="badge-pro d-inline-block" data-aos="fade-up" data-aos-delay="200" aria-label="Mode Hôpital activé">
                            Mode Hôpital
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-auto">
                    <div class="d-flex align-items-center gap-2">
                        <button class="theme-toggle" id="themeToggle" aria-label="Basculer le mode sombre/clair" data-aos="fade-left" data-aos-delay="300"></button>
                        <a href="dashboard_prestataire.php" class="btn btn-outline-light btn-sm rounded-pill px-2 py-1" aria-label="Retour au tableau de bord">
                            <i class="bi bi-arrow-left" aria-hidden="true"></i> <span class="sr-only">Retour</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main id="main-content" class="container-fluid px-3">

        <!-- RECHERCHE -->
        <section class="neumorphic" data-aos="fade-up" aria-labelledby="search-heading">
            <h2 id="search-heading" class="sr-only">Recherche de bénéficiaire</h2>
            <form method="GET" class="position-relative" role="search">
                <label for="search_code" class="sr-only">Rechercher par code bénéficiaire</label>
                <input type="text" id="search_code" name="search_code" class="form-control"
                    placeholder="Entrez le code bénéficiaire..." value="<?= htmlspecialchars($search_code) ?>"
                    aria-describedby="search-help">
                <button type="submit" class="btn btn-primary position-absolute end-0 top-50 translate-middle-y me-2" aria-label="Lancer la recherche">
                    <i class="bi bi-search" aria-hidden="true"></i>
                    <span class="sr-only">Rechercher</span>
                </button>
                <small id="search-help" class="sr-only">Appuyez sur Entrée pour rechercher.</small>
            </form>
        </section>

        <!-- SUCCÈS -->
        <?php if ($success): ?>
            <div class="alert alert-success d-flex align-items-start neumorphic" role="status" aria-live="polite" data-aos="fade-up">
                <i class="bi bi-check-circle-fill me-2 fs-5 text-success" aria-hidden="true"></i>
                <div><?= $success ?></div>
            </div>
        <?php endif; ?>

        <!-- ERREURS -->
        <?php foreach ($errors as $e): ?>
            <div class="alert alert-danger d-flex align-items-start neumorphic" role="alert" aria-live="assertive" data-aos="fade-up">
                <i class="bi bi-exclamation-triangle-fill me-2 fs-5 text-danger" aria-hidden="true"></i>
                <?= htmlspecialchars($e) ?>
            </div>
        <?php endforeach; ?>

        <!-- FORMULAIRE PRINCIPAL -->
        <section class="neumorphic" data-aos="fade-up" data-aos-delay="100" aria-labelledby="form-heading">
            <h2 id="form-heading" class="sr-only">Formulaire d'enregistrement des prestations</h2>
            <form method="POST" enctype="multipart/form-data" id="prestationForm" novalidate>
                <fieldset>
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                    <input type="hidden" name="captured_photo" id="captured_photo">

                    <!-- BÉNÉFICIAIRE -->
                    <div class="mb-3 position-relative">
                        <div class="section-header">
                            <i class="bi bi-person-lines-fill" aria-hidden="true"></i>
                            Sélection du Bénéficiaire <span class="text-danger" aria-label="Requis">*</span>
                        </div>
                        <label for="beneficiaire-select" class="form-label sr-only">Sélectionner un bénéficiaire</label>
                        <select class="form-select" id="beneficiaire-select" name="id_beneficiaire" required aria-required="true"
                            aria-describedby="beneficiaire-help">
                            <option value="">Choisir un bénéficiaire...</option>
                            <?php foreach ($beneficiaires as $b): ?>
                                <option value="<?= $b['id_beneficiaire'] ?>"
                                    <?= ($preselected_beneficiaire_id == $b['id_beneficiaire']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars("{$b['nom']} {$b['prenom']} (#{$b['code_beneficiaire']})") ?>
                                    <?php if (isset($b['id_referencement'])): ?>
                                        <span class="text-muted small">[Réf. #<?= $b['id_referencement'] ?>]</span>
                                    <?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small id="beneficiaire-help" class="form-text text-muted">Sélectionnez le nom et code du bénéficiaire éligible.</small>
                    </div>

                    <!-- DATE SOIN -->
                    <div class="mb-3 position-relative">
                        <div class="section-header">
                            <i class="bi bi-calendar-event" aria-hidden="true"></i>
                            Date du Soin
                        </div>
                        <label for="date_soin" class="form-label sr-only">Date du soin</label>
                        <input type="date" id="date_soin" class="form-control" name="date_soin" value="<?= $date_soin_display ?>" required
                            aria-describedby="date-help" min="<?= date('Y-m-d', strtotime('-1 year')) ?>" max="<?= $today ?>">
                        <small id="date-help" class="form-text text-muted">Date de la prestation (aujourd'hui par défaut).</small>
                    </div>

                    <!-- PRESTATIONS -->
                    <div class="mb-3">
                        <div class="section-header">
                            <i class="bi bi-clipboard-check" aria-hidden="true"></i>
                            Détails des Prestations <span class="text-danger" aria-label="Requis">*</span>
                        </div>
                        <div id="prestations-rows" role="region" aria-live="polite">
                            <?php for ($i = 0; $i < $num; $i++): ?>
                                <?php
                                $id_p = $posted_ids[$i] ?? '';
                                $mont = $posted_monts[$i] ?? '';
                                ?>
                                <div class="prestation-row p-3 mb-2 rounded-3" role="group" aria-labelledby="prestation-label-<?= $i ?>">
                                    <h3 id="prestation-label-<?= $i ?>" class="sr-only">Ligne de prestation <?= $i + 1 ?></h3>
                                    <div class="row g-2 align-items-end">
                                        <div class="col-12 col-lg-6 position-relative">
                                            <label for="prestation-<?= $i ?>" class="form-label sr-only">Type de prestation</label>
                                            <select class="form-select form-select-sm" id="prestation-<?= $i ?>" name="id_prestation[]" required aria-required="true">
                                                <option value="">Sélectionner une prestation...</option>
                                                <?php foreach ($prestations as $p): ?>
                                                    <option value="<?= $p['id_prestation'] ?>" data-taux="<?= $p['taux_remboursement'] ?>" <?= ($id_p == $p['id_prestation']) ? 'selected' : '' ?>>
                                                        <?= htmlspecialchars($p['nom'] . ($p['description'] ? ' - ' . $p['description'] : '')) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-6 col-lg-2 position-relative">
                                            <label for="montant-<?= $i ?>" class="form-label sr-only">Montant facturé en FCFA</label>
                                            <input type="number" id="montant-<?= $i ?>" step="0.01" min="0.01" class="form-control form-control-sm" name="montant_facture[]" value="<?= htmlspecialchars($mont) ?>" required
                                                aria-describedby="montant-help-<?= $i ?>" placeholder="0.00">
                                            <small id="montant-help-<?= $i ?>" class="form-text text-muted sr-only">Montant en FCFA</small>
                                        </div>
                                        <div class="col-3 col-lg-2">
                                            <span class="form-control form-control-sm bg-light text-center taux-span" aria-label="Taux de remboursement">0 %</span>
                                        </div>
                                        <div class="col-3 col-lg-2">
                                            <span class="form-control form-control-sm bg-light text-center remb-span" aria-label="Montant remboursé">0 FCFA</span>
                                        </div>
                                        <?php if ($num > 1 || $i > 0): ?>
                                            <div class="col-auto">
                                                <button type="button" class="btn btn-outline-danger btn-sm rounded-circle remove-row" title="Supprimer cette ligne" aria-label="Supprimer la ligne de prestation <?= $i + 1 ?>">
                                                    <i class="bi bi-trash" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endfor; ?>
                        </div>
                        <button type="button" class="btn btn-outline-primary btn-sm w-100 rounded-pill mb-3" id="add-prestation" aria-label="Ajouter une nouvelle ligne de prestation">
                            <i class="bi bi-plus-circle me-1" aria-hidden="true"></i>Ajouter une Prestation
                        </button>

                        <!-- TOTAUX -->
                        <div class="row g-2" role="group" aria-labelledby="totals-heading">
                            <h3 id="totals-heading" class="sr-only">Totaux des montants</h3>
                            <div class="col-4">
                                <div class="total-box text-primary border-primary" role="status" aria-live="polite">
                                    <div class="small fw-bold">Total Facturé</div>
                                    <strong id="total_facture" aria-label="Total facturé">0.00</strong> FCFA
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="total-box text-success border-success" role="status" aria-live="polite">
                                    <div class="small fw-bold">Total Remboursé</div>
                                    <strong id="total_rembourse" aria-label="Total remboursé">0.00</strong> FCFA
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="total-box text-warning border-warning" role="status" aria-live="polite">
                                    <div class="small fw-bold">Total à Payer</div>
                                    <strong id="total_a_payer" aria-label="Total à payer">0.00</strong> FCFA
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- PIÈCE JOINTE -->
                    <div class="mb-3">
                        <div class="section-header">
                            <i class="bi bi-paperclip" aria-hidden="true"></i>
                            Pièce Jointe Obligatoire (PDF, JPG, PNG - max 5Mo) <span class="text-danger" aria-label="Requis">*</span>
                        </div>
                        <label for="pieces_jointes" class="form-label sr-only">Sélectionner un fichier pièce jointe</label>
                        <div class="input-group">
                            <input type="file" id="pieces_jointes" class="form-control" name="pieces_jointes" accept=".pdf,.jpg,.jpeg,.png" required
                                aria-describedby="file-help">
                            <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#cameraModal" aria-label="Prendre une photo avec la caméra">
                                <i class="bi bi-camera me-1" aria-hidden="true"></i><span class="sr-only">Prendre Photo</span>
                            </button>
                        </div>
                        <small id="file-help" class="form-text text-muted">Joignez une facture ou preuve pour validation.</small>
                        <img id="preview" src="#" alt="Aperçu de la pièce jointe sélectionnée" class="img-fluid rounded-3 mt-2 d-none" style="max-height: 150px; box-shadow: var(--shadow);" role="img">
                    </div>

                    <!-- COMMENTAIRE -->
                    <div class="mb-4">
                        <div class="section-header">
                            <i class="bi bi-chat-text" aria-hidden="true"></i>
                            Commentaire Optionnel
                        </div>
                        <label for="commentaire" class="form-label sr-only">Commentaire</label>
                        <textarea id="commentaire" class="form-control" name="commentaire" rows="3" maxlength="500"
                            placeholder="Détails supplémentaires sur les soins fournis..." aria-describedby="comment-help"><?= htmlspecialchars($commentaire_display) ?></textarea>
                        <small id="comment-help" class="form-text text-muted">Observations ou notes (max. 500 caractères).</small>
                    </div>
                </fieldset>

                <!-- BOUTONS D'ACTION -->
                <div class="d-grid gap-2 btn-grid">
                    <a href="dashboard_prestataire.php" class="btn btn-outline-secondary btn-neo">
                        <i class="bi bi-arrow-left me-1" aria-hidden="true"></i>Retour au Dashboard
                    </a>
                    <button type="submit" name="submit_prestations" id="submitButton" class="btn btn-primary btn-neo">
                        <i class="bi bi-check-lg me-1" aria-hidden="true"></i>Enregistrer la Demande
                    </button>
                </div>
            </form>
        </section>
    </main>

    <!-- TEMPLATE POUR AJOUT DE LIGNES -->
    <div id="prestation-template" style="display:none;">
        <div class="prestation-row p-3 mb-2 rounded-3" role="group" aria-labelledby="new-prestation-label">
            <h3 id="new-prestation-label" class="sr-only">Nouvelle ligne de prestation</h3>
            <div class="row g-2 align-items-end">
                <div class="col-12 col-lg-6 position-relative">
                    <label class="form-label sr-only">Type de prestation</label>
                    <select class="form-select form-select-sm" name="id_prestation[]" required aria-required="true">
                        <option value="">Sélectionner une prestation...</option>
                        <?php foreach ($prestations as $p): ?>
                            <option value="<?= $p['id_prestation'] ?>" data-taux="<?= $p['taux_remboursement'] ?>">
                                <?= htmlspecialchars($p['nom'] . ($p['description'] ? ' - ' . $p['description'] : '')) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-6 col-lg-2 position-relative">
                    <label class="form-label sr-only">Montant facturé en FCFA</label>
                    <input type="number" step="0.01" min="0.01" class="form-control form-control-sm" name="montant_facture[]" required placeholder="0.00">
                </div>
                <div class="col-3 col-lg-2">
                    <span class="form-control form-control-sm bg-light text-center taux-span" aria-label="Taux de remboursement">0 %</span>
                </div>
                <div class="col-3 col-lg-2">
                    <span class="form-control form-control-sm bg-light text-center remb-span" aria-label="Montant remboursé">0 FCFA</span>
                </div>
                <div class="col-auto">
                    <button type="button" class="btn btn-outline-danger btn-sm rounded-circle remove-row" title="Supprimer" aria-label="Supprimer cette ligne">
                        <i class="bi bi-trash" aria-hidden="true"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL CAMÉRA POUR PHOTO -->
    <div class="modal fade" id="cameraModal" tabindex="-1" aria-labelledby="camera-title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-4">
                <div class="modal-header border-0">
                    <h2 class="modal-title" id="camera-title">
                        <i class="bi bi-camera" aria-hidden="true"></i> Capturer une Photo
                    </h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer la modal photo"></button>
                </div>
                <div class="modal-body text-center p-0">
                    <video id="video" autoplay playsinline muted class="rounded-3 w-100" style="max-height: 50vh;" aria-label="Flux caméra en direct" aria-live="off"></video>
                    <canvas id="canvas" style="display:none;"></canvas>
                    <div class="p-3">
                        <button id="capture" class="btn btn-primary rounded-pill px-4 py-2 me-2" aria-label="Capturer la photo actuelle">
                            <i class="bi bi-camera-fill me-1" aria-hidden="true"></i>Capturer
                        </button>
                        <button id="retake" class="btn btn-secondary rounded-pill px-4 py-2" style="display:none;" aria-label="Reprendre une nouvelle photo">
                            <i class="bi bi-arrow-counterclockwise me-1" aria-hidden="true"></i>Reprendre
                        </button>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary rounded-pill" data-bs-dismiss="modal" aria-label="Annuler la capture">
                        <i class="bi bi-x me-1" aria-hidden="true"></i>Annuler
                    </button>
                    <button id="savePhoto" class="btn btn-primary rounded-pill" style="display:none;" aria-label="Utiliser cette photo comme pièce jointe">
                        <i class="bi bi-check me-1" aria-hidden="true"></i>Utiliser Photo
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL DE CONFIRMATION D'ENREGISTREMENT -->
    <div class="modal fade" id="confirmModal" tabindex="-1" aria-labelledby="confirm-title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-4">
                <div class="modal-header border-0 bg-primary text-white">
                    <h2 class="modal-title" id="confirm-title">
                        <i class="bi bi-exclamation-triangle me-2" aria-hidden="true"></i>Confirmer l'Enregistrement
                    </h2>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fermer la confirmation"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3">Vous êtes sur le point d'enregistrer cette demande de remboursement. Vérifiez les détails suivants :</p>
                    <ul class="list-unstyled">
                        <li><strong>Bénéficiaire :</strong> <span id="confirm-beneficiaire"></span></li>
                        <li><strong>Date du soin :</strong> <span id="confirm-date"></span></li>
                        <li><strong>Total facturé :</strong> <span id="confirm-total-facture"></span> FCFA</li>
                        <li><strong>Total remboursé :</strong> <span id="confirm-total-rembourse"></span> FCFA</li>
                        <li><strong>Total à payer :</strong> <span id="confirm-total-apayer"></span> FCFA</li>
                        <?php if ($niveau === 'Hôpital'): ?>
                            <li class="text-warning"><strong>Note :</strong> Le référencement sera marqué comme expiré et consulté après enregistrement.</li>
                        <?php endif; ?>
                    </ul>
                    <div class="alert alert-warning mt-3" role="alert">
                        <i class="bi bi-info-circle me-2"></i>Cette action est irréversible. Assurez-vous que toutes les informations sont correctes.
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal" aria-label="Annuler l'enregistrement">
                        <i class="bi bi-x me-1" aria-hidden="true"></i>Annuler
                    </button>
                    <button type="button" id="confirmSubmit" class="btn btn-primary rounded-pill" aria-label="Confirmer et enregistrer la demande">
                        <i class="bi bi-check-lg me-1" aria-hidden="true"></i>Confirmer l'Enregistrement
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 500,
            once: true
        });

        // Dark Mode Toggle
        const toggle = document.getElementById('themeToggle');
        const body = document.body;
        toggle.addEventListener('click', () => {
            const theme = body.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
            body.setAttribute('data-theme', theme);
            localStorage.setItem('theme', theme);
        });
        const savedTheme = localStorage.getItem('theme') || 'light';
        body.setAttribute('data-theme', savedTheme);

        // Calculs pour Prestations
        function calcRow(row) {
            const sel = row.querySelector('select[name="id_prestation[]"]');
            const opt = sel.selectedOptions[0];
            const taux = parseFloat(opt?.dataset.taux || 0);
            const f = parseFloat(row.querySelector('input[name="montant_facture[]"]').value) || 0;
            const r = Math.round((f * taux / 100) * 100) / 100;
            row.querySelector('.taux-span').textContent = taux + ' %';
            row.querySelector('.remb-span').textContent = r.toFixed(0) + ' FCFA';
            updateTotals();
        }

        function updateTotals() {
            let tf = 0,
                tr = 0;
            document.querySelectorAll('.prestation-row').forEach(row => {
                tf += parseFloat(row.querySelector('input[name="montant_facture[]"]').value) || 0;
                tr += parseFloat(row.querySelector('.remb-span').textContent.replace(/[^0-9.]/g, '')) || 0;
            });
            document.getElementById('total_facture').textContent = tf.toFixed(2);
            document.getElementById('total_rembourse').textContent = tr.toFixed(2);
            document.getElementById('total_a_payer').textContent = (tf - tr).toFixed(2);
        }

        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.prestation-row').forEach(calcRow);
            updateTotals();
        });

        document.addEventListener('change', e => {
            if (e.target.matches('select[name="id_prestation[]"], input[name="montant_facture[]"]')) {
                calcRow(e.target.closest('.prestation-row'));
            }
        });

        document.getElementById('add-prestation').onclick = () => {
            const template = document.getElementById('prestation-template').firstElementChild.cloneNode(true);
            document.getElementById('prestations-rows').appendChild(template);
            calcRow(template);
            // Announce for screen readers
            const announcement = document.createElement('div');
            announcement.setAttribute('aria-live', 'polite');
            announcement.classList.add('sr-only');
            announcement.textContent = 'Nouvelle ligne de prestation ajoutée.';
            document.body.appendChild(announcement);
            setTimeout(() => announcement.remove(), 1000);
        };

        document.addEventListener('click', e => {
            if (e.target.closest('.remove-row')) {
                const rows = document.querySelectorAll('.prestation-row');
                if (rows.length <= 1) {
                    alert('Au moins une prestation est obligatoire.');
                    return;
                }
                e.target.closest('.prestation-row').remove();
                updateTotals();
                // Announce removal
                const announcement = document.createElement('div');
                announcement.setAttribute('aria-live', 'polite');
                announcement.classList.add('sr-only');
                announcement.textContent = 'Ligne de prestation supprimée.';
                document.body.appendChild(announcement);
                setTimeout(() => announcement.remove(), 1000);
            }
        });

        // Caméra pour Photo
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const capture = document.getElementById('capture');
        const retake = document.getElementById('retake');
        const savePhoto = document.getElementById('savePhoto');
        const preview = document.getElementById('preview');
        const inputPhoto = document.getElementById('captured_photo');
        const fileInput = document.querySelector('input[name="pieces_jointes"]');
        let stream;

        document.getElementById('cameraModal').addEventListener('shown.bs.modal', async () => {
            try {
                stream = await navigator.mediaDevices.getUserMedia({
                    video: {
                        facingMode: 'environment'
                    }
                });
                video.srcObject = stream;
                video.play();
            } catch (err) {
                alert('Impossible d\'accéder à la caméra. Utilisez un fichier uploadé.');
                const modal = bootstrap.Modal.getInstance(document.getElementById('cameraModal'));
                modal.hide();
            }
        });

        document.getElementById('cameraModal').addEventListener('hidden.bs.modal', () => {
            if (stream) stream.getTracks().forEach(track => track.stop());
            preview.classList.add('d-none');
            capture.style.display = 'inline-block';
            retake.style.display = 'none';
            savePhoto.style.display = 'none';
        });

        capture.onclick = () => {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0);
            preview.src = canvas.toDataURL('image/jpeg', 0.85);
            preview.alt = 'Photo capturée de la pièce jointe';
            preview.classList.remove('d-none');
            capture.style.display = 'none';
            retake.style.display = 'inline-block';
            savePhoto.style.display = 'inline-block';
        };

        retake.onclick = () => {
            preview.classList.add('d-none');
            capture.style.display = 'inline-block';
            retake.style.display = 'none';
            savePhoto.style.display = 'none';
        };

        savePhoto.onclick = () => {
            inputPhoto.value = preview.src;
            fileInput.value = '';
            // Clear the required validation since photo is used
            fileInput.removeAttribute('required');
            const modal = bootstrap.Modal.getInstance(document.getElementById('cameraModal'));
            modal.hide();
            // Announce
            const announcement = document.createElement('div');
            announcement.setAttribute('aria-live', 'polite');
            announcement.classList.add('sr-only');
            announcement.textContent = 'Photo enregistrée comme pièce jointe.';
            document.body.appendChild(announcement);
            setTimeout(() => announcement.remove(), 2000);
        };

        fileInput.onchange = () => {
            if (fileInput.files[0]) {
                preview.src = URL.createObjectURL(fileInput.files[0]);
                preview.alt = `Aperçu du fichier ${fileInput.files[0].name}`;
                preview.classList.remove('d-none');
                inputPhoto.value = '';
                // Ensure required is set for file
                fileInput.setAttribute('required', 'required');
            }
        };

        // Confirmation avant enregistrement
        const form = document.getElementById('prestationForm');
        const confirmModal = new bootstrap.Modal(document.getElementById('confirmModal'));
        const confirmSubmit = document.getElementById('confirmSubmit');
        const submitButton = document.getElementById('submitButton');
        let isConfirmed = false;

        form.addEventListener('submit', e => {
            if (isConfirmed) {
                // Allow submission if confirmed
                return;
            }
            e.preventDefault(); // Empêche la soumission immédiate

            // Custom validation for pièce jointe (file or photo)
            const hasFile = fileInput.files && fileInput.files.length > 0;
            const hasPhoto = inputPhoto.value.trim() !== '';
            if (!hasFile && !hasPhoto) {
                e.stopPropagation();
                const errorDiv = document.createElement('div');
                errorDiv.className = 'alert alert-danger';
                errorDiv.innerHTML = '<i class="bi bi-exclamation-triangle-fill me-2"></i>Pièce jointe obligatoire. Fournissez un fichier ou une photo.';
                const pieceSection = document.querySelector('.mb-3:has(#pieces_jointes)');
                pieceSection.parentNode.insertBefore(errorDiv, pieceSection.nextSibling);
                setTimeout(() => errorDiv.remove(), 5000);
                return;
            }

            if (!form.checkValidity()) {
                e.stopPropagation();
                form.classList.add('was-validated');
                return; // Ne pas montrer la confirmation si invalide
            }

            // Récupérer les détails pour la confirmation
            const beneficiaireSelect = document.getElementById('beneficiaire-select');
            const dateSoin = document.getElementById('date_soin').value;
            const totalFacture = document.getElementById('total_facture').textContent;
            const totalRembourse = document.getElementById('total_rembourse').textContent;
            const totalAPayer = document.getElementById('total_a_payer').textContent;

            const selectedOption = beneficiaireSelect.options[beneficiaireSelect.selectedIndex];
            const beneficiaireText = selectedOption ? selectedOption.textContent.trim() : 'Non sélectionné';

            document.getElementById('confirm-beneficiaire').textContent = beneficiaireText;
            document.getElementById('confirm-date').textContent = new Date(dateSoin).toLocaleDateString('fr-FR');
            document.getElementById('confirm-total-facture').textContent = totalFacture;
            document.getElementById('confirm-total-rembourse').textContent = totalRembourse;
            document.getElementById('confirm-total-apayer').textContent = totalAPayer;

            // Afficher la modal de confirmation
            confirmModal.show();

            // Gérer la confirmation
            const confirmHandler = (e) => {
                if (e) e.preventDefault();
                confirmModal.hide();
                isConfirmed = true;
                form.removeEventListener('submit', submitListener); // Remove the listener to avoid loop
                confirmSubmit.removeEventListener('click', confirmHandler);
                form.submit(); // Direct submit now
            };
            confirmSubmit.addEventListener('click', confirmHandler);

            // Announce for screen readers
            const announcement = document.createElement('div');
            announcement.setAttribute('aria-live', 'assertive');
            announcement.classList.add('sr-only');
            announcement.textContent = 'Veuillez confirmer les détails avant l\'enregistrement.';
            document.body.appendChild(announcement);
            setTimeout(() => announcement.remove(), 2000);
        });

        // Store the listener reference
        const submitListener = form._submitListener || form.addEventListener('submit', arguments.callee);
        form._submitListener = submitListener;
    </script>
</body>

</html>

<?php require_once '../includes/footer.php'; ?>