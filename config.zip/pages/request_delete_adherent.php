<?php
// pages/request_delete_adherent.php
require_once '../includes/header.php';
checkRole('agent_mobilisateur');

$errors = [];
$success = null;
$id_adhesion = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Vérifier si l'adhésion existe et appartient à l'agent
$stmt = $pdo->prepare("
    SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom 
    FROM adhesions a 
    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
    WHERE a.id_adhesion = ? AND a.created_by = ? AND u.departement = ?
");
$stmt->execute([$id_adhesion, $_SESSION['user_id'], $_SESSION['departement']]);
$adhesion = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$adhesion) {
    $errors[] = "Adhésion non trouvée ou accès non autorisé.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_request'])) {
    $raison = sanitize($_POST['raison']);

    if (empty($raison)) {
        $errors[] = "La raison de la demande est requise.";
    }

    // Vérifier si une demande existe déjà
    $stmt = $pdo->prepare("SELECT id_demande FROM demandes_suppression WHERE id_adhesion = ? AND statut = 'en_attente'");
    $stmt->execute([$id_adhesion]);
    if ($stmt->fetch()) {
        $errors[] = "Une demande de suppression est déjà en attente pour cette adhésion.";
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO demandes_suppression (id_adhesion, id_agent, date_demande, raison, statut) 
                               VALUES (?, ?, CURDATE(), ?, 'en_attente')");
        $stmt->execute([$id_adhesion, $_SESSION['user_id'], $raison]);

        // Log de l'activité
        $stmt = $pdo->prepare("INSERT INTO logs_activites (id_utilisateur, action, details) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], 'request_delete_adherent', "Demande de suppression pour adhésion ID $id_adhesion"]);

        $success = "Demande de suppression soumise avec succès.";
    }
}
?>
<h2 class="mb-4">Demander la Suppression d'un Adhérent</h2>
<?php if ($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>
<?php if ($errors): ?>
    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endforeach; ?>
<?php endif; ?>
<?php if ($adhesion): ?>
    <div class="card">
        <div class="card-header">Formulaire de Demande de Suppression</div>
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Numéro Adhérent</label>
                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($adhesion['num_adherent'] . ' - ' . $adhesion['nom'] . ' ' . $adhesion['prenom']); ?>" disabled>
                </div>
                <div class="mb-3">
                    <label for="raison" class="form-label">Raison de la suppression *</label>
                    <textarea class="form-control" id="raison" name="raison" rows="4" required></textarea>
                </div>
                <button type="submit" name="submit_request" class="btn btn-primary">Soumettre la Demande</button>
            </form>
        </div>
    </div>
<?php else: ?>
    <div class="alert alert-danger">Aucune adhésion sélectionnée ou accès non autorisé.</div>
<?php endif; ?>
<?php require_once '../includes/footer.php'; ?>