<?php
ob_start();
session_start();
date_default_timezone_set('Africa/Dakar'); // Fuseau de Matam
error_log("Fuseau horaire PHP : " . date_default_timezone_get());
error_log("Date/heure PHP actuelle : " . date('Y-m-d H:i:s'));
require_once '../includes/auth.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

$errors = [];
$success = null;

// Log pour vérifier le chargement du fichier
error_log("Démarrage de reset_password.php, chemin autoload : " . realpath('../vendor/autoload.php'));

// Vérifier les paramètres GET (email et token)
$email = isset($_GET['email']) ? sanitize(trim($_GET['email'])) : '';
$token = isset($_GET['token']) ? sanitize(trim($_GET['token'])) : '';

if (empty($email) || empty($token)) {
    $errors[] = "Lien de réinitialisation invalide.";
    error_log("Paramètres manquants : email=$email, token=$token");
} else {
    try {
        // Vérifier si l'email existe dans password_resets
        $stmt = $pdo->prepare("SELECT email, token, expires_at FROM password_resets WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $reset = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$reset) {
            $errors[] = "Aucun jeton trouvé pour cet email.";
            error_log("Aucun jeton trouvé pour email=$email");
        } elseif ($reset['token'] !== $token) {
            $errors[] = "Le jeton est incorrect.";
            error_log("Jeton incorrect : attendu={$reset['token']}, reçu=$token pour email=$email");
        } elseif (strtotime($reset['expires_at']) <= time()) {
            $errors[] = "Le lien de réinitialisation a expiré.";
            error_log("Jeton expiré : expires_at={$reset['expires_at']} pour email=$email");
        } else {
            error_log("Jeton valide pour email=$email, token=$token, expires_at={$reset['expires_at']}");
        }
    } catch (PDOException $e) {
        $errors[] = "Une erreur est survenue. Veuillez réessayer.";
        error_log("Erreur PDO lors de la vérification du jeton : " . $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password']) && empty($errors)) {
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $confirm_password = isset($_POST['confirm_password']) ? trim($_POST['confirm_password']) : '';

    // Valider le mot de passe
    if (empty($password)) {
        $errors[] = "Le mot de passe est requis.";
    } elseif (strlen($password) < 8) {
        $errors[] = "Le mot de passe doit contenir au moins 8 caractères.";
    } elseif ($password !== $confirm_password) {
        $errors[] = "Les mots de passe ne correspondent pas.";
    }

    if (empty($errors)) {
        try {
            // Mettre à jour le mot de passe dans utilisateurs
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("
                UPDATE utilisateurs 
                SET mot_de_passe = :mot_de_passe 
                WHERE email = :email AND statut = 'actif'
            ");
            $stmt->execute([
                'mot_de_passe' => $hashed_password,
                'email' => $email
            ]);
            error_log("Mot de passe mis à jour pour email=$email");

            // Récupérer l'id_utilisateur pour le log
            $stmt = $pdo->prepare("SELECT id_utilisateur FROM utilisateurs WHERE email = :email");
            $stmt->execute(['email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Enregistrer l'activité
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO logs_activites (id_utilisateur, action, details, date_action)
                        VALUES (:id_utilisateur, :action, :details, NOW())
                    ");
                    $stmt->execute([
                        'id_utilisateur' => $user['id_utilisateur'],
                        'action' => 'reset_password',
                        'details' => "Réinitialisation du mot de passe pour {$email}"
                    ]);
                    error_log("Activité de réinitialisation enregistrée pour email=$email");
                } catch (PDOException $e) {
                    error_log("Erreur log activité : " . $e->getMessage());
                }
            }

            // Supprimer le jeton utilisé
            $stmt = $pdo->prepare("DELETE FROM password_resets WHERE email = :email AND token = :token");
            $stmt->execute(['email' => $email, 'token' => $token]);
            error_log("Jeton supprimé pour email=$email, token=$token");

            $success = "Votre mot de passe a été réinitialisé avec succès. Vous pouvez maintenant vous connecter.";
            // Rediriger après 3 secondes
            header("Refresh: 3; url=login.php");
        } catch (PDOException $e) {
            $errors[] = "Une erreur est survenue lors de la réinitialisation. Veuillez réessayer.";
            error_log("Erreur PDO lors de la mise à jour du mot de passe : " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation Mot de Passe - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;
            --secondary: #4b5563;
            --accent: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --background: #f8fafc;
            --card-bg: #ffffff;
            --text: #1f2a44;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #e6effa 0%, #f4f7fa 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 1rem;
        }

        .reset-card {
            max-width: 450px;
            width: 100%;
            background: var(--card-bg);
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeIn 0.8s ease-in-out;
        }

        .reset-header {
            background: linear-gradient(135deg, var(--primary), #1e40af);
            padding: 2rem;
            text-align: center;
            color: white;
        }

        .reset-header img {
            max-width: 100px;
            border-radius: 50%;
            margin-bottom: 1rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }

        .reset-header h2 {
            font-size: 1.75rem;
            font-weight: 700;
            margin: 0;
        }

        .reset-header p {
            font-size: 1rem;
            opacity: 0.9;
            margin: 0.5rem 0 0;
        }

        .card-body {
            padding: 2rem;
        }

        .form-label {
            font-weight: 500;
            color: var(--text);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .form-control {
            border-radius: 8px;
            border: 1px solid #d1d5db;
            padding: 0.75rem 1rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 8px rgba(37, 99, 235, 0.2);
            outline: none;
        }

        .input-group-text {
            background: transparent;
            border: 1px solid #d1d5db;
            border-radius: 0 8px 8px 0;
            cursor: pointer;
        }

        .btn-primary {
            background: var(--primary);
            border: none;
            border-radius: 8px;
            padding: 0.75rem;
            font-weight: 500;
            font-size: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        .btn-primary:hover {
            background: #1e40af;
            transform: translateY(-2px);
        }

        .alert {
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            animation: slideIn 0.5s ease-in-out;
        }

        .alert-dismissible .btn-close {
            padding: 1rem;
        }

        .back-to-login {
            display: block;
            text-align: center;
            margin-top: 1rem;
            font-size: 0.875rem;
            color: var(--primary);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .back-to-login:hover {
            color: #1e40af;
            text-decoration: underline;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-10px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @media (max-width: 576px) {
            .reset-card {
                margin: 1rem;
            }
            .reset-header {
                padding: 1.5rem;
            }
            .reset-header img {
                max-width: 80px;
            }
            .reset-header h2 {
                font-size: 1.5rem;
            }
            .card-body {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="reset-card">
        <!-- Header -->
        <div class="reset-header">
            <img src="../Uploads/photos/logo1.png" alt="Logo de Mutuelle Santé Matam" aria-label="Logo de Mutuelle Santé Matam">
            <h2>Mutuelle Santé Matam</h2>
            <p>Nouveau mot de passe</p>
        </div>
        <!-- Form -->
        <div class="card-body">
            <?php if ($errors): ?>
                <?php foreach ($errors as $error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php else: ?>
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="password" class="form-label"><i class="bi bi-lock"></i> Nouveau mot de passe</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="password" name="password" required aria-describedby="passwordHelp">
                            <span class="input-group-text toggle-password" data-target="password">
                                <i class="bi bi-eye"></i>
                            </span>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label"><i class="bi bi-lock"></i> Confirmer le mot de passe</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            <span class="input-group-text toggle-password" data-target="confirm_password">
                                <i class="bi bi-eye"></i>
                            </span>
                        </div>
                    </div>
                    <button type="submit" name="reset_password" class="btn btn-primary w-100">
                        <i class="bi bi-check-circle"></i> Réinitialiser le mot de passe
                    </button>
                </form>
            <?php endif; ?>
            <a href="login.php" class="back-to-login"><i class="bi bi-arrow-left"></i> Retour à la connexion</a>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        document.querySelectorAll('.toggle-password').forEach(button => {
            button.addEventListener('click', () => {
                const targetId = button.getAttribute('data-target');
                const input = document.getElementById(targetId);
                const icon = button.querySelector('i');
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('bi-eye');
                    icon.classList.add('bi-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('bi-eye-slash');
                    icon.classList.add('bi-eye');
                }
            });
        });
    </script>
</body>
</html>
<?php
ob_end_flush();
?>