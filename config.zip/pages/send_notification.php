<?php
// pages/send_notification.php
require_once '../includes/header.php';
checkRole('agent_mobilisateur');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = sanitize($_POST['message']);
    $stmt = $pdo->prepare("INSERT INTO notifications (id_utilisateur, type, message, date_envoi, statut) 
                           SELECT id_utilisateur, 'annonce', ?, CURDATE(), 'envoye' 
                           FROM utilisateurs WHERE role = 'adherent' AND departement = ?");
    $stmt->execute([$message, $_SESSION['departement']]);

    $success = "Notification envoyée avec succès.";
}
?>
<h2 class="mb-4">Envoyer une Notification</h2>
<?php if (isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>
<div class="card">
    <div class="card-body">
        <form method="POST">
            <div class="mb-3">
                <label for="message" class="form-label">Message de Sensibilisation</label>
                <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Envoyer</button>
        </form>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>