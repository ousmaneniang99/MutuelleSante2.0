<?php
// pages/track_refunds.php
require_once '../includes/header.php';
checkRole('prestataire_soins');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();
$demandes_remboursement = [];
$statut_filter = $_GET['statut'] ?? 'all';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['validate_refund'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
    } else {
        try {
            $id_demande = intval($_POST['id_demande'] ?? 0);
            $statut = filter_var($_POST['statut'] ?? '', FILTER_SANITIZE_SPECIAL_CHARS);
            $montant_rembourse = isset($_POST['montant_rembourse']) && $_POST['montant_rembourse'] !== '' ? floatval($_POST['montant_rembourse']) : null;

            if ($id_demande <= 0 || !in_array($statut, ['approuve', 'rejete'])) {
                $errors[] = "Données invalides pour la validation du remboursement.";
            } elseif ($statut === 'approuve' && ($montant_rembourse === null || $montant_rembourse <= 0)) {
                $errors[] = "Le montant remboursé est requis et doit être positif pour approuver.";
            } else {
                // Update remboursement
                $stmt = $pdo->prepare("
                    UPDATE demandes_remboursement 
                    SET statut = ?, montant_rembourse = ?, validated_by = ?, date_mise_a_jour = NOW() 
                    WHERE id_demande = ? AND statut = 'en_validation' AND id_prestataire = ?
                ");
                $stmt->execute([$statut, $montant_rembourse, $_SESSION['user_id'], $id_demande, $_SESSION['user_id']]);

                if ($stmt->rowCount() === 0) {
                    $errors[] = "Demande non trouvée ou non en validation.";
                } else {
                    // Log activity
                    logActivity($pdo, $_SESSION['user_id'], "Validation de la demande de remboursement ID $id_demande ($statut)");
                    $success = "Demande de remboursement mise à jour avec succès.";
                }
            }
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la mise à jour : " . htmlspecialchars($e->getMessage());
            error_log("Erreur dans track_refunds.php : " . $e->getMessage());
        }
    }
}

try {
    // Fetch demandes de remboursement
    $query = "
        SELECT dr.id_demande, dr.id_adhesion, dr.id_beneficiaire, dr.date_soin, dr.montant_facture, 
               dr.montant_rembourse, dr.statut, dr.pieces_jointes, dr.commentaire,
               p.nom AS prestation_nom, b.nom AS beneficiaire_nom, b.prenom AS beneficiaire_prenom, 
               b.code_beneficiaire, a.num_adherent
        FROM demandes_remboursement dr
        JOIN prestations p ON dr.id_prestation = p.id_prestation
        JOIN beneficiaires b ON dr.id_beneficiaire = b.id_beneficiaire
        JOIN adhesions a ON dr.id_adhesion = a.id_adhesion
        WHERE dr.id_prestataire = ?
    ";
    $params = [$_SESSION['user_id']];
    if ($statut_filter !== 'all') {
        $query .= " AND dr.statut = ?";
        $params[] = $statut_filter;
    }
    $query .= " ORDER BY dr.date_soin DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $demandes_remboursement = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des données : " . htmlspecialchars($e->getMessage());
    error_log("Erreur dans track_refunds.php : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suivi et Validation des Remboursements - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }
        .container {
            max-width: 1200px;
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .card-header {
            border-bottom: none;
            padding: 1.5rem;
            font-size: 1.25rem;
            font-weight: 600;
            background: linear-gradient(90deg, #007bff, #0056b3);
            color: white;
        }
        .alert {
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert i {
            font-size: 1.2rem;
        }
        .form-label {
            font-weight: 500;
            color: #333;
        }
        .form-control, .form-select {
            border-radius: 8px;
            padding: 0.75rem;
            border: 1px solid #ced4da;
            transition: border-color 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
        }
        .input-group .form-control {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
        }
        .btn-primary, .btn-info, .btn-secondary {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-info:hover {
            background-color: #138496;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .table {
            border-radius: 8px;
            overflow: hidden;
        }
        .table th {
            background-color: #e9ecef;
            font-weight: 600;
            color: #2c3e50;
        }
        .table td, .table th {
            padding: 1rem;
            vertical-align: middle;
        }
        .badge {
            font-size: 0.9rem;
            padding: 0.5rem 1rem;
            border-radius: 12px;
        }
        .badge-en_attente { background-color: #6c757d; }
        .badge-en_validation { background-color: #17a2b8; }
        .badge-approuve { background-color: #28a745; }
        .badge-rejete { background-color: #dc3545; }
        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 2rem;
        }
        .form-row {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .pieces-jointes-link {
            color: #007bff;
            text-decoration: none;
        }
        .pieces-jointes-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-wallet-fill me-2"></i>Suivi et Validation des Remboursements</h2>

        <!-- Messages -->
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill"></i>
                <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Demandes de Remboursement -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-list-ul me-2"></i>Liste des Demandes de Remboursement
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <label for="statut_filter" class="form-label">Filtrer par statut :</label>
                        <select id="statut_filter" class="form-select" onchange="window.location.href='track_refunds.php?statut='+this.value;">
                            <option value="all" <?php echo $statut_filter === 'all' ? 'selected' : ''; ?>>Tous</option>
                            <option value="en_attente" <?php echo $statut_filter === 'en_attente' ? 'selected' : ''; ?>>En attente</option>
                            <option value="en_validation" <?php echo $statut_filter === 'en_validation' ? 'selected' : ''; ?>>En validation</option>
                            <option value="approuve" <?php echo $statut_filter === 'approuve' ? 'selected' : ''; ?>>Approuvé</option>
                            <option value="rejete" <?php echo $statut_filter === 'rejete' ? 'selected' : ''; ?>>Rejeté</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="search_demande" class="form-label">Rechercher une demande :</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-search"></i></span>
                            <input type="text" id="search_demande" class="form-control" placeholder="Rechercher par code, nom, prestation..." aria-label="Rechercher">
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-demandes">
                        <thead>
                            <tr>
                                <th><i class="bi bi-person-vcard me-2"></i>Numéro Adhésion</th>
                                <th><i class="bi bi-person-hearts me-2"></i>Code Bénéficiaire</th>
                                <th><i class="bi bi-person me-2"></i>Bénéficiaire</th>
                                <th><i class="bi bi-clipboard me-2"></i>Prestation</th>
                                <th><i class="bi bi-calendar me-2"></i>Date de Soin</th>
                                <th><i class="bi bi-currency-exchange me-2"></i>Montant Facturé</th>
                                <th><i class="bi bi-file-earmark-text me-2"></i>Pièces Jointes</th>
                                <th><i class="bi bi-chat me-2"></i>Commentaire</th>
                                <th><i class="bi bi-info-circle me-2"></i>Statut</th>
                                <th><i class="bi bi-gear me-2"></i>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($demandes_remboursement)): ?>
                                <tr>
                                    <td colspan="10" class="text-center">Aucune demande trouvée.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($demandes_remboursement as $demande): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($demande['num_adherent'] ?? 'Non spécifié'); ?></td>
                                        <td><?php echo htmlspecialchars($demande['code_beneficiaire'] ?? 'Non spécifié'); ?></td>
                                        <td><?php echo htmlspecialchars(($demande['beneficiaire_nom'] ?? 'Non spécifié') . ' ' . ($demande['beneficiaire_prenom'] ?? '')); ?></td>
                                        <td><?php echo htmlspecialchars($demande['prestation_nom'] ?? 'Non spécifié'); ?></td>
                                        <td><?php echo htmlspecialchars($demande['date_soin'] ?? 'Non spécifiée'); ?></td>
                                        <td><?php echo htmlspecialchars(formatFCFA($demande['montant_facture'] ?? 0)); ?></td>
                                        <td>
                                            <?php if ($demande['pieces_jointes'] && file_exists($demande['pieces_jointes'])): ?>
                                                <a href="<?php echo htmlspecialchars($demande['pieces_jointes']); ?>" target="_blank" class="pieces-jointes-link"><i class="bi bi-file-earmark-text me-1"></i>Voir</a>
                                            <?php else: ?>
                                                Aucun
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($demande['commentaire'] ?: 'Aucun'); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo htmlspecialchars($demande['statut']); ?>">
                                                <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $demande['statut']))); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($demande['statut'] === 'en_validation'): ?>
                                                <form method="POST" class="form-row d-flex gap-2 align-items-center">
                                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                                    <input type="hidden" name="id_demande" value="<?php echo htmlspecialchars($demande['id_demande']); ?>">
                                                    <input type="hidden" name="validate_refund" value="1">
                                                    <select name="statut" class="form-select w-auto" required>
                                                        <option value="approuve">Approuver</option>
                                                        <option value="rejete">Rejeter</option>
                                                    </select>
                                                    <input type="number" step="0.01" name="montant_rembourse" class="form-control w-auto" placeholder="Montant remboursé">
                                                    <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-check me-1"></i>Valider</button>
                                                </form>
                                            <?php else: ?>
                                                <a href="generate_invoice.php?id=<?php echo htmlspecialchars($demande['id_demande']); ?>" class="btn btn-sm btn-info">
                                                    <i class="bi bi-receipt-cutoff me-1"></i>Facture
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <a href="dashboard_prestataire.php" class="btn btn-secondary mt-3">
                    <i class="bi bi-arrow-left me-2"></i>Retour
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Search functionality for demandes table
        document.getElementById('search_demande').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-demandes tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });

        // Dynamically toggle montant_rembourse required attribute
        document.querySelectorAll('.form-select').forEach(select => {
            select.addEventListener('change', function() {
                const montantInput = this.closest('.form-row').querySelector('input[name="montant_rembourse"]');
                montantInput.required = this.value === 'approuve';
            });
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>