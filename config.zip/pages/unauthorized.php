<?php
// pages/unauthorized.php
require_once '../config/database.php';
require_once '../includes/functions.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
setFlashMessage('danger', 'Accès non autorisé. Vous n\'avez pas les permissions nécessaires.');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Accès non autorisé</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Accès non autorisé</h1>
        <p class="alert alert-danger"><?php echo $_SESSION['flash_message']['message']; unset($_SESSION['flash_message']); ?></p>
        <a href="/sante/index.php" class="btn btn-primary">Retour à l'accueil</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>