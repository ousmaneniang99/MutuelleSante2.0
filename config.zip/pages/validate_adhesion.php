<?php
// pages/validate_adhesion.php
ob_start(); // Start output buffering to prevent headers already sent
require_once __DIR__ . '/../includes/header.php';

// Enable error reporting for debugging (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Vérifications de session et rôle
checkSessionTimeout();
checkRole('directeur_departemental');

$errors = [];
$success = null;
$new_adhesions = []; // Initialiser pour nouvelles adhésions
$renewal_adhesions = []; // Initialiser pour renouvellements
$new_total_pages = 0; // Pagination pour nouvelles adhésions
$renewal_total_pages = 0; // Pagination pour renouvellements

// Vérifier la session département
if (!isset($_SESSION['departement']) || empty($_SESSION['departement'])) {
    $errors[] = "Erreur : Département de l'utilisateur non défini.";
    error_log("Département non défini dans la session pour utilisateur ID: {$_SESSION['user_id']}");
}

// Paramètres de pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['csrf_token'])) {
    if (!verifyCsrfToken($_POST['csrf_token'])) {
        $errors[] = "Erreur de sécurité CSRF. Veuillez réessayer.";
        error_log("Échec de validation CSRF pour validate_adhesion.php, utilisateur ID: {$_SESSION['user_id']}");
    } else {
        try {
            $pdo->beginTransaction();

            if ($_POST['action'] === 'validate_all_new') {
                $stmt = $pdo->prepare("
                    SELECT a.id_adhesion, a.created_by
                    FROM adhesions a
                    JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
                    WHERE agent.departement = ? AND a.statut = 'en_attente_validation'
                    AND (a.old_card_photo IS NULL OR a.old_card_photo = '')
                    AND (
                        SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion 
                        AND b.photo_path IS NOT NULL 
                        AND b.photo_path != ''
                    ) >= 3
                    AND (
                        SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion
                    ) = (
                        SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion 
                        AND b.photo_path IS NOT NULL 
                        AND b.photo_path != ''
                    )
                ");
                $stmt->execute([$_SESSION['departement']]);
                $adhesions_to_validate = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if ($adhesions_to_validate) {
                    $stmt_adhesion = $pdo->prepare("
                        UPDATE adhesions 
                        SET statut = 'active' 
                        WHERE id_adhesion = ? AND statut = 'en_attente_validation'
                    ");
                    $stmt_benef = $pdo->prepare("
                        UPDATE beneficiaires 
                        SET statut = 'actif' 
                        WHERE id_adhesion = ? AND statut = 'en_attente_approbation'
                    ");

                    foreach ($adhesions_to_validate as $adh) {
                        $id_adhesion = $adh['id_adhesion'];
                        $agent_id = $adh['created_by'];

                        $stmt_adhesion->execute([$id_adhesion]);
                        $stmt_benef->execute([$id_adhesion]);
                        $details = "Adhésion nouvelle #$id_adhesion approuvée (via validation globale) par {$_SESSION['nom']} {$_SESSION['prenom']} dans le département {$_SESSION['departement']}";
                        logActivity($pdo, $_SESSION['user_id'], 'validate_adhesion', $details);
                        sendNotification($pdo, $agent_id, "L'adhésion nouvelle #$id_adhesion a été approuvée par le directeur départemental.");
                    }

                    $success = count($adhesions_to_validate) . " nouvelle(s) adhésion(s) approuvée(s) avec succès.";
                    error_log(count($adhesions_to_validate) . " nouvelles adhésions mises à jour à active par utilisateur ID: {$_SESSION['user_id']}, département: {$_SESSION['departement']}");
                    $pdo->commit();
                } else {
                    $errors[] = "Aucune nouvelle adhésion en attente avec au moins 3 bénéficiaires ayant tous des photos.";
                    error_log("Aucune nouvelle adhésion en attente pour validation globale, utilisateur ID: {$_SESSION['user_id']}");
                    $pdo->commit();
                }
            } elseif ($_POST['action'] === 'validate_all_renewal') {
                $stmt = $pdo->prepare("
                    SELECT a.id_adhesion, a.created_by
                    FROM adhesions a
                    JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
                    WHERE agent.departement = ? AND a.statut = 'en_attente_validation'
                    AND a.old_card_photo IS NOT NULL 
                    AND a.old_card_photo != ''
                    AND (
                        SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion 
                        AND b.photo_path IS NOT NULL 
                        AND b.photo_path != ''
                    ) >= 3
                    AND (
                        SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion
                    ) = (
                        SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion 
                        AND b.photo_path IS NOT NULL 
                        AND b.photo_path != ''
                    )
                ");
                $stmt->execute([$_SESSION['departement']]);
                $adhesions_to_validate = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if ($adhesions_to_validate) {
                    $stmt_adhesion = $pdo->prepare("
                        UPDATE adhesions 
                        SET statut = 'active' 
                        WHERE id_adhesion = ? AND statut = 'en_attente_validation'
                    ");
                    $stmt_benef = $pdo->prepare("
                        UPDATE beneficiaires 
                        SET statut = 'actif' 
                        WHERE id_adhesion = ? AND statut = 'en_attente_approbation'
                    ");

                    foreach ($adhesions_to_validate as $adh) {
                        $id_adhesion = $adh['id_adhesion'];
                        $agent_id = $adh['created_by'];

                        $stmt_adhesion->execute([$id_adhesion]);
                        $stmt_benef->execute([$id_adhesion]);
                        $details = "Adhésion renouvellement #$id_adhesion approuvée (via validation globale) par {$_SESSION['nom']} {$_SESSION['prenom']} dans le département {$_SESSION['departement']}";
                        logActivity($pdo, $_SESSION['user_id'], 'validate_adhesion', $details);
                        sendNotification($pdo, $agent_id, "L'adhésion renouvellement #$id_adhesion a été approuvée par le directeur départemental.");
                    }

                    $success = count($adhesions_to_validate) . " renouvellement(s) approuvé(s) avec succès.";
                    error_log(count($adhesions_to_validate) . " renouvellements mis à jour à active par utilisateur ID: {$_SESSION['user_id']}, département: {$_SESSION['departement']}");
                    $pdo->commit();
                } else {
                    $errors[] = "Aucun renouvellement en attente avec une photo de carte précédente et au moins 3 bénéficiaires ayant tous des photos.";
                    error_log("Aucun renouvellement en attente pour validation globale, utilisateur ID: {$_SESSION['user_id']}");
                    $pdo->commit();
                }
            } elseif (isset($_POST['id_adhesion']) && in_array($_POST['action'], ['approuvee', 'rejete'])) {
                $id_adhesion = filter_var($_POST['id_adhesion'], FILTER_VALIDATE_INT);
                $action = $_POST['action'];

                if ($id_adhesion) {
                    $stmt_agent = $pdo->prepare("SELECT created_by, id_utilisateur FROM adhesions WHERE id_adhesion = ?");
                    $stmt_agent->execute([$id_adhesion]);
                    $adhesion_data = $stmt_agent->fetch(PDO::FETCH_ASSOC);
                    $agent_id = $adhesion_data['created_by'];
                    $id_utilisateur = $adhesion_data['id_utilisateur'];

                    if ($action === 'approuvee') {
                        // Vérifier les conditions avant d'approuver
                        $stmt_check = $pdo->prepare("
                            SELECT 
                                (SELECT COUNT(*) 
                                 FROM beneficiaires b 
                                 WHERE b.id_adhesion = a.id_adhesion
                                ) AS total_beneficiaires,
                                (SELECT COUNT(*) 
                                 FROM beneficiaires b 
                                 WHERE b.id_adhesion = a.id_adhesion 
                                 AND b.photo_path IS NOT NULL 
                                 AND b.photo_path != ''
                                ) AS beneficiaire_count_with_photos,
                                CASE 
                                    WHEN a.old_card_photo IS NOT NULL AND a.old_card_photo != '' 
                                    THEN 1 
                                    ELSE 0 
                                END AS is_renewal
                            FROM adhesions a
                            WHERE a.id_adhesion = ?
                        ");
                        $stmt_check->execute([$id_adhesion]);
                        $check = $stmt_check->fetch(PDO::FETCH_ASSOC);

                        if ($check['total_beneficiaires'] >= 3 && $check['total_beneficiaires'] == $check['beneficiaire_count_with_photos']) {
                            $stmt = $pdo->prepare("
                                UPDATE adhesions 
                                SET statut = 'active' 
                                WHERE id_adhesion = ? AND statut = 'en_attente_validation'
                            ");
                            $stmt->execute([$id_adhesion]);

                            if ($stmt->rowCount() > 0) {
                                $stmt_benef = $pdo->prepare("
                                    UPDATE beneficiaires 
                                    SET statut = 'actif' 
                                    WHERE id_adhesion = ? AND statut = 'en_attente_approbation'
                                ");
                                $stmt_benef->execute([$id_adhesion]);

                                $details = "Adhésion #$id_adhesion approuvée par {$_SESSION['nom']} {$_SESSION['prenom']} dans le département {$_SESSION['departement']}";
                                logActivity($pdo, $_SESSION['user_id'], 'validate_adhesion', $details);
                                sendNotification($pdo, $agent_id, "L'adhésion #$id_adhesion a été approuvée par le directeur départemental.");
                                $success = "Adhésion approuvée avec succès.";
                                error_log("Adhésion ID $id_adhesion mise à jour à active par utilisateur ID: {$_SESSION['user_id']}, département: {$_SESSION['departement']}");
                                $pdo->commit();
                            } else {
                                $pdo->rollBack();
                                $errors[] = "Adhésion non trouvée ou déjà traitée.";
                                error_log("Échec de mise à jour : aucune adhésion trouvée pour ID $id_adhesion, utilisateur ID: {$_SESSION['user_id']}");
                            }
                        } else {
                            $pdo->rollBack();
                            $errors[] = "Validation bloquée : l'adhésion n'a pas au moins 3 bénéficiaires avec photos ou certains bénéficiaires n'ont pas de photos.";
                            error_log("Validation bloquée pour ID $id_adhesion (manque de bénéficiaires avec photos), utilisateur ID: {$_SESSION['user_id']}");
                        }
                    } elseif ($action === 'rejete') {
                        // Supprimer les bénéficiaires
                        $stmt_benef = $pdo->prepare("DELETE FROM beneficiaires WHERE id_adhesion = ?");
                        $stmt_benef->execute([$id_adhesion]);

                        // Supprimer l'adhésion
                        $stmt_adhesion = $pdo->prepare("DELETE FROM adhesions WHERE id_adhesion = ? AND statut = 'en_attente_validation'");
                        $stmt_adhesion->execute([$id_adhesion]);

                        if ($stmt_adhesion->rowCount() > 0) {
                            // Supprimer l'utilisateur associé
                            $stmt_user = $pdo->prepare("DELETE FROM utilisateurs WHERE id_utilisateur = ?");
                            $stmt_user->execute([$id_utilisateur]);

                            $details = "Adhésion #$id_adhesion et utilisateur ID $id_utilisateur supprimés par {$_SESSION['nom']} {$_SESSION['prenom']} dans le département {$_SESSION['departement']}";
                            logActivity($pdo, $_SESSION['user_id'], 'delete_adhesion_and_user', $details);
                            sendNotification($pdo, $agent_id, "L'adhésion #$id_adhesion et l'utilisateur associé ont été supprimés par le directeur départemental.");
                            $success = "Adhésion, ses bénéficiaires et l'utilisateur associé supprimés avec succès.";
                            error_log("Adhésion ID $id_adhesion, bénéficiaires et utilisateur ID $id_utilisateur supprimés par utilisateur ID: {$_SESSION['user_id']}, département: {$_SESSION['departement']}");
                            $pdo->commit();
                        } else {
                            $pdo->rollBack();
                            $errors[] = "Adhésion non trouvée ou déjà traitée.";
                            error_log("Échec de suppression : aucune adhésion trouvée pour ID $id_adhesion, utilisateur ID: {$_SESSION['user_id']}");
                        }
                    }
                } else {
                    $errors[] = "ID d'adhésion invalide.";
                    error_log("ID d'adhésion invalide: id_adhesion=$id_adhesion, utilisateur ID: {$_SESSION['user_id']}");
                    $pdo->commit();
                }
            } else {
                $errors[] = "Action invalide.";
                error_log("Action invalide: action={$_POST['action']}, utilisateur ID: {$_SESSION['user_id']}");
                $pdo->commit();
            }

            header("Location: validate_adhesion.php?page=$page" . ($success ? "&success=" . urlencode($success) : ""));
            exit();
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = "Erreur lors de la mise à jour ou suppression des adhésions.";
            error_log("Erreur PDO dans validate_adhesion.php (POST) : " . $e->getMessage() . " - Code: " . $e->getCode());
        }
    }
}

// Récupérer les adhésions
try {
    if (!$pdo instanceof PDO) {
        $errors[] = "Erreur : Connexion à la base de données non établie.";
        error_log("Connexion PDO non initialisée dans validate_adhesion.php");
    } elseif (!isset($_SESSION['departement']) || empty($_SESSION['departement'])) {
        $errors[] = "Erreur : Département de l'utilisateur non défini.";
        error_log("Département non défini dans la session pour utilisateur ID: {$_SESSION['user_id']}");
    } else {
        // Vérifier si la colonne old_card_photo existe
        $stmt_check = $pdo->query("SHOW COLUMNS FROM adhesions LIKE 'old_card_photo'");
        $old_card_photo_exists = $stmt_check->rowCount() > 0;

        if (!$old_card_photo_exists) {
            $errors[] = "Erreur : La colonne 'old_card_photo' n'existe pas dans la table adhesions.";
            error_log("Colonne old_card_photo manquante dans la table adhesions, utilisateur ID: {$_SESSION['user_id']}");
        } else {
            // Nouvelles adhésions
            $stmt_new = $pdo->prepare("
                SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom, a.date_adhesion, a.type_adhesion,
                       agent.nom AS agent_nom, agent.prenom AS agent_prenom,
                       (SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion
                       ) AS beneficiaire_count,
                       CASE 
                           WHEN a.old_card_photo IS NOT NULL AND a.old_card_photo != '' 
                           THEN 1 
                           ELSE 0 
                       END AS is_renewal,
                       (SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion 
                        AND b.photo_path IS NOT NULL 
                        AND b.photo_path != ''
                       ) AS beneficiaire_count_with_photos
                FROM adhesions a 
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
                WHERE agent.departement = ? AND a.statut = 'en_attente_validation'
                AND (a.old_card_photo IS NULL OR a.old_card_photo = '')
                ORDER BY 
                    CASE 
                        WHEN (
                            (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion) >= 3 
                            AND 
                            (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion) = 
                            (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion AND b.photo_path IS NOT NULL AND b.photo_path != '')
                        ) THEN 0 
                        ELSE 1 
                    END ASC,
                    a.date_adhesion DESC
                LIMIT ? OFFSET ?
            ");
            $stmt_new->bindValue(1, $_SESSION['departement'], PDO::PARAM_STR);
            $stmt_new->bindValue(2, (int)$perPage, PDO::PARAM_INT);
            $stmt_new->bindValue(3, (int)$offset, PDO::PARAM_INT);
            $stmt_new->execute();
            $new_adhesions = $stmt_new->fetchAll(PDO::FETCH_ASSOC);

            // Compter le total des nouvelles adhésions
            $stmt_new_count = $pdo->prepare("
                SELECT COUNT(*) 
                FROM adhesions a 
                JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
                WHERE agent.departement = ? AND a.statut = 'en_attente_validation'
                AND (a.old_card_photo IS NULL OR a.old_card_photo = '')
            ");
            $stmt_new_count->execute([$_SESSION['departement']]);
            $new_total_adhesions = $stmt_new_count->fetchColumn() ?: 0;
            $new_total_pages = ceil($new_total_adhesions / $perPage);

            // Renouvellements
            $stmt_renewal = $pdo->prepare("
                SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom, a.date_adhesion, a.type_adhesion,
                       agent.nom AS agent_nom, agent.prenom AS agent_prenom,
                       (SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion
                       ) AS beneficiaire_count,
                       CASE 
                           WHEN a.old_card_photo IS NOT NULL AND a.old_card_photo != '' 
                           THEN 1 
                           ELSE 0 
                       END AS is_renewal,
                       a.old_card_photo,
                       (SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion 
                        AND b.photo_path IS NOT NULL 
                        AND b.photo_path != ''
                       ) AS beneficiaire_count_with_photos
                FROM adhesions a 
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
                WHERE agent.departement = ? AND a.statut = 'en_attente_validation'
                AND a.old_card_photo IS NOT NULL 
                AND a.old_card_photo != ''
                ORDER BY 
                    CASE 
                        WHEN (
                            (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion) >= 3 
                            AND 
                            (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion) = 
                            (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion AND b.photo_path IS NOT NULL AND b.photo_path != '')
                            AND a.old_card_photo IS NOT NULL 
                            AND a.old_card_photo != ''
                        ) THEN 0 
                        ELSE 1 
                    END ASC,
                    a.date_adhesion DESC
                LIMIT ? OFFSET ?
            ");
            $stmt_renewal->bindValue(1, $_SESSION['departement'], PDO::PARAM_STR);
            $stmt_renewal->bindValue(2, (int)$perPage, PDO::PARAM_INT);
            $stmt_renewal->bindValue(3, (int)$offset, PDO::PARAM_INT);
            $stmt_renewal->execute();
            $renewal_adhesions = $stmt_renewal->fetchAll(PDO::FETCH_ASSOC);

            // Compter le total des renouvellements
            $stmt_renewal_count = $pdo->prepare("
                SELECT COUNT(*) 
                FROM adhesions a 
                JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
                WHERE agent.departement = ? AND a.statut = 'en_attente_validation'
                AND a.old_card_photo IS NOT NULL 
                AND a.old_card_photo != ''
            ");
            $stmt_renewal_count->execute([$_SESSION['departement']]);
            $renewal_total_adhesions = $stmt_renewal_count->fetchColumn() ?: 0;
            $renewal_total_pages = ceil($renewal_total_adhesions / $perPage);
        }
    }
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des adhésions.";
    error_log("Erreur PDO dans validate_adhesion.php (récupération des adhésions) : " . $e->getMessage() . " - Code: " . $e->getCode());
}

$csrf_token = generateCsrfToken();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Valider les Adhésions - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1d4ed8; /* Bleu moderne */
            --secondary: #6b7280; /* Gris neutre */
            --accent: #10b981; /* Vert émeraude */
            --warning: #f59e0b; /* Orange doux */
            --danger: #dc2626; /* Rouge vif */
            --background: #f1f5f9; /* Fond clair */
            --card-bg: #ffffff; /* Fond carte */
            --text: #111827; /* Texte sombre */
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background: linear-gradient(135deg, var(--primary), #1e3a8a);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 1rem;
        }

        .navbar-brand img {
            max-width: 32px;
            margin-right: 0.4rem;
        }

        .navbar-brand, .nav-link {
            color: white !important;
            font-weight: 500;
            font-size: 0.9rem;
        }

        .nav-link:hover {
            color: var(--accent) !important;
        }

        .dropdown-menu {
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            border: none;
        }

        .dropdown-item:hover {
            background: #e5e7eb;
            color: var(--primary);
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 1rem 0.75rem;
        }

        .card {
            background: var(--card-bg);
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin-bottom: 1.25rem;
        }

        .card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary), #1e3a8a);
            color: white;
            font-weight: 600;
            border-radius: 10px 10px 0 0;
            padding: 0.75rem;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }

        .btn-primary, .btn-success, .btn-danger {
            border-radius: 8px;
            padding: 0.4rem 0.9rem;
            font-weight: 500;
            font-size: 0.85rem;
            min-width: 80px;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
        }

        .btn-primary {
            background: var(--primary);
            border: none;
        }

        .btn-primary:hover {
            background: #1e3a8a;
            transform: scale(1.03);
            box-shadow: 0 3px 10px rgba(37, 99, 235, 0.2);
        }

        .btn-success {
            background: var(--accent);
            border: none;
        }

        .btn-success:hover {
            background: #059669;
            transform: scale(1.03);
            box-shadow: 0 3px 10px rgba(16, 185, 129, 0.2);
        }

        .btn-danger {
            background: var(--danger);
            border: none;
        }

        .btn-danger:hover {
            background: #b91c1c;
            transform: scale(1.03);
            box-shadow: 0 3px 10px rgba(239, 68, 68, 0.2);
        }

        .btn-disabled {
            background: var(--secondary);
            cursor: not-allowed;
            opacity: 0.6;
        }

        .btn-disabled:hover {
            transform: none;
            box-shadow: none;
        }

        .table {
            background: var(--card-bg);
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
        }

        .table thead {
            background: #e5e7eb;
            color: var(--text);
            font-weight: 600;
            font-size: 0.85rem;
        }

        .table tbody tr {
            transition: background 0.2s ease;
        }

        .table tbody tr:hover {
            background: #f3f4f6;
        }

        .table td, .table th {
            padding: 0.6rem;
            font-size: 0.8rem;
            white-space: nowrap;
        }

        .pagination .page-link {
            border-radius: 6px;
            margin: 0 3px;
            color: var(--primary);
            border: 1px solid #d1d5db;
            font-size: 0.85rem;
            padding: 0.4rem 0.7rem;
            transition: all 0.3s ease;
        }

        .pagination .page-item.active .page-link {
            background: var(--primary);
            border-color: var(--primary);
            color: white;
        }

        .pagination .page-link:hover {
            background: #e5e7eb;
            color: var(--primary);
        }

        .search-container {
            position: relative;
            max-width: 100%;
            margin-bottom: 1rem;
        }

        .search-input {
            border-radius: 8px;
            padding: 0.5rem 1rem 0.5rem 2.2rem;
            border: 1px solid #d1d5db;
            width: 100%;
            font-size: 0.85rem;
            transition: all 0.3s ease;
        }

        .search-input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 6px rgba(37, 99, 235, 0.2);
            outline: none;
        }

        .search-icon {
            position: absolute;
            left: 0.6rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary);
            font-size: 0.85rem;
        }

        .alert {
            border-radius: 8px;
            padding: 0.6rem 1rem;
            margin-bottom: 0.75rem;
            font-size: 0.85rem;
            animation: slideIn 0.5s ease-in-out;
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }

        .carousel-inner img {
            max-width: 100px;
            height: auto;
            border-radius: 8px;
            margin: 0 auto;
            object-fit: cover;
        }

        .carousel-control-prev, .carousel-control-next {
            width: 10%;
            background: rgba(0, 0, 0, 0.3);
        }

        .carousel-control-prev-icon, .carousel-control-next-icon {
            background-size: 100%, 100%;
            width: 1.5rem;
            height: 1.5rem;
        }

        .modal-content {
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
        }

        .modal-header {
            background: var(--primary);
            color: white;
            border-radius: 10px 10px 0 0;
            padding: 0.75rem;
        }

        .modal-body {
            padding: 1rem;
        }

        .modal-footer {
            border-top: 1px solid #e5e7eb;
            padding: 0.75rem;
        }

        .beneficiaire-list {
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 0.5rem;
            margin-top: 0.5rem;
        }

        .beneficiaire-list li {
            padding: 0.5rem;
            font-size: 0.8rem;
            border-bottom: 1px solid #e5e7eb;
        }

        .beneficiaire-list li:last-child {
            border-bottom: none;
        }

        .beneficiaire-list li span {
            font-weight: 600;
            color: var(--secondary);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-15px); }
            to { opacity: 1; transform: translateX(0); }
        }

        /* Responsive Design */
        @media (max-width: 992px) {
            .container {
                padding: 0.75rem 0.5rem;
            }

            .card-header {
                font-size: 0.9rem;
                padding: 0.6rem;
            }

            .table-responsive {
                overflow-x: auto;
            }

            .table td, .table th {
                font-size: 0.75rem;
                padding: 0.5rem;
            }

            .btn-primary, .btn-success, .btn-danger {
                font-size: 0.75rem;
                padding: 0.35rem 0.7rem;
                min-width: 70px;
            }

            .carousel-inner img {
                max-width: 90px;
            }

            .beneficiaire-list {
                font-size: 0.75rem;
            }
        }

        @media (max-width: 768px) {
            .table thead {
                display: none; /* Masquer les en-têtes sur mobile */
            }

            .table tbody tr {
                display: block;
                margin-bottom: 0.75rem;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                padding: 0.5rem;
                background: var(--card-bg);
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            }

            .table tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: 0.75rem;
                padding: 0.4rem 0.5rem;
                border: none;
            }

            .table tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                font-size: 0.75rem;
                color: var(--secondary);
                width: 40%;
            }

            .table tbody td[data-label="Actions"] {
                display: flex;
                flex-wrap: wrap;
                gap: 0.4rem;
                justify-content: center;
            }

            .carousel-inner img {
                max-width: 80px;
            }

            .modal-dialog {
                margin: 0.5rem;
                max-width: 95%;
            }

            .modal-body {
                padding: 0.75rem;
            }

            .modal-body .row > div {
                margin-bottom: 0.75rem;
            }

            .search-input {
                font-size: 0.8rem;
                padding: 0.4rem 0.9rem 0.4rem 2rem;
            }

            .search-icon {
                font-size: 0.8rem;
            }

            .pagination .page-link {
                font-size: 0.8rem;
                padding: 0.35rem 0.6rem;
            }

            .beneficiaire-list {
                font-size: 0.7rem;
                max-height: 150px;
            }
        }

        @media (max-width: 576px) {
            .navbar-brand img {
                max-width: 28px;
            }

            .navbar-brand, .nav-link {
                font-size: 0.85rem;
            }

            .btn-primary, .btn-success, .btn-danger {
                font-size: 0.7rem;
                padding: 0.3rem 0.6rem;
                min-width: 60px;
            }

            .alert {
                font-size: 0.75rem;
                padding: 0.5rem 0.75rem;
            }

            .carousel-inner img {
                max-width: 70px;
            }

            .carousel-control-prev, .carousel-control-next {
                width: 12%;
            }

            .modal-header {
                font-size: 0.9rem;
            }

            .modal-body p {
                font-size: 0.75rem;
            }

            .beneficiaire-list {
                font-size: 0.65rem;
                max-height: 120px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Alerts -->
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill"></i> <?php echo htmlspecialchars($_GET['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
            </div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill"></i> <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
            </div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i> <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Nouvelles Adhésions -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-person-plus-fill" aria-hidden="true"></i> Nouvelles Adhésions (Sans Photo de Carte Précédente)
            </div>
            <div class="card-body">
                <div class="search-container">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" id="search_new_adhesion" class="form-control search-input" placeholder="Rechercher une nouvelle adhésion..." aria-label="Rechercher une nouvelle adhésion par numéro, nom, prénom ou type">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-adhesions" id="new-adhesions-table">
                        <thead>
                            <tr>
                                <th scope="col">Numéro</th>
                                <th scope="col">Nom</th>
                                <th scope="col">Prénom</th>
                                <th scope="col">Date</th>
                                <th scope="col">Type</th>
                                <th scope="col">Agent</th>
                                <th scope="col">Bénéficiaires</th>
                                <th scope="col">Statut</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($new_adhesions)): ?>
                                <tr><td colspan="9" class="text-center">Aucune nouvelle adhésion en attente.</td></tr>
                            <?php else: ?>
                                <?php foreach ($new_adhesions as $adhesion): ?>
                                    <?php
                                    // Vérifier si l'adhésion est prête pour validation
                                    $can_approve = $adhesion['beneficiaire_count'] >= 3 && $adhesion['beneficiaire_count'] == $adhesion['beneficiaire_count_with_photos'];
                                    ?>
                                    <tr>
                                        <td data-label="Numéro"><?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?></td>
                                        <td data-label="Nom"><?php echo htmlspecialchars($adhesion['nom'] ?? 'N/A'); ?></td>
                                        <td data-label="Prénom"><?php echo htmlspecialchars($adhesion['prenom'] ?? 'N/A'); ?></td>
                                        <td data-label="Date"><?php echo htmlspecialchars($adhesion['date_adhesion'] ?? 'N/A'); ?></td>
                                        <td data-label="Type"><?php echo htmlspecialchars($adhesion['type_adhesion'] ?? 'N/A'); ?></td>
                                        <td data-label="Agent"><?php echo htmlspecialchars(($adhesion['agent_nom'] ?? 'N/A') . ' ' . ($adhesion['agent_prenom'] ?? '')); ?></td>
                                        <td data-label="Bénéficiaires"><?php echo htmlspecialchars($adhesion['beneficiaire_count'] ?? 0); ?></td>
                                        <td data-label="Statut"><span class="badge bg-secondary">Nouvelle</span></td>
                                        <td data-label="Actions">
                                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#adhesionModal<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" aria-label="Voir les détails de l'adhésion <?php echo htmlspecialchars($adhesion['num_adherent']); ?>"><i class="bi bi-eye"></i> Détails</button>
                                            <form method="POST" action="" style="display:inline;">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                                <input type="hidden" name="id_adhesion" value="<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                                <?php if ($can_approve): ?>
                                                    <button type="submit" name="action" value="approuvee" class="btn btn-success btn-sm" onclick="return confirm('Confirmer l\'approbation de l\'adhésion ? Tous les bénéficiaires associés seront approuvés.');" aria-label="Approuver l'adhésion <?php echo htmlspecialchars($adhesion['num_adherent']); ?>"><i class="bi bi-check-circle"></i> Approuver</button>
                                                <?php endif; ?>
                                                <button type="submit" name="action" value="rejete" class="btn btn-danger btn-sm" onclick="return confirm('Confirmer la suppression de l\'adhésion, de ses bénéficiaires et de l\'utilisateur associé ? Cette action est irréversible.');" aria-label="Supprimer l'adhésion <?php echo htmlspecialchars($adhesion['num_adherent']); ?>"><i class="bi bi-trash"></i> Supprimer</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination pour Nouvelles Adhésions -->
                <?php if ($new_total_pages > 1): ?>
                    <nav aria-label="Pagination des nouvelles adhésions">
                        <ul class="pagination justify-content-center mt-3">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Page précédente"><i class="bi bi-chevron-left"></i></a>
                            </li>
                            <?php for ($i = max(1, $page - 2); $i <= min($new_total_pages, $page + 2); $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>" aria-label="Page <?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo $page >= $new_total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Page suivante"><i class="bi bi-chevron-right"></i></a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
                <!-- Bouton Valider Tout pour Nouvelles Adhésions -->
                <?php if (!empty($new_adhesions)): ?>
                    <div class="validate-all-container text-end mt-3">
                        <form method="POST" onsubmit="return confirm('Confirmer l\'approbation de toutes les nouvelles adhésions en attente ? Tous les bénéficiaires associés seront approuvés.');">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            <button type="submit" name="action" value="validate_all_new" class="btn btn-success btn-lg" aria-label="Valider toutes les nouvelles adhésions en attente"><i class="bi bi-check-all"></i> Valider Toutes les Nouvelles Adhésions</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Renouvellements -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-arrow-repeat" aria-hidden="true"></i> Renouvellements (Avec Photo de Carte Précédente)
            </div>
            <div class="card-body">
                <div class="search-container">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" id="search_renewal_adhesion" class="form-control search-input" placeholder="Rechercher un renouvellement..." aria-label="Rechercher un renouvellement par numéro, nom, prénom ou type">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-adhesions" id="renewal-adhesions-table">
                        <thead>
                            <tr>
                                <th scope="col">Numéro</th>
                                <th scope="col">Nom</th>
                                <th scope="col">Prénom</th>
                                <th scope="col">Date</th>
                                <th scope="col">Type</th>
                                <th scope="col">Agent</th>
                                <th scope="col">Bénéficiaires</th>
                                <th scope="col">Statut</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($renewal_adhesions)): ?>
                                <tr><td colspan="9" class="text-center">Aucun renouvellement en attente avec une photo de carte précédente.</td></tr>
                            <?php else: ?>
                                <?php foreach ($renewal_adhesions as $adhesion): ?>
                                    <?php
                                    // Vérifier si l'adhésion est prête pour validation
                                    $can_approve = $adhesion['beneficiaire_count'] >= 3 && 
                                                   $adhesion['beneficiaire_count'] == $adhesion['beneficiaire_count_with_photos'] && 
                                                   !empty($adhesion['old_card_photo']);
                                    ?>
                                    <tr>
                                        <td data-label="Numéro"><?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?></td>
                                        <td data-label="Nom"><?php echo htmlspecialchars($adhesion['nom'] ?? 'N/A'); ?></td>
                                        <td data-label="Prénom"><?php echo htmlspecialchars($adhesion['prenom'] ?? 'N/A'); ?></td>
                                        <td data-label="Date"><?php echo htmlspecialchars($adhesion['date_adhesion'] ?? 'N/A'); ?></td>
                                        <td data-label="Type"><?php echo htmlspecialchars($adhesion['type_adhesion'] ?? 'N/A'); ?></td>
                                        <td data-label="Agent"><?php echo htmlspecialchars(($adhesion['agent_nom'] ?? 'N/A') . ' ' . ($adhesion['agent_prenom'] ?? '')); ?></td>
                                        <td data-label="Bénéficiaires"><?php echo htmlspecialchars($adhesion['beneficiaire_count'] ?? 0); ?></td>
                                        <td data-label="Statut"><span class="badge bg-success">Renouvellement</span></td>
                                        <td data-label="Actions">
                                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#adhesionModal<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" aria-label="Voir les détails du renouvellement <?php echo htmlspecialchars($adhesion['num_adherent']); ?>"><i class="bi bi-eye"></i> Détails</button>
                                            <form method="POST" action="" style="display:inline;">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                                <input type="hidden" name="id_adhesion" value="<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                                <?php if ($can_approve): ?>
                                                    <button type="submit" name="action" value="approuvee" class="btn btn-success btn-sm" onclick="return confirm('Confirmer l\'approbation du renouvellement ? Tous les bénéficiaires associés seront approuvés.');" aria-label="Approuver le renouvellement <?php echo htmlspecialchars($adhesion['num_adherent']); ?>"><i class="bi bi-check-circle"></i> Approuver</button>
                                                <?php endif; ?>
                                                <button type="submit" name="action" value="rejete" class="btn btn-danger btn-sm" onclick="return confirm('Confirmer la suppression du renouvellement, de ses bénéficiaires et de l\'utilisateur associé ? Cette action est irréversible.');" aria-label="Supprimer le renouvellement <?php echo htmlspecialchars($adhesion['num_adherent']); ?>"><i class="bi bi-trash"></i> Supprimer</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination pour Renouvellements -->
                <?php if ($renewal_total_pages > 1): ?>
                    <nav aria-label="Pagination des renouvellements">
                        <ul class="pagination justify-content-center mt-3">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Page précédente"><i class="bi bi-chevron-left"></i></a>
                            </li>
                            <?php for ($i = max(1, $page - 2); $i <= min($renewal_total_pages, $page + 2); $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>" aria-label="Page <?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo $page >= $renewal_total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Page suivante"><i class="bi bi-chevron-right"></i></a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
                <!-- Bouton Valider Tout pour Renouvellements -->
                <?php if (!empty($renewal_adhesions)): ?>
                    <div class="validate-all-container text-end mt-3">
                        <form method="POST" onsubmit="return confirm('Confirmer l\'approbation de tous les renouvellements en attente ? Tous les bénéficiaires associés seront approuvés.');">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            <button type="submit" name="action" value="validate_all_renewal" class="btn btn-success btn-lg" aria-label="Valider tous les renouvellements en attente"><i class="bi bi-check-all"></i> Valider Tous les Renouvellements</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Modals pour Détails des Adhésions -->
        <?php
        $all_adhesions = array_merge($new_adhesions, $renewal_adhesions);
        if (!empty($all_adhesions)):
        ?>
            <?php foreach ($all_adhesions as $adhesion): ?>
                <div class="modal fade" id="adhesionModal<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" tabindex="-1" aria-labelledby="adhesionModalLabel<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="adhesionModalLabel<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                    Détails de l'Adhésion <?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?>
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p><strong>Numéro Adhérent :</strong> <?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?></p>
                                        <p><strong>Nom :</strong> <?php echo htmlspecialchars($adhesion['nom'] ?? 'N/A'); ?></p>
                                        <p><strong>Prénom :</strong> <?php echo htmlspecialchars($adhesion['prenom'] ?? 'N/A'); ?></p>
                                        <p><strong>Statut :</strong> <?php echo $adhesion['is_renewal'] == 1 ? '<span class="badge bg-success">Renouvellement</span>' : '<span class="badge bg-secondary">Nouvelle</span>'; ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong>Date d'Adhésion :</strong> <?php echo htmlspecialchars($adhesion['date_adhesion'] ?? 'N/A'); ?></p>
                                        <p><strong>Type :</strong> <?php echo htmlspecialchars($adhesion['type_adhesion'] ?? 'N/A'); ?></p>
                                        <p><strong>Agent :</strong> <?php echo htmlspecialchars(($adhesion['agent_nom'] ?? 'N/A') . ' ' . ($adhesion['agent_prenom'] ?? '')); ?></p>
                                        <p><strong>Bénéficiaires :</strong> <?php echo htmlspecialchars($adhesion['beneficiaire_count'] ?? 0); ?></p>
                                    </div>
                                </div>

                                <!-- Affichage de la Photo de Carte Précédente pour Renouvellements -->
                                <?php if ($adhesion['is_renewal'] == 1 && !empty($adhesion['old_card_photo']) && file_exists($adhesion['old_card_photo'])): ?>
                                    <h6 class="mt-3">Photo de Carte Précédente</h6>
                                    <img src="<?php echo htmlspecialchars($adhesion['old_card_photo']); ?>" alt="Photo de carte précédente pour adhésion <?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?>" class="img-fluid mb-3" style="max-width: 200px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
                                <?php else: ?>
                                    <p class="text-muted mt-3">Aucune photo de carte précédente disponible.</p>
                                <?php endif; ?>

                                <!-- Bénéficiaires avec Photos -->
                                <h6 class="mt-3">Bénéficiaires avec Photos</h6>
                                <?php
                                $stmt_benef_with_photos = $pdo->prepare("
                                    SELECT nom, prenom, relation, photo_path
                                    FROM beneficiaires 
                                    WHERE id_adhesion = ? 
                                    AND photo_path IS NOT NULL 
                                    AND photo_path != ''
                                ");
                                $stmt_benef_with_photos->execute([$adhesion['id_adhesion']]);
                                $beneficiaires_with_photos = $stmt_benef_with_photos->fetchAll(PDO::FETCH_ASSOC);
                                ?>
                                <?php if (!empty($beneficiaires_with_photos)): ?>
                                    <div id="carouselBenef<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" class="carousel slide" data-bs-ride="carousel">
                                        <div class="carousel-inner">
                                            <?php foreach ($beneficiaires_with_photos as $index => $benef): ?>
                                                <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                                                    <img src="<?php echo htmlspecialchars($benef['photo_path']); ?>" alt="Photo de <?php echo htmlspecialchars(($benef['nom'] ?? 'N/A') . ' ' . ($benef['prenom'] ?? 'N/A')); ?>" class="d-block">
                                                    <div class="carousel-caption d-none d-md-block">
                                                        <h6><?php echo htmlspecialchars(($benef['nom'] ?? 'N/A') . ' ' . ($benef['prenom'] ?? 'N/A')); ?></h6>
                                                        <p><?php echo htmlspecialchars($benef['relation'] ?? 'N/A'); ?></p>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselBenef<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" data-bs-slide="prev">
                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden">Précédent</span>
                                        </button>
                                        <button class="carousel-control-next" type="button" data-bs-target="#carouselBenef<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" data-bs-slide="next">
                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden">Suivant</span>
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">Aucune photo de bénéficiaire disponible.</p>
                                <?php endif; ?>

                                <!-- Bénéficiaires sans Photos -->
                                <h6 class="mt-3">Bénéficiaires sans Photos</h6>
                                <?php
                                $stmt_benef_without_photos = $pdo->prepare("
                                    SELECT nom, prenom, relation
                                    FROM beneficiaires 
                                    WHERE id_adhesion = ? 
                                    AND (photo_path IS NULL OR photo_path = '')
                                ");
                                $stmt_benef_without_photos->execute([$adhesion['id_adhesion']]);
                                $beneficiaires_without_photos = $stmt_benef_without_photos->fetchAll(PDO::FETCH_ASSOC);
                                ?>
                                <?php if (!empty($beneficiaires_without_photos)): ?>
                                    <ul class="beneficiaire-list">
                                        <?php foreach ($beneficiaires_without_photos as $benef): ?>
                                            <li>
                                                <span>Nom :</span> <?php echo htmlspecialchars(($benef['nom'] ?? 'N/A') . ' ' . ($benef['prenom'] ?? 'N/A')); ?> 
                                                <span>(<?php echo htmlspecialchars($benef['relation'] ?? 'N/A'); ?>)</span>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-muted">Aucun bénéficiaire sans photo.</p>
                                <?php endif; ?>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" aria-label="Fermer">Fermer</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Debounced Search Functionality for New Adhesions
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }

        const searchNewInput = document.getElementById('search_new_adhesion');
        if (searchNewInput) {
            const searchNewFunc = debounce(function(e) {
                const search = e.target.value.toLowerCase();
                const rows = document.querySelectorAll('#new-adhesions-table tbody tr');
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(search) ? '' : 'none';
                });
            }, 300);
            searchNewInput.addEventListener('input', searchNewFunc);
        }

        // Debounced Search Functionality for Renewals
        const searchRenewalInput = document.getElementById('search_renewal_adhesion');
        if (searchRenewalInput) {
            const searchRenewalFunc = debounce(function(e) {
                const search = e.target.value.toLowerCase();
                const rows = document.querySelectorAll('#renewal-adhesions-table tbody tr');
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(search) ? '' : 'none';
                });
            }, 300);
            searchRenewalInput.addEventListener('input', searchRenewalFunc);
        }
    </script>
</body>
</html>

<?php
require_once __DIR__ . '/../includes/footer.php';
ob_end_flush(); // Flush the output buffer
?>