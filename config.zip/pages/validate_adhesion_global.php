<?php
// pages/validate_adhesion_global.php
ob_start();
require_once __DIR__ . '/../includes/header.php';

// Enable error reporting for debugging (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Vérifications de session et rôle
checkSessionTimeout();
checkRole('admin');

$errors = [];
$new_adhesions = [];
$renewal_adhesions = [];
$new_total_pages = 0;
$renewal_total_pages = 0;
$departements = [];

// Paramètres de pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Filtre par département
$departement_filter = isset($_GET['departement']) ? $_GET['departement'] : 'all';
$departement_where = ($departement_filter !== 'all') ? "AND u.departement = :departement" : "";
$departement_bind = ($departement_filter !== 'all') ? [$departement_filter] : [];

// Récupérer la liste des départements pour le filtre
try {
    $stmt = $pdo->prepare("SELECT id_departement, nom FROM departements ORDER BY nom ASC");
    $stmt->execute();
    $departements = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des départements.";
    error_log("Erreur PDO : " . $e->getMessage());
}

// Récupérer les adhésions
try {
    if (!$pdo instanceof PDO) {
        $errors[] = "Erreur : Connexion à la base de données non établie.";
        error_log("Connexion PDO non initialisée dans validate_adhesion_global.php");
    } else {
        // Vérifier si la colonne old_card_photo existe
        $stmt_check = $pdo->query("SHOW COLUMNS FROM adhesions LIKE 'old_card_photo'");
        $old_card_photo_exists = $stmt_check->rowCount() > 0;

        if (!$old_card_photo_exists) {
            $errors[] = "Erreur : La colonne 'old_card_photo' n'existe pas dans la table adhesions.";
            error_log("Colonne old_card_photo manquante dans la table adhesions, utilisateur ID: {$_SESSION['user_id']}");
        } else {
            // Nouvelles adhésions (globale)
            $query_new = "
                SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom, a.date_adhesion, a.type_adhesion,
                       agent.nom AS agent_nom, agent.prenom AS agent_prenom, agent.telephone AS agent_telephone,
                       d.nom AS departement_nom,
                       (SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion
                       ) AS total_beneficiaires,
                       (SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion 
                        AND b.photo_path IS NOT NULL 
                        AND b.photo_path != ''
                       ) AS beneficiaire_count_with_photos,
                       CASE 
                           WHEN a.old_card_photo IS NOT NULL AND a.old_card_photo != '' 
                           THEN 1 
                           ELSE 0 
                       END AS is_renewal,
                       (SELECT CASE 
                                WHEN COUNT(*) >= 3 
                                AND SUM(CASE WHEN b2.photo_path IS NOT NULL AND b2.photo_path != '' THEN 1 ELSE 0 END) = COUNT(*) 
                                THEN 1 ELSE 0 END 
                        FROM beneficiaires b2 
                        WHERE b2.id_adhesion = a.id_adhesion
                       ) AS is_complete
                FROM adhesions a 
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
                JOIN departements d ON u.departement = d.id_departement
                WHERE a.statut = 'en_attente_validation'
                AND (a.old_card_photo IS NULL OR a.old_card_photo = '')
                $departement_where
                ORDER BY is_complete DESC, a.date_adhesion DESC
                LIMIT ? OFFSET ?
            ";
            $stmt_new = $pdo->prepare($query_new);
            if ($departement_filter !== 'all') {
                $stmt_new->bindValue(1, $departement_filter, PDO::PARAM_INT);
                $stmt_new->bindValue(2, (int)$perPage, PDO::PARAM_INT);
                $stmt_new->bindValue(3, (int)$offset, PDO::PARAM_INT);
            } else {
                $stmt_new->bindValue(1, (int)$perPage, PDO::PARAM_INT);
                $stmt_new->bindValue(2, (int)$offset, PDO::PARAM_INT);
            }
            $stmt_new->execute();
            $new_adhesions = $stmt_new->fetchAll(PDO::FETCH_ASSOC);

            // Compter le total des nouvelles adhésions globale
            $query_new_count = "
                SELECT COUNT(*) 
                FROM adhesions a 
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
                WHERE a.statut = 'en_attente_validation'
                AND (a.old_card_photo IS NULL OR a.old_card_photo = '')
                $departement_where
            ";
            $stmt_new_count = $pdo->prepare($query_new_count);
            $stmt_new_count->execute($departement_bind);
            $new_total_adhesions = $stmt_new_count->fetchColumn() ?: 0;
            $new_total_pages = ceil($new_total_adhesions / $perPage);

            // Renouvellements globale
            $query_renewal = "
                SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom, a.date_adhesion, a.type_adhesion,
                       agent.nom AS agent_nom, agent.prenom AS agent_prenom, agent.telephone AS agent_telephone,
                       d.nom AS departement_nom,
                       (SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion
                       ) AS total_beneficiaires,
                       (SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion 
                        AND b.photo_path IS NOT NULL 
                        AND b.photo_path != ''
                       ) AS beneficiaire_count_with_photos,
                       CASE 
                           WHEN a.old_card_photo IS NOT NULL AND a.old_card_photo != '' 
                           THEN 1 
                           ELSE 0 
                       END AS is_renewal,
                       a.old_card_photo,
                       (SELECT CASE 
                                WHEN COUNT(*) >= 3 
                                AND SUM(CASE WHEN b2.photo_path IS NOT NULL AND b2.photo_path != '' THEN 1 ELSE 0 END) = COUNT(*) 
                                THEN 1 ELSE 0 END 
                        FROM beneficiaires b2 
                        WHERE b2.id_adhesion = a.id_adhesion
                       ) AS is_complete
                FROM adhesions a 
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
                JOIN departements d ON u.departement = d.id_departement
                WHERE a.statut = 'en_attente_validation'
                AND a.old_card_photo IS NOT NULL 
                AND a.old_card_photo != ''
                $departement_where
                ORDER BY is_complete DESC, a.date_adhesion DESC
                LIMIT ? OFFSET ?
            ";
            $stmt_renewal = $pdo->prepare($query_renewal);
            if ($departement_filter !== 'all') {
                $stmt_renewal->bindValue(1, $departement_filter, PDO::PARAM_INT);
                $stmt_renewal->bindValue(2, (int)$perPage, PDO::PARAM_INT);
                $stmt_renewal->bindValue(3, (int)$offset, PDO::PARAM_INT);
            } else {
                $stmt_renewal->bindValue(1, (int)$perPage, PDO::PARAM_INT);
                $stmt_renewal->bindValue(2, (int)$offset, PDO::PARAM_INT);
            }
            $stmt_renewal->execute();
            $renewal_adhesions = $stmt_renewal->fetchAll(PDO::FETCH_ASSOC);

            // Compter le total des renouvellements globale
            $query_renewal_count = "
                SELECT COUNT(*) 
                FROM adhesions a 
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
                WHERE a.statut = 'en_attente_validation'
                AND a.old_card_photo IS NOT NULL 
                AND a.old_card_photo != ''
                $departement_where
            ";
            $stmt_renewal_count = $pdo->prepare($query_renewal_count);
            $stmt_renewal_count->execute($departement_bind);
            $renewal_total_adhesions = $stmt_renewal_count->fetchColumn() ?: 0;
            $renewal_total_pages = ceil($renewal_total_adhesions / $perPage);
        }
    }
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des adhésions.";
    error_log("Erreur PDO dans validate_adhesion_global.php (récupération des adhésions) : " . $e->getMessage() . " - Code: " . $e->getCode());
}

// Fonction pour afficher le téléphone (version complète, sans masquage pour les admins)
function displayTelephone($telephone) {
    return !empty($telephone) ? htmlspecialchars($telephone) : 'N/A';
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adhésions en Attente - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-medical: linear-gradient(135deg, #1e3a8a, #3b82f6, #1d4ed8);
            --success-health: linear-gradient(135deg, #15803d, #22c55e, #16a34a);
            --warning-gold: linear-gradient(135deg, #d97706, #f59e0b, #b45309);
            --danger-alert: linear-gradient(135deg, #dc2626, #ef4444, #b91c1c);
            --glass-bg: rgba(255, 255, 255, 0.15);
            --glass-border: rgba(255, 255, 255, 0.25);
            --shadow-glow: 0 20px 40px -10px rgba(59, 130, 246, 0.25);
            --shadow-hover: 0 30px 50px -12px rgba(59, 130, 246, 0.35);
            --text: #1e293b;
            --card-bg: rgba(255, 255, 255, 0.95);
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 50%, #f0f9ff 100%);
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 20% 50%, rgba(120, 119, 198, 0.15) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.15) 0%, transparent 50%),
                        radial-gradient(circle at 40% 80%, rgba(120, 219, 255, 0.15) 0%, transparent 50%);
            z-index: -1;
        }

        .navbar {
            background: var(--primary-medical);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            padding: 0.75rem 1rem;
            backdrop-filter: blur(20px);
        }

        .navbar-brand img {
            max-width: 36px;
            margin-right: 0.5rem;
            border-radius: 50%;
        }

        .navbar-brand, .nav-link {
            color: white !important;
            font-weight: 600;
            font-size: 1rem;
        }

        .nav-link:hover {
            color: #22c55e !important;
            transform: scale(1.05);
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2.5rem 1rem;
        }

        /* Header Hero */
        .header-hero {
            background: var(--primary-medical);
            border-radius: 28px;
            padding: 2.5rem;
            color: white;
            margin-bottom: 2.5rem;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-glow);
            backdrop-filter: blur(25px);
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .header-hero::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: conic-gradient(from 0deg, transparent, rgba(255,255,255,0.15), transparent 30%);
            animation: rotate 25s linear infinite;
            opacity: 0.4;
        }

        @keyframes rotate { 100% { transform: rotate(360deg); } }

        .header-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.75rem;
            background: linear-gradient(45deg, #fff, #e0f2fe, #bfdbfe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 0 4px 12px rgba(0,0,0,0.15);
            position: relative;
            z-index: 1;
        }

        .header-subtitle {
            font-size: 1.2rem;
            opacity: 0.98;
            font-weight: 400;
            max-width: 750px;
            margin: 0 auto;
            line-height: 1.6;
        }

        /* Cards */
        .card {
            background: var(--card-bg);
            border-radius: 16px;
            padding: 2rem;
            box-shadow: var(--shadow-glow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(15px);
            transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
            margin-bottom: 2.5rem;
            position: relative;
            overflow: hidden;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-medical);
            transform: scaleX(0);
            transition: transform 0.5s ease;
        }

        .card:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.98);
        }

        .card:hover::before {
            transform: scaleX(1);
        }

        .card-header {
            background: var(--primary-medical);
            color: white;
            font-weight: 700;
            border-radius: 12px 12px 0 0;
            padding: 1rem 1.5rem;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin: -2rem -2rem 1.5rem -2rem;
            position: relative;
            z-index: 1;
        }

        /* Filter Section */
        .filter-container {
            background: var(--glass-bg);
            backdrop-filter: blur(25px);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2.5rem;
            border: 1px solid var(--glass-border);
            box-shadow: var(--shadow-glow);
            transition: all 0.4s ease;
        }

        .filter-container:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-hover);
        }

        .form-select, .btn-filter {
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.4s ease;
            border: 1px solid var(--glass-border);
            background: var(--card-bg);
            padding: 0.75rem;
        }

        .form-select:focus, .btn-filter:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.25);
            outline: none;
            transform: scale(1.02);
        }

        .btn-filter {
            background: var(--primary-medical);
            color: white;
            border: none;
            font-weight: 600;
        }

        .btn-filter:hover {
            background: linear-gradient(135deg, #1e40af, #1d4ed8);
            transform: scale(1.05);
            box-shadow: 0 6px 15px rgba(59, 130, 246, 0.3);
        }

        /* Search Input */
        .search-container {
            position: relative;
            max-width: 100%;
            margin-bottom: 2rem;
        }

        .search-input {
            border-radius: 12px;
            padding: 0.75rem 1rem 0.75rem 3rem;
            border: 1px solid var(--glass-border);
            background: var(--glass-bg);
            backdrop-filter: blur(15px);
            width: 100%;
            font-size: 1rem;
            transition: all 0.4s ease;
            color: var(--text);
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.05);
        }

        .search-input:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.25), inset 0 2px 4px rgba(0,0,0,0.05);
            outline: none;
            background: rgba(255,255,255,0.2);
        }

        .search-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: #6b7280;
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }

        .search-input:focus + .search-icon {
            color: #3b82f6;
        }

        /* Table */
        .table {
            background: var(--card-bg);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            margin-bottom: 1.5rem;
        }

        .table thead {
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
            color: var(--text);
            font-weight: 600;
            font-size: 0.9rem;
            border-bottom: 2px solid rgba(59, 130, 246, 0.1);
        }

        .table tbody tr {
            transition: all 0.3s ease;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        .table tbody tr:hover {
            background: linear-gradient(135deg, rgba(243, 244, 246, 0.8), rgba(248, 250, 252, 0.8));
            transform: scale(1.01);
        }

        .table td, .table th {
            padding: 1rem 0.75rem;
            font-size: 0.95rem;
            white-space: nowrap;
            vertical-align: middle;
        }

        .badge {
            font-size: 0.85rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }

        .badge:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }

        /* Pagination */
        .pagination .page-link {
            border-radius: 8px;
            margin: 0 4px;
            color: #3b82f6;
            border: 1px solid #e2e8f0;
            font-size: 0.9rem;
            padding: 0.6rem 1rem;
            transition: all 0.4s ease;
            font-weight: 500;
        }

        .pagination .page-item.active .page-link {
            background: var(--primary-medical);
            border-color: #3b82f6;
            color: white;
            box-shadow: 0 4px 8px rgba(59, 130, 246, 0.3);
        }

        .pagination .page-link:hover {
            background: linear-gradient(135deg, #e0f2fe, #bfdbfe);
            color: #1e3a8a;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2);
        }

        /* Alerts */
        .alert {
            border-radius: 12px;
            padding: 1rem 1.25rem;
            margin-bottom: 1rem;
            font-size: 0.95rem;
            animation: slideIn 0.6s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: var(--glass-bg);
            backdrop-filter: blur(15px);
            border: 1px solid var(--glass-border);
            box-shadow: var(--shadow-glow);
        }

        /* Modal Enhanced Styles */
        .modal {
            z-index: 1060;
        }

        .modal-backdrop {
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(8px);
        }

        .modal-content {
            border-radius: 24px;
            box-shadow: 0 35px 70px -20px rgba(0, 0, 0, 0.3);
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(25px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            overflow: hidden;
            animation: modalSlideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            margin: 1.75rem;
            max-height: calc(100% - 3.5rem);
        }

        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-50px) scale(0.95);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .modal-header {
            background: linear-gradient(135deg, #1e3a8a, #3b82f6);
            color: white;
            border: none;
            padding: 1.5rem 2rem;
            position: relative;
            overflow: hidden;
        }

        .modal-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(circle at 20% 20%, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: -1;
        }

        .modal-title {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .modal-title::before {
            content: '📋';
            font-size: 1.2rem;
        }

        .btn-close {
            filter: invert(1);
            opacity: 0.8;
            border-radius: 50%;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .btn-close:hover {
            opacity: 1;
            transform: scale(1.1);
            background: rgba(255, 255, 255, 0.2);
        }

        .modal-body {
            padding: 2.5rem;
            background: linear-gradient(135deg, rgba(248, 250, 252, 0.5) 0%, rgba(241, 245, 249, 0.5) 100%);
            overflow-y: auto;
            max-height: calc(80vh - 200px);
        }

        .modal-body p {
            font-size: 0.95rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem;
            background: rgba(255, 255, 255, 0.7);
            border-radius: 12px;
            border-left: 4px solid #3b82f6;
            transition: all 0.3s ease;
        }

        .modal-body p:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .modal-body p strong {
            color: #1e3a8a;
            font-weight: 600;
            min-width: 150px;
        }

        .modal-section {
            margin-bottom: 2rem;
            padding: 1.5rem;
            background: rgba(255, 255, 255, 0.8);
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }

        .modal-section h6 {
            color: #1e3a8a;
            font-weight: 700;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.1rem;
        }

        /* Old Card Photo */
        .old-card-photo {
            text-align: center;
            margin: 1.5rem 0;
        }

        .old-card-photo img {
            max-width: 250px;
            height: auto;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            transition: all 0.4s ease;
            border: 3px solid #3b82f6;
        }

        .old-card-photo img:hover {
            transform: scale(1.05) rotate(1deg);
            box-shadow: 0 12px 35px rgba(0, 0, 0, 0.2);
        }

        /* Carousel Enhanced */
        .carousel {
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
        }

        .carousel-inner img {
            max-width: 160px;
            height: 200px;
            object-fit: cover;
            border-radius: 12px;
            margin: 0 auto;
            transition: all 0.4s ease;
        }

        .carousel-item:hover .carousel-inner img {
            transform: scale(1.08);
        }

        .carousel-control-prev,
        .carousel-control-next {
            width: 5%;
            opacity: 0.7;
            transition: opacity 0.3s ease;
        }

        .carousel-control-prev:hover,
        .carousel-control-next:hover {
            opacity: 1;
        }

        .carousel-caption {
            background: linear-gradient(135deg, rgba(0, 0, 0, 0.8), rgba(30, 58, 138, 0.8));
            border-radius: 12px;
            padding: 1rem;
            backdrop-filter: blur(10px);
            color: white;
            font-weight: 500;
        }

        .carousel-caption h6 {
            margin: 0 0 0.5rem 0;
            font-size: 1rem;
            color: white;
        }

        .carousel-caption p {
            margin: 0;
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .modal-footer {
            border: none;
            padding: 1.5rem 2.5rem;
            background: linear-gradient(135deg, rgba(248, 250, 252, 0.5) 0%, rgba(241, 245, 249, 0.5) 100%);
        }

        .modal-footer .btn {
            border-radius: 12px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .modal-footer .btn-secondary {
            background: linear-gradient(135deg, #6b7280, #9ca3af);
            border: none;
        }

        .modal-footer .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(107, 114, 128, 0.3);
        }

        /* Animations */
        .fade-in-up {
            animation: fadeInUp 1s cubic-bezier(0.4, 0, 0.2, 1) forwards;
            opacity: 0;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        /* Enhanced Responsive Design */
        @media (max-width: 1200px) {
            .container { padding: 2rem 1rem; }
            .header-title { font-size: 2.3rem; }
        }

        @media (max-width: 992px) {
            .container { padding: 1.5rem 0.75rem; }
            .header-title { font-size: 2rem; }
            .header-subtitle { font-size: 1.1rem; }
            .table td, .table th { font-size: 0.85rem; padding: 0.75rem 0.5rem; }
            .card { padding: 1.5rem; }
            .modal-body { padding: 1.5rem; }
            .modal-body p strong { min-width: 120px; }
            .carousel-inner img { max-width: 140px; height: 180px; }
        }

        @media (max-width: 768px) {
            .container { padding: 1rem 0.5rem; }
            .header-hero { padding: 2rem 1.5rem; border-radius: 20px; margin-bottom: 2rem; }
            .header-title { font-size: 1.8rem; }
            .header-subtitle { font-size: 1rem; }
            .table thead { display: none; }
            .table tbody tr {
                display: block;
                margin-bottom: 1.5rem;
                border: 1px solid #e5e7eb;
                border-radius: 12px;
                padding: 1rem;
                background: var(--card-bg);
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            }

            .table tbody td {
                display: block;
                justify-content: flex-start;
                align-items: flex-start;
                font-size: 0.9rem;
                padding: 0.75rem 0;
                border: none;
                border-bottom: 1px solid rgba(0,0,0,0.05);
                white-space: normal;
            }

            .table tbody td::before {
                content: attr(data-label) ": ";
                font-weight: 700;
                font-size: 0.9rem;
                color: #1e3a8a;
                display: block;
                margin-bottom: 0.25rem;
            }

            .table tbody td[data-label="Détails"] {
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
                justify-content: center;
                width: 100%;
                text-align: center;
            }

            .card-header { margin: -1.5rem -1.5rem 1.25rem -1.5rem; padding: 0.75rem 1rem; font-size: 1rem; }
            .card { padding: 1rem; margin-bottom: 2rem; }
            .filter-container { padding: 1.5rem; }
            .search-input { padding-left: 2.5rem; font-size: 0.95rem; }
            .carousel-inner img { max-width: 120px; height: 150px; }
            .modal-dialog { margin: 0.5rem; max-width: calc(100% - 1rem); }
            .modal-content { border-radius: 16px; margin: 0.5rem; }
            .modal-header { padding: 1rem 1.5rem; }
            .modal-title { font-size: 1.2rem; }
            .modal-body { padding: 1rem; max-height: calc(80vh - 150px); }
            .modal-body p { flex-direction: column; align-items: flex-start; gap: 0.25rem; padding: 0.5rem; }
            .modal-body p strong { min-width: auto; }
            .modal-section { padding: 1rem; margin-bottom: 1.5rem; }
            .modal-section h6 { font-size: 1rem; }
            .modal-footer { padding: 1rem 1.5rem; }
            .old-card-photo img { max-width: 200px; }
            .carousel-control-prev, .carousel-control-next { width: 8%; }
        }

        @media (max-width: 576px) {
            .navbar-brand img { max-width: 30px; }
            .navbar-brand, .nav-link { font-size: 0.9rem; }
            .btn-primary { font-size: 0.8rem; padding: 0.5rem 0.75rem; }
            .alert { font-size: 0.85rem; padding: 0.75rem 1rem; flex-direction: column; align-items: flex-start; gap: 0.5rem; }
            .header-hero { padding: 1.5rem 1rem; border-radius: 16px; }
            .header-title { font-size: 1.6rem; }
            .header-subtitle { font-size: 0.95rem; }
            .form-select, .btn-filter { font-size: 0.9rem; padding: 0.6rem; }
            .table tbody td { font-size: 0.85rem; }
            .badge { font-size: 0.8rem; padding: 0.4rem 0.8rem; }
            .carousel-inner img { max-width: 100px; height: 130px; }
            .modal-header { padding: 0.75rem 1rem; }
            .modal-title { font-size: 1.1rem; }
            .modal-body { padding: 0.75rem; }
            .modal-body p { font-size: 0.85rem; padding: 0.4rem; }
            .modal-section h6 { font-size: 0.95rem; }
            .old-card-photo img { max-width: 150px; }
            .carousel-caption { padding: 0.5rem; }
            .carousel-caption h6 { font-size: 0.9rem; }
            .carousel-caption p { font-size: 0.8rem; }
        }

        @media (max-width: 480px) {
            .container { padding: 0.75rem 0.25rem; }
            .header-title { font-size: 1.4rem; }
            .card { padding: 0.75rem; }
            .card-header { margin: -0.75rem -0.75rem 1rem -0.75rem; padding: 0.5rem 0.75rem; font-size: 0.9rem; }
            .filter-container { padding: 1rem; }
            .search-container { margin-bottom: 1.5rem; }
            .search-input { padding-left: 2rem; font-size: 0.9rem; }
            .search-icon { left: 0.75rem; font-size: 1rem; }
            .modal-body { max-height: calc(90vh - 150px); }
            .modal-section { padding: 0.75rem; }
        }

        /* Additional Responsive Enhancements for Better Compatibility */
        @media (max-width: 360px) {
            .container { padding: 0.5rem 0.25rem; }
            .header-hero { padding: 1.25rem 1rem; }
            .header-title { font-size: 1.3rem; }
            .table tbody td { font-size: 0.8rem; padding: 0.5rem 0; }
            .btn-sm { padding: 0.25rem 0.5rem; font-size: 0.75rem; }
            .badge { font-size: 0.7rem; padding: 0.3rem 0.6rem; }
            .carousel-inner img { max-width: 90px; height: 110px; }
        }

        /* Ensure better table responsiveness on very small screens */
        @media (max-width: 400px) {
            .table tbody td[data-label="Détails"] button {
                width: 100%;
                margin-bottom: 0.5rem;
            }
        }

        /* Improve button sizing for touch devices */
        @media (hover: none) and (pointer: coarse) {
            .btn {
                min-height: 44px;
                padding: 0.75rem 1rem;
            }
            .btn-sm {
                min-height: 40px;
                padding: 0.5rem 0.75rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header Hero -->
        <div class="header-hero fade-in-up">
            <h1 class="header-title animate__animated animate__fadeInDown">
                🛡️ Adhésions en Attente - Vue Globale
            </h1>
            <p class="header-subtitle animate__animated animate__fadeInUp">
                Consultez les adhésions en attente de validation pour tous les départements de Matam. Les adhésions prêtes pour validation sont prioritaires.
            </p>
        </div>

        <!-- Alerts -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i> <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Filtre par département -->
        <div class="filter-container fade-in-up" style="animation-delay: 0.2s;">
            <div class="card-header mb-4">
                <i class="bi bi-filter-circle-fill"></i> Filtrer par Département
            </div>
            <form method="GET" action="">
                <div class="row g-3">
                    <div class="col-md-4">
                        <select class="form-select" name="departement" aria-label="Sélectionner un département">
                            <option value="all" <?php echo $departement_filter === 'all' ? 'selected' : ''; ?>>Tous les départements</option>
                            <?php foreach ($departements as $dept): ?>
                                <option value="<?php echo htmlspecialchars($dept['id_departement']); ?>" <?php echo $departement_filter === $dept['id_departement'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($dept['nom']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-filter w-100"><i class="bi bi-search"></i> Filtrer</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Nouvelles Adhésions -->
        <div class="card fade-in-up" style="animation-delay: 0.4s;">
            <div class="card-header">
                <i class="bi bi-person-plus-fill"></i> Nouvelles Adhésions (Sans Photo de Carte Précédente)
            </div>
            <div class="card-body">
                <div class="search-container">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" id="search_new_adhesion" class="form-control search-input" placeholder="Rechercher une nouvelle adhésion..." aria-label="Rechercher une nouvelle adhésion par numéro, nom, prénom ou type">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-adhesions" id="new-adhesions-table">
                        <thead>
                            <tr>
                                <th scope="col">Numéro</th>
                                <th scope="col">Nom</th>
                                <th scope="col">Prénom</th>
                                <th scope="col">Date</th>
                                <th scope="col">Type</th>
                                <th scope="col">Agent</th>
                                <th scope="col">Tél. Agent</th>
                                <th scope="col">Département</th>
                                <th scope="col">Bénéficiaires</th>
                                <th scope="col">Prête pour Validation</th>
                                <th scope="col">Statut</th>
                                <th scope="col">Détails</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($new_adhesions)): ?>
                                <tr><td colspan="12" class="text-center py-4"><i class="bi bi-inbox display-4 text-muted mb-3"></i><p class="text-muted mb-0">Aucune nouvelle adhésion en attente.</p></td></tr>
                            <?php else: ?>
                                <?php foreach ($new_adhesions as $adhesion): ?>
                                    <?php $is_complete = ($adhesion['is_complete'] == 1); ?>
                                    <tr>
                                        <td data-label="Numéro"><?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?></td>
                                        <td data-label="Nom"><?php echo htmlspecialchars($adhesion['nom'] ?? 'N/A'); ?></td>
                                        <td data-label="Prénom"><?php echo htmlspecialchars($adhesion['prenom'] ?? 'N/A'); ?></td>
                                        <td data-label="Date"><?php echo htmlspecialchars($adhesion['date_adhesion'] ?? 'N/A'); ?></td>
                                        <td data-label="Type"><?php echo htmlspecialchars($adhesion['type_adhesion'] ?? 'N/A'); ?></td>
                                        <td data-label="Agent"><?php echo htmlspecialchars(($adhesion['agent_nom'] ?? 'N/A') . ' ' . ($adhesion['agent_prenom'] ?? '')); ?></td>
                                        <td data-label="Tél. Agent"><?php echo displayTelephone($adhesion['agent_telephone'] ?? ''); ?></td>
                                        <td data-label="Département"><?php echo htmlspecialchars($adhesion['departement_nom'] ?? 'N/A'); ?></td>
                                        <td data-label="Bénéficiaires"><?php echo htmlspecialchars($adhesion['total_beneficiaires'] ?? 0); ?></td>
                                        <td data-label="Prête pour Validation">
                                            <span class="badge bg-<?php echo $is_complete ? 'success' : 'warning'; ?>"><?php echo $is_complete ? 'O' : 'N'; ?></span>
                                        </td>
                                        <td data-label="Statut"><span class="badge bg-secondary">Nouvelle</span></td>
                                        <td data-label="Détails">
                                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#adhesionModal<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" aria-label="Voir les détails de l'adhésion <?php echo htmlspecialchars($adhesion['num_adherent']); ?>"><i class="bi bi-eye"></i></button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination pour Nouvelles Adhésions -->
                <?php if ($new_total_pages > 1): ?>
                    <nav aria-label="Pagination des nouvelles adhésions" class="mt-4">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&departement=<?php echo htmlspecialchars($departement_filter); ?>" aria-label="Page précédente"><i class="bi bi-chevron-left"></i></a>
                            </li>
                            <?php for ($i = max(1, $page - 2); $i <= min($new_total_pages, $page + 2); $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&departement=<?php echo htmlspecialchars($departement_filter); ?>" aria-label="Page <?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo $page >= $new_total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&departement=<?php echo htmlspecialchars($departement_filter); ?>" aria-label="Page suivante"><i class="bi bi-chevron-right"></i></a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>

        <!-- Renouvellements -->
        <div class="card fade-in-up" style="animation-delay: 0.6s;">
            <div class="card-header">
                <i class="bi bi-arrow-repeat"></i> Renouvellements (Avec Photo de Carte Précédente)
            </div>
            <div class="card-body">
                <div class="search-container">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" id="search_renewal_adhesion" class="form-control search-input" placeholder="Rechercher un renouvellement..." aria-label="Rechercher un renouvellement par numéro, nom, prénom ou type">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-adhesions" id="renewal-adhesions-table">
                        <thead>
                            <tr>
                                <th scope="col">Numéro</th>
                                <th scope="col">Nom</th>
                                <th scope="col">Prénom</th>
                                <th scope="col">Date</th>
                                <th scope="col">Type</th>
                                <th scope="col">Agent</th>
                                <th scope="col">Tél. Agent</th>
                                <th scope="col">Département</th>
                                <th scope="col">Bénéficiaires</th>
                                <th scope="col">Prêt</th>
                                <th scope="col">Statut</th>
                                <th scope="col">Détails</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($renewal_adhesions)): ?>
                                <tr><td colspan="12" class="text-center py-4"><i class="bi bi-arrow-repeat display-4 text-muted mb-3"></i><p class="text-muted mb-0">Aucun renouvellement en attente avec une photo de carte précédente.</p></td></tr>
                            <?php else: ?>
                                <?php foreach ($renewal_adhesions as $adhesion): ?>
                                    <?php $is_complete = ($adhesion['is_complete'] == 1); ?>
                                    <tr>
                                        <td data-label="Numéro"><?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?></td>
                                        <td data-label="Nom"><?php echo htmlspecialchars($adhesion['nom'] ?? 'N/A'); ?></td>
                                        <td data-label="Prénom"><?php echo htmlspecialchars($adhesion['prenom'] ?? 'N/A'); ?></td>
                                        <td data-label="Date"><?php echo htmlspecialchars($adhesion['date_adhesion'] ?? 'N/A'); ?></td>
                                        <td data-label="Type"><?php echo htmlspecialchars($adhesion['type_adhesion'] ?? 'N/A'); ?></td>
                                        <td data-label="Agent"><?php echo htmlspecialchars(($adhesion['agent_nom'] ?? 'N/A') . ' ' . ($adhesion['agent_prenom'] ?? '')); ?></td>
                                        <td data-label="Tél. Agent"><?php echo displayTelephone($adhesion['agent_telephone'] ?? ''); ?></td>
                                        <td data-label="Département"><?php echo htmlspecialchars($adhesion['departement_nom'] ?? 'N/A'); ?></td>
                                        <td data-label="Bénéficiaires"><?php echo htmlspecialchars($adhesion['total_beneficiaires'] ?? 0); ?></td>
                                        <td data-label="Prête pour Validation">
                                            <span class="badge bg-<?php echo $is_complete ? 'success' : 'warning'; ?>"><?php echo $is_complete ? 'O' : 'N'; ?></span>
                                        </td>
                                        <td data-label="Statut"><span class="badge bg-success">RNV</span></td>
                                        <td data-label="Détails">
                                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#adhesionModal<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" aria-label="Voir les détails du renouvellement <?php echo htmlspecialchars($adhesion['num_adherent']); ?>"><i class="bi bi-eye"></i></button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination pour Renouvellements -->
                <?php if ($renewal_total_pages > 1): ?>
                    <nav aria-label="Pagination des renouvellements" class="mt-4">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&departement=<?php echo htmlspecialchars($departement_filter); ?>" aria-label="Page précédente"><i class="bi bi-chevron-left"></i></a>
                            </li>
                            <?php for ($i = max(1, $page - 2); $i <= min($renewal_total_pages, $page + 2); $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&departement=<?php echo htmlspecialchars($departement_filter); ?>" aria-label="Page <?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo $page >= $renewal_total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&departement=<?php echo htmlspecialchars($departement_filter); ?>" aria-label="Page suivante"><i class="bi bi-chevron-right"></i></a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>

        <!-- Modals pour Détails des Adhésions -->
        <?php
        $all_adhesions = array_merge($new_adhesions, $renewal_adhesions);
        if (!empty($all_adhesions)):
        ?>
            <?php foreach ($all_adhesions as $adhesion): ?>
                <div class="modal fade" id="adhesionModal<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" tabindex="-1" aria-labelledby="adhesionModalLabel<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-xl">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="adhesionModalLabel<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                    Détails de l'Adhésion <?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?>
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p><strong>Numéro Adhérent :</strong> <?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?></p>
                                        <p><strong>Nom :</strong> <?php echo htmlspecialchars($adhesion['nom'] ?? 'N/A'); ?></p>
                                        <p><strong>Prénom :</strong> <?php echo htmlspecialchars($adhesion['prenom'] ?? 'N/A'); ?></p>
                                        <p><strong>Statut :</strong> <?php echo $adhesion['is_renewal'] == 1 ? '<span class="badge bg-success">Renouvellement</span>' : '<span class="badge bg-secondary">Nouvelle</span>'; ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong>Date d'Adhésion :</strong> <?php echo htmlspecialchars($adhesion['date_adhesion'] ?? 'N/A'); ?></p>
                                        <p><strong>Type :</strong> <?php echo htmlspecialchars($adhesion['type_adhesion'] ?? 'N/A'); ?></p>
                                        <p><strong>Agent :</strong> <?php echo htmlspecialchars(($adhesion['agent_nom'] ?? 'N/A') . ' ' . ($adhesion['agent_prenom'] ?? '')); ?></p>
                                        <p><strong>Téléphone Agent :</strong> <?php echo displayTelephone($adhesion['agent_telephone'] ?? ''); ?></p>
                                        <p><strong>Département :</strong> <?php echo htmlspecialchars($adhesion['departement_nom'] ?? 'N/A'); ?></p>
                                        <p><strong>Bénéficiaires :</strong> <?php echo htmlspecialchars($adhesion['total_beneficiaires'] ?? 0); ?></p>
                                        <p><strong>Prête pour Validation :</strong> <span class="badge bg-<?php echo ($adhesion['total_beneficiaires'] >= 3 && $adhesion['total_beneficiaires'] == $adhesion['beneficiaire_count_with_photos']) ? 'success' : 'danger'; ?>"><?php echo ($adhesion['total_beneficiaires'] >= 3 && $adhesion['total_beneficiaires'] == $adhesion['beneficiaire_count_with_photos']) ? 'O' : 'N'; ?></span></p>
                                    </div>
                                </div>

                                <!-- Affichage de la Photo de Carte Précédente pour Renouvellements -->
                                <?php if ($adhesion['is_renewal'] == 1 && !empty($adhesion['old_card_photo']) && file_exists($adhesion['old_card_photo'])): ?>
                                    <h6 class="mt-3">Photo de Carte Précédente</h6>
                                    <img src="<?php echo htmlspecialchars($adhesion['old_card_photo']); ?>" alt="Photo de carte précédente pour adhésion <?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?>" class="img-fluid mb-3" style="max-width: 200px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
                                <?php else: ?>
                                    <p class="text-muted mt-3">Aucune photo de carte précédente disponible.</p>
                                <?php endif; ?>

                                <!-- Bénéficiaires -->
                                <h6 class="mt-3">Bénéficiaires</h6>
                                <?php
                                $stmt_benef = $pdo->prepare("
                                    SELECT nom, prenom, relation, photo_path
                                    FROM beneficiaires 
                                    WHERE id_adhesion = ? 
                                ");
                                $stmt_benef->execute([$adhesion['id_adhesion']]);
                                $all_beneficiaires = $stmt_benef->fetchAll(PDO::FETCH_ASSOC);

                                $benef_with_photo = [];
                                $benef_without_photo = [];

                                foreach ($all_beneficiaires as $benef) {
                                    if (!empty($benef['photo_path']) && file_exists($benef['photo_path'])) {
                                        $benef_with_photo[] = $benef;
                                    } else {
                                        $benef_without_photo[] = $benef;
                                    }
                                }
                                ?>

                                <!-- Bénéficiaires avec photos -->
                                <h6 class="mt-3">Bénéficiaires avec photos</h6>
                                <?php if (!empty($benef_with_photo)): ?>
                                    <div id="carouselBenef<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" class="carousel slide" data-bs-ride="carousel">
                                        <div class="carousel-inner">
                                            <?php foreach ($benef_with_photo as $index => $benef): ?>
                                                <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                                                    <img src="<?php echo htmlspecialchars($benef['photo_path']); ?>" alt="Photo de <?php echo htmlspecialchars(($benef['nom'] ?? 'N/A') . ' ' . ($benef['prenom'] ?? 'N/A')); ?>" class="d-block">
                                                    <div class="carousel-caption d-none d-md-block">
                                                        <h6><?php echo htmlspecialchars(($benef['nom'] ?? 'N/A') . ' ' . ($benef['prenom'] ?? 'N/A')); ?></h6>
                                                        <p><?php echo htmlspecialchars($benef['relation'] ?? 'N/A'); ?></p>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselBenef<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" data-bs-slide="prev">
                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden">Précédent</span>
                                        </button>
                                        <button class="carousel-control-next" type="button" data-bs-target="#carouselBenef<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" data-bs-slide="next">
                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden">Suivant</span>
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">Aucun bénéficiaire avec photo.</p>
                                <?php endif; ?>

                                <!-- Bénéficiaires sans photos -->
                                <h6 class="mt-3">Bénéficiaires sans photos</h6>
                                <?php if (!empty($benef_without_photo)): ?>
                                    <ul class="list-group">
                                        <?php foreach ($benef_without_photo as $benef): ?>
                                            <li class="list-group-item">
                                                <strong><?php echo htmlspecialchars(($benef['nom'] ?? 'N/A') . ' ' . ($benef['prenom'] ?? 'N/A')); ?></strong>
                                                (<?php echo htmlspecialchars($benef['relation'] ?? 'N/A'); ?>) - Photo manquante
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-muted">Aucun bénéficiaire sans photo.</p>
                                <?php endif; ?>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" aria-label="Fermer">Fermer</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.js"></script>
    <script>
        // Debounced Search Functionality for New Adhesions
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }

        const searchNewInput = document.getElementById('search_new_adhesion');
        if (searchNewInput) {
            const searchNewFunc = debounce(function(e) {
                const search = e.target.value.toLowerCase();
                const rows = document.querySelectorAll('#new-adhesions-table tbody tr');
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(search) ? '' : 'none';
                });
            }, 300);
            searchNewInput.addEventListener('input', searchNewFunc);
        }

        // Debounced Search Functionality for Renewals
        const searchRenewalInput = document.getElementById('search_renewal_adhesion');
        if (searchRenewalInput) {
            const searchRenewalFunc = debounce(function(e) {
                const search = e.target.value.toLowerCase();
                const rows = document.querySelectorAll('#renewal-adhesions-table tbody tr');
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(search) ? '' : 'none';
                });
            }, 300);
            searchRenewalInput.addEventListener('input', searchRenewalFunc);
        }
    </script>
</body>
</html>
<?php
require_once __DIR__ . '/../includes/footer.php';
ob_end_flush();
?>