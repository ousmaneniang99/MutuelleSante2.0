<?php
// pages/validate_beneficiaire.php
require_once __DIR__ . '/../includes/header.php';

// Restreindre l'accès au directeur_departemental uniquement
checkRole('directeur_departemental');

$errors = [];
$success = null;
$beneficiaires = []; // ✅ Initialisation

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['csrf_token'])) {
    if (!verifyCsrfToken($_POST['csrf_token'])) {
        $errors[] = "Erreur de sécurité CSRF. Veuillez réessayer.";
        error_log("Échec de validation CSRF pour validate_beneficiaire.php, utilisateur ID: {$_SESSION['user_id']}");
    } else {
        try {
            $pdo->beginTransaction();

            if ($_POST['action'] === 'validate_all') {
                // Valider tous les bénéficiaires en attente AVEC PHOTO_PATH et adhésions actives
                $stmt = $pdo->prepare("
                    SELECT b.id_beneficiaire, a.created_by
                    FROM beneficiaires b
                    JOIN adhesions a ON b.id_adhesion = a.id_adhesion
                    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                    WHERE b.statut = 'en_attente_approbation' 
                    AND a.statut = 'active' 
                    AND u.departement = ?
                    AND b.photo_path IS NOT NULL 
                    AND b.photo_path != ''
                    AND b.photo_path NOT LIKE 'default%' 
                    AND b.photo_path NOT LIKE '%null%'
                ");
                $stmt->execute([$_SESSION['departement']]);
                $beneficiaires_to_validate = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if ($beneficiaires_to_validate) {
                    $stmt_benef = $pdo->prepare("UPDATE beneficiaires SET statut = 'actif' WHERE id_beneficiaire = ?");
                    $count_validated = 0;
                    foreach ($beneficiaires_to_validate as $benef) {
                        $id_beneficiaire = $benef['id_beneficiaire'];
                        $agent_id = $benef['created_by'];

                        $stmt_benef->execute([$id_beneficiaire]);
                        if ($stmt_benef->rowCount() > 0) {
                            $count_validated++;
                            $details = "Bénéficiaire ID $id_beneficiaire approuvé (validation globale avec photo) par {$_SESSION['nom']} {$_SESSION['prenom']}";
                            logActivity($pdo, $_SESSION['user_id'], 'validate_beneficiaire', $details);
                            sendNotification($pdo, $agent_id, "Bénéficiaire ID $id_beneficiaire approuvé par le directeur départemental.");
                        }
                    }
                    $success = "$count_validated bénéficiaire(s) avec photo approuvé(s).";
                } else {
                    $errors[] = "Aucun bénéficiaire avec photo valide en attente.";
                }
            } 
            // ✅ Validation individuelle : APPROUVER ou SUPPRIMER
            elseif ($_POST['action'] === 'validate_beneficiaire' && isset($_POST['id_beneficiaire'])) {
                $id_beneficiaire = intval($_POST['id_beneficiaire']);
                $action_type = isset($_POST['action_type']) ? sanitize($_POST['action_type']) : 'approve';

                if ($id_beneficiaire <= 0) {
                    $errors[] = "ID de bénéficiaire invalide.";
                } else {
                    // Vérifier le bénéficiaire et l'adhésion
                    $stmt_check = $pdo->prepare("
                        SELECT a.statut, a.created_by, b.photo_path, b.statut as benef_statut
                        FROM adhesions a
                        JOIN beneficiaires b ON a.id_adhesion = b.id_adhesion
                        WHERE b.id_beneficiaire = ?
                    ");
                    $stmt_check->execute([$id_beneficiaire]);
                    $result = $stmt_check->fetch(PDO::FETCH_ASSOC);

                    if (!$result) {
                        $errors[] = "Bénéficiaire non trouvé.";
                    } elseif ($result['benef_statut'] !== 'en_attente_approbation') {
                        $errors[] = "Bénéficiaire déjà traité.";
                    } elseif ($result['statut'] !== 'active') {
                        $errors[] = "Adhésion non active.";
                    } else {
                        $agent_id = $result['created_by'];
                        
                        if ($action_type === 'approve') {
                            // ✅ APPROBATION : Vérifier photo_path
                            if (empty($result['photo_path']) || 
                                $result['photo_path'] === null || 
                                strpos($result['photo_path'], 'default') !== false ||
                                strpos($result['photo_path'], 'null') !== false) {
                                $errors[] = "Photo manquante ou invalide pour approbation.";
                            } else {
                                // Approuver
                                $stmt = $pdo->prepare("UPDATE beneficiaires SET statut = 'actif' WHERE id_beneficiaire = ?");
                                $stmt->execute([$id_beneficiaire]);
                                
                                if ($stmt->rowCount() > 0) {
                                    $details = "Bénéficiaire ID $id_beneficiaire APPROUVÉ par {$_SESSION['nom']} {$_SESSION['prenom']}";
                                    logActivity($pdo, $_SESSION['user_id'], 'validate_beneficiaire_approve', $details);
                                    sendNotification($pdo, $agent_id, "Bénéficiaire ID $id_beneficiaire APPROUVÉ par le directeur.");
                                    $success = "Bénéficiaire approuvé avec succès.";
                                }
                            }
                        } elseif ($action_type === 'reject') {
                            // ❌ REJET : SUPPRIMER de la BD
                            $stmt = $pdo->prepare("DELETE FROM beneficiaires WHERE id_beneficiaire = ?");
                            $stmt->execute([$id_beneficiaire]);
                            
                            if ($stmt->rowCount() > 0) {
                                $details = "Bénéficiaire ID $id_beneficiaire REJETÉ ET SUPPRIMÉ par {$_SESSION['nom']} {$_SESSION['prenom']}";
                                logActivity($pdo, $_SESSION['user_id'], 'validate_beneficiaire_reject', $details);
                                sendNotification($pdo, $agent_id, "Bénéficiaire ID $id_beneficiaire REJETÉ ET SUPPRIMÉ par le directeur.");
                                $success = "Bénéficiaire rejeté et supprimé définitivement.";
                            } else {
                                $errors[] = "Échec de la suppression.";
                            }
                        } else {
                            $errors[] = "Action non reconnue.";
                        }
                    }
                }
            } else {
                $errors[] = "Action non reconnue.";
                error_log("Action invalide: " . json_encode($_POST));
            }

            $pdo->commit();
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Erreur base de données.";
            error_log("Erreur PDO : " . $e->getMessage());
        }
    }
}

// ✅ Récupération avec vérification photo_path
try {
    $stmt = $pdo->prepare("
        SELECT b.id_beneficiaire, b.nom, b.prenom, a.num_adherent, b.date_entree,
               COALESCE(CONCAT(agent.nom, ' ', agent.prenom), 'Non spécifié') as agent_nom,
               CASE 
                   WHEN b.photo_path IS NOT NULL AND b.photo_path != '' 
                   AND b.photo_path NOT LIKE 'default%' AND b.photo_path NOT LIKE '%null%'
                   THEN '✅ Photo OK'
                   ELSE '❌ Photo manquante'
               END as photo_status
        FROM beneficiaires b 
        JOIN adhesions a ON b.id_adhesion = a.id_adhesion 
        JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
        LEFT JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
        WHERE b.statut = 'en_attente_approbation' 
        AND a.statut = 'active' 
        AND u.departement = ?
        ORDER BY b.date_entree DESC
    ");
    $stmt->execute([$_SESSION['departement']]);
    $beneficiaires = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $beneficiaires = [];
    $errors[] = "Erreur de récupération des données.";
    error_log("Erreur SELECT : " . $e->getMessage());
}

$csrf_token = generateCsrfToken();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Valider les Bénéficiaires - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb; --secondary: #4b5563; --accent: #10b981;
            --warning: #f59e0b; --danger: #ef4444; --background: #f8fafc;
            --card-bg: #ffffff; --text: #1f2a44;
        }
        body { font-family: 'Inter', sans-serif; background: var(--background); color: var(--text); }
        .container { max-width: 1200px; margin-top: 2rem; }
        h2 { font-weight: 700; color: var(--primary); display: flex; align-items: center; gap: 0.5rem; }
        .card { border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); background: var(--card-bg); }
        .card-header { background: linear-gradient(135deg, var(--primary), #1e40af); color: white; font-weight: 600; border-radius: 12px 12px 0 0; padding: 1.5rem; }
        .table th { font-weight: 600; color: var(--text); border-bottom: 2px solid var(--primary); }
        .table td { vertical-align: middle; }
        
        .photo-ok { background: #dcfce7; color: #166534; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem; }
        .photo-missing { background: #fef2f2; color: #dc2626; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem; }
        
        .btn-approve { background: var(--accent); border: none; border-radius: 6px; padding: 0.4rem 0.8rem; font-size: 0.85rem; }
        .btn-approve:hover { background: #059669; transform: translateY(-1px); }
        .btn-reject { background: var(--danger); border: none; border-radius: 6px; padding: 0.4rem 0.8rem; font-size: 0.85rem; }
        .btn-reject:hover { background: #dc2626; transform: translateY(-1px); }
        
        .btn:disabled { opacity: 0.6; cursor: not-allowed; }
        .alert { border-radius: 8px; animation: slideIn 0.5s ease-in-out; }
        @keyframes slideIn { from { opacity: 0; transform: translateX(-10px); } to { opacity: 1; transform: translateX(0); } }
        .validate-all-container { margin-top: 1.5rem; text-align: right; background: #f0fdf4; padding: 1rem; border-radius: 8px; border-left: 4px solid var(--accent); }
        .info-box { 
            background: linear-gradient(135deg, #eff6ff, #dbeafe); 
            border: 1px solid #bfdbfe; border-radius: 8px; padding: 1rem; margin-bottom: 1rem;
            border-left: 4px solid var(--primary);
        }
        .warning-box {
            background: linear-gradient(135deg, #fef3c7, #fde68a);
            border: 1px solid #f59e0b; border-radius: 8px; padding: 1rem; margin-bottom: 1rem;
            border-left: 4px solid var(--warning);
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-4"><i class="bi bi-person-check"></i> Valider les Bénéficiaires</h2>

        <div class="info-box">
            <i class="bi bi-info-circle me-2 text-primary"></i>
            <strong>Critères d'approbation :</strong> Adhésions actives + <strong>photo valide requise</strong><br>
            <small class="text-muted">✅ <strong>Approuver</strong> = Statut "actif" | ❌ <strong>Rejeter</strong> = <strong>SUPPRESSION DEFINITIVE</strong> de la base</small>
        </div>

        <div class="warning-box">
            <i class="bi bi-exclamation-triangle me-2 text-warning"></i>
            <strong>⚠️ ATTENTION :</strong> Le rejet entraîne la <strong>SUPPRESSION DÉFINITIVE</strong> du bénéficiaire de la base de données. 
            Cette action est <strong>IRREVERSIBLE</strong>.
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="bi bi-exclamation-triangle me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <i class="bi bi-person-lines-fill me-2"></i> Bénéficiaires en Attente d'Approbation 
                <span class="badge bg-success ms-2"><?php echo count($beneficiaires); ?> trouvé(s)</span>
              
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Numéro Adhérent</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Date d'Entrée</th>
                                <th>Agent</th>
                                <th>Statut Photo</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($beneficiaires)): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">
                                        <i class="bi bi-inbox fs-1 mb-3 d-block"></i>
                                        Aucun bénéficiaire en attente d'approbation avec adhésion active.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($beneficiaires as $beneficiaire): ?>
                                    <?php $has_valid_photo = strpos($beneficiaire['photo_status'], 'OK') !== false; ?>
                                    <tr class="<?php echo !$has_valid_photo ? 'table-danger' : ''; ?>">
                                        <td><strong><?php echo htmlspecialchars($beneficiaire['num_adherent'] ?? 'N/A'); ?></strong></td>
                                        <td><?php echo htmlspecialchars($beneficiaire['nom']); ?></td>
                                        <td><?php echo htmlspecialchars($beneficiaire['prenom']); ?></td>
                                        <td><?php echo date('d/m/Y', strtotime($beneficiaire['date_entree'] ?? 'now')); ?></td>
                                        <td><?php echo htmlspecialchars($beneficiaire['agent_nom']); ?></td>
                                        <td>
                                            <span class="<?php echo $has_valid_photo ? 'photo-ok' : 'photo-missing'; ?>">
                                                <?php echo $beneficiaire['photo_status']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="d-flex gap-1 flex-wrap">
                                                <form method="POST" style="display: inline;" 
                                                      onsubmit="return confirm('<?= $has_valid_photo ? "Approuver ce bénéficiaire ?" : "Photo manquante ! Impossible d\'approuver." ?>');">
                                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                                    <input type="hidden" name="id_beneficiaire" value="<?php echo htmlspecialchars($beneficiaire['id_beneficiaire']); ?>">
                                                    <input type="hidden" name="action_type" value="approve">
                                                    <button type="submit" name="action" value="validate_beneficiaire" 
                                                            class="btn btn-approve btn-sm <?php echo !$has_valid_photo ? 'disabled' : ''; ?>"
                                                            <?= !$has_valid_photo ? 'disabled' : '' ?>>
                                                        <i class="bi bi-check-circle"></i> Approuver
                                                    </button>
                                                </form>
                                                
                                                <form method="POST" style="display: inline;" 
                                                      onsubmit="return confirm('⚠️ SUPPRESSION DÉFINITIVE !\n\nCe bénéficiaire sera EFFACÉ de la base de données.\nCette action est IRREVERSIBLE.\n\nConfirmez-vous la suppression ?');">
                                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                                    <input type="hidden" name="id_beneficiaire" value="<?php echo htmlspecialchars($beneficiaire['id_beneficiaire']); ?>">
                                                    <input type="hidden" name="action_type" value="reject">
                                                    <button type="submit" name="action" value="validate_beneficiaire" 
                                                            class="btn btn-reject btn-sm"
                                                            onclick="return confirm('SUPPRESSION DÉFINITIVE CONFIRMÉE ?');">
                                                        <i class="bi bi-trash"></i> Rejeter & Supprimer
                                                    </button>
                                                </form>
                                            </div>
                                            <?php if (!$has_valid_photo): ?>
                                                <small class="text-danger d-block mt-1">❌ Photo requise pour approbation</small>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <?php if (!empty($beneficiaires)): ?>
                <div class="validate-all-container">
                    <form method="POST" onsubmit="return confirm('✅ Approuver TOUS les bénéficiaires AVEC PHOTO VALIDE ?\n\nLes bénéficiaires sans photo ne seront PAS approuvés.');">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                        <button type="submit" name="action" value="validate_all" class="btn btn-success btn-lg">
                            <i class="bi bi-check-all me-2"></i>✅ Valider Tous avec Photo (<?php echo count($beneficiaires); ?>)
                        </button>
                    </form>
                    <small class="text-muted d-block mt-2">* Ne valide que les bénéficiaires avec photo valide</small>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Double confirmation pour suppression
        document.querySelectorAll('.btn-reject').forEach(btn => {
            btn.addEventListener('click', function(e) {
                if (!confirm('⚠️ SUPPRESSION DÉFINITIVE !\n\nCette action va EFFACER le bénéficiaire de la base.\nIRREVERSIBLE !\n\nConfirmez-vous ?')) {
                    e.preventDefault();
                    e.stopPropagation();
                    return false;
                }
                if (!confirm('DERNIÈRE CONFIRMATION :\n\nLe bénéficiaire sera SUPPRIMÉ DÉFINITIVEMENT.\n\nAppuyez OK pour continuer.')) {
                    e.preventDefault();
                    e.stopPropagation();
                    return false;
                }
            });
        });
    </script>
</body>
</html>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>