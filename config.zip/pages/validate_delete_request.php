<?php
// pages/validate_delete_request.php
require_once '../includes/header.php';
checkRole('directeur_departmental');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['approve']) || isset($_POST['reject']))) {
    if (!verifyCsrfToken($_POST['csrf_token'])) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
    } else {
        $id_demande = intval($_POST['id_demande']);
        $action = isset($_POST['approve']) ? 'approuvee' : 'rejetee';

        // Verify the request belongs to the department
        $stmt = $pdo->prepare("
            SELECT ds.id_demande
            FROM demandes_suppression ds
            JOIN adhesions a ON ds.id_adhesion = a.id_adhesion
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
            JOIN utilisateurs agent ON ds.id_agent = agent.id_utilisateur
            WHERE ds.id_demande = ? AND agent.departement = ? AND agent.role = 'agent_mobilisateur'
        ");
        $stmt->execute([$id_demande, $_SESSION['departement']]);
        if (!$stmt->fetch()) {
            $errors[] = "Demande non trouvée ou accès non autorisé.";
        } else {
            try {
                $pdo->beginTransaction();
                $stmt = $pdo->prepare("UPDATE demandes_suppression SET statut = ? WHERE id_demande = ?");
                $stmt->execute([$action, $id_demande]);

                if ($action === 'approuvee') {
                    $stmt = $pdo->prepare("
                        UPDATE adhesions a
                        JOIN demandes_suppression ds ON a.id_adhesion = ds.id_adhesion
                        SET a.statut = 'supprimee'
                        WHERE ds.id_demande = ?
                    ");
                    $stmt->execute([$id_demande]);
                }

                // Log activity
                $stmt = $pdo->prepare("INSERT INTO logs_activites (id_utilisateur, action, details) VALUES (?, ?, ?)");
                $stmt->execute([$_SESSION['user_id'], $action === 'approuvee' ? 'approve_deletion' : 'reject_deletion', "Demande $id_demande $action"]);

                $pdo->commit();
                $success = "Demande $action avec succès.";
                header("Location: dashboard_directeur.php");
                exit();
            } catch (PDOException $e) {
                $pdo->rollBack();
                $errors[] = "Erreur lors du traitement : " . $e->getMessage();
            }
        }
    }
}
?>

<h2 class="mb-4 text-center"><i class="bi bi-trash"></i> Valider les Demandes de Suppression</h2>

<?php if ($success): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($success); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php if ($errors): ?>
    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<!-- Re-use the table from dashboard_directeur.php for consistency -->
<div class="card">
    <div class="card-header bg-primary text-white"><i class="bi bi-trash"></i> Demandes de Suppression en Attente</div>
    <div class="card-body">
        <?php
        $stmt_demandes = $pdo->prepare("
            SELECT ds.id_demande, ds.id_adhesion, ds.date_demande, ds.raison, a.num_adherent, u.nom, u.prenom, ua.nom as agent_nom, ua.prenom as agent_prenom 
            FROM demandes_suppression ds 
            JOIN adhesions a ON ds.id_adhesion = a.id_adhesion 
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
            JOIN utilisateurs ua ON ds.id_agent = ua.id_utilisateur 
            WHERE ua.departement = ? AND ua.role = 'agent_mobilisateur' AND ds.statut = 'en_attente'
            ORDER BY ds.date_demande DESC
        ");
        $stmt_demandes->execute([$_SESSION['departement']]);
        $demandes = $stmt_demandes->fetchAll(PDO::FETCH_ASSOC);
        ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID Demande</th>
                    <th>Numéro Adhérent</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Agent</th>
                    <th>Date Demande</th>
                    <th>Raison</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($demandes)): ?>
                    <tr><td colspan="8" class="text-center">Aucune demande en attente.</td></tr>
                <?php else: ?>
                    <?php foreach ($demandes as $demande): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($demande['id_demande']); ?></td>
                            <td><?php echo htmlspecialchars($demande['num_adherent']); ?></td>
                            <td><?php echo htmlspecialchars($demande['nom']); ?></td>
                            <td><?php echo htmlspecialchars($demande['prenom']); ?></td>
                            <td><?php echo htmlspecialchars($demande['agent_nom'] . ' ' . $demande['agent_prenom']); ?></td>
                            <td><?php echo htmlspecialchars($demande['date_demande']); ?></td>
                            <td><?php echo htmlspecialchars($demande['raison']); ?></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                    <input type="hidden" name="id_demande" value="<?php echo htmlspecialchars($demande['id_demande']); ?>">
                                    <button type="submit" name="approve" class="btn btn-success btn-sm" onclick="return confirm('Confirmer l\'approbation de la suppression ?');"><i class="bi bi-check"></i> Approuver</button>
                                    <button type="submit" name="reject" class="btn btn-danger btn-sm" onclick="return confirm('Confirmer le rejet de la suppression ?');"><i class="bi bi-x"></i> Rejeter</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php require_once '../includes/footer.php'; ?>