<?php
// pages/validate_referencement.php
ob_start();
require_once '../includes/header.php';
checkRole('directeur_departemental');

$errors = [];
$success = '';
$csrf_token = generateCsrfToken();

// === RÉCUPÉRER LE DÉPARTEMENT DU DIRECTEUR ===
$id_departement = null;
try {
    $stmt = $pdo->prepare("SELECT departement FROM utilisateurs WHERE id_utilisateur = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $id_departement = $stmt->fetchColumn();
} catch (Exception $e) {
    $errors[] = "Erreur système.";
}
if (!$id_departement) {
    $errors[] = "Compte non rattaché à un département.";
}

// === CHARGER RÉFÉRENCEMENTS EN ATTENTE ===
$referencements = [];
if (empty($errors)) {
    try {
        $stmt = $pdo->prepare("
            SELECT r.id_referencement, r.date_referencement, r.referencement AS fichier,
                   b.code_beneficiaire, b.nom AS nom_benef, b.prenom AS prenom_benef,
                   ps.nom AS source_nom, pd.nom AS dest_nom
            FROM notes_referencement r
            JOIN beneficiaires b ON r.id_beneficiaire = b.id_beneficiaire
            JOIN prestataires ps ON r.id_prestataire_source = ps.id_prestataire
            JOIN prestataires pd ON r.id_prestataire_destinataire = pd.id_prestataire
            JOIN utilisateurs u ON pd.id_utilisateur = u.id_utilisateur
            WHERE u.departement = ? 
              AND r.statut = 'en_attente_approbation'
            ORDER BY r.date_referencement DESC
        ");
        $stmt->execute([$id_departement]);
        $referencements = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $errors[] = "Erreur chargement.";
    }
}

// === CHARGER RÉFÉRENCEMENT SÉLECTIONNÉ ===
$id_ref = intval($_GET['id'] ?? 0);
$ref = null;

if ($id_ref > 0 && empty($errors)) {
    try {
        $stmt = $pdo->prepare("
            SELECT r.*, 
                   b.code_beneficiaire, b.nom AS nom_benef, b.prenom AS prenom_benef,
                   ps.nom AS source_nom, 
                   pd.nom AS dest_nom
            FROM notes_referencement r
            JOIN beneficiaires b ON r.id_beneficiaire = b.id_beneficiaire
            JOIN prestataires ps ON r.id_prestataire_source = ps.id_prestataire
            JOIN prestataires pd ON r.id_prestataire_destinataire = pd.id_prestataire
            JOIN utilisateurs u ON pd.id_utilisateur = u.id_utilisateur
            WHERE r.id_referencement = ? 
              AND u.departement = ? 
              AND r.statut = 'en_attente_approbation'
        ");
        $stmt->execute([$id_ref, $id_departement]);
        $ref = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$ref) {
            $errors[] = "Référencement non trouvé ou déjà traité.";
        }
    } catch (Exception $e) {
        $errors[] = "Erreur chargement.";
    }
}

// === TRAITEMENT : APPROUVER / REJETER ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrfToken($_POST['token'] ?? '') && $ref) {
    $action = $_POST['action'] ?? '';
    $commentaire = trim($_POST['commentaire'] ?? '');

    if (!in_array($action, ['approuve', 'rejete'])) {
        $errors[] = "Action invalide.";
    }
    if (empty($commentaire)) {
        $errors[] = "Commentaire obligatoire.";
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            $statut = $action === 'approuve' ? 'approuve' : 'rejete';
            $approved_by = $action === 'approuve' ? $_SESSION['user_id'] : null;

            $stmt = $pdo->prepare("
                UPDATE notes_referencement 
                SET statut = ?, 
                    approved_by = ?, 
                    commentaire = ?
                WHERE id_referencement = ? 
                  AND statut = 'en_attente_approbation'
            ");
            $stmt->execute([$statut, $approved_by, $commentaire, $id_ref]);

            if ($stmt->rowCount() > 0) {
                $pdo->commit();
                $success = "Référencement " . ($action === 'approuve' ? "approuvé" : "rejeté") . ".";
                $ref = null;
                header("Location: validate_referencement.php?success=1");
                exit;
            } else {
                $pdo->rollBack();
                $errors[] = "Aucune modification.";
            }
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Erreur : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validation Référencements</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <style>
        :root {
            --primary: #10b981; --primary-dark: #059669; --success: #22c55e; --danger: #ef4444;
            --warning: #f59e0b; --info: #0ea5e9; --light: #f8fafc; --dark: #111827; --border: #e2e8f0;
            --shadow-sm: 0 4px 12px rgba(0,0,0,0.08); --shadow-md: 0 10px 25px rgba(0,0,0,0.1);
            --shadow-lg: 0 20px 40px rgba(0,0,0,0.15); --radius: 1.25rem; --transition: all 0.3s ease;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: linear-gradient(135deg, #f0fdf4, #dcfce7); font-family: 'Inter', sans-serif; color: var(--dark); min-height: 100vh; line-height: 1.6; }

        /* HEADER */
        .header-banner { background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; padding: 2.5rem 0; position: relative; overflow: hidden; box-shadow: 0 10px 30px rgba(16,185,129,0.2); }
        .header-banner::before { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 20"><path d="M0,10 Q50,0 100,10 L100,20 L0,20 Z" fill="rgba(255,255,255,0.1)"/></svg>') center/cover; opacity: 0.3; }
        .logo-img { width: 80px; height: 80px; object-fit: contain; border-radius: 1.5rem; border: 4px solid rgba(255,255,255,0.3); box-shadow: 0 8px 20px rgba(0,0,0,0.25); transition: var(--transition); }
        .logo-img:hover { transform: scale(1.1) rotate(8deg); }
        .page-title { font-weight: 800; font-size: 2rem; letter-spacing: -0.5px; margin: 0; }
        .dept-badge { background: rgba(255,255,255,0.25); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.4); padding: 0.4rem 1rem; border-radius: 2rem; font-weight: 600; font-size: 0.85rem; }

        .main-container { max-width: 1400px; margin: 0 auto; padding: 2rem 1rem; }

        /* LISTE */
        .list-card { background: white; border-radius: var(--radius); overflow: hidden; box-shadow: var(--shadow-md); margin-bottom: 2rem; }
        .list-card .card-header { background: var(--primary); color: white; font-weight: 700; padding: 1.25rem 1.5rem; font-size: 1.1rem; border: none; }
        .table { margin: 0; font-size: 0.9rem; }
        .table th { background: var(--primary); color: white; font-weight: 600; text-transform: uppercase; font-size: 0.8rem; letter-spacing: 0.5px; padding: 1rem; border: none; }
        .table td { vertical-align: middle; padding: 0.9rem 1rem; border-color: #f1f5f9; }
        .table tr:hover { background: #f8fff9; }
        .badge-code { background: #e0f2fe; color: #0369a1; font-family: monospace; font-weight: 600; padding: 0.2rem 0.5rem; border-radius: 0.5rem; }

        /* DÉTAIL */
        .detail-card { background: white; border-radius: var(--radius); overflow: hidden; box-shadow: var(--shadow-md); }
        .detail-card .card-header { background: var(--primary); color: white; font-weight: 700; padding: 1.25rem 1.5rem; font-size: 1.1rem; }
        .info-box { background: #f8fafc; border-left: 5px solid var(--primary); padding: 1.2rem; border-radius: 12px; margin-bottom: 1rem; }
        .info-box h6 { margin: 0 0 0.5rem; font-weight: 700; color: var(--primary-dark); }
        .file-preview { max-height: 500px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .btn-action { border-radius: 12px; padding: 0.75rem 1.5rem; font-weight: 600; box-shadow: 0 4px 10px rgba(0,0,0,0.1); transition: var(--transition); }
        .btn-approve { background: var(--success); color: white; }
        .btn-reject { background: var(--danger); color: white; }
        .btn-action:hover { transform: translateY(-3px); box-shadow: 0 8px 20px rgba(0,0,0,0.15); }

        /* ALERTES */
        .alert { border-radius: var(--radius); padding: 1rem 1.5rem; box-shadow: var(--shadow-sm); border: none; animation: slideDown 0.5s ease; margin-bottom: 1.5rem; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-15px); } to { opacity: 1; transform: translateY(0); } }

        /* FOOTER */
        .footer-actions { display: flex; flex-wrap: wrap; gap: 1rem; justify-content: center; margin-top: 2rem; }
        .btn-rounded { border-radius: 2rem; padding: 0.75rem 1.75rem; font-weight: 600; }

        /* RESPONSIVE */
        @media (max-width: 768px) {
            .page-title { font-size: 1.6rem; }
            .logo-img { width: 60px; height: 60px; }
            .table { font-size: 0.8rem; }
            .table th, .table td { padding: 0.6rem; }
            .btn-action { padding: 0.6rem 1.2rem; font-size: 0.9rem; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="header-banner">
    <div class="container position-relative">
        <div class="row align-items-center g-3">
            <div class="col-3 col-md-2 text-center">
                <img src="<?= $logo_path ?? '../assets/images/logo-default.png' ?>" alt="Logo" class="logo-img" data-aos="zoom-in">
            </div>
            <div class="col-6 col-md-8 text-center">
                <h1 class="page-title" data-aos="fade-up" data-aos-delay="100">
                    Validation Référencements
                </h1>
                <p class="mb-1 opacity-90" data-aos="fade-up" data-aos-delay="150">
                    Département : <strong><?= htmlspecialchars($_SESSION['departement'] ?? 'N/A') ?></strong>
                </p>
            </div>
            <div class="col-3 col-md-2 text-end">
                <a href="dashboard_directeur.php" class="btn btn-outline-light btn-sm rounded-pill" data-aos="fade-left">
                    <i class="bi bi-arrow-left"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<div class="main-container">

    <!-- ALERTES -->
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success d-flex align-items-center" data-aos="fade-up">
            <i class="bi bi-check-circle-fill me-3 fs-5"></i>
            <div>Action effectuée avec succès !</div>
            <button class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php foreach ($errors as $e): ?>
        <div class="alert alert-danger d-flex align-items-center" data-aos="fade-up">
            <i class="bi bi-exclamation-triangle-fill me-3 fs-5"></i>
            <div><?= htmlspecialchars($e) ?></div>
            <button class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    <?php endforeach; ?>

    <!-- LISTE DES RÉFÉRENCEMENTS EN ATTENTE -->
    <?php if (!empty($referencements)): ?>
        <div class="list-card" data-aos="fade-up">
            <div class="card-header">
                <i class="bi bi-list-check me-2"></i>
                Référencements en attente (<?= count($referencements) ?>)
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Bénéficiaire</th>
                            <th>De → Vers</th>
                            <th>Document</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($referencements as $r): ?>
                            <tr>
                                <td><strong><?= date('d/m/Y', strtotime($r['date_referencement'])) ?></strong></td>
                                <td>
                                    <div class="fw-bold text-success"><?= htmlspecialchars($r['code_beneficiaire']) ?></div>
                                    <small><?= htmlspecialchars($r['nom_benef'] . ' ' . $r['prenom_benef']) ?></small>
                                </td>
                                <td>
                                    <small class="text-primary"><?= htmlspecialchars($r['source_nom']) ?></small><br>
                                    <i class="bi bi-arrow-down text-success"></i><br>
                                    <small class="fw-bold text-primary"><?= htmlspecialchars($r['dest_nom']) ?></small>
                                </td>
                                <td>
                                    <?php if ($r['fichier'] && file_exists('../' . $r['fichier'])): ?>
                                        <a href="../<?= htmlspecialchars($r['fichier']) ?>" target="_blank" class="text-success">
                                            <i class="bi bi-file-earmark-check"></i> Voir
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted"><i class="bi bi-file-x"></i> —</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="?id=<?= $r['id_referencement'] ?>" class="btn btn-warning btn-sm">
                                        <i class="bi bi-eye"></i> Valider
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php else: ?>
        <div class="text-center py-5" data-aos="fade-up">
            <i class="bi bi-inbox display-1 text-success mb-3"></i>
            <h4>Aucun référencement en attente</h4>
            <p class="text-muted">Tout est à jour !</p>
            <a href="dashboard_directeur.php" class="btn btn-success rounded-pill px-4">
                <i class="bi bi-arrow-left"></i> Tableau de bord
            </a>
        </div>
    <?php endif; ?>

    <!-- DÉTAIL + VALIDATION -->
    <?php if ($ref): ?>
        <hr class="my-5">
        <div class="detail-card" data-aos="fade-up">
            <div class="card-header text-center">
                <i class="bi bi-file-earmark-text-fill"></i>
                Détail du Référencement #<?= $ref['id_referencement'] ?>
            </div>
            <div class="card-body">
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="info-box">
                            <h6><i class="bi bi-person-badge"></i> Bénéficiaire</h6>
                            <p class="mb-0">
                                <strong><?= htmlspecialchars($ref['code_beneficiaire']) ?></strong><br>
                                <?= htmlspecialchars($ref['nom_benef'] . ' ' . $ref['prenom_benef']) ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-box">
                            <h6><i class="bi bi-arrow-repeat"></i> Transfert</h6>
                            <p class="mb-0">
                                <strong>De :</strong> <?= htmlspecialchars($ref['source_nom']) ?><br>
                                <strong>Vers :</strong> <?= htmlspecialchars($ref['dest_nom']) ?>
                            </p>
                        </div>
                    </div>
                </div>

                <!-- DOCUMENT -->
                <?php 
                $fichier_path = $ref['referencement'] ?? '';
                $full_path = '../' . $fichier_path;
                $ext = $fichier_path ? strtolower(pathinfo($fichier_path, PATHINFO_EXTENSION)) : '';
                ?>
                <?php if ($fichier_path && file_exists($full_path)): ?>
                    <div class="mt-4 text-center">
                        <h5 class="mb-3"><i class="bi bi-file-earmark-medical"></i> Document de Référencement</h5>
                        <?php if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                            <img src="../<?= htmlspecialchars($fichier_path) ?>" class="img-fluid file-preview" alt="Document">
                        <?php elseif ($ext === 'pdf'): ?>
                            <iframe src="../<?= htmlspecialchars($fichier_path) ?>" width="100%" height="600" style="border: none; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);"></iframe>
                        <?php endif; ?>
                        <div class="mt-3">
                            <a href="../<?= htmlspecialchars($fichier_path) ?>" target="_blank" class="btn btn-success btn-rounded">
                                <i class="bi bi-download"></i> Télécharger
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning text-center">
                        <i class="bi bi-exclamation-triangle"></i> Document non disponible.
                    </div>
                <?php endif; ?>

                <!-- FORMULAIRE DÉCISION -->
                <hr class="my-4">
                <form method="POST">
                    <input type="hidden" name="token" value="<?= $csrf_token ?>">
                    <div class="mb-4">
                        <label class="form-label fw-bold">
                            <i class="bi bi-chat-square-text"></i> Commentaire <span class="text-danger">*</span>
                        </label>
                        <textarea name="commentaire" class="form-control" rows="4" required 
                                  placeholder="Justifiez votre décision (obligatoire)..."></textarea>
                    </div>
                    <div class="text-center">
                        <button type="submit" name="action" value="approuve" class="btn btn-approve btn-action px-5 mx-2">
                            <i class="bi bi-check-circle-fill"></i> Approuver
                        </button>
                        <button type="submit" name="action" value="rejete" class="btn btn-reject btn-action px-5 mx-2">
                            <i class="bi bi-x-circle-fill"></i> Rejeter
                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <!-- FOOTER ACTIONS -->
    <div class="footer-actions" data-aos="fade-up">
        <a href="validate_referencement.php" class="btn btn-outline-success btn-rounded">
            <i class="bi bi-arrow-clockwise"></i> Actualiser
        </a>
        <a href="dashboard_directeur.php" class="btn btn-secondary btn-rounded">
            <i class="bi bi-arrow-left"></i> Tableau de bord
        </a>
    </div>
</div>

<!-- SCRIPTS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
    AOS.init({ duration: 600, once: true, offset: 50 });
    setTimeout(() => { document.querySelectorAll('.alert').forEach(a => new bootstrap.Alert(a).close()); }, 5000);
</script>

</body>
</html>

<?php 
ob_end_flush(); 
require_once '../includes/footer.php'; 
?>