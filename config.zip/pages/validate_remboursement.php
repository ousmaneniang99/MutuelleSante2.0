<?php
// pages/validate_remboursement.php
ob_start();
require_once '../includes/header.php';
checkRole('directeur_departemental');

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();

$dept = (int)($_SESSION['departement'] ?? 0);
$dept_name = match($dept) {
    1 => 'Matam',
    2 => 'Kanel',
    3 => 'Ranérou',
};

if ($dept === 0) {
    $errors[] = "Département invalide.";
}

// Nombre total de demandes en attente (pour badge)
$total_demandes = 0;
try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM demandes_remboursement d
        JOIN adhesions a ON d.id_adhesion = a.id_adhesion
        WHERE d.statut = 'en_attente' AND a.departement = ?
    ");
    $stmt->execute([$dept]);
    $total_demandes = $stmt->fetchColumn();
} catch (Exception $e) {
    $errors[] = "Erreur lors du comptage des demandes.";
}

// Validation groupée
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['valider_selection']) && verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    $ids = array_filter(array_map('intval', $_POST['demande'] ?? []));
    if (!empty($ids)) {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("
            UPDATE demandes_remboursement d 
            JOIN adhesions a ON d.id_adhesion = a.id_adhesion 
            SET d.statut = 'en_validation', 
                d.validated_by = ?, 
                d.date_mise_a_jour = NOW()
            WHERE d.id_demande IN ($placeholders) 
              AND d.statut = 'en_attente' 
              AND a.departement = ?
        ");
        $params = array_merge([$_SESSION['user_id']], $ids, [$dept]);
        if ($stmt->execute($params)) {
            $count = $stmt->rowCount();
            logActivity($pdo, $_SESSION['user_id'], "validation_groupée_remboursement", "Validées : $count demandes");
            $success = "$count demande(s) validée(s) avec succès !";
        } else {
            $errors[] = "Erreur lors de la validation groupée.";
        }
    } else {
        $errors[] = "Aucune demande sélectionnée.";
    }
}

// Chargement des données groupées par prestataire et mois
$donnees = [];
try {
    $stmt = $pdo->prepare("
        SELECT DISTINCT p.id_prestataire, p.nom AS prestataire, p.logo, p.telephone, p.adresse, p.statut
        FROM demandes_remboursement d
        JOIN adhesions a ON d.id_adhesion = a.id_adhesion
        JOIN prestataires p ON d.id_prestataire = p.id_prestataire
        WHERE d.statut = 'en_attente' AND a.departement = ?
        ORDER BY p.nom
    ");
    $stmt->execute([$dept]);
    $prestataires = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($prestataires as $prest) {
        $id_prest = $prest['id_prestataire'];
        $logo_path = !empty($prest['logo']) && file_exists("../{$prest['logo']}")
            ? "../{$prest['logo']}"
            : "../assets/images/logo-default.png";

        $stmt = $pdo->prepare("
            SELECT DATE_FORMAT(d.date_soin, '%Y-%m') AS mois,
                   COUNT(*) AS total,
                   SUM(d.montant_rembourse) AS total_montant
            FROM demandes_remboursement d
            JOIN adhesions a ON d.id_adhesion = a.id_adhesion
            WHERE d.statut = 'en_attente' 
              AND a.departement = ? 
              AND d.id_prestataire = ?
            GROUP BY mois
            ORDER BY mois DESC
        ");
        $stmt->execute([$dept, $id_prest]);
        $mois_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $prest_mois = [];
        foreach ($mois_list as $m) {
            $mois_key = $m['mois'];
            $date = new DateTime("$mois_key-01");
            $formatter = new IntlDateFormatter('fr_FR', IntlDateFormatter::LONG, IntlDateFormatter::NONE);
            $formatter->setPattern('MMMM yyyy');
            $mois_fr = ucfirst($formatter->format($date));

            $stmt = $pdo->prepare("
                SELECT d.id_demande, d.montant_rembourse, d.date_soin, d.pieces_jointes,
                       a.num_adherent, b.nom AS b_nom, b.prenom AS b_prenom,
                       pr.nom AS prestation
                FROM demandes_remboursement d
                JOIN adhesions a ON d.id_adhesion = a.id_adhesion
                JOIN beneficiaires b ON d.id_beneficiaire = b.id_beneficiaire
                JOIN prestations pr ON d.id_prestation = pr.id_prestation
                WHERE d.statut = 'en_attente' 
                  AND a.departement = ? 
                  AND d.id_prestataire = ? 
                  AND DATE_FORMAT(d.date_soin, '%Y-%m') = ?
                ORDER BY d.date_soin DESC
            ");
            $stmt->execute([$dept, $id_prest, $mois_key]);
            $demandes = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $prest_mois[$mois_key] = [
                'mois_fr' => $mois_fr,
                'total' => $m['total'],
                'total_montant' => $m['total_montant'],
                'demandes' => $demandes
            ];
        }

        $donnees[$id_prest] = [
            'prestataire' => $prest['prestataire'],
            'logo' => $logo_path,
            'telephone' => $prest['telephone'] ?? '—',
            'adresse' => $prest['adresse'] ?? '—',
            'statut' => $prest['statut'],
            'mois' => $prest_mois
        ];
    }
} catch (Exception $e) {
    error_log("Erreur DB validate_remboursement: " . $e->getMessage());
    $errors[] = "Erreur lors du chargement des données.";
}
?>

<!DOCTYPE html>
<html lang="fr" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validation Remboursements — <?= htmlspecialchars($dept_name) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: #1e40af;
            --primary-hover: #2563eb;
            --success: #10b981;
            --success-dark: #059669;
            --danger: #ef4444;
            --light: #f8fafc;
            --glass: rgba(255,255,255,0.15);
            --border: rgba(226,232,240,0.3);
            --shadow: 0 8px 32px rgba(0,0,0,0.12);
            --radius: 1.25rem;
        }
        body {
            background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
            font-family: 'Inter', sans-serif;
            color: #1e293b;
            min-height: 100vh;
        }
        .container { max-width: 1400px; }
        .header {
            background: linear-gradient(135deg, var(--primary), var(--primary-hover));
            color: white;
            border-radius: var(--radius);
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
        }
        .card-prest {
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(12px);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            margin-bottom: 1.5rem;
            transition: transform 0.3s ease;
        }
        .card-prest:hover { transform: translateY(-6px); }
        .prest-header {
            background: linear-gradient(135deg, var(--primary), var(--primary-hover));
            color: white;
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .prest-logo {
            width: 56px;
            height: 56px;
            object-fit: contain;
            border-radius: 12px;
            border: 3px solid white;
        }
        .month-card {
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(10px);
            border-radius: 1rem;
            margin: 1rem;
            overflow: hidden;
        }
        .month-header {
            background: rgba(255,255,255,0.4);
            padding: 0.75rem 1.25rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
        }
        .table-responsive { overflow-x: auto; }
        .table th { background: rgba(255,255,255,0.3); font-size: 0.8rem; text-transform: uppercase; }
        .btn-valider {
            background: linear-gradient(135deg, var(--success), var(--success-dark));
            color: white;
            border: none;
            padding: 0.9rem 2.5rem;
            border-radius: 3rem;
            font-weight: 700;
            box-shadow: 0 8px 24px rgba(16,185,129,0.4);
            transition: all 0.3s ease;
            min-width: 280px;
        }
        .btn-valider:hover:not(:disabled) { transform: translateY(-3px); }
        .btn-valider:disabled { opacity: 0.6; cursor: not-allowed; }
        .file-preview {
            max-width: 40px;
            max-height: 40px;
            object-fit: cover;
            border-radius: 6px;
            border: 2px solid #e2e8f0;
        }
        .file-link {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container py-4">

    <!-- Header -->
    <div class="header text-center">
        <h1 class="mb-1">
            <i class="bi bi-shield-check me-2"></i>
            Validation des Remboursements — <?= htmlspecialchars($dept_name) ?>
        </h1>
        <?php if ($total_demandes > 0): ?>
            <span class="badge bg-danger badge-total"><?= $total_demandes ?> demande(s) en attente</span>
        <?php endif; ?>
    </div>

    <!-- Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success d-flex align-items-center">
            <i class="bi bi-check-circle-fill fs-4 me-3"></i>
            <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>
    <?php foreach ($errors as $err): ?>
        <div class="alert alert-danger d-flex align-items-center">
            <i class="bi bi-exclamation-triangle-fill fs-4 me-3"></i>
            <?= htmlspecialchars($err) ?>
        </div>
    <?php endforeach; ?>

    <!-- Formulaire principal -->
    <form method="POST" id="formValidation">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
        <input type="hidden" name="valider_selection" value="1">

        <?php if (empty($donnees)): ?>
            <div class="alert alert-info text-center p-5">
                <i class="bi bi-emoji-smile fs-1"></i>
                <h5 class="mt-3">Aucune demande de remboursement en attente</h5>
            </div>
        <?php else: ?>

            <?php foreach ($donnees as $id_prest => $prest): ?>
                <div class="card-prest">
                    <div class="prest-header">
                        <img src="<?= htmlspecialchars($prest['logo']) ?>" alt="Logo" class="prest-logo">
                        <div>
                            <h5 class="mb-0"><?= htmlspecialchars($prest['prestataire']) ?></h5>
                            <small>
                                <i class="bi bi-telephone-fill"></i> <?= htmlspecialchars($prest['telephone']) ?> •
                                <span class="badge <?= $prest['statut']==='actif' ? 'bg-success' : 'bg-danger' ?>">
                                    <?= ucfirst($prest['statut']) ?>
                                </span>
                            </small>
                        </div>
                    </div>

                    <?php foreach ($prest['mois'] as $mois_key => $m): ?>
                        <div class="month-card">
                            <div class="month-header" data-bs-toggle="collapse" data-bs-target="#collapse-<?= $id_prest ?>-<?= $mois_key ?>">
                                <div class="d-flex align-items-center gap-3">
                                    <input type="checkbox" class="form-check-input select-month" 
                                           id="select-month-<?= $id_prest ?>-<?= $mois_key ?>" 
                                           data-month="<?= $id_prest ?>-<?= $mois_key ?>">
                                    <label for="select-month-<?= $id_prest ?>-<?= $mois_key ?>" class="mb-0 fw-bold">
                                        <?= htmlspecialchars($m['mois_fr']) ?> 
                                        <span class="badge bg-secondary ms-2"><?= $m['total'] ?></span>
                                    </label>
                                </div>
                                <strong class="text-success"><?= formatFCFA($m['total_montant']) ?></strong>
                            </div>

                            <div class="collapse" id="collapse-<?= $id_prest ?>-<?= $mois_key ?>">
                                <div class="p-3">
                                    <div class="table-responsive">
                                        <table class="table table-hover mb-0">
                                            <thead>
                                                <tr>
                                                    <th><input type="checkbox" disabled></th>
                                                    <th>ID</th>
                                                    <th>Adhérent</th>
                                                    <th>Bénéficiaire</th>
                                                    <th>Prestation</th>
                                                    <th>Montant</th>
                                                    <th>Date</th>
                                                    <th>Fichier</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($m['demandes'] as $d): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="demande[]" value="<?= $d['id_demande'] ?>"
                                                                   class="form-check-input demande-checkbox"
                                                                   data-montant="<?= $d['montant_rembourse'] ?>"
                                                                   data-month="<?= $id_prest ?>-<?= $mois_key ?>">
                                                        </td>
                                                        <td><strong>#<?= $d['id_demande'] ?></strong></td>
                                                        <td><?= htmlspecialchars($d['num_adherent']) ?></td>
                                                        <td><?= htmlspecialchars($d['b_nom'] . ' ' . $d['b_prenom']) ?></td>
                                                        <td><?= htmlspecialchars($d['prestation']) ?></td>
                                                        <td class="fw-bold text-success"><?= formatFCFA($d['montant_rembourse']) ?></td>
                                                        <td><?= date('d/m/Y', strtotime($d['date_soin'])) ?></td>
                                                        <td>
                                                            <?php 
                                                            // Récupération et nettoyage du chemin stocké
                                                            $db_path = trim($d['pieces_jointes'] ?? '');

                                                            // Supprime les ../ du début si présents
                                                            if (str_starts_with($db_path, '../')) {
                                                                $clean_path = substr($db_path, 3);
                                                            } else {
                                                                $clean_path = $db_path;
                                                            }

                                                            // Chemin final à utiliser depuis le dossier pages/
                                                            $display_path = "../" . $clean_path;

                                                            if ($clean_path && file_exists($display_path)):
                                                                $ext = strtolower(pathinfo($clean_path, PATHINFO_EXTENSION));
                                                                $is_image = in_array($ext, ['jpg', 'jpeg', 'png', 'gif']);
                                                            ?>
                                                                <a href="<?= htmlspecialchars($display_path) ?>" 
                                                                   target="_blank" 
                                                                   class="file-link btn btn-sm <?= $is_image ? 'btn-outline-primary' : 'btn-outline-secondary' ?>" 
                                                                   title="Ouvrir le fichier">
                                                                    <?php if ($is_image): ?>
                                                                        <img src="<?= htmlspecialchars($display_path) ?>" 
                                                                             alt="Aperçu" 
                                                                             class="file-preview" 
                                                                             loading="lazy">
                                                                    <?php else: ?>
                                                                        <i class="bi bi-file-earmark-pdf fs-4"></i>
                                                                    <?php endif; ?>
                                                                    <span class="ms-1">Voir (<?= strtoupper($ext) ?>)</span>
                                                                </a>
                                                            <?php else: ?>
                                                                <span class="text-danger small">
                                                                    <?php if ($clean_path): ?>
                                                                        Introuvable : <?= htmlspecialchars($clean_path) ?>
                                                                    <?php else: ?>
                                                                        —
                                                                    <?php endif; ?>
                                                                </span>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>

            <!-- Bouton Valider -->
            <div class="text-center my-5">
                <button type="submit" class="btn btn-valider" id="btnValider" disabled>
                    <i class="bi bi-check2-all me-2"></i>
                    Valider la sélection (<span id="selectedCount">0</span>)
                </button>
                <div class="mt-2 text-muted">
                    Montant total sélectionné : <strong id="totalMontant">0 FCFA</strong>
                </div>
            </div>

        <?php endif; ?>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const checkboxes = document.querySelectorAll('.demande-checkbox');
    const btnValider = document.getElementById('btnValider');
    const selectedCountEl = document.getElementById('selectedCount');
    const totalMontantEl = document.getElementById('totalMontant');

    function updateUI() {
        let count = 0;
        let total = 0;
        checkboxes.forEach(cb => {
            if (cb.checked) {
                count++;
                total += parseFloat(cb.dataset.montant) || 0;
            }
        });
        selectedCountEl.textContent = count;
        totalMontantEl.textContent = total.toLocaleString('fr-FR') + ' FCFA';
        btnValider.disabled = count === 0;
    }

    checkboxes.forEach(cb => cb.addEventListener('change', updateUI));

    document.querySelectorAll('.select-month').forEach(header => {
        header.addEventListener('change', function() {
            const month = this.dataset.month;
            document.querySelectorAll(`.demande-checkbox[data-month="${month}"]`)
                .forEach(cb => cb.checked = this.checked);
            updateUI();
        });
    });

    updateUI();
});
</script>

<?php
ob_end_flush();
require_once '../includes/footer.php';
?>