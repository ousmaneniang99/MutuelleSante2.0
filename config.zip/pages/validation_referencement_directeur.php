<?php
// pages/validation_referencement_directeur.php
ob_start();
require_once '../includes/header.php';
checkRole('directeur'); // Doit être directeur

$errors = [];
$success = '';
$csrf_token = generateCsrfToken();

// === RÉCUPÉRER ID_PRESTATAIRE DU DIRECTEUR ===
$id_prestataire = null;
try {
    $stmt = $pdo->prepare("SELECT id_prestataire FROM prestataires WHERE id_utilisateur = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $id_prestataire = $stmt->stmt->fetchColumn();
} catch (Exception $e) {
    $errors[] = "Erreur accès structure.";
}

if (!$id_prestataire) {
    die("Structure non configurée.");
}

// === RÉCUPÉRER LE RÉFÉRENCEMENT À VALIDER ===
$id_ref = intval($_GET['id'] ?? 0);
$referencement = null;

if ($id_ref > 0) {
    try {
        $stmt = $pdo->prepare("
            SELECT r.*, 
                   b.code_beneficiaire, b.nom AS nom_benef, b.prenom AS prenom_benef,
                   ps.nom_structure AS source_nom,
                   pd.nom_structure AS dest_nom
            FROM referencements r
            JOIN beneficiaires b ON r.id_beneficiaire = b.id_beneficiaire
            JOIN prestataires ps ON r.id_prestataire_source = ps.id_prestataire
            JOIN prestataires pd ON r.id_prestataire_destinataire = pd.id_prestataire
            WHERE r.id_referencement = ? 
              AND r.id_prestataire_destinataire = ?
              AND r.statut = 'en_attente_approbation'
        ");
        $stmt->execute([$id_ref, $id_prestataire]);
        $referencement = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$referencement) {
            $errors[] = "Référencement non trouvé ou déjà traité.";
        }
    } catch (Exception $e) {
        $errors[] = "Erreur chargement référencement.";
    }
} else {
    $errors[] = "ID invalide.";
}

// === TRAITEMENT VALIDATION ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrfToken($_POST['token'] ?? '') && $referencement) {
    $action = $_POST['action'] ?? '';
    $commentaire = trim($_POST['commentaire'] ?? '');

    if (!in_array($action, ['approuve', 'rejete'])) {
        $errors[] = "Action invalide.";
    }

    if (empty($commentaire)) {
        $errors[] = "Commentaire obligatoire.";
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            $statut = $action === 'approuve' ? 'approuve' : 'rejete';
            $stmt = $pdo->prepare("
                UPDATE referencements 
                SET statut = ?, 
                    approved_by = ?, 
                    commentaire = ?, 
                    date_validation = CURDATE()
                WHERE id_referencement = ? 
                  AND id_prestataire_destinataire = ?
                  AND statut = 'en_attente_approbation'
            ");
            $stmt->execute([$statut, $_SESSION['user_id'], $commentaire, $id_ref, $id_prestataire]);

            if ($stmt->rowCount() > 0) {
                $pdo->commit();
                $success = "Référencement " . ($action === 'approuve' ? "approuvé" : "rejeté") . " avec succès.";
                $referencement = null; // Masquer le formulaire après validation
            } else {
                $pdo->rollBack();
                $errors[] = "Échec de la mise à jour.";
            }
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Erreur : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validation Référencement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #dc2626;
            --primary-dark: #b91c1c;
            --light: #f9fafb;
            --dark: #111827;
            --gray: #6b7280;
            --success: #10b981;
            --danger: #ef4444;
            --border: #e5e7eb;
            --warning: #f59e0b;
        }
        * { box-sizing: border-box; }
        body {
            background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
            font-family: 'Inter', sans-serif;
            color: var(--dark);
            min-height: 100vh;
            margin: 0;
        }

        /* Header */
        .header-banner {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            padding: 2.5rem 0;
            border-bottom: 6px solid #991b1b;
            box-shadow: 0 10px 20px rgba(220, 38, 38, 0.2);
            position: relative;
            overflow: hidden;
        }
        .header-banner::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><polygon fill="rgba(255,255,255,0.05)" points="0,100 100,0 100,100"/></svg>') no-repeat;
            background-size: cover;
        }
        .logo-img {
            width: 80px; height: 80px;
            object-fit: contain;
            border-radius: 16px;
            border: 4px solid rgba(255,255,255,0.3);
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            transition: transform 0.3s ease;
        }
        .logo-img:hover { transform: scale(1.05); }
        .page-title { font-size: 2rem; font-weight: 700; margin: 0; }
        .page-subtitle { font  font-size: 1.1rem; opacity: 0.95; margin: 0.5rem 0 0; }

        /* Card */
        .card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 12px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            background: white;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card:hover { transform: translateY(-5px); box-shadow: 0 20px 40px rgba(0,0,0,0.15); }

        /* Info Box */
        .info-box {
            background: #f8f9fa;
            border-left: 5px solid var(--primary);
            padding: 1rem 1.5rem;
            border-radius: 0 12px 12px 0;
            margin-bottom: 1.5rem;
        }

        /* Buttons */
        .btn-action {
            border-radius: 12px;
            font-weight: 600;
            padding: 0.75rem 1.5rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            min-width: 140px;
        }
        .btn-approve {
            background: linear-gradient(135deg, var(--success), #059669);
            color: white;
            border: none;
        }
        .btn-approve:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(16,185,129,0.4); }
        .btn-reject {
            background: linear-gradient(135deg, var(--danger), #dc2626);
            color: white;
            border: none;
        }
        .btn-reject:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(239,68,68,0.4); }

        /* Alerts */
        .alert {
            border: none;
            border-radius: 12px;
            padding: 1rem 1.5rem;
            margin-bottom: 1.5rem;
            font-weight: 500;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            animation: slideDown 0.4s ease;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .page-title { font-size: 1.6rem; }
            .logo-img { width: 60px; height: 60px; }
        }
    </style>
</head>
<body>

<!-- Header -->
<div class of="header-banner">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-2 text-center">
                <img src="<?= $logo_path ?? '../assets/images/logo-default.png' ?>" alt="Logo" class="logo-img">
            </div>
            <div class="col-8 text-center">
                <h1 class="page-title mb-0">Validation Référencement</h1>
                <p class="page-subtitle">Décision du directeur</p>
            </div>
            <div class="col-2 text-end">
                <a href="list_referencements_directeur.php" class="btn btn-light btn-sm">
                    <i class="bi bi-list-ul"></i> Liste
                </a>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">

    <?php if ($success): ?>
        <div class="alert alert-success d-flex align-items-center">
            <i class="bi bi-check-circle-fill me-2 fs-5"></i>
            <?= htmlspecialchars($success) ?>
            <button class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php foreach ($errors as $e): ?>
        <div class="alert alert-danger d-flex align-items-center">
            <i class="bi bi-exclamation-triangle-fill me-2 fs-5"></i>
            <?= htmlspecialchars($e) ?>
            <button class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    <?php endforeach; ?>

    <?php if ($referencement): ?>
        <!-- Détails du référencement -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="info-box">
                    <h5><i class="bi bi-person-fill"></i> Bénéficiaire</h5>
                    <p class="mb-0"><strong><?= htmlspecialchars($referencement['code_beneficiaire']) ?></strong> - <?= htmlspecialchars($referencement['nom_benef'] . ' ' . $referencement['prenom_benef']) ?></p>
                </div>
                <div class="info-box">
                    <h5><i class="bi bi-arrow-right-circle-fill"></i> Transfert</h5>
                    <p class="mb-0"><strong>De :</strong> <?= htmlspecialchars($referencement['source_nom']) ?><br>
                       <strong>Vers :</strong> <?= htmlspecialchars($referencement['dest_nom']) ?></p>
                </div>
                <div class="info-box">
                    <h5><i class="bi bi-calendar-event"></i> Date</h5>
                    <p class="mb-0"><?= htmlspecialchars($referencement['date_referencement']) ?></p>
                </div>
                <div class="info-box">
                    <h5><i class="bi bi-chat-left-text-fill"></i> Motif</h5>
                    <p class="mb-0"><?= nl2br(htmlspecialchars($referencement['raison'])) ?></p>
                </div>
            </div>
        </div>

        <!-- Formulaire de validation -->
        <div class="card">
            <div class="card-header text-center bg-primary text-white">
                <i class="bi bi-check2-all"></i> Votre décision
            </div>
            <div class="card-body p-4">
                <form method="POST">
                    <input type="hidden" name="token" value="<?= $csrf_token ?>">
                    <div class="mb-4">
                        <label class="form-label fw-bold">
                            <i class="bi bi-chat-square-text-fill"></i> Commentaire <span class="text-danger">*</span>
                        </label>
                        <textarea name="commentaire" class="form-control" rows="4" required 
                                  placeholder="Justifiez votre décision (ex: patient pris en charge, besoin d'examens spécialisés, etc.)..."></textarea>
                    </div>

                    <div class="d-flex gap-3 justify-content-center flex-wrap">
                        <button type="submit" name="action" value="approuve" class="btn btn-action btn-approve">
                            <i class="bi bi-check-circle-fill"></i> Approuver
                        </button>
                        <button type="submit" name="action" value="rejete" class="btn btn-action btn-reject">
                            <i class="bi bi-x-circle-fill"></i> Rejeter
                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="bi bi-check2-all display-1 text-muted"></i>
            <p class="lead mt-3">Aucun référencement en attente ou déjà traité.</p>
            <a href="list_referencements_directeur.php" class="btn btn-primary">Retour à la liste</a>
        </div>
    <?php endif; ?>

    <div class="text-center mt-4">
        <a href="dashboard_directeur.php" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Retour
        </a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php ob_end_flush(); require_once '../includes/footer.php'; ?>