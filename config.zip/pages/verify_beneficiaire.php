<?php
// pages/verify_beneficiaire.php
require_once '../includes/header.php';
checkRole('prestataire_soins');

$errors = [];
$result = null;
$csrf_token = generateCsrfToken();
$today = date('Y-m-d');

// === INFOS PRESTATAIRE ===
$stmt = $pdo->prepare("
    SELECT p.id_prestataire, p.nom AS nom_prestataire, p.logo, n.niveau 
    FROM prestataires p 
    JOIN niveau n ON p.id_niveau = n.id_niveau 
    WHERE p.id_utilisateur = ?
");
$stmt->execute([$_SESSION['user_id']]);
$prestataire = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$prestataire) {
    $errors[] = "Profil prestataire incomplet.";
    $niveau = 'Standard';
    $id_prestataire = null;
} else {
    $niveau = $prestataire['niveau'];
    $id_prestataire = $prestataire['id_prestataire'];
    $logo_path = !empty($prestataire['logo']) && file_exists("../" . $prestataire['logo'])
        ? "../" . $prestataire['logo']
        : "../assets/images/logo-default.png";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Token de sécurité invalide.";
    } else {
        $identifier = trim($_POST['identifier'] ?? '');
        if (empty($identifier)) {
            $errors[] = "Veuillez entrer un code ou numéro de carte.";
        } else {
            try {
                $stmt = $pdo->prepare("
                    SELECT 
                        b.id_beneficiaire, b.nom, b.prenom, b.code_beneficiaire, b.statut AS b_statut, b.date_sortie, b.date_entree,
                        a.id_adhesion, a.num_adherent,
                        u.numero_carte_identite
                    FROM beneficiaires b
                    JOIN adhesions a ON b.id_adhesion = a.id_adhesion
                    JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                    WHERE b.code_beneficiaire = ? OR u.numero_carte_identite = ?
                ");
                $stmt->execute([$identifier, $identifier]);
                $beneficiaire = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$beneficiaire) {
                    $errors[] = "Bénéficiaire non trouvé.";
                } else {
                    $is_eligibile = true;
                    $messages = [];

                    // 1. Bénéficiaire actif
                    if ($beneficiaire['b_statut'] !== 'actif') {
                        $is_eligibile = false;
                        $messages[] = "Bénéficiaire inactif.";
                    }

                    // 2. Date de sortie non dépassée
                    if ($beneficiaire['date_sortie'] && $beneficiaire['date_sortie'] <= $today) {
                        $is_eligibile = false;
                        $messages[] = "Date de sortie dépassée (expiré).";
                    }

                    // 3. Période d'observation (adhésion depuis au moins 1 mois)
                    $date_un_mois = date('Y-m-d', strtotime('-1 month'));
                    if ($beneficiaire['date_entree'] > $date_un_mois) {
                        $is_eligibile = false;
                        $messages[] = "Période d'observation (moins d'un mois).";
                    }

                    // 4. Cotisation à jour
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*) 
                        FROM paiements 
                        WHERE id_adhesion = ? 
                          AND statut = 'paye' 
                          AND date_paiement >= DATE_SUB(?, INTERVAL 12 MONTH)
                    ");
                    $stmt->execute([$beneficiaire['id_adhesion'], $today]);
                    $has_payment = $stmt->fetchColumn();

                    if (!$has_payment) {
                        $is_eligibile = false;
                        $messages[] = "Cotisation non à jour.";
                    }

                    // 5. Hôpital : Référencement valide
                    if ($niveau === 'Hôpital' && $is_eligibile) {
                        $stmt = $pdo->prepare("
                            SELECT id_referencement 
                            FROM notes_referencement 
                            WHERE id_beneficiaire = ? 
                              AND id_prestataire_destinataire = ? 
                              AND statut = 'approuve' 
                              AND consulte = 0
                        ");
                        $stmt->execute([$beneficiaire['id_beneficiaire'], $id_prestataire]);
                        $ref_valide = $stmt->fetchColumn();

                        if (!$ref_valide) {
                            $is_eligibile = false;
                            $messages[] = "Aucun référencement valide ou déjà utilisé.";
                        }
                    }

                    // === RÉSULTAT FINAL ===
                    if ($is_eligibile) {
                        $result = [
                            'id_adhesion' => $beneficiaire['id_adhesion'],
                            'id_beneficiaire' => $beneficiaire['id_beneficiaire'],
                            'nom' => $beneficiaire['nom'],
                            'prenom' => $beneficiaire['prenom'],
                            'code_beneficiaire' => $beneficiaire['code_beneficiaire'],
                            'num_adherent' => $beneficiaire['num_adherent'],
                            'statut' => 'Éligible',
                            'message' => 'Le bénéficiaire est éligible aux soins.'
                        ];
                        logActivity($pdo, $_SESSION['user_id'], "Vérification OK : {$beneficiaire['code_beneficiaire']}");
                    } else {
                        $errors = array_merge($errors, $messages);
                        logActivity($pdo, $_SESSION['user_id'], "Vérification KO : {$beneficiaire['code_beneficiaire']} – " . implode(' | ', $messages));
                    }
                }
            } catch (Exception $e) {
                $errors[] = "Erreur système. Réessayez.";
                error_log("verify_beneficiaire.php: " . $e->getMessage());
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#1e40af">
    <title>Vérification Éligibilité</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <!-- Scanner -->
    <script src="https://cdn.jsdelivr.net/npm/quagga@0.12.1/dist/quagga.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js"></script>
    <link rel="manifest" href="manifest.json">
    <style>
        :root {
            --primary: #1e40af;
            --primary-glow: #3b82f6;
            --success: #10b981;
            --success-glow: #34d399;
            --warning: #f59e0b;
            --danger: #ef4444;
            --dark: #0f172a;
            --light: #f8fafc;
            --glass: rgba(255, 255, 255, 0.1);
            --glass-dark: rgba(15, 23, 42, 0.7);
            --border: rgba(255, 255, 255, 0.15);
            --radius: 1.8rem;
            --transition: all 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
            --glow: 0 0 20px rgba(59, 130, 246, 0.4);
        }

        [data-theme="light"] {
            --dark: #f8fafc;
            --light: #0f172a;
            --glass: rgba(255, 255, 255, 0.8);
            --border: rgba(0, 0, 0, 0.1);
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --primary-glow: #2563eb;
            --success-glow: #059669;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            font-family: 'Space Grotesk', sans-serif;
            color: var(--text-primary, #1e293b);
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: radial-gradient(circle at 20% 80%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(16, 185, 129, 0.1) 0%, transparent 50%);
            pointer-events: none;
            z-index: -1;
        }

        .container { max-width: 780px; margin: 2rem auto; padding: 0 1rem; }

        /* HEADER */
        .header {
            background: linear-gradient(135deg, rgba(30, 64, 175, 0.95), rgba(59, 130, 246, 0.95));
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            color: white;
            padding: 2.5rem 0;
            margin-bottom: 2.5rem;
            border-radius: 0 0 var(--radius) var(--radius);
            box-shadow: 0 20px 40px rgba(0,0,0,0.1), var(--glow);
            position: relative;
            overflow: hidden;
        }

        .header::after {
            content: '';
            position: absolute;
            top: -50%; left: -50%;
            width: 200%; height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: pulse 8s infinite;
            pointer-events: none;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.5; }
            50% { transform: scale(1.3); opacity: 0.8; }
        }

        .logo {
            width: 72px; height: 72px;
            object-fit: cover;
            border-radius: 20px;
            border: 4px solid rgba(255,255,255,0.4);
            box-shadow: 0 12px 30px rgba(0,0,0,0.1), 0 0 20px rgba(59,130,246,0.3);
            transition: var(--transition);
        }

        .logo:hover { transform: rotate(8deg) scale(1.1); }

        .page-title {
            font-size: 2.3rem;
            font-weight: 800;
            margin: 0;
            text-shadow: 0 4px 10px rgba(0,0,0,0.1);
            letter-spacing: -0.5px;
        }

        .hospital-badge {
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            color: white;
            font-size: 0.85rem;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-weight: 700;
            box-shadow: 0 4px 15px rgba(139,92,246,0.2);
        }

        /* GLASS CARD */
        .glass-card {
            background: var(--glass);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1.5px solid var(--border);
            border-radius: var(--radius);
            box-shadow: 0 15px 35px rgba(0,0,0,0.05), var(--glow);
            padding: 2rem;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .glass-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: linear-gradient(135deg, rgba(255,255,255,0.1), transparent);
            pointer-events: none;
        }

        .glass-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 25px 50px rgba(0,0,0,0.08), 0 0 30px rgba(59,130,246,0.2);
        }

        /* INPUT */
        .form-control {
            background: rgba(255,255,255,0.8);
            border: 1.5px solid rgba(0,0,0,0.1);
            border-radius: 16px;
            padding: 1rem 1.4rem;
            font-size: 1.1rem;
            color: var(--text-primary, #1e293b);
            transition: var(--transition);
            box-shadow: inset 0 2px 8px rgba(0,0,0,0.05);
        }

        .form-control::placeholder { color: rgba(0,0,0,0.4); }
        .form-control:focus {
            border-color: var(--primary-glow);
            box-shadow: 0 0 0 4px rgba(59,130,246,0.1), inset 0 2px 8px rgba(0,0,0,0.05);
            background: rgba(255,255,255,0.95);
        }

        /* BTN */
        .btn {
            border-radius: 16px;
            padding: 0.9rem 2.2rem;
            font-weight: 700;
            font-size: 1.05rem;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            box-shadow: 0 8px 20px rgba(0,0,0,0.08);
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 50%; left: 50%;
            width: 0; height: 0;
            background: rgba(255,255,255,0.3);
            border-radius: 50%;
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }

        .btn:active::before {
            width: 300px; height: 300px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-glow));
            color: white;
            border: none;
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(30,64,175,0.2), var(--glow);
        }

        .btn-success {
            background: linear-gradient(135deg, var(--success), var(--success-glow));
            color: white;
            border: none;
        }

        .btn-success:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(16,185,129,0.2), 0 0 25px rgba(16,185,129,0.2);
        }

        .btn-scan {
            width: 64px; height: 64px;
            border-radius: 50%;
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 8px 25px rgba(16,185,129,0.2), 0 0 20px rgba(16,185,129,0.3);
            transition: var(--transition);
        }

        .btn-scan:hover {
            transform: scale(1.15) rotate(15deg);
            box-shadow: 0 12px 35px rgba(16,185,129,0.3), 0 0 30px rgba(16,185,129,0.5);
        }

        /* RESULT CARD */
        .result-card {
            background: rgba(255,255,255,0.8);
            backdrop-filter: blur(16px);
            border-left: 6px solid var(--success-glow);
            border-radius: 18px;
            padding: 2rem;
            box-shadow: 0 15px 35px rgba(0,0,0,0.05), 0 0 25px rgba(16,185,129,0.1);
            transition: var(--transition);
        }

        .result-card:hover {
            transform: translateY(-5px);
        }

        .badge-eligible {
            background: linear-gradient(135deg, var(--success), var(--success-glow));
            color: white;
            padding: 0.6rem 1.4rem;
            border-radius: 50px;
            font-weight: 700;
            font-size: 0.95rem;
            box-shadow: 0 6px 20px rgba(16,185,129,0.2);
            animation: pulse-badge 2s infinite;
        }

        @keyframes pulse-badge {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        /* SCANNER */
        #scanner-video {
            width: 100%;
            max-height: 70vh;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        }

        .scan-frame {
            position: absolute;
            top: 50%; left: 50%;
            width: 280px; height: 280px;
            transform: translate(-50%, -50%);
            border: 4px solid #10b981;
            border-radius: 24px;
            box-shadow: 0 0 0 9999px rgba(0,0,0,0.3), 0 0 30px rgba(16,185,129,0.4);
            animation: scan-glow 2s infinite;
        }

        @keyframes scan-glow {
            0%, 100% { box-shadow: 0 0 0 9999px rgba(0,0,0,0.3), 0 0 30px rgba(16,185,129,0.4); }
            50% { box-shadow: 0 0 0 9999px rgba(0,0,0,0.4), 0 0 50px rgba(16,185,129,0.6); }
        }

        .scan-line {
            position: absolute;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, transparent, #10b981, transparent);
            box-shadow: 0 0 15px #10b981;
            animation: scan 1.6s infinite;
            pointer-events: none;
            top: 50%;
        }

        /* THEME TOGGLE */
        .theme-toggle {
            background: rgba(255,255,255,0.8);
            border: 1.5px solid rgba(0,0,0,0.1);
            color: var(--text-primary, #1e293b);
            width: 52px; height: 52px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            transition: var(--transition);
            backdrop-filter: blur(10px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.05);
        }

        .theme-toggle:hover {
            background: rgba(255,255,255,0.95);
            transform: rotate(360deg);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1), 0 0 20px rgba(0,0,0,0.1);
        }

        @media (max-width: 768px) {
            .page-title { font-size: 1.8rem; }
            .glass-card { padding: 1.5rem; }
            .btn { width: 100%; margin: 0.5rem 0; }
            .scan-frame { width: 220px; height: 220px; }
        }
    </style>
</head>
<body data-theme="light">

<!-- HEADER -->
<div class="header">
    <div class="container position-relative">
        <div class="row align-items-center">
            <div class="col-md-8 d-flex align-items-center gap-4">
                <img src="<?= $logo_path ?>" alt="Logo" class="logo" data-aos="zoom-in">
                <div data-aos="fade-up" data-aos-delay="100">
                    <h1 class="page-title">
                        Vérification d'Éligibilité
                        <?php if ($niveau === 'Hôpital'): ?>
                            <span class="hospital-badge ms-2">Hôpital</span>
                        <?php endif; ?>
                    </h1>
                </div>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-md-0">
                <button class="theme-toggle" id="theme-toggle" data-aos="fade-left" data-aos-delay="200">
                    <i class="bi bi-moon-stars-fill"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<div class="container">

    <!-- ERREURS -->
    <?php foreach ($errors as $e): ?>
        <div class="alert alert-danger glass-card mb-3" data-aos="fade-up">
            <i class="bi bi-x-octagon-fill"></i> <?= htmlspecialchars($e) ?>
        </div>
    <?php endforeach; ?>

    <!-- RÉSULTAT -->
    <?php if ($result): ?>
        <div class="alert alert-success glass-card mb-4" data-aos="fade-up">
            <i class="bi bi-shield-check"></i> <?= htmlspecialchars($result['message']) ?>
        </div>

        <div class="result-card mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="mb-0 fw-bold" style="color: var(--text-primary, #1e293b);">Bénéficiaire Éligible</h5>
                <span class="badge-eligible">Validé</span>
            </div>
            <div class="result-item" style="color: var(--text-primary, #1e293b);">
                <strong>Nom complet :</strong>
                <span><?= htmlspecialchars("{$result['nom']} {$result['prenom']}") ?></span>
            </div>
            <div class="result-item" style="color: var(--text-primary, #1e293b);">
                <strong>Code :</strong>
                <code class="bg-white text-dark px-3 py-1 rounded"><?= htmlspecialchars($result['code_beneficiaire']) ?></code>
            </div>
            <div class="result-item" style="color: var(--text-primary, #1e293b);">
                <strong>Adhérent :</strong>
                <span><?= htmlspecialchars($result['num_adherent']) ?></span>
            </div>
        </div>

        <div class="text-center" data-aos="fade-up" data-aos-delay="200">
            <a href="register_prestation.php?num_beneficiaire=<?= urlencode($result['code_beneficiaire']) ?>&id_adhesion=<?= $result['id_adhesion'] ?>" 
               class="btn btn-success btn-lg">
                <i class="bi bi-clipboard-plus-fill"></i> Enregistrer une Prestation
            </a>
        </div>
    <?php endif; ?>

    <!-- FORMULAIRE -->
    <div class="glass-card mt-5" data-aos="fade-up" data-aos-delay="300">
        <h5 class="mb-4 fw-bold text-center" style="color: var(--text-primary, #1e293b);">
            <i class="bi bi-fingerprint"></i> Scanner ou Saisir
        </h5>
        <form method="POST" id="verifyForm">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
            <div class="mb-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <label class="form-label fw-semibold" style="color: var(--text-primary, #1e293b);">
                        Code Bénéficiaire ou Carte d'Identité
                    </label>
                    <button type="button" class="btn btn-scan" data-bs-toggle="modal" data-bs-target="#scannerModal">
                        <i class="bi bi-qr-code-scan"></i>
                    </button>
                </div>
                <input type="text" class="form-control form-control-lg" name="identifier" id="identifier-input"
                       placeholder="Scannez ou saisissez..." 
                       value="<?= htmlspecialchars($_POST['identifier'] ?? '') ?>" required>
                <small class="text-success mt-2 d-block" id="scan-success" style="display:none;">
                    <i class="bi bi-check-circle-fill"></i> Code scanné avec succès
                </small>
            </div>
            <div class="d-flex flex-column flex-md-row gap-3">
                <a href="dashboard_prestataire.php" class="btn btn-outline-secondary flex-fill">
                    <i class="bi bi-arrow-left"></i> Retour
                </a>
                <button type="submit" name="verify" class="btn btn-primary flex-fill">
                    <i class="bi bi-shield-check"></i> Vérifier
                </button>
            </div>
        </form>
    </div>

    <!-- INFO HÔPITAL -->
    <?php if ($niveau === 'Hôpital'): ?>
    <div class="glass-card mt-4 p-3 text-center" data-aos="fade-up" data-aos-delay="400" style="color: var(--text-primary, #1e293b);">
        <i class="bi bi-hospital"></i>
        <strong>Hôpital :</strong> Référencement valide requis.
    </div>
    <?php endif; ?>

</div>

<!-- MODAL SCANNER -->
<div class="modal fade" id="scannerModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
        <div class="modal-content border-0 rounded-4 overflow-hidden" style="background: var(--light, #f8fafc);">
            <div class="modal-header bg-gradient text-white" style="background: linear-gradient(135deg, #10b981, #059669);">
                <h5 class="modal-title">Scanner le Code</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center position-relative p-0">
                <video id="scanner-video" autoplay playsinline></video>
                <div class="scan-frame"></div>
                <div class="scan-line"></div>
                <p class="text-white position-absolute bottom-0 start-50 translate-middle-x mb-4 fw-bold">
                    Placez le code dans le cadre
                </p>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
    AOS.init({ duration: 900, once: true });

    // === SCANNER ===
    let scannerStream;
    const video = document.getElementById('scanner-video');
    const input = document.getElementById('identifier-input');
    const successMsg = document.getElementById('scan-success');

    document.getElementById('scannerModal').addEventListener('shown.bs.modal', async () => {
        try {
            scannerStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
            video.srcObject = scannerStream;
            startScanning();
        } catch (err) {
            alert('Caméra indisponible.');
            bootstrap.Modal.getInstance(document.getElementById('scannerModal')).hide();
        }
    });

    document.getElementById('scannerModal').addEventListener('hidden.bs.modal', () => {
        if (scannerStream) scannerStream.getTracks().forEach(t => t.stop());
    });

    function startScanning() {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        let lastCode = '';

        const scan = () => {
            if (video.readyState === video.HAVE_ENOUGH_DATA) {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

                const qrCode = jsQR(imageData.data, imageData.width, imageData.height);
                if (qrCode && qrCode.data !== lastCode) {
                    handleCode(qrCode.data);
                    return;
                }

                Quagga.decodeSingle({
                    decoder: { readers: ["code_128_reader", "ean_reader", "ean_8_reader", "upc_reader"] },
                    locate: true,
                    src: canvas.toDataURL('image/jpeg')
                }, (result) => {
                    if (result && result.codeResult && result.codeResult.code !== lastCode) {
                        handleCode(result.codeResult.code);
                    }
                });
            }
            requestAnimationFrame(scan);
        };
        scan();
    }

    function handleCode(code) {
        input.value = code;
        successMsg.style.display = 'block';
        setTimeout(() => {
            bootstrap.Modal.getInstance(document.getElementById('scannerModal')).hide();
            successMsg.style.display = 'none';
            document.getElementById('verifyForm').submit();
        }, 1000);
    }

    // === THEME ===
    const toggle = document.getElementById('theme-toggle');
    const body = document.body;
    const icon = toggle.querySelector('i');

    toggle.addEventListener('click', () => {
        const isLight = body.getAttribute('data-theme') === 'light';
        body.setAttribute('data-theme', isLight ? 'dark' : 'light');
        icon.classList.toggle('bi-sun-fill');
        icon.classList.toggle('bi-moon-stars-fill');
        localStorage.setItem('theme', isLight ? 'dark' : 'light');
    });

    if (localStorage.getItem('theme') === 'dark') {
        body.setAttribute('data-theme', 'dark');
        icon.classList.replace('bi-moon-stars-fill', 'bi-sun-fill');
    }
</script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>