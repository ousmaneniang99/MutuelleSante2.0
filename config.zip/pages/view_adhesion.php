<?php
// pages/view_adhesion.php
require_once '../includes/header.php';
checkRole('directeur_departemental');

$errors = [];
$success = null;
$adhesion = null;
$beneficiaires = [];
$kpi = [
    'beneficiaires_en_attente' => 0,
    'beneficiaires_actifs' => 0,
    'total_cotisations' => 0,
    'cotisation_annuelle' => 0,
    'statut_adhesion' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['csrf_token'])) {
    if (!verifyCsrfToken($_POST['csrf_token'])) {
        $errors[] = "Erreur de sécurité CSRF. Veuillez réessayer.";
        error_log("Échec de validation CSRF pour view_adhesion.php, utilisateur ID: {$_SESSION['user_id']}, POST: " . json_encode($_POST));
    } else {
        try {
            $pdo->beginTransaction();

            if ($_POST['action'] === 'validate_all_beneficiaires' && isset($_POST['id_adhesion'])) {
                $id_adhesion = intval($_POST['id_adhesion']);
                $stmt_check = $pdo->prepare("SELECT statut, created_by FROM adhesions WHERE id_adhesion = ? AND statut = 'active'");
                $stmt_check->execute([$id_adhesion]);
                $adhesion_check = $stmt_check->fetch(PDO::FETCH_ASSOC);

                if ($adhesion_check) {
                    $agent_id = $adhesion_check['created_by'];
                    $stmt = $pdo->prepare("
                        UPDATE beneficiaires 
                        SET statut = 'actif' 
                        WHERE id_adhesion = ? AND statut = 'en_attente_approbation'
                    ");
                    $stmt->execute([$id_adhesion]);

                    if ($stmt->rowCount() > 0) {
                        $details = "Tous les bénéficiaires de l'adhésion #$id_adhesion approuvés par {$_SESSION['nom']} {$_SESSION['prenom']} dans le département {$_SESSION['departement']}";
                        logActivity($pdo, $_SESSION['user_id'], 'validate_beneficiaire', $details);
                        sendNotification($pdo, $agent_id, "Tous les bénéficiaires de l'adhésion #$id_adhesion ont été approuvés par le directeur départemental.");
                        $success = $stmt->rowCount() . " bénéficiaire(s) approuvé(s) avec succès.";
                        error_log("{$stmt->rowCount()} bénéficiaires de l'adhésion ID $id_adhesion mis à jour à actif par utilisateur ID: {$_SESSION['user_id']}");
                    } else {
                        $errors[] = "Aucun bénéficiaire en attente pour cette adhésion.";
                        error_log("Aucun bénéficiaire en attente pour l'adhésion ID $id_adhesion, utilisateur ID: {$_SESSION['user_id']}");
                    }
                } else {
                    $errors[] = "L'adhésion n'est pas active ou n'existe pas.";
                    error_log("Adhésion non active pour ID $id_adhesion, utilisateur ID: {$_SESSION['user_id']}");
                }
            } elseif ($_POST['action'] === 'validate_beneficiaire' && isset($_POST['id_beneficiaire'], $_POST['statut'])) {
                $id_beneficiaire = intval($_POST['id_beneficiaire']);
                $statut = sanitize($_POST['statut']);
                error_log("Tentative de mise à jour du bénéficiaire ID: $id_beneficiaire, statut: $statut, utilisateur ID: {$_SESSION['user_id']}");
                if (in_array($statut, ['actif', 'inactif'])) {
                    $stmt_check = $pdo->prepare("
                        SELECT a.statut, a.created_by 
                        FROM adhesions a 
                        JOIN beneficiaires b ON a.id_adhesion = b.id_adhesion 
                        WHERE b.id_beneficiaire = ?
                    ");
                    $stmt_check->execute([$id_beneficiaire]);
                    $adhesion_check = $stmt_check->fetch(PDO::FETCH_ASSOC);

                    if ($adhesion_check && $adhesion_check['statut'] === 'active') {
                        $agent_id = $adhesion_check['created_by'];
                        $stmt = $pdo->prepare("UPDATE beneficiaires SET statut = ? WHERE id_beneficiaire = ?");
                        $stmt->execute([$statut, $id_beneficiaire]);

                        if ($stmt->rowCount() > 0) {
                            $action_label = ($statut === 'actif') ? 'approuvé' : 'désactivé';
                            $details = "Bénéficiaire ID $id_beneficiaire défini à $statut par {$_SESSION['nom']} {$_SESSION['prenom']} dans le département {$_SESSION['departement']}";
                            logActivity($pdo, $_SESSION['user_id'], 'validate_beneficiaire', $details);
                            sendNotification($pdo, $agent_id, "Le bénéficiaire ID $id_beneficiaire a été $action_label par le directeur départemental.");
                            $success = "Bénéficiaire mis à jour avec succès.";
                            error_log("Bénéficiaire ID $id_beneficiaire mis à jour à $statut par utilisateur ID: {$_SESSION['user_id']}");
                        } else {
                            $errors[] = "Aucun bénéficiaire trouvé avec l'ID : $id_beneficiaire.";
                            error_log("Échec de mise à jour : aucun bénéficiaire trouvé pour ID $id_beneficiaire, utilisateur ID: {$_SESSION['user_id']}");
                        }
                    } else {
                        $errors[] = "L'adhésion associée n'est pas active.";
                        error_log("Adhésion non active pour bénéficiaire ID $id_beneficiaire, utilisateur ID: {$_SESSION['user_id']}");
                    }
                } else {
                    $errors[] = "Statut invalide.";
                    error_log("Statut invalide: $statut, utilisateur ID: {$_SESSION['user_id']}");
                }
            } elseif ($_POST['action'] === 'delete_beneficiaire' && isset($_POST['id_beneficiaire'])) {
                $id_beneficiaire = intval($_POST['id_beneficiaire']);
                error_log("Tentative de suppression du bénéficiaire ID: $id_beneficiaire, utilisateur ID: {$_SESSION['user_id']}");
                $stmt_check = $pdo->prepare("
                    SELECT a.created_by, a.id_adhesion
                    FROM beneficiaires b 
                    JOIN adhesions a ON b.id_adhesion = a.id_adhesion 
                    WHERE b.id_beneficiaire = ?
                ");
                $stmt_check->execute([$id_beneficiaire]);
                $result = $stmt_check->fetch(PDO::FETCH_ASSOC);

                if ($result) {
                    $agent_id = $result['created_by'];
                    $id_adhesion = $result['id_adhesion'];
                    $stmt = $pdo->prepare("DELETE FROM beneficiaires WHERE id_beneficiaire = ?");
                    $stmt->execute([$id_beneficiaire]);

                    if ($stmt->rowCount() > 0) {
                        $details = "Bénéficiaire ID $id_beneficiaire supprimé par {$_SESSION['nom']} {$_SESSION['prenom']} dans le département {$_SESSION['departement']}";
                        logActivity($pdo, $_SESSION['user_id'], 'delete_beneficiaire', $details);
                        sendNotification($pdo, $agent_id, "Le bénéficiaire ID $id_beneficiaire a été supprimé par le directeur départemental.");
                        $success = "Bénéficiaire supprimé avec succès.";
                        error_log("Bénéficiaire ID $id_beneficiaire supprimé par utilisateur ID: {$_SESSION['user_id']}");
                    } else {
                        $errors[] = "Aucun bénéficiaire trouvé avec l'ID : $id_beneficiaire.";
                        error_log("Échec de suppression : aucun bénéficiaire trouvé pour ID $id_beneficiaire, utilisateur ID: {$_SESSION['user_id']}");
                    }
                } else {
                    $errors[] = "Bénéficiaire ou adhésion non trouvée.";
                    error_log("Bénéficiaire non trouvé pour ID $id_beneficiaire, utilisateur ID: {$_SESSION['user_id']}");
                }
            } elseif (in_array($_POST['action'], ['approuvee', 'rejete']) && isset($_POST['id_adhesion'])) {
                $id_adhesion = intval($_POST['id_adhesion']);
                $new_statut = $_POST['action'] === 'approuvee' ? 'active' : 'rejete';

                $stmt = $pdo->prepare("
                    SELECT created_by 
                    FROM adhesions 
                    WHERE id_adhesion = ? AND statut = 'en_attente_validation'
                ");
                $stmt->execute([$id_adhesion]);
                $agent_id = $stmt->fetchColumn();

                if ($agent_id !== false) {
                    $stmt = $pdo->prepare("UPDATE adhesions SET statut = ? WHERE id_adhesion = ? AND statut = 'en_attente_validation'");
                    $stmt->execute([$new_statut, $id_adhesion]);

                    if ($stmt->rowCount() > 0) {
                        if ($new_statut === 'active') {
                            $stmt_benef = $pdo->prepare("
                                UPDATE beneficiaires 
                                SET statut = 'actif' 
                                WHERE id_adhesion = ? AND statut = 'en_attente_approbation'
                            ");
                            $stmt_benef->execute([$id_adhesion]);
                        } elseif ($new_statut === 'rejete') {
                            $stmt = $pdo->prepare("UPDATE paiements SET statut = 'rejete' WHERE id_adhesion = ?");
                            $stmt->execute([$id_adhesion]);
                        }
                        $details = "Adhésion #$id_adhesion " . ($new_statut === 'active' ? 'approuvée' : 'rejetée') . " par {$_SESSION['nom']} {$_SESSION['prenom']} dans le département {$_SESSION['departement']}";
                        logActivity($pdo, $_SESSION['user_id'], 'validate_adhesion', $details);
                        sendNotification($pdo, $agent_id, "L'adhésion #$id_adhesion a été " . ($new_statut === 'active' ? 'approuvée' : 'rejetée') . " par le directeur départemental.");
                        $success = "Adhésion " . ($new_statut === 'active' ? 'approuvée' : 'rejetée') . " avec succès.";
                        error_log("Adhésion ID $id_adhesion mise à jour à $new_statut par utilisateur ID: {$_SESSION['user_id']}");
                    } else {
                        $errors[] = "Adhésion non trouvée ou déjà traitée.";
                        error_log("Échec de mise à jour : aucune adhésion trouvée pour ID $id_adhesion, utilisateur ID: {$_SESSION['user_id']}");
                    }
                } else {
                    $errors[] = "Adhésion non trouvée ou accès non autorisé.";
                    error_log("Adhésion non trouvée pour ID $id_adhesion, utilisateur ID: {$_SESSION['user_id']}");
                }
            } else {
                $errors[] = "Action invalide.";
                error_log("Action invalide: action={$_POST['action']}, utilisateur ID: {$_SESSION['user_id']}");
            }

            // Mettre à jour les KPI après chaque action
            if (isset($id_adhesion)) {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM beneficiaires WHERE id_adhesion = ? AND statut = 'en_attente_approbation'");
                $stmt->execute([$id_adhesion]);
                $kpi['beneficiaires_en_attente'] = $stmt->fetchColumn();

                $stmt = $pdo->prepare("SELECT COUNT(*) FROM beneficiaires WHERE id_adhesion = ? AND statut = 'actif'");
                $stmt->execute([$id_adhesion]);
                $kpi['beneficiaires_actifs'] = $stmt->fetchColumn();

                $stmt = $pdo->prepare("SELECT SUM(montant_verse) FROM paiements WHERE id_adhesion = ? AND statut = 'paye'");
                $stmt->execute([$id_adhesion]);
                $kpi['total_cotisations'] = $stmt->fetchColumn() ?: 0;

                $stmt = $pdo->prepare("
                    SELECT tarif_beneficiaire 
                    FROM tarifs 
                    WHERE type_adhesion = (SELECT type_adhesion FROM adhesions WHERE id_adhesion = ?) 
                    AND date_debut <= NOW() 
                    AND (date_fin IS NULL OR date_fin >= NOW())
                    ORDER BY date_debut DESC 
                    LIMIT 1
                ");
                $stmt->execute([$id_adhesion]);
                $tarif_beneficiaire = $stmt->fetchColumn() ?: 0;
                if ($tarif_beneficiaire === 0) {
                    error_log("Aucun tarif valide trouvé pour id_adhesion: $id_adhesion, type_adhesion inconnu ou tarif non valide");
                    $errors[] = "Aucun tarif valide trouvé pour cette adhésion.";
                }
                $kpi['cotisation_annuelle'] = $kpi['beneficiaires_actifs'] * $tarif_beneficiaire;
            }

            $pdo->commit();
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Erreur lors de la mise à jour des données : " . htmlspecialchars($e->getMessage());
            error_log("Erreur PDO dans view_adhesion.php (POST) : " . $e->getMessage());
        }
    }
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $errors[] = "ID d'adhésion non valide.";
} else {
    $id_adhesion = intval($_GET['id']);
    
    try {
        // Vérifier l'existence de l'adhésion
        $stmt = $pdo->prepare("SELECT id_adhesion FROM adhesions WHERE id_adhesion = ?");
        $stmt->execute([$id_adhesion]);
        if (!$stmt->fetch()) {
            $errors[] = "Adhésion non trouvée.";
            error_log("Adhésion non trouvée pour ID $id_adhesion, utilisateur ID: {$_SESSION['user_id']}");
        } else {
            // Fetch adhesion details
            $stmt = $pdo->prepare("
                SELECT a.id_adhesion, a.num_adherent, a.statut, u.nom, u.prenom, a.type_adhesion, a.date_adhesion, u.photo_path,
                       agent.nom AS agent_nom, agent.prenom AS agent_prenom
                FROM adhesions a
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
                WHERE a.id_adhesion = ? AND agent.departement = ? AND agent.role = 'agent_mobilisateur'
            ");
            $stmt->execute([$id_adhesion, $_SESSION['departement']]);
            $adhesion = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$adhesion) {
                $errors[] = "Adhésion non trouvée ou accès non autorisé pour ce département.";
                error_log("Adhésion non trouvée ou accès non autorisé pour ID $id_adhesion, département {$_SESSION['departement']}, utilisateur ID: {$_SESSION['user_id']}");
            } else {
                // Set KPI: Statut de l'adhésion
                $kpi['statut_adhesion'] = $adhesion['statut'] === 'en_attente_validation' ? 'En attente' : ($adhesion['statut'] === 'active' ? 'Actif' : 'Rejeté');

                // Fetch KPI: Bénéficiaires en attente
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM beneficiaires WHERE id_adhesion = ? AND statut = 'en_attente_approbation'");
                $stmt->execute([$id_adhesion]);
                $kpi['beneficiaires_en_attente'] = $stmt->fetchColumn();

                // Fetch KPI: Bénéficiaires actifs
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM beneficiaires WHERE id_adhesion = ? AND statut = 'actif'");
                $stmt->execute([$id_adhesion]);
                $kpi['beneficiaires_actifs'] = $stmt->fetchColumn();

                // Fetch KPI: Paiements Totaux de l'Adhérent
                $stmt = $pdo->prepare("SELECT SUM(montant_verse) FROM paiements WHERE id_adhesion = ? AND statut = 'paye'");
                $stmt->execute([$id_adhesion]);
                $kpi['total_cotisations'] = $stmt->fetchColumn() ?: 0;

                // Fetch KPI: Cotisation annuelle
                $stmt = $pdo->prepare("
                    SELECT tarif_beneficiaire 
                    FROM tarifs 
                    WHERE type_adhesion = ? 
                    AND date_debut <= NOW() 
                    AND (date_fin IS NULL OR date_fin >= NOW())
                    ORDER BY date_debut DESC 
                    LIMIT 1
                ");
                $stmt->execute([$adhesion['type_adhesion']]);
                $tarif_beneficiaire = $stmt->fetchColumn() ?: 0;
                if ($tarif_beneficiaire === 0) {
                    error_log("Aucun tarif valide trouvé pour type_adhesion: {$adhesion['type_adhesion']}, id_adhesion: $id_adhesion");
                    $errors[] = "Aucun tarif valide trouvé pour cette adhésion.";
                }
                $kpi['cotisation_annuelle'] = $kpi['beneficiaires_actifs'] * $tarif_beneficiaire;

                // Fetch beneficiaries
                $stmt = $pdo->prepare("
                    SELECT id_beneficiaire, nom, prenom, date_naissance, relation, code_beneficiaire, date_entree, date_sortie, statut
                    FROM beneficiaires
                    WHERE id_adhesion = ?
                    ORDER BY date_entree DESC
                ");
                $stmt->execute([$id_adhesion]);
                $beneficiaires = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        }
    } catch (PDOException $e) {
        $errors[] = "Erreur lors de la récupération des données : " . htmlspecialchars($e->getMessage());
        error_log("Erreur PDO dans view_adhesion.php (GET) : " . $e->getMessage());
    }
}

$csrf_token = generateCsrfToken();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails de l'Adhésion - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1d4ed8;
            --secondary: #6b7280;
            --accent: #059669;
            --warning: #f59e0b;
            --danger: #ef4444;
            --background: #f1f5f9;
            --card-bg: #ffffff;
            --text: #111827;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #e2e8f0, #f1f5f9);
            color: var(--text);
            min-height: 100vh;
        }

        .container {
            max-width: 1400px;
            margin: 3rem auto;
            padding: 0 1.5rem;
        }

        h2 {
            font-weight: 700;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            animation: fadeIn 0.5s ease-in;
        }

        .card {
            border-radius: 16px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
            background: var(--card-bg);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary), #1e3a8a);
            color: white;
            font-weight: 600;
            border-radius: 16px 16px 0 0;
            padding: 1.75rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-body {
            padding: 2.5rem;
        }

        .table {
            margin-bottom: 0;
            border-radius: 12px;
            overflow: hidden;
            background: var(--card-bg);
        }

        .table th {
            font-weight: 600;
            color: var(--text);
            border-bottom: 2px solid var(--primary);
            padding: 1rem;
        }

        .table td {
            vertical-align: middle;
            padding: 1rem;
        }

        .btn-success, .btn-danger, .btn-warning, .btn-primary {
            border-radius: 10px;
            padding: 0.6rem 1.2rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
        }

        .btn-success {
            background: var(--accent);
            border: none;
        }

        .btn-success:hover {
            background: #047857;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(5, 150, 105, 0.3);
        }

        .btn-danger {
            background: var(--danger);
            border: none;
        }

        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(239, 68, 68, 0.3);
        }

        .btn-warning {
            background: var(--warning);
            border: none;
        }

        .btn-warning:hover {
            background: #d97706;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(245, 158, 11, 0.3);
        }

        .btn-primary {
            background: var(--primary);
            border: none;
        }

        .btn-primary:hover {
            background: #1e3a8a;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(29, 78, 216, 0.3);
        }

        .form-select {
            border-radius: 10px;
            transition: all 0.3s ease;
            padding: 0.5rem;
        }

        .form-select:focus {
            box-shadow: 0 0 10px rgba(37, 99, 235, 0.3);
            border-color: var(--primary);
        }

        .alert {
            border-radius: 12px;
            animation: slideIn 0.5s ease-in-out;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .kpi-card {
            border-radius: 12px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            overflow: hidden;
        }

        .kpi-card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .kpi-card .card-body {
            padding: 1.75rem;
            text-align: center;
        }

        .kpi-card .card-title {
            font-size: 1.1rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            font-weight: 500;
        }

        .kpi-card .card-text {
            font-size: 1.8rem;
            font-weight: 700;
            animation: fadeIn 0.5s ease-in;
        }

        .search-container {
            position: relative;
            margin-bottom: 2rem;
        }

        .search-container i {
            position: absolute;
            top: 50%;
            left: 12px;
            transform: translateY(-50%);
            color: var(--secondary);
            font-size: 1.2rem;
        }

        .search-container input {
            padding-left: 40px;
            border-radius: 10px;
            border: 1px solid var(--secondary);
            transition: all 0.3s ease;
        }

        .search-container input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 10px rgba(37, 99, 235, 0.3);
        }

        .adherent-photo {
            width: 160px;
            height: 160px;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid var(--primary);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-bottom: 1.5rem;
            transition: transform 0.3s ease;
        }

        .adherent-photo:hover {
            transform: scale(1.1);
        }

        .adherent-photo-container {
            text-align: center;
        }

        .validate-all-container {
            margin-top: 2rem;
            text-align: right;
        }

        .spinner {
            display: none;
            border: 4px solid #f3f3f3;
            border-top: 4px solid var(--primary);
            border-radius: 50%;
            width: 24px;
            height: 24px;
            animation: spin 1s linear infinite;
            margin-left: 10px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .action-buttons {
            display: flex;
            gap: 0.75rem;
            align-items: center;
        }

        @media (max-width: 768px) {
            .container {
                margin: 1.5rem;
                padding: 0 1rem;
            }
            .btn-success, .btn-danger, .btn-warning, .btn-primary, .form-select {
                margin-bottom: 0.75rem;
            }
            .validate-all-container {
                text-align: center;
            }
            .action-buttons {
                flex-direction: column;
                align-items: flex-start;
            }
            .kpi-card .card-text {
                font-size: 1.4rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-5"><i class="bi bi-card-list"></i> Détails de l'Adhésion</h2>

        <!-- Messages -->
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i><?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php if ($adhesion): ?>
            <!-- Adhesion Information -->
            <div class="card mb-5">
                <div class="card-header">
                    <i class="bi bi-info-circle-fill me-2"></i>Informations de l'Adhésion
                </div>
                <div class="card-body">
                    <div class="adherent-photo-container">
                        <img src="<?php echo $adhesion['photo_path'] && file_exists($adhesion['photo_path']) ? htmlspecialchars($adhesion['photo_path']) : 'https://via.placeholder.com/150?text=Adhérent'; ?>" 
                             alt="Photo de l'adhérent" 
                             class="adherent-photo"
                             onerror="this.src='https://via.placeholder.com/150?text=Adhérent';">
                    </div>
                    <div class="row g-4">
                        <div class="col-md-6">
                            <p><strong><i class="bi bi-person-vcard-fill me-2"></i>Numéro Adhésion :</strong> <?php echo htmlspecialchars($adhesion['num_adherent']); ?></p>
                            <p><strong><i class="bi bi-person-fill me-2"></i>Adhérent :</strong> <?php echo htmlspecialchars($adhesion['nom'] . ' ' . $adhesion['prenom']); ?></p>
                            <p><strong><i class="bi bi-person-plus-fill me-2"></i>Agent Mobilisateur :</strong> <?php echo htmlspecialchars(($adhesion['agent_nom'] ?? 'Non spécifié') . ' ' . ($adhesion['agent_prenom'] ?? '')); ?></p>
                            <p><strong><i class="bi bi-card-list me-2"></i>Type :</strong> <?php echo htmlspecialchars($adhesion['type_adhesion']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong><i class="bi bi-calendar-fill me-2"></i>Date d'Adhésion :</strong> <?php echo htmlspecialchars($adhesion['date_adhesion']); ?></p>
                            <p><strong><i class="bi bi-toggle-on me-2"></i>Statut :</strong> <?php echo htmlspecialchars($kpi['statut_adhesion']); ?></p>
                            <p><strong><i class="bi bi-currency-exchange me-2"></i>Paiements Totaux de l’Adhérent :</strong> <?php echo htmlspecialchars(formatFCFA($kpi['total_cotisations'])); ?></p>
                        </div>
                    </div>
                    <div class="mt-4 d-flex gap-3 flex-wrap">
                        <?php if ($adhesion['statut'] === 'en_attente_validation'): ?>
                            <form method="POST" style="display: inline;" class="action-form">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                <input type="hidden" name="id_adhesion" value="<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                <button type="submit" name="action" value="approuvee" class="btn btn-success" onclick="return confirm('Confirmer l\'approbation de l\'adhésion ? Tous les bénéficiaires associés seront également approuvés.');">
                                    <i class="bi bi-check-circle-fill me-1"></i>Approuver
                                    <span class="spinner"></span>
                                </button>
                            </form>
                            <form method="POST" style="display: inline;" class="action-form">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                <input type="hidden" name="id_adhesion" value="<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                <button type="submit" name="action" value="rejete" class="btn btn-danger" onclick="return confirm('Confirmer le rejet de l\'adhésion ?');">
                                    <i class="bi bi-x-circle-fill me-1"></i>Rejeter
                                    <span class="spinner"></span>
                                </button>
                            </form>
                        <?php endif; ?>
                        <a href="edit_adhesion.php?id=<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" class="btn btn-warning"><i class="bi bi-pencil-fill me-1"></i>Modifier</a>
                    </div>
                </div>
            </div>

            <!-- KPI Cards -->
            <div class="row g-4 mb-5">
                <div class="col-md-3 col-sm-6">
                    <div class="card kpi-card" style="background: linear-gradient(135deg, var(--primary), #1e3a8a); color: white;">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-person-hearts"></i>Bénéficiaires en Attente</h5>
                            <p class="card-text"><?php echo htmlspecialchars($kpi['beneficiaires_en_attente']); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card kpi-card" style="background: linear-gradient(135deg, var(--accent), #047857); color: white;">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-person-check"></i>Bénéficiaires Actifs</h5>
                            <p class="card-text"><?php echo htmlspecialchars($kpi['beneficiaires_actifs']); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card kpi-card" style="background: linear-gradient(135deg, var(--secondary), #4b5563); color: white;">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-currency-exchange"></i>Paiements Totaux de l’Adhérent</h5>
                            <p class="card-text"><?php echo htmlspecialchars(formatFCFA($kpi['total_cotisations'])); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card kpi-card" style="background: linear-gradient(135deg, var(--warning), #d97706); color: white;">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-currency-dollar"></i>Cotisation Annuelle</h5>
                            <p class="card-text"><?php echo htmlspecialchars(formatFCFA($kpi['cotisation_annuelle'])); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Beneficiaries Table -->
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-people-fill me-2"></i>Bénéficiaires
                </div>
                <div class="card-body">
                    <div class="search-container">
                        <i class="bi bi-search"></i>
                        <input type="text" id="search_beneficiaire" class="form-control" placeholder="Rechercher un bénéficiaire..." aria-label="Rechercher un bénéficiaire">
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-beneficiaires">
                            <thead>
                                <tr>
                                    <th><i class="bi bi-person-fill me-2"></i>Nom</th>
                                    <th><i class="bi bi-person-fill me-2"></i>Prénom</th>
                                    <th><i class="bi bi-calendar-fill me-2"></i>Date de Naissance</th>
                                    <th><i class="bi bi-person-hearts me-2"></i>Relation</th>
                                    <th><i class="bi bi-person-vcard-fill me-2"></i>Code Bénéficiaire</th>
                                    <th><i class="bi bi-toggle-on me-2"></i>Statut</th>
                                    <th><i class="bi bi-gear-fill me-2"></i>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($beneficiaires)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">Aucun bénéficiaire trouvé.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($beneficiaires as $beneficiaire): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($beneficiaire['nom']); ?></td>
                                            <td><?php echo htmlspecialchars($beneficiaire['prenom']); ?></td>
                                            <td><?php echo htmlspecialchars($beneficiaire['date_naissance']); ?></td>
                                            <td><?php echo htmlspecialchars($beneficiaire['relation']); ?></td>
                                            <td><?php echo htmlspecialchars($beneficiaire['code_beneficiaire']); ?></td>
                                            <td><?php echo htmlspecialchars($beneficiaire['statut'] === 'en_attente_approbation' ? 'En attente' : ($beneficiaire['statut'] === 'actif' ? 'Actif' : 'Inactif')); ?></td>
                                            <td>
                                                <div class="action-buttons">
                                                    <?php if ($adhesion['statut'] === 'active' && $beneficiaire['statut'] !== 'en_attente_approbation'): ?>
                                                        <form method="POST" class="action-form d-inline" action="">
                                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                                            <input type="hidden" name="id_beneficiaire" value="<?php echo htmlspecialchars($beneficiaire['id_beneficiaire']); ?>">
                                                            <input type="hidden" name="statut" value="<?php echo $beneficiaire['statut'] === 'actif' ? 'inactif' : 'actif'; ?>">
                                                            <input type="hidden" name="action" value="validate_beneficiaire">
                                                            <button type="submit" class="btn btn-sm <?php echo $beneficiaire['statut'] === 'actif' ? 'btn-warning' : 'btn-success'; ?>" 
                                                                    onclick="return confirm('Confirmer <?php echo $beneficiaire['statut'] === 'actif' ? 'la désactivation' : 'l\'activation'; ?> du bénéficiaire ?');">
                                                                <i class="bi <?php echo $beneficiaire['statut'] === 'actif' ? 'bi-toggle-off' : 'bi-toggle-on'; ?> me-1"></i>
                                                                <?php echo $beneficiaire['statut'] === 'actif' ? 'Désactiver' : 'Activer'; ?>
                                                                <span class="spinner"></span>
                                                            </button>
                                                        </form>
                                                    <?php elseif ($adhesion['statut'] === 'active' && $beneficiaire['statut'] === 'en_attente_approbation'): ?>
                                                        <form method="POST" class="action-form d-flex gap-2 align-items-center" action="">
                                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                                            <input type="hidden" name="id_beneficiaire" value="<?php echo htmlspecialchars($beneficiaire['id_beneficiaire']); ?>">
                                                            <input type="hidden" name="action" value="validate_beneficiaire">
                                                            <select name="statut" class="form-select w-auto" aria-label="Statut du bénéficiaire">
                                                                <option value="actif">Approuver</option>
                                                                <option value="inactif">Rejeter</option>
                                                            </select>
                                                            <button type="submit" class="btn btn-primary btn-sm" onclick="return confirm('Confirmer l\'action pour ce bénéficiaire ?');">
                                                                <i class="bi bi-check-circle-fill me-1"></i>Valider
                                                                <span class="spinner"></span>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                    <form method="POST" class="action-form d-inline" action="">
                                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                                        <input type="hidden" name="id_beneficiaire" value="<?php echo htmlspecialchars($beneficiaire['id_beneficiaire']); ?>">
                                                        <input type="hidden" name="action" value="delete_beneficiaire">
                                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Confirmer la suppression du bénéficiaire ?');">
                                                            <i class="bi bi-trash-fill me-1"></i>Supprimer
                                                            <span class="spinner"></span>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if ($adhesion['statut'] === 'active' && $kpi['beneficiaires_en_attente'] > 0): ?>
                        <div class="validate-all-container">
                            <form method="POST" class="action-form" onsubmit="return confirm('Confirmer l\'approbation de tous les bénéficiaires en attente pour cette adhésion ?');">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                <input type="hidden" name="id_adhesion" value="<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                <button type="submit" name="action" value="validate_all_beneficiaires" class="btn btn-success">
                                    <i class="bi bi-check-all me-1"></i>Valider tous les bénéficiaires
                                    <span class="spinner"></span>
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Search functionality for beneficiaries table
        document.getElementById('search_beneficiaire').addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-beneficiaires tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });

        // Show spinner on form submission
        document.querySelectorAll('.action-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const button = this.querySelector('button[type="submit"]');
                const spinner = button.querySelector('.spinner');
                if (spinner) {
                    spinner.style.display = 'inline-block';
                    button.disabled = true;
                    setTimeout(() => {
                        button.disabled = false; // Réactiver le bouton après 2 secondes si la soumission échoue
                    }, 2000);
                }
            });
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>