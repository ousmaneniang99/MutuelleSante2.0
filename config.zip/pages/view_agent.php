<?php
// pages/view_agent.php
require_once '../includes/header.php';
checkRole('directeur_departemental');

$errors = [];
$agent = null;
$adhesions = [];
$kpi = [
    'adherents_en_attente' => 0,
    'adherents_actifs' => 0,
    'beneficiaires_en_attente' => 0,
    'beneficiaires_actifs' => 0,
    'total_cotisations' => 0,
    'taux_conversion' => 0
];
$filters = [
    'periode' => $_GET['periode'] ?? '30'
];

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $errors[] = "ID de l'agent non valide.";
} else {
    $id_agent = intval($_GET['id']);
    
    try {
        // Fetch agent details
        $stmt = $pdo->prepare("
            SELECT id_utilisateur, nom, prenom, email, telephone, photo_path
            FROM utilisateurs 
            WHERE id_utilisateur = ? AND role = 'agent_mobilisateur' AND departement = ?
        ");
        $stmt->execute([$id_agent, $_SESSION['departement']]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$agent) {
            $errors[] = "Agent non trouvé ou accès non autorisé.";
            error_log("Agent non trouvé ou accès non autorisé pour ID $id_agent, département {$_SESSION['departement']}, utilisateur ID: {$_SESSION['user_id']}");
        } else {
            // Set default photo if empty or file does not exist
            $agent['photo_path'] = (!empty($agent['photo_path']) && file_exists($agent['photo_path'])) 
                ? htmlspecialchars($agent['photo_path']) 
                : 'https://via.placeholder.com/150?text=Agent';

            // Fetch KPI: Adhérents en attente
            $stmt = $pdo->prepare("
                SELECT COUNT(*) 
                FROM adhesions a
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                WHERE a.created_by = ? AND a.statut = 'en_attente_validation' AND u.departement = ?
            ");
            $stmt->execute([$id_agent, $_SESSION['departement']]);
            $kpi['adherents_en_attente'] = $stmt->fetchColumn();

            // Fetch KPI: Adhérents actifs
            $stmt = $pdo->prepare("
                SELECT COUNT(*) 
                FROM adhesions a
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                WHERE a.created_by = ? AND a.statut = 'active' AND u.departement = ?
            ");
            $stmt->execute([$id_agent, $_SESSION['departement']]);
            $kpi['adherents_actifs'] = $stmt->fetchColumn();

            // Fetch KPI: Bénéficiaires en attente
            $stmt = $pdo->prepare("
                SELECT COUNT(*) 
                FROM beneficiaires b
                JOIN adhesions a ON b.id_adhesion = a.id_adhesion
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                WHERE a.created_by = ? AND b.statut = 'en_attente_approbation' AND u.departement = ?
            ");
            $stmt->execute([$id_agent, $_SESSION['departement']]);
            $kpi['beneficiaires_en_attente'] = $stmt->fetchColumn();

            // Fetch KPI: Bénéficiaires actifs
            $stmt = $pdo->prepare("
                SELECT COUNT(*) 
                FROM beneficiaires b
                JOIN adhesions a ON b.id_adhesion = a.id_adhesion
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                WHERE a.created_by = ? AND b.statut = 'actif' AND u.departement = ?
            ");
            $stmt->execute([$id_agent, $_SESSION['departement']]);
            $kpi['beneficiaires_actifs'] = $stmt->fetchColumn();

            // Fetch KPI: Total cotisations payées
            $stmt = $pdo->prepare("
                SELECT SUM(p.montant_verse)
                FROM paiements p
                JOIN adhesions a ON p.id_adhesion = a.id_adhesion
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                WHERE a.created_by = ? AND p.statut = 'paye' AND u.departement = ?
            ");
            $stmt->execute([$id_agent, $_SESSION['departement']]);
            $kpi['total_cotisations'] = $stmt->fetchColumn() ?: 0;

            // Fetch KPI: Taux de conversion
            $total_adhesions = $kpi['adherents_actifs'] + $kpi['adherents_en_attente'];
            $kpi['taux_conversion'] = $total_adhesions > 0 ? round(($kpi['adherents_actifs'] / $total_adhesions) * 100, 2) : 0;

            // Fetch adhesions created by this agent
            $stmt = $pdo->prepare("
                SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom, a.type_adhesion, a.statut, a.date_adhesion,
                       (SELECT COUNT(*) FROM beneficiaires b WHERE b.id_adhesion = a.id_adhesion) as beneficiaire_count,
                       (SELECT SUM(montant_verse) FROM paiements p WHERE p.id_adhesion = a.id_adhesion AND p.statut = 'paye') as total_paye
                FROM adhesions a
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                WHERE a.created_by = ? AND u.departement = ?
                ORDER BY a.date_adhesion DESC
            ");
            $stmt->execute([$id_agent, $_SESSION['departement']]);
            $adhesions = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Fetch data for charts
            $periode = in_array($filters['periode'], ['7', '30', '90']) ? (int)$filters['periode'] : 30;
            $date_debut = date('Y-m-d', strtotime("-$periode days"));

            // Chart: Adhésions par jour
            $stmt = $pdo->prepare("
                SELECT DATE(a.date_adhesion) AS jour, COUNT(a.id_adhesion) AS total
                FROM adhesions a
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                WHERE a.created_by = ? AND a.date_adhesion >= ? AND u.departement = ?
                GROUP BY DATE(a.date_adhesion)
                ORDER BY jour
            ");
            $stmt->execute([$id_agent, $date_debut, $_SESSION['departement']]);
            $adhesions_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $adhesions_labels = [];
            $adhesions_values = [];
            $current_date = strtotime($date_debut);
            $end_date = strtotime('today');
            while ($current_date <= $end_date) {
                $adhesions_labels[] = date('Y-m-d', $current_date);
                $adhesions_values[] = 0;
                $current_date = strtotime('+1 day', $current_date);
            }
            foreach ($adhesions_data as $data) {
                $index = array_search($data['jour'], $adhesions_labels);
                if ($index !== false) {
                    $adhesions_values[$index] = (int)$data['total'];
                }
            }

            // Chart: Cotisations par jour
            $stmt = $pdo->prepare("
                SELECT DATE(p.date_paiement) AS jour, SUM(p.montant_verse) AS total
                FROM paiements p
                JOIN adhesions a ON p.id_adhesion = a.id_adhesion
                JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
                WHERE a.created_by = ? AND p.statut = 'paye' AND p.date_paiement >= ? AND u.departement = ?
                GROUP BY DATE(p.date_paiement)
                ORDER BY jour
            ");
            $stmt->execute([$id_agent, $date_debut, $_SESSION['departement']]);
            $cotisations_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $cotisations_labels = $adhesions_labels; // Same time scale
            $cotisations_values = array_fill(0, count($cotisations_labels), 0);
            foreach ($cotisations_data as $data) {
                $index = array_search($data['jour'], $cotisations_labels);
                if ($index !== false) {
                    $cotisations_values[$index] = (float)$data['total'];
                }
            }

            // Filter labels for readability
            $filtered_labels = [];
            $step = $periode === 90 ? 7 : ($periode === 30 ? 2 : 1);
            for ($i = 0; $i < count($adhesions_labels); $i++) {
                if ($i % $step === 0) {
                    $filtered_labels[] = $adhesions_labels[$i];
                } else {
                    $filtered_labels[] = '';
                }
            }
        }
    } catch (PDOException $e) {
        $errors[] = "Erreur lors de la récupération des données : " . htmlspecialchars($e->getMessage());
        error_log("Erreur PDO dans view_agent.php : " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails de l'Agent - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
    <style>
        :root {
            --primary: #1d4ed8;
            --secondary: #6b7280;
            --accent: #059669;
            --warning: #f59e0b;
            --danger: #ef4444;
            --background: #f1f5f9;
            --card-bg: #ffffff;
            --success-dark: #047857;
            --info-dark: #0288d1;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #e2e8f0, #f1f5f9);
            color: var(--text);
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 3rem auto;
            padding: 0 1.5rem;
        }

        h2 {
            font-weight: 700;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            animation: fadeIn 0.5s ease-in;
        }

        .card {
            border-radius: 16px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
            background: var(--card-bg);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary), #1e3a8a);
            color: white;
            font-weight: 600;
            border-radius: 16px 16px 0 0;
            padding: 1.75rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-body {
            padding: 2.5rem;
        }

        .table {
            margin-bottom: 0;
            border-radius: 12px;
            overflow: hidden;
            background: var(--card-bg);
        }

        .table th {
            font-weight: 600;
            color: var(--text);
            border-bottom: 2px solid var(--primary);
            padding: 1rem;
        }

        .table td {
            vertical-align: middle;
            padding: 1rem;
        }

        .btn-success, .btn-danger, .btn-warning, .btn-primary, .btn-info {
            border-radius: 10px;
            padding: 0.6rem 1.2rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
        }

        .btn-success {
            background: var(--accent);
            border: none;
        }

        .btn-success:hover {
            background: var(--success-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(5, 150, 105, 0.3);
        }

        .btn-info {
            background: #17a2b8;
            border: none;
        }

        .btn-info:hover {
            background: var(--info-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(23, 162, 184, 0.3);
        }

        .btn-warning {
            background: var(--warning);
            border: none;
        }

        .btn-warning:hover {
            background: #d97706;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(245, 158, 11, 0.3);
        }

        .btn-primary {
            background: var(--primary);
            border: none;
        }

        .btn-primary:hover {
            background: #1e3a8a;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(29, 78, 216, 0.3);
        }

        .form-select {
            border-radius: 10px;
            transition: all 0.3s ease;
            padding: 0.5rem;
        }

        .form-select:focus {
            box-shadow: 0 0 10px rgba(37, 99, 235, 0.3);
            border-color: var(--primary);
        }

        .alert {
            border-radius: 12px;
            animation: slideIn 0.5s ease-in-out;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .kpi-card {
            border-radius: 12px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            overflow: hidden;
        }

        .kpi-card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .kpi-card .card-body {
            padding: 1.75rem;
            text-align: center;
        }

        .kpi-card .card-title {
            font-size: 1.1rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            font-weight: 500;
        }

        .kpi-card .card-text {
            font-size: 1.8rem;
            font-weight: 700;
            animation: fadeIn 0.5s ease-in;
        }

        .search-container {
            position: relative;
            margin-bottom: 2rem;
        }

        .search-container i {
            position: absolute;
            top: 50%;
            left: 12px;
            transform: translateY(-50%);
            color: var(--secondary);
            font-size: 1.2rem;
        }

        .search-container input {
            padding-left: 40px;
            border-radius: 10px;
            border: 1px solid var(--secondary);
            transition: all 0.3s ease;
        }

        .search-container input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 10px rgba(37, 99, 235, 0.3);
        }

        .agent-photo {
            width: 160px;
            height: 160px;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid var(--primary);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-bottom: 1.5rem;
            transition: transform 0.3s ease;
        }

        .agent-photo:hover {
            transform: scale(1.1);
        }

        .agent-photo-container {
            text-align: center;
        }

        .chart-card canvas {
            max-height: 350px;
        }

        .filter-container {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            align-items: center;
            margin-bottom: 2rem;
        }

        .filter-container .form-select {
            min-width: 180px;
        }

        .medal {
            color: #ffd700;
            font-size: 1.5rem;
            margin-left: 0.5rem;
        }

        @media (max-width: 768px) {
            .container {
                margin: 1.5rem;
                padding: 0 1rem;
            }
            .btn-success, .btn-info, .btn-warning, .btn-primary, .form-select {
                margin-bottom: 0.75rem;
            }
            .kpi-card .card-text {
                font-size: 1.4rem;
            }
            .filter-container .form-select {
                min-width: 100%;
            }
            .agent-photo {
                width: 120px;
                height: 120px;
            }
            .chart-card canvas {
                max-height: 300px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-5"><i class="bi bi-person-circle"></i> Détails de l'Agent <?php if ($agent && $kpi['taux_conversion'] >= 80): ?><i class="bi bi-award-fill medal" title="Agent performant (Taux de conversion ≥ 80%)"></i><?php endif; ?></h2>

        <!-- Messages -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php elseif ($agent): ?>
            <!-- Agent Information -->
            <div class="card mb-5">
                <div class="card-header">
                    <i class="bi bi-person-circle me-2"></i>Informations de l'Agent
                </div>
                <div class="card-body">
                    <div class="agent-photo-container">
                        <img src="<?php echo $agent['photo_path']; ?>" 
                             alt="Photo de l'agent" 
                             class="agent-photo"
                             onerror="this.src='https://via.placeholder.com/150?text=Agent';">
                    </div>
                    <div class="row g-4">
                        <div class="col-md-6">
                            <p><strong><i class="bi bi-person me-2"></i>Nom :</strong> <?php echo htmlspecialchars($agent['nom']); ?></p>
                            <p><strong><i class="bi bi-person me-2"></i>Prénom :</strong> <?php echo htmlspecialchars($agent['prenom']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong><i class="bi bi-envelope me-2"></i>Email :</strong> <?php echo htmlspecialchars($agent['email']); ?></p>
                            <p><strong><i class="bi bi-telephone me-2"></i>Téléphone :</strong> <?php echo htmlspecialchars($agent['telephone']); ?></p>
                        </div>
                    </div>
                    <div class="mt-4">
                        <a href="edit_agent.php?id=<?php echo htmlspecialchars($agent['id_utilisateur']); ?>" class="btn btn-warning"><i class="bi bi-pencil-fill me-1"></i>Modifier</a>
                    </div>
                </div>
            </div>

            <!-- KPI Cards -->
            <div class="row g-4 mb-5">
                <div class="col-md-4 col-sm-6">
                    <div class="card kpi-card" style="background: linear-gradient(135deg, var(--primary), #1e3a8a); color: white;">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-people"></i>Adhérents en Attente</h5>
                            <p class="card-text"><?php echo htmlspecialchars($kpi['adherents_en_attente']); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="card kpi-card" style="background: linear-gradient(135deg, var(--accent), var(--success-dark)); color: white;">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-people-fill"></i>Adhérents Actifs</h5>
                            <p class="card-text"><?php echo htmlspecialchars($kpi['adherents_actifs']); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="card kpi-card" style="background: linear-gradient(135deg, var(--warning), #d97706); color: white;">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-person-hearts"></i>Bénéficiaires en Attente</h5>
                            <p class="card-text"><?php echo htmlspecialchars($kpi['beneficiaires_en_attente']); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="card kpi-card" style="background: linear-gradient(135deg, #17a2b8, var(--info-dark)); color: white;">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-person-check"></i>Bénéficiaires Actifs</h5>
                            <p class="card-text"><?php echo htmlspecialchars($kpi['beneficiaires_actifs']); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="card kpi-card" style="background: linear-gradient(135deg, var(--secondary), #4b5563); color: white;">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-currency-exchange"></i>Total Cotisations</h5>
                            <p class="card-text"><?php echo htmlspecialchars(formatFCFA($kpi['total_cotisations'])); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="card kpi-card" style="background: linear-gradient(135deg, #6f42c1, #5a32a3); color: white;">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-graph-up"></i>Taux de Conversion</h5>
                            <p class="card-text"><?php echo htmlspecialchars($kpi['taux_conversion']); ?>%</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Adhesions Table -->
            <div class="card mb-5">
                <div class="card-header">
                    <i class="bi bi-card-list me-2"></i>Adhésions Créées par l'Agent
                </div>
                <div class="card-body">
                    <div class="search-container">
                        <i class="bi bi-search"></i>
                        <input type="text" id="search_adhesion" class="form-control" placeholder="Rechercher une adhésion..." aria-label="Rechercher une adhésion">
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-adhesions">
                            <thead>
                                <tr>
                                    <th><i class="bi bi-person-vcard me-2"></i>Numéro Adhésion</th>
                                    <th><i class="bi bi-person me-2"></i>Adhérent</th>
                                    <th><i class="bi bi-card-list me-2"></i>Type</th>
                                    <th><i class="bi bi-calendar me-2"></i>Date Création</th>
                                    <th><i class="bi bi-toggle-on me-2"></i>Statut</th>
                                    <th><i class="bi bi-person-hearts me-2"></i>Bénéficiaires</th>
                                    <th><i class="bi bi-currency-exchange me-2"></i>Total Payé</th>
                                    <th><i class="bi bi-gear me-2"></i>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($adhesions)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">Aucune adhésion trouvée.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($adhesions as $adhesion): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($adhesion['num_adherent']); ?></td>
                                            <td><?php echo htmlspecialchars($adhesion['nom'] . ' ' . $adhesion['prenom']); ?></td>
                                            <td><?php echo htmlspecialchars($adhesion['type_adhesion']); ?></td>
                                            <td><?php echo htmlspecialchars($adhesion['date_adhesion']); ?></td>
                                            <td><?php echo htmlspecialchars($adhesion['statut'] === 'en_attente_validation' ? 'En attente' : ($adhesion['statut'] === 'active' ? 'Actif' : 'Rejeté')); ?></td>
                                            <td><?php echo htmlspecialchars($adhesion['beneficiaire_count']); ?></td>
                                            <td><?php echo htmlspecialchars(formatFCFA($adhesion['total_paye'] ?: 0)); ?></td>
                                            <td>
                                                <div class="d-flex gap-2">
                                                    <a href="view_adhesion.php?id=<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" class="btn btn-info btn-sm"><i class="bi bi-eye me-1"></i>Voir</a>
                                                    <?php if ($adhesion['statut'] === 'en_attente_validation'): ?>
                                                        <a href="validate_adhesion.php?id=<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" class="btn btn-success btn-sm"><i class="bi bi-check me-1"></i>Valider</a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Filters for Charts -->
            <div class="card mb-5">
                <div class="card-header">
                    <i class="bi bi-funnel me-2"></i>Filtres des Graphiques
                </div>
                <div class="card-body">
                    <form method="GET" class="filter-container">
                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($id_agent); ?>">
                        <select class="form-select" name="periode">
                            <option value="7" <?php echo $filters['periode'] === '7' ? 'selected' : ''; ?>>Derniers 7 jours</option>
                            <option value="30" <?php echo $filters['periode'] === '30' ? 'selected' : ''; ?>>Derniers 30 jours</option>
                            <option value="90" <?php echo $filters['periode'] === '90' ? 'selected' : ''; ?>>Derniers 90 jours</option>
                        </select>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-funnel-fill me-2"></i>Filtrer</button>
                    </form>
                </div>
            </div>

            <!-- Charts -->
            <div class="row mb-5">
                <div class="col-md-6 mb-3">
                    <div class="card chart-card">
                        <div class="card-header">
                            <i class="bi bi-bar-chart me-2"></i>Adhésions par Jour
                        </div>
                        <div class="card-body">
                            <canvas id="adhesionsChart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="card chart-card">
                        <div class="card-header">
                            <i class="bi bi-bar-chart me-2"></i>Cotisations par Jour
                        </div>
                        <div class="card-body">
                            <canvas id="cotisationsChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        // Search functionality for adhesions table
        document.getElementById('search_adhesion')?.addEventListener('input', function(e) {
            const search = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.table-adhesions tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });

        // Chart: Adhésions par jour
        const adhesionsCtx = document.getElementById('adhesionsChart')?.getContext('2d');
        if (adhesionsCtx) {
            new Chart(adhesionsCtx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($filtered_labels); ?>,
                    datasets: [{
                        label: 'Nombre d\'Adhésions',
                        data: <?php echo json_encode($adhesions_values); ?>,
                        backgroundColor: 'rgba(4, 120, 87, 0.7)',
                        borderColor: 'rgba(4, 120, 87, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: {
                            title: { 
                                display: true, 
                                text: 'Date', 
                                font: { size: 16, weight: '600' },
                                color: '#111827'
                            },
                            ticks: { 
                                maxRotation: 30, 
                                minRotation: 30, 
                                font: { size: 12 },
                                color: '#111827'
                            },
                            grid: { display: false }
                        },
                        y: {
                            title: { 
                                display: true, 
                                text: 'Nombre d\'Adhésions', 
                                font: { size: 16, weight: '600' },
                                color: '#111827'
                            },
                            beginAtZero: true,
                            ticks: { 
                                stepSize: 1, 
                                font: { size: 12 },
                                color: '#111827'
                            },
                            grid: { 
                                color: 'rgba(0, 0, 0, 0.1)',
                                lineWidth: 1
                            }
                        }
                    },
                    plugins: {
                        legend: { 
                            display: true, 
                            labels: { font: { size: 14 }, color: '#111827' }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            titleFont: { size: 14 },
                            bodyFont: { size: 12 },
                            callbacks: {
                                label: function(context) {
                                    return `${context.dataset.label}: ${context.parsed.y}`;
                                },
                                title: function(tooltipItems) {
                                    return `Date: ${<?php echo json_encode($adhesions_labels); ?>[tooltipItems[0].dataIndex]}`;
                                }
                            }
                        }
                    }
                }
            });
        }

        // Chart: Cotisations par jour
        const cotisationsCtx = document.getElementById('cotisationsChart')?.getContext('2d');
        if (cotisationsCtx) {
            new Chart(cotisationsCtx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($filtered_labels); ?>,
                    datasets: [{
                        label: 'Montant des Cotisations (FCFA)',
                        data: <?php echo json_encode($cotisations_values); ?>,
                        backgroundColor: 'rgba(30, 58, 138, 0.7)',
                        borderColor: 'rgba(30, 58, 138, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: {
                            title: { 
                                display: true, 
                                text: 'Date', 
                                font: { size: 16, weight: '600' },
                                color: '#111827'
                            },
                            ticks: { 
                                maxRotation: 30, 
                                minRotation: 30, 
                                font: { size: 12 },
                                color: '#111827'
                            },
                            grid: { display: false }
                        },
                        y: {
                            title: { 
                                display: true, 
                                text: 'Montant (FCFA)', 
                                font: { size: 16, weight: '600' },
                                color: '#111827'
                            },
                            beginAtZero: true,
                            ticks: { 
                                font: { size: 12 },
                                color: '#111827',
                                callback: function(value) {
                                    return value.toLocaleString();
                                }
                            },
                            grid: { 
                                color: 'rgba(0, 0, 0, 0.1)',
                                lineWidth: 1
                            }
                        }
                    },
                    plugins: {
                        legend: { 
                            display: true, 
                            labels: { font: { size: 14 }, color: '#111827' }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            titleFont: { size: 14 },
                            bodyFont: { size: 12 },
                            callbacks: {
                                label: function(context) {
                                    return `${context.dataset.label}: ${context.parsed.y.toLocaleString()} FCFA`;
                                },
                                title: function(tooltipItems) {
                                    return `Date: ${<?php echo json_encode($cotisations_labels); ?>[tooltipItems[0].dataIndex]}`;
                                }
                            }
                        }
                    }
                }
            });
        }
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>