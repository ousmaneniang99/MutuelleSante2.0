<?php
// pages/view_beneficiaire.php
ob_start();
require_once '../includes/header.php';

// Vérifications de session et rôle
checkSessionTimeout();
checkRole('directeur_departemental');

$errors = [];
$beneficiaire = null;
$adhesion = null;

if (!isset($pdo)) {
    $errors[] = "Erreur : Connexion à la base de données non établie.";
}

// Vérifier si l'ID du bénéficiaire est fourni
if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    $errors[] = "ID de bénéficiaire invalide.";
} else {
    $id_beneficiaire = $_GET['id'];

    try {
        // Récupérer les informations du bénéficiaire avec date de naissance
        $stmt_beneficiaire = $pdo->prepare("
            SELECT b.id_beneficiaire, b.nom, b.prenom, b.date_naissance, b.date_entree, b.statut, a.num_adherent, a.id_adhesion
            FROM beneficiaires b
            JOIN adhesions a ON b.id_adhesion = a.id_adhesion
            JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur
            JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
            WHERE b.id_beneficiaire = ? AND agent.departement = ? AND agent.role = 'agent_mobilisateur'
        ");
        $stmt_beneficiaire->execute([$id_beneficiaire, $_SESSION['departement']]);
        $beneficiaire = $stmt_beneficiaire->fetch(PDO::FETCH_ASSOC);

        if (!$beneficiaire) {
            $errors[] = "Bénéficiaire non trouvé ou accès non autorisé.";
        } else {
            // Récupérer les informations réduites de l'adhésion
            $stmt_adhesion = $pdo->prepare("
                SELECT a.num_adherent, a.type_adhesion, a.statut AS adhesion_statut
                FROM adhesions a
                WHERE a.id_adhesion = ?
            ");
            $stmt_adhesion->execute([$beneficiaire['id_adhesion']]);
            $adhesion = $stmt_adhesion->fetch(PDO::FETCH_ASSOC);
        }
    } catch (PDOException $e) {
        $errors[] = "Erreur lors de la récupération des données : " . htmlspecialchars($e->getMessage());
        error_log("Erreur dans view_beneficiaire.php : " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails du Bénéficiaire - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }
        .container {
            max-width: 800px;
            margin-top: 30px;
            margin-bottom: 30px;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }
        .card-header {
            border-bottom: none;
            padding: 1rem;
            font-size: 1.1rem;
            font-weight: 600;
            background: linear-gradient(90deg, #007bff, #0056b3);
            color: white;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .card-body {
            padding: 1.5rem;
        }
        .alert {
            border-radius: 8px;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .alert i {
            font-size: 1rem;
        }
        .btn-primary, .btn-secondary {
            border-radius: 6px;
            padding: 0.4rem 0.8rem;
            font-weight: 500;
            font-size: 0.9rem;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }
        .page-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        .table {
            border-radius: 6px;
            overflow: hidden;
            background: #ffffff;
            box-shadow: 0 1px 6px rgba(0, 0, 0, 0.05);
        }
        .table th {
            background: linear-gradient(90deg, #007bff, #0056b3);
            color: white;
            font-weight: 600;
            padding: 0.8rem;
            border: none;
            font-size: 0.9rem;
        }
        .table td {
            padding: 0.8rem;
            vertical-align: middle;
            font-size: 0.9rem;
            border: none;
        }
        .table-hover tbody tr:hover {
            background-color: #f1f3f5;
        }
        .table i {
            font-size: 1rem;
            margin-right: 0.4rem;
            color: #007bff;
        }
        @media (max-width: 576px) {
            .container {
                padding: 1rem;
            }
            .page-title {
                font-size: 1.4rem;
            }
            .table th, .table td {
                font-size: 0.8rem;
                padding: 0.6rem;
            }
            .btn-primary, .btn-secondary {
                padding: 0.3rem 0.6rem;
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title"><i class="bi bi-person-circle me-2"></i>Détails du Bénéficiaire</h2>

        <!-- Alerts -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Beneficiary Details -->
        <?php if ($beneficiaire): ?>
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-person-vcard"></i> Informations du Bénéficiaire
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <tbody>
                                <tr>
                                    <th><i class="bi bi-hash"></i> ID</th>
                                    <td><?php echo htmlspecialchars($beneficiaire['id_beneficiaire']); ?></td>
                                </tr>
                                <tr>
                                    <th><i class="bi bi-person"></i> Nom</th>
                                    <td><?php echo htmlspecialchars($beneficiaire['nom']); ?></td>
                                </tr>
                                <tr>
                                    <th><i class="bi bi-person"></i> Prénom</th>
                                    <td><?php echo htmlspecialchars($beneficiaire['prenom']); ?></td>
                                </tr>
                                <tr>
                                    <th><i class="bi bi-cake"></i> Date de Naissance</th>
                                    <td><?php echo htmlspecialchars($beneficiaire['date_naissance'] ?? 'Non renseignée'); ?></td>
                                </tr>
                                <tr>
                                    <th><i class="bi bi-calendar-event"></i> Date d'Entrée</th>
                                    <td><?php echo htmlspecialchars($beneficiaire['date_entree']); ?></td>
                                </tr>
                                <tr>
                                    <th><i class="bi bi-check-circle"></i> Statut</th>
                                    <td><?php echo htmlspecialchars($beneficiaire['statut']); ?></td>
                                </tr>
                                <tr>
                                    <th><i class="bi bi-card-text"></i> Numéro Adhérent</th>
                                    <td><?php echo htmlspecialchars($beneficiaire['num_adherent']); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card mt-3">
                <div class="card-header">
                    <i class="bi bi-card-list"></i> Adhésion Associée
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <tbody>
                                <tr>
                                    <th><i class="bi bi-card-text"></i> Numéro Adhérent</th>
                                    <td><?php echo htmlspecialchars($adhesion['num_adherent']); ?></td>
                                </tr>
                                <tr>
                                    <th><i class="bi bi-list-ul"></i> Type d'Adhésion</th>
                                    <td><?php echo htmlspecialchars($adhesion['type_adhesion']); ?></td>
                                </tr>
                                <tr>
                                    <th><i class="bi bi-check-circle"></i> Statut</th>
                                    <td><?php echo htmlspecialchars($adhesion['adhesion_statut']); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-end gap-2 mt-3">
                <a href="dashboard_directeur.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Retour</a>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-exclamation-triangle-fill"></i> Aucun Bénéficiaire
                </div>
                <div class="card-body text-center">
                    <p class="mb-3">Aucun bénéficiaire sélectionné ou trouvé.</p>
                    <a href="dashboard_directeur.php" class="btn btn-primary"><i class="bi bi-arrow-left me-2"></i>Retour au tableau de bord</a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
<?php
ob_end_flush();
require_once '../includes/footer.php';
?>