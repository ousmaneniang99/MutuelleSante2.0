<?php
// view_paiement.php
require_once '../includes/header.php';
checkSessionTimeout();
checkRole('directeur_departemental');

if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    header("Location: dashboard_directeur.php?error=" . urlencode("ID de paiement invalide."));
    exit();
}

// Retrieve page_paiements from query string, default to 1 if not set
$page_paiements = isset($_GET['page_paiements']) && filter_var($_GET['page_paiements'], FILTER_VALIDATE_INT) ? intval($_GET['page_paiements']) : 1;


$id_paiement = $_GET['id'];

try {
    $stmt = $pdo->prepare("
        SELECT p.id_paiement, a.num_adherent, p.date_paiement, p.montant_verse, p.methode, p.reference_transaction, u.nom AS agent_nom, u.prenom AS agent_prenom
        FROM paiements p 
        JOIN adhesions a ON p.id_adhesion = a.id_adhesion 
        JOIN utilisateurs u ON p.created_by = u.id_utilisateur
        WHERE p.id_paiement = ?
    ");
    $stmt->execute([$id_paiement]);
    $paiement = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$paiement) {
        header("Location: dashboard_directeur.php?error=" . urlencode("Paiement non trouvé."));
        exit();
    }
} catch (PDOException $e) {
    error_log("Erreur lors de la récupération du paiement : " . $e->getMessage());
    header("Location: dashboard_directeur.php?error=" . urlencode("Erreur lors de la récupération des données."));
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails du Paiement - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f8fafc; }
        .container { max-width: 800px; margin: 2rem auto; }
        .card { border-radius: 16px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); }
        .card-header { background: #2563eb; color: white; border-radius: 16px 16px 0 0; padding: 1rem; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-cash"></i> Détails du Paiement #<?php echo htmlspecialchars($paiement['id_paiement']); ?>
            </div>
            <div class="card-body">
                <p><strong>Numéro Adhérent :</strong> <?php echo htmlspecialchars($paiement['num_adherent']); ?></p>
                <p><strong>Date :</strong> <?php echo htmlspecialchars($paiement['date_paiement']); ?></p>
                <p><strong>Montant :</strong> <?php echo htmlspecialchars(formatFCFA($paiement['montant_verse'])); ?></p>
                <p><strong>Méthode :</strong> <?php echo htmlspecialchars($paiement['methode']); ?></p>
                <p><strong>Référence Transaction :</strong> <?php echo htmlspecialchars($paiement['reference_transaction']); ?></p>
                <p><strong>Agent :</strong> <?php echo htmlspecialchars($paiement['agent_nom'] . ' ' . $paiement['agent_prenom']); ?></p>
                <a href="dashboard_directeur.php?page_paiements=<?php echo htmlspecialchars($page_paiements); ?>" class="btn btn-primary mt-3"><i class="bi bi-arrow-left"></i> Retour</a>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>