<?php
// pages/voir.php
ob_start();
require_once '../includes/header.php';
checkSessionTimeout();
checkRole('admin');

$errors = [];
$active_adhesions = [];
$active_total_pages = 0;
$agent = null;

// Vérifier l'agent_id
$agent_id = isset($_GET['agent_id']) && is_numeric($_GET['agent_id']) ? (int)$_GET['agent_id'] : 0;
if ($agent_id <= 0) {
    $errors[] = "ID d'agent invalide.";
    error_log("ID d'agent invalide : " . $_GET['agent_id']);
}

// Paramètres de pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Récupérer les informations de l'agent
try {
    $stmt = $pdo->prepare("
        SELECT u.nom, u.prenom, u.email, d.nom AS departement_nom
        FROM utilisateurs u
        LEFT JOIN departements d ON u.departement = d.id_departement
        WHERE u.id_utilisateur = :agent_id AND u.role = 'agent_mobilisateur'
    ");
    $stmt->bindValue(':agent_id', $agent_id, PDO::PARAM_INT);
    $stmt->execute();
    $agent = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$agent) {
        $errors[] = "Agent non trouvé ou n'est pas un mobilisateur.";
        error_log("Agent non trouvé pour id_utilisateur : " . $agent_id);
    }
} catch (PDOException $e) {
    $errors[] = "Erreur lors de la récupération des informations de l'agent.";
    error_log("Erreur PDO dans voir.php (agent) : " . $e->getMessage());
}

// Récupérer les adhésions actives
if (empty($errors)) {
    try {
        // Vérifier si la colonne old_card_photo existe
        $stmt_check = $pdo->query("SHOW COLUMNS FROM adhesions LIKE 'old_card_photo'");
        $old_card_photo_exists = $stmt_check->rowCount() > 0;

        if (!$old_card_photo_exists) {
            $errors[] = "Erreur : La colonne 'old_card_photo' n'existe pas dans la table adhesions.";
            error_log("Colonne old_card_photo manquante dans la table adhesions, utilisateur ID: {$_SESSION['user_id']}");
        } else {
            // Adhésions actives
            $query_active = "
                SELECT a.id_adhesion, a.num_adherent, u.nom, u.prenom, a.date_adhesion, a.type_adhesion,
                       agent.nom AS agent_nom, agent.prenom AS agent_prenom,
                       d.nom AS departement_nom,
                       (SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion
                       ) AS total_beneficiaires,
                       (SELECT COUNT(*) 
                        FROM beneficiaires b 
                        WHERE b.id_adhesion = a.id_adhesion 
                        AND b.photo_path IS NOT NULL 
                        AND b.photo_path != ''
                       ) AS beneficiaire_count_with_photos,
                       CASE 
                           WHEN a.old_card_photo IS NOT NULL AND a.old_card_photo != '' 
                           THEN 1 
                           ELSE 0 
                       END AS is_renewal,
                       a.old_card_photo
                FROM adhesions a 
                LEFT JOIN utilisateurs u ON a.id_utilisateur = u.id_utilisateur 
                LEFT JOIN utilisateurs agent ON a.created_by = agent.id_utilisateur
                LEFT JOIN departements d ON u.departement = d.id_departement
                WHERE a.statut = 'active'
                AND a.created_by = :agent_id
                ORDER BY a.date_adhesion DESC
                LIMIT :perPage OFFSET :offset
            ";
            $stmt_active = $pdo->prepare($query_active);
            $stmt_active->bindValue(':agent_id', $agent_id, PDO::PARAM_INT);
            $stmt_active->bindValue(':perPage', (int)$perPage, PDO::PARAM_INT);
            $stmt_active->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
            $stmt_active->execute();
            $active_adhesions = $stmt_active->fetchAll(PDO::FETCH_ASSOC);

            // Compter le total des adhésions actives
            $query_active_count = "
                SELECT COUNT(*) 
                FROM adhesions a 
                WHERE a.statut = 'active'
                AND a.created_by = :agent_id
            ";
            $stmt_active_count = $pdo->prepare($query_active_count);
            $stmt_active_count->bindValue(':agent_id', $agent_id, PDO::PARAM_INT);
            $stmt_active_count->execute();
            $active_total_adhesions = $stmt_active_count->fetchColumn() ?: 0;
            $active_total_pages = ceil($active_total_adhesions / $perPage);
        }
    } catch (PDOException $e) {
        $errors[] = "Erreur lors de la récupération des adhésions : " . $e->getMessage();
        error_log("Erreur PDO dans voir.php (adhésions) : " . $e->getMessage() . " - Agent ID: " . $agent_id);
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adhésions Actives de l'Agent - Mutuelle Santé Matam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-medical: linear-gradient(135deg, #1e3a8a, #3b82f6, #1d4ed8);
            --success-health: linear-gradient(135deg, #15803d, #22c55e, #16a34a);
            --warning-gold: linear-gradient(135deg, #d97706, #f59e0b, #b45309);
            --danger-alert: linear-gradient(135deg, #dc2626, #ef4444, #b91c1c);
            --glass-bg: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
            --shadow-glow: 0 25px 50px -12px rgba(59, 130, 246, 0.3);
            --shadow-hover: 0 35px 60px -15px rgba(59, 130, 246, 0.3);
            --text: #1e293b;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 50%, #f0f9ff 100%);
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 20% 50%, rgba(120, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 40% 80%, rgba(120, 219, 255, 0.1) 0%, transparent 50%);
            z-index: -1;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }

        .header-hero {
            background: var(--primary-medical);
            border-radius: 24px;
            padding: 2rem;
            color: white;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-glow);
            backdrop-filter: blur(20px);
            text-align: center;
        }

        .header-hero::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: conic-gradient(from 0deg, transparent, rgba(255,255,255,0.1), transparent 30%);
            animation: rotate 20s linear infinite;
            opacity: 0.3;
        }

        @keyframes rotate { 100% { transform: rotate(360deg); } }

        .header-title {
            font-size: 2.2rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            background: linear-gradient(45deg, #fff, #e0f2fe);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-subtitle {
            font-size: 1.1rem;
            opacity: 0.95;
            font-weight: 400;
            max-width: 700px;
            margin: 0 auto;
        }

        .card {
            background: rgba(255,255,255,0.9);
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: var(--shadow-glow);
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px);
            transition: all 0.4s ease;
            margin-bottom: 2rem;
        }

        .card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-hover);
            background: rgba(255,255,255,0.95);
        }

        .card-header {
            background: var(--primary-medical);
            color: white;
            font-weight: 600;
            border-radius: 10px 10px 0 0;
            padding: 0.75rem;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }

        .search-container {
            position: relative;
            max-width: 100%;
            margin-bottom: 1.5rem;
        }

        .search-input {
            border-radius: 10px;
            padding: 0.6rem 1rem 0.6rem 2.5rem;
            border: 1px solid var(--glass-border);
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            width: 100%;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            color: var(--text);
        }

        .search-input:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 6px rgba(59, 130, 246, 0.2);
            outline: none;
        }

        .search-icon {
            position: absolute;
            left: 0.8rem;
            top: 50%;
            transform: translateY(-50%);
            color: #6b7280;
            font-size: 1rem;
        }

        .table {
            background: var(--card-bg);
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
        }

        .table thead {
            background: rgba(229, 231, 235, 0.9);
            color: var(--text);
            font-weight: 600;
            font-size: 0.85rem;
        }

        .table tbody tr {
            transition: background 0.2s ease;
        }

        .table tbody tr:hover {
            background: rgba(243, 244, 246, 0.9);
        }

        .table td, .table th {
            padding: 0.75rem;
            font-size: 0.9rem;
            white-space: nowrap;
        }

        .badge {
            font-size: 0.8rem;
            padding: 0.4rem 0.8rem;
            border-radius: 12px;
        }

        .pagination .page-link {
            border-radius: 6px;
            margin: 0 3px;
            color: #3b82f6;
            border: 1px solid #d1d5db;
            font-size: 0.85rem;
            padding: 0.4rem 0.7rem;
            transition: all 0.3s ease;
        }

        .pagination .page-item.active .page-link {
            background: var(--primary-medical);
            border-color: #3b82f6;
            color: white;
        }

        .pagination .page-link:hover {
            background: #e5e7eb;
            color: #1e3a8a;
        }

        .alert {
            border-radius: 8px;
            padding: 0.6rem 1rem;
            margin-bottom: 0.75rem;
            font-size: 0.9rem;
            animation: slideIn 0.5s ease-in-out;
            display: flex;
            align-items: center;
            gap: 0.4rem;
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border: 1px solid var(--glass-border);
        }

        .modal-content {
            border-radius: 10px;
            box-shadow: var(--shadow-glow);
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(10px);
        }

        .modal-header {
            background: var(--primary-medical);
            color: white;
            border-radius: 10px 10px 0 0;
            padding: 0.75rem;
        }

        .modal-body {
            padding: 1.5rem;
        }

        .modal-footer {
            border-top: 1px solid #e5e7eb;
            padding: 0.75rem;
        }

        .carousel-inner img {
            max-width: 120px;
            height: auto;
            border-radius: 8px;
            margin: 0 auto;
            object-fit: cover;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .carousel-caption {
            background: rgba(0, 0, 0, 0.5);
            border-radius: 8px;
            padding: 0.5rem;
        }

        .fade-in-up {
            animation: fadeInUp 0.8s ease forwards;
            opacity: 0;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-15px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @media (max-width: 992px) {
            .container { padding: 1.5rem 0.75rem; }
            .header-title { font-size: 1.8rem; }
            .table td, .table th { font-size: 0.8rem; padding: 0.5rem; }
        }

        @media (max-width: 768px) {
            .table thead { display: none; }
            .table tbody tr {
                display: block;
                margin-bottom: 0.75rem;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                padding: 0.5rem;
                background: var(--card-bg);
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            }

            .table tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: 0.8rem;
                padding: 0.4rem 0.5rem;
                border: none;
            }

            .table tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                font-size: 0.8rem;
                color: #6b7280;
                width: 40%;
            }

            .table tbody td[data-label="Détails"] {
                display: flex;
                flex-wrap: wrap;
                gap: 0.4rem;
                justify-content: center;
            }

            .carousel-inner img { max-width: 100px; }
            .modal-dialog { margin: 0.5rem; max-width: 95%; }
        }

        @media (max-width: 576px) {
            .btn-primary { font-size: 0.75rem; padding: 0.3rem 0.6rem; }
            .alert { font-size: 0.8rem; padding: 0.5rem 0.75rem; }
            .carousel-inner img { max-width: 80px; }
            .modal-header { font-size: 0.9rem; }
            .modal-body p { font-size: 0.8rem; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header Hero -->
        <div class="header-hero fade-in-up">
            <h1 class="header-title animate__animated animate__fadeInDown">
                🛡️ Adhésions Actives de l'Agent
            </h1>
            <p class="header-subtitle animate__animated animate__fadeInUp">
                <?php if ($agent): ?>
                    Adhésions actives créées par <?php echo htmlspecialchars($agent['nom'] . ' ' . $agent['prenom']); ?> (<?php echo htmlspecialchars($agent['email']); ?>) - Département : <?php echo htmlspecialchars($agent['departement_nom'] ?? 'N/A'); ?>
                <?php else: ?>
                    Adhésions actives de l'agent
                <?php endif; ?>
            </p>
        </div>

        <!-- Alerts -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill"></i> <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Adhésions Actives -->
        <div class="card fade-in-up" style="animation-delay: 0.2s;">
            <div class="card-header">
                <i class="bi bi-check-circle-fill"></i> Adhésions Actives
            </div>
            <div class="card-body">
                <div class="search-container">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" id="search_active_adhesion" class="form-control search-input" placeholder="Rechercher une adhésion active..." aria-label="Rechercher une adhésion active par numéro, nom, prénom ou type">
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-adhesions" id="active-adhesions-table">
                        <thead>
                            <tr>
                                <th scope="col">Numéro</th>
                                <th scope="col">Nom</th>
                                <th scope="col">Prénom</th>
                                <th scope="col">Date</th>
                                <th scope="col">Type</th>
                                <th scope="col">Département</th>
                                <th scope="col">Bénéficiaires</th>
                                <th scope="col">Statut</th>
                                <th scope="col">Détails</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($active_adhesions)): ?>
                                <tr><td colspan="9" class="text-center">Aucune adhésion active.</td></tr>
                            <?php else: ?>
                                <?php foreach ($active_adhesions as $adhesion): ?>
                                    <tr>
                                        <td data-label="Numéro"><?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?></td>
                                        <td data-label="Nom"><?php echo htmlspecialchars($adhesion['nom'] ?? 'N/A'); ?></td>
                                        <td data-label="Prénom"><?php echo htmlspecialchars($adhesion['prenom'] ?? 'N/A'); ?></td>
                                        <td data-label="Date"><?php echo htmlspecialchars($adhesion['date_adhesion'] ?? 'N/A'); ?></td>
                                        <td data-label="Type"><?php echo htmlspecialchars($adhesion['type_adhesion'] ?? 'N/A'); ?></td>
                                        <td data-label="Département"><?php echo htmlspecialchars($adhesion['departement_nom'] ?? 'N/A'); ?></td>
                                        <td data-label="Bénéficiaires"><?php echo htmlspecialchars($adhesion['total_beneficiaires'] ?? 0); ?></td>
                                        <td data-label="Statut">
                                            <span class="badge bg-<?php echo $adhesion['is_renewal'] == 1 ? 'success' : 'primary'; ?>">
                                                <?php echo $adhesion['is_renewal'] == 1 ? 'Renouvellement' : 'Actif'; ?>
                                            </span>
                                        </td>
                                        <td data-label="Détails">
                                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#adhesionModal<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" aria-label="Voir les détails de l'adhésion <?php echo htmlspecialchars($adhesion['num_adherent']); ?>">
                                                <i class="bi bi-eye"></i> Détails
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination pour Adhésions Actives -->
                <?php if ($active_total_pages > 1): ?>
                    <nav aria-label="Pagination des adhésions actives" class="mt-3">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&agent_id=<?php echo htmlspecialchars($agent_id); ?>" aria-label="Page précédente"><i class="bi bi-chevron-left"></i></a>
                            </li>
                            <?php for ($i = max(1, $page - 2); $i <= min($active_total_pages, $page + 2); $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&agent_id=<?php echo htmlspecialchars($agent_id); ?>" aria-label="Page <?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo $page >= $active_total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&agent_id=<?php echo htmlspecialchars($agent_id); ?>" aria-label="Page suivante"><i class="bi bi-chevron-right"></i></a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>

        <!-- Modals pour Détails des Adhésions -->
        <?php if (!empty($active_adhesions)): ?>
            <?php foreach ($active_adhesions as $adhesion): ?>
                <div class="modal fade" id="adhesionModal<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" tabindex="-1" aria-labelledby="adhesionModalLabel<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="adhesionModalLabel<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>">
                                    Détails de l'Adhésion <?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?>
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p><strong>Numéro Adhérent :</strong> <?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?></p>
                                        <p><strong>Nom :</strong> <?php echo htmlspecialchars($adhesion['nom'] ?? 'N/A'); ?></p>
                                        <p><strong>Prénom :</strong> <?php echo htmlspecialchars($adhesion['prenom'] ?? 'N/A'); ?></p>
                                        <p><strong>Statut :</strong> 
                                            <span class="badge bg-<?php echo $adhesion['is_renewal'] == 1 ? 'success' : 'primary'; ?>">
                                                <?php echo $adhesion['is_renewal'] == 1 ? 'Renouvellement' : 'Actif'; ?>
                                            </span>
                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong>Date d'Adhésion :</strong> <?php echo htmlspecialchars($adhesion['date_adhesion'] ?? 'N/A'); ?></p>
                                        <p><strong>Type :</strong> <?php echo htmlspecialchars($adhesion['type_adhesion'] ?? 'N/A'); ?></p>
                                        <p><strong>Département :</strong> <?php echo htmlspecialchars($adhesion['departement_nom'] ?? 'N/A'); ?></p>
                                        <p><strong>Bénéficiaires :</strong> <?php echo htmlspecialchars($adhesion['total_beneficiaires'] ?? 0); ?></p>
                                    </div>
                                </div>

                                <!-- Affichage de la Photo de Carte Précédente pour Renouvellements -->
                                <?php if ($adhesion['is_renewal'] == 1 && !empty($adhesion['old_card_photo']) && file_exists($adhesion['old_card_photo'])): ?>
                                    <h6 class="mt-3">Photo de Carte Précédente</h6>
                                    <img src="<?php echo htmlspecialchars($adhesion['old_card_photo']); ?>" alt="Photo de carte précédente pour adhésion <?php echo htmlspecialchars($adhesion['num_adherent'] ?? 'N/A'); ?>" class="img-fluid mb-3" style="max-width: 200px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
                                <?php else: ?>
                                    <p class="text-muted mt-3">Aucune photo de carte précédente disponible.</p>
                                <?php endif; ?>

                                <!-- Carrousel des Photos des Bénéficiaires -->
                                <h6 class="mt-3">Bénéficiaires</h6>
                                <?php
                                $stmt_benef = $pdo->prepare("
                                    SELECT nom, prenom, relation, photo_path
                                    FROM beneficiaires 
                                    WHERE id_adhesion = ? 
                                    AND photo_path IS NOT NULL 
                                    AND photo_path != ''
                                ");
                                $stmt_benef->execute([$adhesion['id_adhesion']]);
                                $beneficiaires = $stmt_benef->fetchAll(PDO::FETCH_ASSOC);
                                ?>
                                <?php if (!empty($beneficiaires)): ?>
                                    <div id="carouselBenef<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" class="carousel slide" data-bs-ride="carousel">
                                        <div class="carousel-inner">
                                            <?php foreach ($beneficiaires as $index => $benef): ?>
                                                <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                                                    <img src="<?php echo htmlspecialchars($benef['photo_path']); ?>" alt="Photo de <?php echo htmlspecialchars(($benef['nom'] ?? 'N/A') . ' ' . ($benef['prenom'] ?? 'N/A')); ?>" class="d-block">
                                                    <div class="carousel-caption d-none d-md-block">
                                                        <h6><?php echo htmlspecialchars(($benef['nom'] ?? 'N/A') . ' ' . ($benef['prenom'] ?? 'N/A')); ?></h6>
                                                        <p><?php echo htmlspecialchars($benef['relation'] ?? 'N/A'); ?></p>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselBenef<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" data-bs-slide="prev">
                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden">Précédent</span>
                                        </button>
                                        <button class="carousel-control-next" type="button" data-bs-target="#carouselBenef<?php echo htmlspecialchars($adhesion['id_adhesion']); ?>" data-bs-slide="next">
                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden">Suivant</span>
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">Aucune photo de bénéficiaire disponible.</p>
                                <?php endif; ?>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" aria-label="Fermer">Fermer</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.js"></script>
    <script>
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }

        const searchActiveInput = document.getElementById('search_active_adhesion');
        if (searchActiveInput) {
            const searchActiveFunc = debounce(function(e) {
                const search = e.target.value.toLowerCase();
                const rows = document.querySelectorAll('#active-adhesions-table tbody tr');
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(search) ? '' : 'none';
                });
            }, 300);
            searchActiveInput.addEventListener('input', searchActiveFunc);
        }
    </script>
</body>
</html>
<?php
require_once __DIR__ . '/../includes/footer.php';
ob_end_flush();
?>