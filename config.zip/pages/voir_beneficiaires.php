<?php
ob_start();
require_once '../includes/header.php';
checkRole('admin'); // Restrict to admin role

$errors = [];
$success = null;
$csrf_token = generateCsrfToken();

// Initialize filter variables
$statut_filter = isset($_GET['statut']) ? sanitize($_GET['statut']) : '';
$search_query = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$num_adherent_filter = isset($_GET['num_adherent']) ? sanitize($_GET['num_adherent']) : '';

// Build the query for beneficiaries
$query = "
    SELECT b.id_beneficiaire, b.code_beneficiaire, b.nom, b.prenom, b.date_naissance, b.relation, b.statut,
           a.num_adherent, a.type_adhesion, a.date_adhesion, a.date_expiration
    FROM beneficiaires b
    JOIN adhesions a ON b.id_adhesion = a.id_adhesion
    WHERE 1=1
";
$params = [];

if ($statut_filter) {
    $query .= " AND b.statut = ?";
    $params[] = $statut_filter;
}
if ($search_query) {
    $query .= " AND (b.nom LIKE ? OR b.prenom LIKE ? OR b.code_beneficiaire LIKE ?)";
    $search_like = $search_query . '%'; // Match start of string
    $params[] = $search_like;
    $params[] = $search_like;
    $params[] = $search_like;
}
if ($num_adherent_filter) {
    $query .= " AND a.num_adherent LIKE ?";
    $params[] = $num_adherent_filter . '%'; // Match start of string
}
$query .= " ORDER BY b.nom, b.prenom";

$stmt_beneficiaires = $pdo->prepare($query);
$stmt_beneficiaires->execute($params);
$beneficiaires = $stmt_beneficiaires->fetchAll(PDO::FETCH_ASSOC);

// Handle CSV export
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['export_csv'], $_POST['csrf_token'])) {
    if (!verifyCsrfToken($_POST['csrf_token'])) {
        $errors[] = "Erreur de validation CSRF. Veuillez réessayer.";
    } else {
        // Generate CSV
        $filename = "beneficiaires_" . date('Ymd_His') . ".csv";
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        $output = fopen('php://output', 'w');
        fputcsv($output, [
            'Code Bénéficiaire', 'Nom', 'Prénom', 'Date de Naissance', 'Relation',
            'Numéro Adhérent', 'Type d\'Adhésion', 'Statut',
            'Date d\'Adhésion', 'Date d\'Expiration'
        ], ';');

        foreach ($beneficiaires as $beneficiaire) {
            fputcsv($output, [
                $beneficiaire['code_beneficiaire'],
                $beneficiaire['nom'],
                $beneficiaire['prenom'],
                $beneficiaire['date_naissance'],
                $beneficiaire['relation'],
                $beneficiaire['num_adherent'],
                $beneficiaire['type_adhesion'],
                $beneficiaire['statut'],
                $beneficiaire['date_adhesion'],
                $beneficiaire['date_expiration']
            ], ';');
        }

        fclose($output);
        logActivity($pdo, $_SESSION['user_id'], 'export_beneficiaries', "Export CSV des bénéficiaires effectué");
        ob_end_flush();
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Bénéficiaires - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Inter', sans-serif;
        }
        .container {
            max-width: 1200px;
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            border-bottom: none;
            padding: 1.5rem;
            font-size: 1.25rem;
            font-weight: 600;
            background-color: #007bff;
            color: white;
        }
        .card-body {
            padding: 2rem;
        }
        .alert {
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert i {
            font-size: 1.2rem;
        }
        .form-control, .form-select {
            border-radius: 8px;
            padding: 0.75rem;
            border: 1px solid #ced4da;
            transition: border-color 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
        }
        .btn-primary, .btn-secondary {
            border-radius: 8px;
            padding: 0.5rem 1rem;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover { background-color: #0056b3; }
        .btn-secondary:hover { background-color: #5a6268; }
        .table {
            border-radius: 8px;
            overflow: hidden;
        }
        .table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }
        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="page-title text-center"><i class="bi bi-people me-2"></i>Gestion des Bénéficiaires</h2>

        <!-- Messages -->
        <?php if ($errors): ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i>
                <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Filter Form -->
        <div class="card mb-4">
            <div class="card-header">
                <i class="bi bi-filter me-2"></i>Filtres
            </div>
            <div class="card-body">
                <form method="GET" action="">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="num_adherent" class="form-label">Numéro Adhérent</label>
                            <input type="text" class="form-control" id="num_adherent" name="num_adherent" value="<?php echo htmlspecialchars($num_adherent_filter); ?>" placeholder="Ex: ADH123">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="statut" class="form-label">Statut</label>
                            <select class="form-select" id="statut" name="statut">
                                <option value="">Tous les statuts</option>
                                <option value="actif" <?php echo $statut_filter === 'actif' ? 'selected' : ''; ?>>Actif</option>
                                <option value="en_attente_approbation" <?php echo $statut_filter === 'en_attente_approbation' ? 'selected' : ''; ?>>En attente</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="search" class="form-label">Recherche (Nom, Prénom, Code)</label>
                            <input type="text" class="form-control" id="search" name="search" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Rechercher...">
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <button type="submit" class="btn btn-primary"><i class="bi bi-search me-2"></i>Filtrer</button>
                        <form method="POST" action="" class="d-inline">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            <button type="submit" name="export_csv" class="btn btn-secondary"><i class="bi bi-download me-2"></i>Exporter en CSV</button>
                        </form>
                    </div>
                </form>
            </div>
        </div>

        <!-- Beneficiaries Table -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-table me-2"></i>Liste des Bénéficiaires
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="beneficiairesTable" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Code Bénéficiaire</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Date de Naissance</th>
                                <th>Relation</th>
                                <th>Numéro Adhérent</th>
                                <th>Type d'Adhésion</th>
                                <th>Statut</th>
                                <th>Date d'Adhésion</th>
                                <th>Date d'Expiration</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($beneficiaires as $beneficiaire): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($beneficiaire['code_beneficiaire']); ?></td>
                                    <td><?php echo htmlspecialchars($beneficiaire['nom']); ?></td>
                                    <td><?php echo htmlspecialchars($beneficiaire['prenom']); ?></td>
                                    <td><?php echo htmlspecialchars($beneficiaire['date_naissance']); ?></td>
                                    <td><?php echo htmlspecialchars($beneficiaire['relation']); ?></td>
                                    <td><?php echo htmlspecialchars($beneficiaire['num_adherent']); ?></td>
                                    <td><?php echo htmlspecialchars($beneficiaire['type_adhesion']); ?></td>
                                    <td><?php echo htmlspecialchars($beneficiaire['statut'] === 'actif' ? 'Actif' : 'En attente'); ?></td>
                                    <td><?php echo htmlspecialchars($beneficiaire['date_adhesion']); ?></td>
                                    <td><?php echo htmlspecialchars($beneficiaire['date_expiration']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#beneficiairesTable').DataTable({
                "language": {
                    "url": "https://cdn.datatables.net/plug-ins/1.13.6/i18n/fr-FR.json"
                },
                "pageLength": 10,
                "order": [[1, 'asc']], // Sort by Nom
                "responsive": true
            });
        });
    </script>
</body>
</html>

<?php
ob_end_flush();
require_once '../includes/footer.php';
?>